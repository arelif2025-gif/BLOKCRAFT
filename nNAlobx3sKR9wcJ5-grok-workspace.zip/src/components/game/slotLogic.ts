import { addItem } from "@/game/inventory";
import { isTool } from "@/game/items";
import type { GameEngine } from "@/game/engine";
import type { ItemStack } from "@/game/types";

export type SlotRef = { bag: string; i: number };

const MAX = 64;

export function copyStack(s: ItemStack): ItemStack {
  return s.dur != null ? { id: s.id, count: s.count, dur: s.dur } : { id: s.id, count: s.count };
}

export function clickStack(
  cursor: ItemStack | null,
  origin: SlotRef | null,
  slot: ItemStack | null,
  here: SlotRef,
  read: (r: SlotRef) => ItemStack | null,
  write: (r: SlotRef, v: ItemStack | null) => void,
): { cursor: ItemStack | null; origin: SlotRef | null } {
  if (!cursor) {
    if (!slot) return { cursor: null, origin: null };
    write(here, null);
    return { cursor: copyStack(slot), origin: here };
  }
  if (!slot) {
    write(here, copyStack(cursor));
    return { cursor: null, origin: null };
  }
  if (slot.id === cursor.id && !isTool(slot.id) && slot.count < MAX) {
    const take = Math.min(MAX - slot.count, cursor.count);
    slot.count += take;
    write(here, slot);
    const left = cursor.count - take;
    return { cursor: left > 0 ? { ...cursor, count: left } : null, origin: left > 0 ? origin : null };
  }
  write(here, copyStack(cursor));
  if (origin && !sameRef(origin, here)) {
    const home = read(origin);
    if (!home) {
      write(origin, copyStack(slot));
      return { cursor: null, origin: null };
    }
  }
  return { cursor: copyStack(slot), origin: here };
}

export function gatherMatches(
  cursor: ItemStack,
  slots: SlotRef[],
  read: (r: SlotRef) => ItemStack | null,
  write: (r: SlotRef, v: ItemStack | null) => void,
): ItemStack {
  if (isTool(cursor.id) || cursor.count >= MAX) return cursor;
  const next = copyStack(cursor);
  for (const ref of slots) {
    if (next.count >= MAX) break;
    const slot = read(ref);
    if (!slot || slot.id !== next.id || isTool(slot.id)) continue;
    const take = Math.min(MAX - next.count, slot.count);
    next.count += take;
    slot.count -= take;
    write(ref, slot.count > 0 ? slot : null);
  }
  return next;
}

export function stashCursor(engine: GameEngine, held: ItemStack, origin: SlotRef | null, read: (r: SlotRef) => ItemStack | null, write: (r: SlotRef, v: ItemStack | null) => void) {
  if (origin) {
    const home = read(origin);
    if (!home) {
      write(origin, copyStack(held));
      return;
    }
    if (home.id === held.id && !isTool(held.id) && home.count < MAX) {
      const take = Math.min(MAX - home.count, held.count);
      home.count += take;
      write(origin, home);
      held = { ...held, count: held.count - take };
      if (held.count <= 0) return;
    }
  }
  addItem(engine.hotbar, engine.inventory, held.id, held.count);
}

function sameRef(a: SlotRef, b: SlotRef) {
  return a.bag === b.bag && a.i === b.i;
}
