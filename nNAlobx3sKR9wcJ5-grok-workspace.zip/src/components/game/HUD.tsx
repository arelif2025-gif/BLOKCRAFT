import { useEffect, useRef, useState } from "react";
import { Hammer } from "lucide-react";
import { blockName } from "@/game/blocks";
import { maxDurability } from "@/game/items";
import { useGameStore } from "@/game/store";

type Props = {
  icons: Record<number, string>;
  onCraft: () => void;
  onWake: () => void;
};

export function HUD({ icons, onCraft, onWake }: Props) {
  const hud = useGameStore((s) => s.hud);
  const phase = useGameStore((s) => s.phase);
  const isMobile = useGameStore((s) => s.isMobile);
  const low = hud.health > 0 && hud.health <= 4;
  const prevHp = useRef(hud.health);
  const [hurt, setHurt] = useState(0);
  useEffect(() => {
    if (hud.health < prevHp.current) setHurt((n) => n + 1);
    prevHp.current = hud.health;
  }, [hud.health]);
  if (phase === "title" || phase === "loading" || phase === "credits") return null;

  const hearts = [];
  for (let i = 0; i < 10; i++) {
    const hp = hud.health - i * 2;
    hearts.push(hp >= 2 ? "full" : hp === 1 ? "half" : "empty");
  }
  const bubbles = [];
  const air = hud.air ?? 10;
  if (air < 9.96) {
    for (let i = 0; i < 10; i++) {
      const left = air - i;
      bubbles.push(left >= 1 ? "full" : left >= 0.45 ? "pop" : "empty");
    }
  }
  const foods = [];
  for (let i = 0; i < 10; i++) {
    const fp = (hud.food ?? 20) - i * 2;
    foods.push(fp >= 2 ? "full" : fp === 1 ? "half" : "empty");
  }

  return (
    <div className="hud-root" aria-hidden={phase !== "playing"}>
      <div className="hud-top">
        <div className="hud-chip">
          <span className="hud-muted">xyz</span>
          <span className="hud-num">
            {hud.x.toFixed(1)} {hud.y.toFixed(1)} {hud.z.toFixed(1)}
          </span>
        </div>
        <div className="hud-chip">
          <span className="day-dot" data-day={hud.isDay ? "1" : "0"} />
          <span>{hud.isDay ? "Gündüz" : "Gece"}</span>
        </div>
        <div className="hud-chip">
          <span>{hud.biome}</span>
        </div>
        {hud.inWater ? <div className="hud-chip">Yüzme</div> : null}
        {hud.sneaking && !hud.inWater ? <div className="hud-chip">{hud.blocking ? "Kalkan" : "Eğilme"}</div> : null}
        {!isMobile ? <div className="hud-chip">{hud.fps} fps</div> : null}
      </div>

      {phase === "playing" ? (
        <button type="button" className="craft-fab" onClick={onCraft} aria-label="Yapım masası">
          <Hammer size={18} />
          <span>Yapım</span>
          {!isMobile ? <kbd>.</kbd> : null}
        </button>
      ) : null}

      {phase === "playing" ? <div className="crosshair" /> : null}

      {hud.targetName ? <div className="target-label">{hud.targetName}</div> : null}

      {hud.toast ? <div className="game-toast">{hud.toast}</div> : null}

      {hud.sleeping ? (
        <div className="sleep-screen" style={{ ["--p" as string]: String(hud.sleep) }}>
          <div className="sleep-veil" />
          <div className="sleep-card">
            <p>Uyuyorsun</p>
            <div className="sleep-bar">
              <i style={{ width: `${Math.round(hud.sleep * 100)}%` }} />
            </div>
            <button type="button" onClick={onWake}>
              Yataktan kalk
            </button>
          </div>
        </div>
      ) : null}

      {low ? <div className="hurt-cloud" /> : null}
      {hurt > 0 ? <div key={hurt} className={`hurt-flash ${low ? "is-deep" : ""}`} /> : null}

      <div className="hud-bottom">
        <div className="bars-row">
          <div className="vitals">
            {bubbles.length > 0 ? (
              <div className="bubbles" aria-label="Nefes">
                {bubbles.map((k, i) => (
                  <Bubble key={i} kind={k} />
                ))}
              </div>
            ) : null}
            <div className="hearts" aria-label={`${hud.health} can`}>
            {hearts.map((k, i) => (
              <Heart key={i} kind={k} />
            ))}
            {hurt > 0 ? <i key={hurt} className="heart-glint" /> : null}
            </div>
          </div>
          <div className="foods" aria-label={`${hud.food} açlık`}>
            {foods.map((k, i) => (
              <Drum key={i} kind={k} />
            ))}
          </div>
        </div>
        <div className="hotbar-row">
          <Slot icon={hud.offhand ? icons[hud.offhand.id] : undefined} count={hud.offhand?.count ?? 0} offhand />
          <div className="hotbar">
            {hud.hotbar.map((s, i) => (
              <Slot
                key={i}
                icon={s ? icons[s.id] : undefined}
                count={s?.count ?? 0}
                selected={i === hud.selectedSlot}
                label={s ? blockName(s.id) : ""}
                dur={s?.dur}
                durMax={s ? durMaxOf(s.id, s.dur) : 0}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function durMaxOf(id: number, dur?: number) {
  return maxDurability(id) || (dur ?? 0);
}

function Slot({
  icon,
  count,
  selected,
  offhand,
  label,
  dur,
  durMax,
}: {
  icon?: string;
  count: number;
  selected?: boolean;
  offhand?: boolean;
  label?: string;
  dur?: number;
  durMax?: number;
}) {
  const showDur = dur != null && durMax && durMax > 0 && dur < durMax;
  const pct = showDur ? Math.max(0, Math.min(1, dur / durMax)) : 0;
  return (
    <div className={`slot ${selected ? "is-selected" : ""} ${offhand ? "is-offhand" : ""}`} title={label}>
      {icon ? <img src={icon} alt="" draggable={false} /> : null}
      {count > 1 ? <span className="slot-count">{count}</span> : null}
      {showDur ? (
        <i className="slot-dur" style={{ width: `${Math.round(pct * 100)}%`, background: pct > 0.3 ? "#5ec45a" : "#c4453c" }} />
      ) : null}
    </div>
  );
}

function Bubble({ kind }: { kind: string }) {
  const full = kind === "full";
  const pop = kind === "pop";
  return (
    <svg viewBox="0 0 16 16" className={`bubble bubble-${kind}`} aria-hidden="true">
      <circle cx="8" cy="8" r="5.2" fill={full ? "#7fd4f0" : pop ? "#9adff2" : "none"} stroke="#143046" strokeWidth="1.3" />
      {full || pop ? <circle cx="6.1" cy="6.2" r="1.3" fill="#f4fbff" /> : null}
      {pop ? <path d="M3 8 H6 M10 8 H13 M8 3 V6 M8 10 V13" stroke="#d8f4ff" strokeWidth="1.2" /> : null}
      {kind === "empty" ? <circle cx="8" cy="8" r="5.2" fill="#102028" stroke="#1c3344" strokeWidth="1.3" /> : null}
    </svg>
  );
}

function Heart({ kind }: { kind: string }) {
  return (
    <svg viewBox="0 0 16 16" className={`heart heart-${kind}`} aria-hidden="true">
      <path
        d="M8 14 L2.2 8.4 A3.6 3.6 0 0 1 8 3.8 A3.6 3.6 0 0 1 13.8 8.4 Z"
        fill={kind === "empty" ? "none" : "#c4453c"}
        stroke="#2a120f"
        strokeWidth="1.3"
      />
      {kind === "half" ? (
        <path d="M8 14 L2.2 8.4 A3.6 3.6 0 0 1 8 3.8 Z" fill="#c4453c" />
      ) : null}
      {kind === "empty" ? (
        <path
          d="M8 14 L2.2 8.4 A3.6 3.6 0 0 1 8 3.8 A3.6 3.6 0 0 1 13.8 8.4 Z"
          fill="#1a1c16"
          stroke="#2a120f"
          strokeWidth="1.3"
        />
      ) : null}
    </svg>
  );
}

function Drum({ kind }: { kind: string }) {
  return (
    <svg viewBox="0 0 16 16" className={`drum drum-${kind}`} aria-hidden="true">
      <path
        d="M5 3.2 C5 2.2 6.2 1.4 7.6 1.6 C9.2 1.8 10 3 10 4.2 L9.6 8.2 C11.4 8.6 13.2 10.2 13.2 12.1 C13.2 14.2 11.2 15.4 8.8 15.4 C6.2 15.4 4.4 14 4.4 12.1 C4.4 10.6 5.4 9.4 7 8.6 L6.2 4.4 C6 3.6 5.6 3.4 5 3.2 Z"
        fill={kind === "empty" ? "#1a1c16" : "#c47a32"}
        stroke="#2a1a0f"
        strokeWidth="1.1"
      />
      {kind === "full" || kind === "half" ? (
        <path d="M8.2 8.6 C10.4 9 12 10.4 12 12 C12 13.6 10.4 14.6 8.8 14.6 C7.4 14.6 6 13.8 6 12.4 C6 10.8 7 9.4 8.2 8.6 Z" fill="#e8c070" />
      ) : null}
      {kind === "half" ? <rect x="8.8" y="1" width="7" height="14" fill="#0e100c" opacity="0.72" /> : null}
    </svg>
  );
}
