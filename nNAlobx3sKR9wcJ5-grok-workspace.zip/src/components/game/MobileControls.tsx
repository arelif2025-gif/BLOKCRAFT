import { useRef } from "react";
import { useGameStore } from "@/game/store";
import type { GameEngine } from "@/game/engine";
import { Backpack, Hammer, Pause, Pickaxe, Square } from "lucide-react";

type Props = {
  engine: GameEngine | null;
  onPause: () => void;
  onInventory: () => void;
  onCraft: () => void;
};

export function MobileControls({ engine, onPause, onInventory, onCraft }: Props) {
  const phase = useGameStore((s) => s.phase);
  const joy = useRef<{ id: number; x: number; y: number } | null>(null);
  const look = useRef<{ id: number; x: number; y: number } | null>(null);
  const stick = useRef<HTMLDivElement>(null);
  const nub = useRef<HTMLDivElement>(null);

  if (phase !== "playing") return null;

  const setMove = (x: number, y: number) => {
    if (!engine) return;
    engine.input.touchMoveX = x;
    engine.input.touchMoveY = y;
  };

  return (
    <div className="touch-layer">
      <div
        className="joy-pad"
        ref={stick}
        onPointerDown={(e) => {
          (e.currentTarget as HTMLDivElement).setPointerCapture(e.pointerId);
          joy.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
        }}
        onPointerMove={(e) => {
          if (!joy.current || joy.current.id !== e.pointerId) return;
          const dx = e.clientX - joy.current.x;
          const dy = e.clientY - joy.current.y;
          const r = 48;
          const m = Math.hypot(dx, dy);
          const nx = m > r ? (dx / m) * r : dx;
          const ny = m > r ? (dy / m) * r : dy;
          if (nub.current) nub.current.style.transform = `translate(${nx}px, ${ny}px)`;
          setMove(nx / r, -ny / r);
        }}
        onPointerUp={(e) => {
          if (joy.current?.id !== e.pointerId) return;
          joy.current = null;
          if (nub.current) nub.current.style.transform = "translate(0,0)";
          setMove(0, 0);
        }}
      >
        <div className="joy-base">
          <div className="joy-nub" ref={nub} />
        </div>
      </div>

      <div
        className="look-pad"
        onPointerDown={(e) => {
          (e.currentTarget as HTMLDivElement).setPointerCapture(e.pointerId);
          look.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
        }}
        onPointerMove={(e) => {
          if (!look.current || look.current.id !== e.pointerId) return;
          const dx = e.clientX - look.current.x;
          const dy = e.clientY - look.current.y;
          look.current.x = e.clientX;
          look.current.y = e.clientY;
          engine?.input.addLook(dx * 1.6, dy * 1.6);
        }}
        onPointerUp={(e) => {
          if (look.current?.id === e.pointerId) look.current = null;
        }}
      />

      <div className="touch-actions">
        <button type="button" className="touch-btn" onClick={onPause} aria-label="Duraklat">
          <Pause size={18} />
        </button>
        <button type="button" className="touch-btn" onClick={onInventory} aria-label="Envanter">
          <Backpack size={18} />
        </button>
        <button type="button" className="touch-btn" onClick={onCraft} aria-label="Yapım">
          <Hammer size={18} />
        </button>
        <button
          type="button"
          className="touch-btn"
          onPointerDown={() => engine?.input.keys.add("Space")}
          onPointerUp={() => engine?.input.keys.delete("Space")}
          aria-label="Zıpla"
        >
          Z
        </button>
        <button
          type="button"
          className="touch-btn"
          onPointerDown={() => engine?.input.keys.add("ShiftLeft")}
          onPointerUp={() => engine?.input.keys.delete("ShiftLeft")}
          aria-label="Eğil"
        >
          Eğil
        </button>
        <button
          type="button"
          className="touch-btn touch-break"
          onPointerDown={() => engine?.input.keys.add("Mouse0")}
          onPointerUp={() => engine?.input.keys.delete("Mouse0")}
          aria-label="Kır"
        >
          <Pickaxe size={18} />
        </button>
        <button
          type="button"
          className="touch-btn touch-place"
          onPointerDown={() => engine?.input.keys.add("Mouse2")}
          onPointerUp={() => engine?.input.keys.delete("Mouse2")}
          aria-label="Koy"
        >
          <Square size={18} />
        </button>
      </div>
    </div>
  );
}
