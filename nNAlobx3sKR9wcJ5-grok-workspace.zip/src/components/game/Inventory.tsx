import { useEffect, useRef, useState } from "react";
import { blockName } from "@/game/blocks";
import { isTool } from "@/game/tools";
import { useGameStore } from "@/game/store";
import { StevePreview } from "./StevePreview";
import { clickStack, gatherMatches, stashCursor, type SlotRef } from "./slotLogic";
import type { GameEngine } from "@/game/engine";
import type { ItemStack } from "@/game/types";

type Bag = "hotbar" | "inv" | "armor" | "offhand";
type Props = {
  engine: GameEngine | null;
  icons: Record<number, string>;
};

const ARMOR_LABELS = ["Kask", "Göğüs", "Pantolon", "Bot"];

export function Inventory({ engine, icons }: Props) {
  const hud = useGameStore((s) => s.hud);
  const [cursor, setCursor] = useState<ItemStack | null>(null);
  const [origin, setOrigin] = useState<SlotRef | null>(null);
  const [mouse, setMouse] = useState({ x: 0, y: 0 });
  const cursorRef = useRef(cursor);
  const originRef = useRef(origin);
  cursorRef.current = cursor;
  originRef.current = origin;

  useEffect(() => {
    return () => {
      const held = cursorRef.current;
      if (!held || !engine) return;
      stashCursor(
        engine,
        held,
        originRef.current,
        (r) => getSlot(engine, r.bag as Bag, r.i),
        (r, v) => setSlot(engine, r.bag as Bag, r.i, v),
      );
      engine.refreshHud();
    };
  }, [engine]);

  const onSlot = (bag: Bag, i: number, detail = 1) => {
    if (!engine) return;
    const read = (r: SlotRef) => getSlot(engine, r.bag as Bag, r.i);
    const write = (r: SlotRef, v: ItemStack | null) => setSlot(engine, r.bag as Bag, r.i, v);
    if (detail >= 2 && cursor && !isTool(cursor.id)) {
      const slots: SlotRef[] = [
        ...engine.hotbar.map((_, n) => ({ bag: "hotbar", i: n })),
        ...engine.inventory.map((_, n) => ({ bag: "inv", i: n })),
      ];
      setCursor(gatherMatches({ ...cursor }, slots, read, write));
      engine.refreshHud();
      return;
    }
    const next = clickStack(cursor, origin, getSlot(engine, bag, i), { bag, i }, read, write);
    setCursor(next.cursor);
    setOrigin(next.origin);
    engine.refreshHud();
  };

  return (
    <div
      className="overlay-root inventory-overlay"
      onMouseMove={(e) => setMouse({ x: e.clientX, y: e.clientY })}
    >
      <div className="inv-panel" role="dialog" aria-label="Envanter">
        <header className="inv-head">
          <h2>Envanter</h2>
          <p>Fareyi hareket ettir — karakter bakar. E veya Esc kapatır.</p>
        </header>
        <div className="inv-body">
          <div className="inv-equip">
            <div className="armor-col">
              {hud.armor.map((s, i) => (
                <InvSlot
                  key={i}
                  icon={s ? icons[s.id] : undefined}
                  count={s?.count ?? 0}
                  label={ARMOR_LABELS[i]}
                  onClick={(e) => onSlot("armor", i, e.detail)}
                />
              ))}
              <InvSlot
                icon={hud.offhand ? icons[hud.offhand.id] : undefined}
                count={hud.offhand?.count ?? 0}
                label="Sol el"
                onClick={(e) => onSlot("offhand", 0, e.detail)}
              />
            </div>
            <StevePreview mouseX={mouse.x} mouseY={mouse.y} />
          </div>
          <div className="inv-grid">
            {hud.inventory.map((s, i) => (
              <InvSlot
                key={i}
                icon={s ? icons[s.id] : undefined}
                count={s?.count ?? 0}
                label={s ? blockName(s.id) : ""}
                onClick={(e) => onSlot("inv", i, e.detail)}
              />
            ))}
          </div>
        </div>
        <div className="inv-hotbar">
          {hud.hotbar.map((s, i) => (
            <InvSlot
              key={i}
              icon={s ? icons[s.id] : undefined}
              count={s?.count ?? 0}
              selected={i === hud.selectedSlot}
              label={s ? blockName(s.id) : ""}
              onClick={(e) => onSlot("hotbar", i, e.detail)}
            />
          ))}
        </div>
      </div>
      {cursor ? (
        <div className="cursor-item" style={{ left: mouse.x + 12, top: mouse.y + 12 }}>
          {icons[cursor.id] ? <img src={icons[cursor.id]} alt="" /> : null}
          {cursor.count > 1 ? <span>{cursor.count}</span> : null}
        </div>
      ) : null}
    </div>
  );
}

function InvSlot({
  icon,
  count,
  selected,
  label,
  onClick,
}: {
  icon?: string;
  count: number;
  selected?: boolean;
  label?: string;
  onClick: (e: { detail: number }) => void;
}) {
  return (
    <button type="button" className={`slot inv-slot ${selected ? "is-selected" : ""}`} title={label} onClick={onClick}>
      {icon ? <img src={icon} alt="" draggable={false} /> : null}
      {count > 1 ? <span className="slot-count">{count}</span> : null}
    </button>
  );
}

function getSlot(engine: GameEngine, bag: Bag, i: number): ItemStack | null {
  if (bag === "hotbar") return engine.hotbar[i] ?? null;
  if (bag === "inv") return engine.inventory[i] ?? null;
  if (bag === "armor") return engine.armor[i] ?? null;
  return engine.offhand;
}

function setSlot(engine: GameEngine, bag: Bag, i: number, v: ItemStack | null) {
  if (bag === "hotbar") engine.hotbar[i] = v;
  else if (bag === "inv") engine.inventory[i] = v;
  else if (bag === "armor") engine.armor[i] = v;
  else engine.offhand = v;
}
