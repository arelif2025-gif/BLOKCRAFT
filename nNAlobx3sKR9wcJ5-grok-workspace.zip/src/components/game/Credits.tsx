type Props = {
  lines: string[];
  shots: string[];
  onBack: () => void;
};

export function Credits({ lines, shots, onBack }: Props) {
  return (
    <div className="credits-root">
      <div className="credits-track">
        <p className="credits-kicker">Blokcraft</p>
        {lines.map((line, i) => (
          <div key={i} className="credits-block">
            <p>{line}</p>
            {shots[i] ? <img src={shots[i]} alt="" /> : null}
          </div>
        ))}
        <button type="button" className="credits-back" onClick={onBack}>
          Oyuna geri dön
        </button>
      </div>
    </div>
  );
}
