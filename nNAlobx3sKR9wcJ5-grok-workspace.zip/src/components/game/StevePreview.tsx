import { useEffect, useRef } from "react";
import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";

type Props = {
  mouseX: number;
  mouseY: number;
};

export function StevePreview({ mouseX, mouseY }: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const mouse = useRef({ x: 0, y: 0 });
  mouse.current = { x: mouseX, y: mouseY };

  useEffect(() => {
    const wrap = wrapRef.current;
    if (!wrap) return;
    const canvas = document.createElement("canvas");
    canvas.className = "steve-canvas";
    wrap.appendChild(canvas);

    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: false });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 20);
    camera.position.set(0, 1.15, 4.4);
    camera.lookAt(0, 1.0, 0);
    scene.add(new THREE.AmbientLight(0xffffff, 0.85));
    const key = new THREE.DirectionalLight(0xfff4d8, 1.1);
    key.position.set(2.2, 4, 3);
    scene.add(key);
    const fill = new THREE.DirectionalLight(0xb8d0ff, 0.35);
    fill.position.set(-3, 1, -2);
    scene.add(fill);

    const root = new THREE.Group();
    scene.add(root);

    let head: THREE.Object3D | null = null;
    let raf = 0;
    let dead = false;
    const loader = new GLTFLoader();
    loader.load(
      "/models/steve.gltf",
      (gltf) => {
        if (dead) return;
        const model = gltf.scene;
        model.traverse((o) => {
          const m = o as THREE.Mesh;
          if (m.isMesh) {
            m.frustumCulled = false;
            const mat = m.material as THREE.MeshStandardMaterial;
            if (mat.map) {
              mat.map.magFilter = THREE.NearestFilter;
              mat.map.minFilter = THREE.NearestFilter;
              mat.map.flipY = false;
            }
          }
        });
        const box = new THREE.Box3().setFromObject(model);
        const size = new THREE.Vector3();
        box.getSize(size);
        const center = new THREE.Vector3();
        box.getCenter(center);
        model.position.sub(center);
        model.position.y += size.y * 0.5;
        root.add(model);
        head = model.getObjectByName("Head") ?? null;
      },
      undefined,
      () => {
        /* model missing — keep empty stage */
      },
    );

    const loop = () => {
      raf = requestAnimationFrame(loop);
      const w = wrap.clientWidth;
      const h = wrap.clientHeight;
      if (w > 0 && h > 0) {
        renderer.setSize(w, h, false);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
      }
      const rect = wrap.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height * 0.4;
      const dx = mouse.current.x - cx;
      const dy = mouse.current.y - cy;
      const yaw = Math.atan2(dx, 160) * 0.9;
      const pitch = THREE.MathUtils.clamp(-dy / 280, -0.55, 0.45);
      root.rotation.y = THREE.MathUtils.lerp(root.rotation.y, yaw, 0.18);
      if (head) {
        head.rotation.x = THREE.MathUtils.lerp(head.rotation.x, pitch, 0.2);
      } else {
        root.rotation.x = THREE.MathUtils.lerp(root.rotation.x, pitch * 0.25, 0.15);
      }
      renderer.render(scene, camera);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      dead = true;
      cancelAnimationFrame(raf);
      renderer.dispose();
      canvas.remove();
    };
  }, []);

  return <div ref={wrapRef} className="steve-wrap" />;
}
