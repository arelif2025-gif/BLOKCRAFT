import { useGameStore } from "@/game/store";
import type { GameEngine } from "@/game/engine";

type Props = {
  engine: GameEngine | null;
  onResume: () => void;
  onQuit: () => void;
};

export function PauseMenu({ engine, onResume, onQuit }: Props) {
  const settings = useGameStore((s) => s.settings);
  const setSettings = useGameStore((s) => s.setSettings);

  return (
    <div className="overlay-root pause-overlay">
      <div className="pause-panel" role="dialog" aria-label="Duraklatıldı">
        <p className="title-kicker">Menü</p>
        <h2>Duraklatıldı</h2>
        <div className="pause-actions">
          <button type="button" className="btn-primary" onClick={onResume}>
            Devam et
          </button>
          <button
            type="button"
            className="btn-ghost"
            onClick={() => {
              engine?.save();
            }}
          >
            Kaydet
          </button>
          <button type="button" className="btn-ghost" onClick={onQuit}>
            Ana menü
          </button>
        </div>
        <div className="settings">
          <label>
            <span>Fare hassasiyeti</span>
            <input
              type="range"
              min={0.4}
              max={3}
              step={0.1}
              value={settings.sensitivity}
              onChange={(e) => setSettings({ sensitivity: Number(e.target.value) })}
            />
            <em>{settings.sensitivity.toFixed(1)}</em>
          </label>
          <label>
            <span>Görüş mesafesi</span>
            <input
              type="range"
              min={2}
              max={6}
              step={1}
              value={settings.renderDistance}
              onChange={(e) => {
                const renderDistance = Number(e.target.value);
                setSettings({ renderDistance });
                engine?.setRenderDistance(renderDistance);
              }}
            />
            <em>{settings.renderDistance}</em>
          </label>
          <label>
            <span>Ses</span>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={settings.volume}
              onChange={(e) => {
                const volume = Number(e.target.value);
                setSettings({ volume });
                engine?.audio.setVolume(volume);
              }}
            />
            <em>{Math.round(settings.volume * 100)}</em>
          </label>
        </div>
        <p className="pause-hint">Shift eğil / kalkan · " koş · Tab yere at · . yapım masası · E envanter</p>
      </div>
    </div>
  );
}
