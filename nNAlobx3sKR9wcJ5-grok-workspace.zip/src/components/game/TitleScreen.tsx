import { useMemo, useState } from "react";
import { ArrowLeft, Dices, Trash2 } from "lucide-react";
import { useGameStore } from "@/game/store";
import {
  PANTS,
  SHIRTS,
  SKINS,
  createWorld,
  deleteWorld,
  listWorlds,
  loadLook,
  parseSeed,
  saveLook,
  type Look,
  type WorldCard,
} from "@/game/save";

type Props = {
  onPlay: (id: string) => void;
};

type View = "home" | "worlds" | "create" | "look" | "keys" | "options";

const SPLASHES = [
  "Sevgiyle yapıldı!",
  "Creeper'a dikkat!",
  "Boş elle başla!",
  "Yine mi elmas?",
  "Blok blok!",
  "Gece dışarı çıkma!",
  "Teknede daha hızlı!",
];

function hex(n: number) {
  return `#${n.toString(16).padStart(6, "0")}`;
}

function ago(t: number) {
  const m = Math.floor(Math.max(0, Date.now() - t) / 60000);
  if (m < 1) return "az önce";
  if (m < 60) return `${m} dk önce`;
  const h = Math.floor(m / 60);
  if (h < 48) return `${h} sa önce`;
  return `${Math.floor(h / 24)} gün önce`;
}

export function TitleScreen({ onPlay }: Props) {
  const [view, setView] = useState<View>("home");
  const [worlds, setWorlds] = useState<WorldCard[]>(() => listWorlds());
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [look, setLook] = useState<Look>(() => loadLook());
  const [name, setName] = useState("Yeni dünya");
  const [seedText, setSeedText] = useState("");
  const [start, setStart] = useState<"dawn" | "day" | "night">("day");
  const [bonus, setBonus] = useState(false);
  const [monsters, setMonsters] = useState(true);
  const settings = useGameStore((s) => s.settings);
  const setSettings = useGameStore((s) => s.setSettings);
  const seedPreview = useMemo(() => (seedText.trim() ? parseSeed(seedText) : null), [seedText]);
  const splash = useMemo(() => SPLASHES[Math.floor(Math.random() * SPLASHES.length)]!, []);

  const refresh = () => setWorlds(listWorlds());
  const patchLook = (next: Look) => {
    setLook(next);
    saveLook(next);
  };

  return (
    <div className={`overlay-root title-screen${view === "home" ? " is-home" : ""}`}>
      {view === "home" ? (
        <div className="mc-home">
          <div className="mc-logo-wrap">
            <h1 className="mc-logo">BLOKCRAFT</h1>
            <div className="mc-edition">HAYATTA KALMA</div>
            <div className="mc-splash">{splash}</div>
          </div>
          <button type="button" className="mc-btn" onClick={() => { refresh(); setView("worlds"); }}>
            Tek oyunculu
          </button>
          <button type="button" className="mc-btn" onClick={() => setView("look")}>
            Karakter
          </button>
          <button type="button" className="mc-btn" onClick={() => setView("keys")}>
            Nasıl oynanır
          </button>
          <div className="mc-row">
            <button type="button" className="mc-btn mc-btn-half" onClick={() => setView("options")}>
              Seçenekler...
            </button>
          </div>
          <div className="mc-foot">
            <span>Blokcraft</span>
            <span>Blok kır, yerleştir, yaşa</span>
          </div>
        </div>
      ) : (
        <div className="title-panel menu-wide mc-panel">
          <button type="button" className="menu-back" onClick={() => setView(view === "create" ? "worlds" : "home")}>
            <ArrowLeft size={16} /> Geri
          </button>

          {view === "worlds" ? (
            <>
              <p className="title-kicker">Tek oyunculu</p>
              <h2>Dünyalar</h2>
              <div className="world-list">
                {worlds.length === 0 ? <p className="title-lead">Henüz dünya yok.</p> : null}
                {worlds.map((w) => (
                  <div key={w.id} className="world-row">
                    <button type="button" className="world-main" onClick={() => onPlay(w.id)}>
                      <strong>{w.name}</strong>
                      <span>Tohum {w.seed} · Gün {Math.floor(w.worldTime / 420)} · {ago(w.updated)}</span>
                    </button>
                    {confirmId === w.id ? (
                      <button
                        type="button"
                        className="world-del"
                        onClick={() => {
                          deleteWorld(w.id);
                          setConfirmId(null);
                          refresh();
                        }}
                      >
                        Sil
                      </button>
                    ) : (
                      <button type="button" className="icon-btn" aria-label="Dünyayı sil" onClick={() => setConfirmId(w.id)}>
                        <Trash2 size={16} />
                      </button>
                    )}
                  </div>
                ))}
              </div>
              <button type="button" className="mc-btn" onClick={() => setView("create")}>
                Yeni dünya
              </button>
            </>
          ) : null}

          {view === "create" ? (
            <>
              <p className="title-kicker">Yeni dünya</p>
              <h2>Özellikler</h2>
              <label className="field">
                Ad
                <input value={name} maxLength={32} onChange={(e) => setName(e.target.value)} />
              </label>
              <label className="field">
                Tohum
                <span className="seed-row">
                  <input
                    value={seedText}
                    placeholder="Boş bırak, rastgele olsun"
                    onChange={(e) => setSeedText(e.target.value)}
                  />
                  <button type="button" className="icon-btn" aria-label="Rastgele tohum" onClick={() => setSeedText(String(Math.floor(Math.random() * 1e9) + 1))}>
                    <Dices size={16} />
                  </button>
                </span>
                {seedPreview != null ? <small>Sayı: {seedPreview}</small> : null}
              </label>
              <p className="field-label">Başlangıç</p>
              <div className="seg">
                {(["dawn", "day", "night"] as const).map((id) => (
                  <button key={id} type="button" className={start === id ? "on" : ""} onClick={() => setStart(id)}>
                    {id === "dawn" ? "Şafak" : id === "day" ? "Gündüz" : "Gece"}
                  </button>
                ))}
              </div>
              <label className="check">
                <input type="checkbox" checked={bonus} onChange={(e) => setBonus(e.target.checked)} />
                Bonus sandık: tahta kazma, tahta ve pişmiş et
              </label>
              <label className="check">
                <input type="checkbox" checked={monsters} onChange={(e) => setMonsters(e.target.checked)} />
                Canavarlar çıksın
              </label>
              <button
                type="button"
                className="mc-btn"
                onClick={() => {
                  const id = createWorld({
                    name,
                    seed: parseSeed(seedText),
                    start,
                    bonus,
                    monsters,
                  });
                  onPlay(id);
                }}
              >
                Dünyayı oluştur
              </button>
            </>
          ) : null}

          {view === "look" ? (
            <>
              <p className="title-kicker">Karakter</p>
              <h2>Görünüş</h2>
              <div className="look-layout">
                <div className="look-stage" aria-hidden>
                  <i className="look-head" style={{ background: hex(SKINS[look.skin] ?? SKINS[0]) }} />
                  <i className="look-body" style={{ background: hex(SHIRTS[look.shirt] ?? SHIRTS[0]) }} />
                  <span>
                    <i style={{ background: hex(SKINS[look.skin] ?? SKINS[0]) }} />
                    <i style={{ background: hex(SKINS[look.skin] ?? SKINS[0]) }} />
                  </span>
                  <b>
                    <i style={{ background: hex(PANTS[look.pants] ?? PANTS[0]) }} />
                    <i style={{ background: hex(PANTS[look.pants] ?? PANTS[0]) }} />
                  </b>
                </div>
                <div>
                  <p className="field-label">Ten</p>
                  <div className="swatches">
                    {SKINS.map((c, i) => (
                      <button key={c} type="button" className={look.skin === i ? "on" : ""} style={{ background: hex(c) }} aria-label={`Ten ${i + 1}`} onClick={() => patchLook({ ...look, skin: i })} />
                    ))}
                  </div>
                  <p className="field-label">Gömlek</p>
                  <div className="swatches">
                    {SHIRTS.map((c, i) => (
                      <button key={c} type="button" className={look.shirt === i ? "on" : ""} style={{ background: hex(c) }} aria-label={`Gömlek ${i + 1}`} onClick={() => patchLook({ ...look, shirt: i })} />
                    ))}
                  </div>
                  <p className="field-label">Pantolon</p>
                  <div className="swatches">
                    {PANTS.map((c, i) => (
                      <button key={c} type="button" className={look.pants === i ? "on" : ""} style={{ background: hex(c) }} aria-label={`Pantolon ${i + 1}`} onClick={() => patchLook({ ...look, pants: i })} />
                    ))}
                  </div>
                </div>
              </div>
              <p className="title-lead">Bu görünüş bütün dünyalarda, üçüncü şahısta kullanılır.</p>
            </>
          ) : null}

          {view === "keys" ? (
            <>
              <p className="title-kicker">Kontroller</p>
              <h2>Nasıl oynanır</h2>
              <ul className="title-keys">
                <li><kbd>W A S D</kbd> hareket</li>
                <li><kbd>Space</kbd> zıpla / yüz</li>
                <li><kbd>Shift</kbd> eğil / kalkan</li>
                <li><kbd>"</kbd> koş</li>
                <li><kbd>Sol tık</kbd> kır / vur</li>
                <li><kbd>Sağ tık</kbd> koy</li>
                <li><kbd>.</kbd> yapım masası</li>
                <li><kbd>Tab</kbd> yere at</li>
                <li><kbd>E</kbd> envanter</li>
                <li><kbd>C</kbd> üçüncü şahıs</li>
                <li><kbd>Esc</kbd> duraklat</li>
              </ul>
            </>
          ) : null}

          {view === "options" ? (
            <>
              <p className="title-kicker">Ayarlar</p>
              <h2>Seçenekler</h2>
              <label className="field">
                Fare hassasiyeti
                <input type="range" min={0.4} max={3} step={0.1} value={settings.sensitivity} onChange={(e) => setSettings({ sensitivity: Number(e.target.value) })} />
              </label>
              <label className="field">
                Görüş mesafesi
                <input type="range" min={2} max={8} step={1} value={settings.renderDistance} onChange={(e) => setSettings({ renderDistance: Number(e.target.value) })} />
              </label>
              <label className="field">
                Ses
                <input type="range" min={0} max={1} step={0.05} value={settings.volume} onChange={(e) => setSettings({ volume: Number(e.target.value) })} />
              </label>
            </>
          ) : null}
        </div>
      )}
    </div>
  );
}
