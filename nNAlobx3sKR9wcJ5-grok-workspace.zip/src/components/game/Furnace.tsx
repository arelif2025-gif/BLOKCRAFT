import { useEffect, useRef, useState } from "react";
import { Flame } from "lucide-react";
import { blockName } from "@/game/blocks";
import { COOK_TIME, fuelSeconds, smeltResult } from "@/game/furnace";
import { isTool } from "@/game/items";
import { useGameStore } from "@/game/store";
import { clickStack, copyStack, gatherMatches, stashCursor, type SlotRef } from "./slotLogic";
import type { GameEngine } from "@/game/engine";
import type { ItemStack } from "@/game/types";

type Props = {
  engine: GameEngine | null;
  icons: Record<number, string>;
};

export function Furnace({ engine, icons }: Props) {
  const hud = useGameStore((s) => s.hud);
  const [cursor, setCursor] = useState<ItemStack | null>(null);
  const [origin, setOrigin] = useState<SlotRef | null>(null);
  const [mouse, setMouse] = useState({ x: 0, y: 0 });
  const [, bump] = useState(0);
  const cursorRef = useRef(cursor);
  const originRef = useRef(origin);
  cursorRef.current = cursor;
  originRef.current = origin;
  const refresh = () => {
    engine?.refreshHud();
    bump((n) => n + 1);
  };
  const f = engine?.activeFurnace() ?? null;

  const read = (r: SlotRef): ItemStack | null => {
    if (!engine) return null;
    if (r.bag === "hotbar") return engine.hotbar[r.i] ?? null;
    if (r.bag === "inv") return engine.inventory[r.i] ?? null;
    const furn = engine.activeFurnace();
    if (!furn) return null;
    if (r.bag === "input") return furn.input;
    if (r.bag === "fuel") return furn.fuel;
    return furn.out;
  };
  const write = (r: SlotRef, v: ItemStack | null) => {
    if (!engine) return;
    if (r.bag === "hotbar") engine.hotbar[r.i] = v;
    else if (r.bag === "inv") engine.inventory[r.i] = v;
    else if (r.bag === "input" || r.bag === "fuel" || r.bag === "out") engine.setFurnaceSlot(r.bag, v);
  };

  useEffect(() => {
    return () => {
      const held = cursorRef.current;
      if (!held || !engine) return;
      stashCursor(engine, held, originRef.current, read, write);
      engine.refreshHud();
    };
  }, [engine]);

  const clickSlot = (which: "input" | "fuel" | "out" | "hotbar" | "inv", i = 0, detail = 1) => {
    if (!engine) return;
    const here = { bag: which, i };
    if (detail >= 2 && cursor && !isTool(cursor.id)) {
      const slots: SlotRef[] = [
        ...engine.hotbar.map((_, n) => ({ bag: "hotbar", i: n })),
        ...engine.inventory.map((_, n) => ({ bag: "inv", i: n })),
        { bag: "input", i: 0 },
        { bag: "fuel", i: 0 },
        { bag: "out", i: 0 },
      ];
      setCursor(gatherMatches({ ...cursor }, slots, read, write));
      refresh();
      return;
    }
    if (which === "out") {
      const slot = read(here);
      if (!slot || cursor) return;
      write(here, null);
      setCursor(copyStack(slot));
      setOrigin(here);
      refresh();
      return;
    }
    const next = clickStack(cursor, origin, read(here), here, read, write);
    setCursor(next.cursor);
    setOrigin(next.origin);
    refresh();
  };

  const cookPct = f ? Math.min(1, f.cook / COOK_TIME) : 0;
  const burnPct = f && f.burnMax > 0 ? Math.min(1, f.burn / f.burnMax) : 0;
  const burning = (f?.burn ?? 0) > 0;
  const inputBad = !!f?.input && smeltResult(f.input.id) === 0;
  const fuelBad = !!f?.fuel && fuelSeconds(f.fuel.id) === 0 && !burning;
  const status = inputBad
    ? "Bu eşya pişmez. Ham demir, ham altın veya çiğ et koy."
    : fuelBad
      ? "Bu yakıt yanmaz. Kömür, odun, tahta veya çubuk koy."
      : burning
        ? "Ateş yanıyor. Ok dolunca bir adet pişer."
        : "Yakıt bitince alev söner. Pişirme okla ilerler.";

  return (
    <div className="overlay-root inventory-overlay" onMouseMove={(e) => setMouse({ x: e.clientX, y: e.clientY })}>
      <div className="inv-panel craft-panel" role="dialog" aria-label="Fırın">
        <header className="inv-head">
          <h2>
            <Flame size={18} /> Fırın
          </h2>
          <p>Üst yuva pişer, alt yuva yakar. Esc kapatır, pişirme sürer.</p>
        </header>
        <div className="furnace-machine">
          <div className="furnace-io">
            <span>Pişecek</span>
            <button type="button" className="slot furnace-slot" onClick={(e) => clickSlot("input", 0, e.detail)} title="Pişecek">
              {f?.input ? <img src={icons[f.input.id]} alt={blockName(f.input.id)} /> : null}
              {(f?.input?.count ?? 0) > 1 ? <span className="slot-count">{f!.input!.count}</span> : null}
            </button>
            <div className="furnace-fire-col">
              <div className="flame-gauge" aria-label={burning ? "Yakıt yanıyor" : "Ateş yok"}>
                <i className="flame-ghost-shape" />
                <i className="flame-lit-shape" style={{ height: `${Math.round(burnPct * 100)}%` }} />
              </div>
            </div>
            <button type="button" className="slot furnace-slot" onClick={(e) => clickSlot("fuel", 0, e.detail)} title="Yakıt">
              {f?.fuel ? <img src={icons[f.fuel.id]} alt={blockName(f.fuel.id)} /> : null}
              {(f?.fuel?.count ?? 0) > 1 ? <span className="slot-count">{f!.fuel!.count}</span> : null}
            </button>
            <span>Yakıt</span>
          </div>
          <div className="smelt-arrow" aria-hidden>
            <div className="smelt-arrow-track">
              <i className="smelt-shaft" />
              <i className="smelt-head" />
            </div>
            <div className="smelt-arrow-fill" style={{ width: `${Math.round(cookPct * 100)}%` }}>
              <i className="smelt-shaft" />
              <i className="smelt-head" />
            </div>
          </div>
          <div className="furnace-out">
            <span>Çıktı</span>
            <button type="button" className="slot furnace-slot" onClick={(e) => clickSlot("out", 0, e.detail)} title="Çıktı">
              {f?.out ? <img src={icons[f.out.id]} alt={blockName(f.out.id)} /> : null}
              {(f?.out?.count ?? 0) > 1 ? <span className="slot-count">{f!.out!.count}</span> : null}
            </button>
          </div>
        </div>
        <p className="furnace-status">{status}</p>
        <div className="inv-grid">
          {hud.inventory.map((s, i) => (
            <button key={i} type="button" className="slot" onClick={(e) => clickSlot("inv", i, e.detail)}>
              {s ? <img src={icons[s.id]} alt="" /> : null}
              {(s?.count ?? 0) > 1 ? <span className="slot-count">{s!.count}</span> : null}
            </button>
          ))}
        </div>
        <div className="inv-hotbar">
          {hud.hotbar.map((s, i) => (
            <button key={i} type="button" className="slot" onClick={(e) => clickSlot("hotbar", i, e.detail)}>
              {s ? <img src={icons[s.id]} alt="" /> : null}
              {(s?.count ?? 0) > 1 ? <span className="slot-count">{s!.count}</span> : null}
            </button>
          ))}
        </div>
      </div>
      {cursor ? (
        <img className="inv-cursor" src={icons[cursor.id]} alt="" style={{ left: mouse.x + 8, top: mouse.y + 8 }} />
      ) : null}
    </div>
  );
}