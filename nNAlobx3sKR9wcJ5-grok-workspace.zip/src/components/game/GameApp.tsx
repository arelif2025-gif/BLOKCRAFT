import { useCallback, useEffect, useRef, useState } from "react";
import { GameEngine } from "@/game/engine";
import { useGameStore } from "@/game/store";
import { Credits } from "./Credits";
import { Crafting } from "./Crafting";
import { Furnace } from "./Furnace";
import { HUD } from "./HUD";
import { Inventory } from "./Inventory";
import { MobileControls } from "./MobileControls";
import { PauseMenu } from "./PauseMenu";
import { MenuPanorama } from "./MenuPanorama";
import { TitleScreen } from "./TitleScreen";

export function GameApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const [icons, setIcons] = useState<Record<number, string>>({});
  const [engineTick, setEngineTick] = useState(0);
  const phase = useGameStore((s) => s.phase);
  const loading = useGameStore((s) => s.loading);
  const clickToPlay = useGameStore((s) => s.clickToPlay);
  const isMobile = useGameStore((s) => s.isMobile);
  const loadError = useGameStore((s) => s.loadError);
  const setPhase = useGameStore((s) => s.setPhase);
  const setMobile = useGameStore((s) => s.setMobile);
  const setClickToPlay = useGameStore((s) => s.setClickToPlay);

  useEffect(() => {
    const mq = window.matchMedia("(pointer: coarse), (max-width: 700px)");
    const sync = () => setMobile(mq.matches);
    sync();
    mq.addEventListener("change", sync);
    return () => mq.removeEventListener("change", sync);
  }, [setMobile]);

  const boot = useCallback(async (id: string) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    engineRef.current?.dispose();
    engineRef.current = null;
    useGameStore.getState().resetHud();
    useGameStore.getState().setLoadError(null);
    setPhase("loading");
    setClickToPlay(false);
    const engine = new GameEngine(canvas);
    engineRef.current = engine;
    window.__blokEngine = engine;
    try {
      await engine.init({ id });
      engine.audio.setVolume(useGameStore.getState().settings.volume);
      setIcons(engine.iconsMap());
      engine.start();
      setEngineTick((n) => n + 1);
      setPhase("playing");
      setClickToPlay(true);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Dünya yüklenemedi";
      useGameStore.getState().setLoadError(msg);
      setPhase("title");
    }
  }, [setPhase, setClickToPlay]);

  useEffect(() => {
    return () => {
      engineRef.current?.dispose();
      engineRef.current = null;
    };
  }, []);

  const closeOverlay = useCallback(() => {
    if (useGameStore.getState().phase === "crafting") engineRef.current?.dumpCraftBack();
    setPhase("playing");
    if (useGameStore.getState().isMobile) setClickToPlay(false);
    else engineRef.current?.requestLock();
  }, [setPhase, setClickToPlay]);

  const openCraft = useCallback(() => {
    document.exitPointerLock?.();
    setPhase("crafting");
  }, [setPhase]);

  useEffect(() => {
    const craftKey = (code: string) => code === "Period" || code === "NumpadDecimal" || code === "Slash";
    let relockOnUp = false;
    const onKey = (e: KeyboardEvent) => {
      const st = useGameStore.getState();
      if (st.phase === "title" || st.phase === "loading" || st.phase === "credits") return;
      if (craftKey(e.code)) {
        if (e.repeat) return;
        e.preventDefault();
        if (st.phase === "crafting") {
          relockOnUp = true;
          closeOverlay();
        } else if (st.phase === "playing" || st.phase === "inventory" || st.phase === "furnace") {
          document.exitPointerLock?.();
          setClickToPlay(false);
          setPhase("crafting");
        }
        return;
      }
      if (e.code === "Escape") {
        e.preventDefault();
        if (useGameStore.getState().hud.sleeping) {
          engineRef.current?.wake();
          relockOnUp = true;
          engineRef.current?.requestLock();
          return;
        }
        if (st.phase === "inventory" || st.phase === "crafting" || st.phase === "furnace") {
          relockOnUp = true;
          closeOverlay();
          return;
        }
        if (st.phase === "paused") {
          setPhase("playing");
          relockOnUp = true;
          engineRef.current?.requestLock();
          return;
        }
        document.exitPointerLock?.();
        setPhase("paused");
        engineRef.current?.save();
        return;
      }
      if (e.code === "KeyE") {
        e.preventDefault();
        if (st.phase === "inventory" || st.phase === "crafting" || st.phase === "furnace") {
          relockOnUp = true;
          closeOverlay();
        } else if (st.phase === "playing") {
          document.exitPointerLock?.();
          setClickToPlay(false);
          setPhase("inventory");
        }
      }
    };
    const onUp = (e: KeyboardEvent) => {
      if (!relockOnUp) return;
      if (e.code !== "Escape" && e.code !== "KeyE" && !craftKey(e.code)) return;
      relockOnUp = false;
      const st = useGameStore.getState();
      if (st.phase === "playing" && !st.isMobile) engineRef.current?.requestLock();
    };
    window.addEventListener("keydown", onKey, true);
    window.addEventListener("keyup", onUp, true);
    return () => {
      window.removeEventListener("keydown", onKey, true);
      window.removeEventListener("keyup", onUp, true);
    };
  }, [setPhase, setClickToPlay, closeOverlay]);

  const onCanvasClick = () => {
    if (phase !== "playing") return;
    engineRef.current?.requestLock();
  };

  const quit = () => {
    engineRef.current?.save();
    engineRef.current?.dispose();
    engineRef.current = null;
    useGameStore.getState().resetHud();
    setPhase("title");
  };

  return (
    <div className="game-shell">
      <MenuPanorama active={phase === "title"} />
      <canvas
        ref={canvasRef}
        className="game-canvas"
        onClick={onCanvasClick}
        onContextMenu={(e) => e.preventDefault()}
      />

      {phase === "credits" ? (
        <Credits
          lines={engineRef.current?.creditsView().lines ?? ["Gezgin, End'in kapısından geçti."]}
          shots={engineRef.current?.creditsView().shots ?? []}
          onBack={() => engineRef.current?.returnFromCredits()}
        />
      ) : null}

      {phase === "title" ? (
        <TitleScreen onPlay={(id) => void boot(id)} />
      ) : null}

      {phase === "loading" ? (
        <div className="overlay-root load-overlay">
          <div className="title-panel">
            <p className="title-kicker">Dünya</p>
            <h2>Chunklar üretiliyor</h2>
            <div className="load-bar">
              <i style={{ width: `${Math.round(loading * 100)}%` }} />
            </div>
            <p className="title-lead">{Math.round(loading * 100)}%</p>
          </div>
        </div>
      ) : null}

      {loadError ? (
        <div className="overlay-root">
          <div className="title-panel">
            <h2>Yükleme hatası</h2>
            <p className="title-lead">{loadError}</p>
          </div>
        </div>
      ) : null}

      {phase === "playing" && clickToPlay ? (
        <button type="button" className="click-play" onClick={onCanvasClick}>
          <span>{isMobile ? "Dokun ve oyna" : "Tıkla ve oyna"}</span>
          <small>WASD yürü · Space zıpla · Shift eğil · . yapım</small>
        </button>
      ) : null}

      <HUD
        icons={icons}
        onCraft={openCraft}
        onWake={() => {
          engineRef.current?.wake();
          engineRef.current?.requestLock();
        }}
      />

      {phase === "paused" ? (
        <PauseMenu
          engine={engineRef.current}
          onResume={() => {
            setPhase("playing");
            engineRef.current?.requestLock();
          }}
          onQuit={quit}
        />
      ) : null}

      {phase === "inventory" ? <Inventory engine={engineRef.current} icons={icons} /> : null}
      {phase === "crafting" ? <Crafting engine={engineRef.current} icons={icons} /> : null}
      {phase === "furnace" ? <Furnace engine={engineRef.current} icons={icons} /> : null}

      {isMobile ? (
        <MobileControls
          engine={engineRef.current}
          onPause={() => {
            document.exitPointerLock?.();
            setPhase("paused");
          }}
          onInventory={() => {
            if (phase === "inventory") {
              setPhase("playing");
              setClickToPlay(false);
            } else {
              setPhase("inventory");
              setClickToPlay(false);
            }
          }}
          onCraft={() => {
            if (phase === "crafting") closeOverlay();
            else openCraft();
          }}
        />
      ) : null}
      <span className="sr-only">{engineTick}</span>
    </div>
  );
}
