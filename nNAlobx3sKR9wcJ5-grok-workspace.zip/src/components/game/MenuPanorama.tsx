import { useEffect, useRef } from "react";
import * as THREE from "three";
import { buildAtlas } from "@/game/atlas";
import { meshChunk, meshWater } from "@/game/mesher";
import { CHUNK_D, CHUNK_W } from "@/game/types";
import { World } from "@/game/world";

const SEED = 48211;

export function MenuPanorama({ active }: { active: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!active) return;
    const canvas = ref.current;
    if (!canvas) return;
    let dead = false;
    const gl = canvas.getContext("webgl2") ?? canvas.getContext("webgl");
    if (!gl) return;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ canvas, context: gl, antialias: false, alpha: false });
    } catch {
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    renderer.setClearColor(0x6ea0c8, 1);

    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0xe08a55, 36, 92);
    const camera = new THREE.PerspectiveCamera(72, 1, 0.15, 140);
    camera.rotation.order = "YXZ";

    const skyCanvas = document.createElement("canvas");
    skyCanvas.width = 8;
    skyCanvas.height = 256;
    const sctx = skyCanvas.getContext("2d")!;
    const grad = sctx.createLinearGradient(0, 0, 0, 256);
    grad.addColorStop(0, "#2f5f92");
    grad.addColorStop(0.42, "#e07a48");
    grad.addColorStop(0.58, "#f2b15a");
    grad.addColorStop(1, "#7eaf55");
    sctx.fillStyle = grad;
    sctx.fillRect(0, 0, 8, 256);
    const skyTex = new THREE.CanvasTexture(skyCanvas);
    const sky = new THREE.Mesh(
      new THREE.SphereGeometry(110, 28, 18),
      new THREE.MeshBasicMaterial({ map: skyTex, side: THREE.BackSide, depthWrite: false }),
    );
    scene.add(sky);

    scene.add(new THREE.HemisphereLight(0xffe2c4, 0x3a4a28, 0.72));
    scene.add(new THREE.AmbientLight(0xffd0a0, 0.28));
    const sun = new THREE.DirectionalLight(0xffc089, 1.25);
    sun.position.set(-60, 22, 16);
    scene.add(sun);
    const sunBall = new THREE.Mesh(
      new THREE.SphereGeometry(4.2, 16, 12),
      new THREE.MeshBasicMaterial({ color: 0xfff4c8 }),
    );
    scene.add(sunBall);

    const worldGroup = new THREE.Group();
    scene.add(worldGroup);

    let yaw = 0.6;
    let cam = new THREE.Vector3(8, 32, 8);
    let raf = 0;

    const fit = () => {
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      if (w < 2 || h < 2) return;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };

    const loop = () => {
      if (dead) return;
      raf = requestAnimationFrame(loop);
      fit();
      yaw += 0.0017;
      camera.position.copy(cam);
      camera.rotation.set(-0.08, yaw, 0);
      sky.position.copy(cam);
      renderer.render(scene, camera);
    };
    raf = requestAnimationFrame(loop);

    void (async () => {
      const atlas = await buildAtlas();
      if (dead) {
        atlas.texture.dispose();
        return;
      }
      const world = new World(SEED, "overworld");
      const [sx, sy, sz] = world.findSpawn();
      cam = new THREE.Vector3(sx, sy + 6.5, sz);
      sunBall.position.set(sx - 48, sy + 16, sz + 8);
      const mat = new THREE.MeshLambertMaterial({ map: atlas.texture, vertexColors: true });
      const waterMat = new THREE.MeshLambertMaterial({
        color: 0x2a6ea8,
        transparent: true,
        opacity: 0.55,
        vertexColors: true,
        depthWrite: false,
      });
      const cx0 = Math.floor(sx / CHUNK_W);
      const cz0 = Math.floor(sz / CHUNK_D);
      const R = 3;
      for (let dz = -R; dz <= R; dz++) {
        for (let dx = -R; dx <= R; dx++) {
          if (dead) return;
          const cx = cx0 + dx;
          const cz = cz0 + dz;
          world.ensureChunk(cx, cz);
          const geo = meshChunk(world, cx, cz);
          if (geo) worldGroup.add(new THREE.Mesh(geo, mat));
          const water = meshWater(world, cx, cz);
          if (water) worldGroup.add(new THREE.Mesh(water, waterMat));
        }
        await new Promise((r) => setTimeout(r, 0));
      }
    })();

    return () => {
      dead = true;
      cancelAnimationFrame(raf);
      scene.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        mesh.geometry?.dispose();
      });
      renderer.dispose();
    };
  }, [active]);

  if (!active) return null;
  return <canvas ref={ref} className="pano-canvas" aria-hidden />;
}
