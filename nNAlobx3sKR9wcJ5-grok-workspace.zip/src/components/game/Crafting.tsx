import { useEffect, useRef, useState } from "react";
import { Hammer } from "lucide-react";
import { blockName } from "@/game/blocks";
import { RECIPES } from "@/game/craft";
import { isTool } from "@/game/items";
import { useGameStore } from "@/game/store";
import { clickStack, gatherMatches, stashCursor, type SlotRef } from "./slotLogic";
import type { GameEngine } from "@/game/engine";
import type { ItemStack } from "@/game/types";

type Bag = "hotbar" | "inv" | "craft";

type Props = {
  engine: GameEngine | null;
  icons: Record<number, string>;
};

export function Crafting({ engine, icons }: Props) {
  const hud = useGameStore((s) => s.hud);
  const [cursor, setCursor] = useState<ItemStack | null>(null);
  const [origin, setOrigin] = useState<SlotRef | null>(null);
  const [mouse, setMouse] = useState({ x: 0, y: 0 });
  const [, bump] = useState(0);
  const cursorRef = useRef(cursor);
  const originRef = useRef(origin);
  cursorRef.current = cursor;
  originRef.current = origin;
  const refresh = () => {
    engine?.refreshHud();
    bump((n) => n + 1);
  };

  useEffect(() => {
    return () => {
      const held = cursorRef.current;
      if (!held || !engine) return;
      stashCursor(
        engine,
        held,
        originRef.current,
        (r) => getSlot(engine, r.bag as Bag, r.i),
        (r, v) => setSlot(engine, r.bag as Bag, r.i, v),
      );
      engine.refreshHud();
    };
  }, [engine]);

  const onSlot = (bag: Bag, i: number, detail = 1) => {
    if (!engine) return;
    const read = (r: SlotRef) => getSlot(engine, r.bag as Bag, r.i);
    const write = (r: SlotRef, v: ItemStack | null) => setSlot(engine, r.bag as Bag, r.i, v);
    if (detail >= 2 && cursor && !isTool(cursor.id)) {
      const slots: SlotRef[] = [
        ...engine.hotbar.map((_, n) => ({ bag: "hotbar", i: n })),
        ...engine.inventory.map((_, n) => ({ bag: "inv", i: n })),
        ...engine.craftGrid.map((_, n) => ({ bag: "craft", i: n })),
      ];
      setCursor(gatherMatches({ ...cursor }, slots, read, write));
      refresh();
      return;
    }
    const next = clickStack(cursor, origin, getSlot(engine, bag, i), { bag, i }, read, write);
    setCursor(next.cursor);
    setOrigin(next.origin);
    refresh();
  };

  const result = engine?.matchedCraft() ?? null;
  const craftSlots = engine?.craftGrid ?? [];

  return (
    <div
      className="overlay-root inventory-overlay"
      onMouseMove={(e) => setMouse({ x: e.clientX, y: e.clientY })}
    >
      <div className="inv-panel craft-panel" role="dialog" aria-label="Yapım masası">
        <header className="inv-head">
          <h2>
            <Hammer size={18} /> Yapım masası
          </h2>
          <p>1 odun = 4 tahta · 1 tahta = 4 çubuk. Nokta veya Esc kapatır.</p>
        </header>

        <div className="craft-layout">
          <div className="craft-bench">
            <div className="craft-grid">
              {Array.from({ length: 9 }, (_, i) => {
                const s = craftSlots[i];
                return (
                  <InvSlot
                    key={i}
                    icon={s ? icons[s.id] : undefined}
                    count={s?.count ?? 0}
                    label={s ? blockName(s.id) : ""}
                    onClick={(e) => onSlot("craft", i, e.detail)}
                  />
                );
              })}
            </div>
            <div className="craft-arrow" aria-hidden="true" />
            <button
              type="button"
              className="slot inv-slot craft-result"
              title={result ? blockName(result.out.id) : "Sonuç"}
              onClick={() => {
                if (!engine || !result) return;
                engine.takeCraftResult();
                refresh();
              }}
            >
              {result && icons[result.out.id] ? <img src={icons[result.out.id]} alt="" draggable={false} /> : null}
              {result && result.out.count > 1 ? <span className="slot-count">{result.out.count}</span> : null}
            </button>
          </div>

          <div className="craft-book">
            <p className="craft-book-label">Tarifler</p>
            <div className="craft-recipes">
              {RECIPES.map((r) => {
                const ok = engine?.canMake(r.id) ?? false;
                return (
                  <button
                    key={r.id}
                    type="button"
                    className="craft-recipe"
                    disabled={!ok}
                    onClick={() => {
                      if (!engine) return;
                      engine.craftRecipe(r.id);
                      refresh();
                    }}
                  >
                    {icons[r.out.id] ? <img src={icons[r.out.id]} alt="" /> : null}
                    <span>{r.name}</span>
                    <em>×{r.out.count}</em>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="inv-grid craft-inv">
          {hud.inventory.map((s, i) => (
            <InvSlot
              key={i}
              icon={s ? icons[s.id] : undefined}
              count={s?.count ?? 0}
              label={s ? blockName(s.id) : ""}
              onClick={(e) => onSlot("inv", i, e.detail)}
            />
          ))}
        </div>
        <div className="inv-hotbar">
          {hud.hotbar.map((s, i) => (
            <InvSlot
              key={i}
              icon={s ? icons[s.id] : undefined}
              count={s?.count ?? 0}
              selected={i === hud.selectedSlot}
              label={s ? blockName(s.id) : ""}
              onClick={(e) => onSlot("hotbar", i, e.detail)}
            />
          ))}
        </div>
      </div>
      {cursor ? (
        <div className="cursor-item" style={{ left: mouse.x + 12, top: mouse.y + 12 }}>
          {icons[cursor.id] ? <img src={icons[cursor.id]} alt="" /> : null}
          {cursor.count > 1 ? <span>{cursor.count}</span> : null}
        </div>
      ) : null}
    </div>
  );
}

function InvSlot({
  icon,
  count,
  selected,
  label,
  onClick,
}: {
  icon?: string;
  count: number;
  selected?: boolean;
  label?: string;
  onClick: (e: { detail: number }) => void;
}) {
  return (
    <button type="button" className={`slot inv-slot ${selected ? "is-selected" : ""}`} title={label} onClick={onClick}>
      {icon ? <img src={icon} alt="" draggable={false} /> : null}
      {count > 1 ? <span className="slot-count">{count}</span> : null}
    </button>
  );
}

function getSlot(engine: GameEngine, bag: Bag, i: number): ItemStack | null {
  if (bag === "hotbar") return engine.hotbar[i] ?? null;
  if (bag === "inv") return engine.inventory[i] ?? null;
  return engine.craftGrid[i] ?? null;
}

function setSlot(engine: GameEngine, bag: Bag, i: number, v: ItemStack | null) {
  if (bag === "hotbar") engine.hotbar[i] = v;
  else if (bag === "inv") engine.inventory[i] = v;
  else engine.craftGrid[i] = v;
}
