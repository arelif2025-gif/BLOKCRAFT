import * as THREE from "three";
import { BLOCKS } from "./blocks";
import { drawItemIcon, drawMeatIcon, drawStickIcon, drawToolIcon } from "./tools";
import { isTool, itemName } from "./items";
import { AMETHYST, BEEF, BLAZE_POWDER, BLAZE_ROD, BOAT, BUCKET, CHICKEN_MEAT, COOKED_BEEF, COOKED_CHICKEN, COOKED_MUTTON, COOKED_PORK, ENDER_PEARL, EYE_OF_ENDER, FLINT, FLINT_STEEL, GOLD_INGOT, IRON_INGOT, LAVA, LAVA_BUCKET, MUTTON, PORK, PORTAL, RAW_GOLD, RAW_IRON, STICK, WATER, WATER_BUCKET } from "./types";

export const ATLAS_COLS = 16;
export const ATLAS_ROWS = 12;
export const TILE = 32;
export const FACES_PER = 6;

const FACE_PX: Array<[number, number]> = [
  [0, 16],
  [16, 16],
  [0, 32],
  [32, 0],
  [16, 0],
  [0, 0],
];

const SRC: Record<number, string> = {
  0: "/textures/grass.png",
  2: "/textures/stone.png",
  3: "/textures/wood.png",
  4: "/textures/leaves.png",
  5: "/textures/coal.png",
  6: "/textures/gold.png",
  7: "/textures/diamond.png",
};

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error(`texture ${src}`));
    img.src = src;
  });
}

function extract16(src: CanvasImageSource, sx: number, sy: number): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = 16;
  c.height = 16;
  const ctx = c.getContext("2d")!;
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(src, sx, sy, 16, 16, 0, 0, 16, 16);
  const img = ctx.getImageData(0, 0, 16, 16);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) d[i + 3] = 255;
  ctx.putImageData(img, 0, 0);
  return c;
}

function tileOpaqueCount(src: CanvasImageSource, sx: number, sy: number): number {
  const c = document.createElement("canvas");
  c.width = 16;
  c.height = 16;
  const ctx = c.getContext("2d")!;
  ctx.drawImage(src, sx, sy, 16, 16, 0, 0, 16, 16);
  const d = ctx.getImageData(0, 0, 16, 16).data;
  let n = 0;
  for (let i = 3; i < d.length; i += 4) if (d[i]! > 16) n++;
  return n;
}

function firstPainted(src: CanvasImageSource): [number, number] {
  for (const [x, y] of FACE_PX) {
    if (tileOpaqueCount(src, x, y) > 40) return [x, y];
  }
  return [0, 0];
}

function blitUpscale(dst: CanvasRenderingContext2D, tile: HTMLCanvasElement, dx: number, dy: number) {
  dst.imageSmoothingEnabled = false;
  dst.drawImage(tile, 0, 0, 16, 16, dx, dy, TILE, TILE);
}

function clamp(n: number) {
  return n < 0 ? 0 : n > 255 ? 255 : n | 0;
}

function paintNoise(ctx: CanvasRenderingContext2D, x: number, y: number, rgb: [number, number, number], spread: number) {
  const img = ctx.createImageData(16, 16);
  const d = img.data;
  for (let i = 0; i < 256; i++) {
    const n = (Math.random() - 0.5) * spread;
    const j = i * 4;
    d[j] = clamp(rgb[0] + n);
    d[j + 1] = clamp(rgb[1] + n);
    d[j + 2] = clamp(rgb[2] + n);
    d[j + 3] = 255;
  }
  ctx.putImageData(img, x, y);
}

function paintStripes(ctx: CanvasRenderingContext2D, x: number, y: number, a: [number, number, number], b: [number, number, number]) {
  const img = ctx.createImageData(16, 16);
  const d = img.data;
  for (let py = 0; py < 16; py++) {
    for (let px = 0; px < 16; px++) {
      const stripe = Math.floor(px / 4) % 2 === 0;
      const n = (Math.random() - 0.5) * 14;
      const c = stripe ? a : b;
      const j = (py * 16 + px) * 4;
      d[j] = clamp(c[0] + n);
      d[j + 1] = clamp(c[1] + n);
      d[j + 2] = clamp(c[2] + n);
      d[j + 3] = 255;
    }
  }
  ctx.putImageData(img, x, y);
}

function bookshelfSheet(planks: HTMLCanvasElement): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = 64;
  c.height = 64;
  const ctx = c.getContext("2d")!;
  ctx.imageSmoothingEnabled = false;
  const side = bookshelfSide();
  const top = extract16(planks, 0, 32);
  const bottom = extract16(planks, 32, 0);
  // kitaplık.geo.json: east, west, up, down, south, north
  ctx.drawImage(side, 0, 16);
  ctx.drawImage(side, 16, 16);
  ctx.drawImage(top, 0, 32);
  ctx.drawImage(bottom, 32, 0);
  ctx.drawImage(side, 16, 0);
  ctx.drawImage(side, 0, 0);
  return c;
}

function bookshelfSide(): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = 16;
  c.height = 16;
  const ctx = c.getContext("2d")!;
  const img = ctx.createImageData(16, 16);
  const d = img.data;
  const wood: Array<[number, number, number]> = [
    [186, 148, 92],
    [150, 112, 64],
    [112, 78, 42],
  ];
  const books: Array<[number, number, number]> = [
    [168, 48, 42],
    [46, 78, 158],
    [42, 122, 58],
    [92, 58, 36],
    [128, 52, 146],
    [186, 146, 48],
    [38, 112, 124],
    [156, 78, 42],
  ];
  const set = (x: number, y: number, rgb: [number, number, number]) => {
    const j = (y * 16 + x) * 4;
    d[j] = rgb[0];
    d[j + 1] = rgb[1];
    d[j + 2] = rgb[2];
    d[j + 3] = 255;
  };
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      const frame = y === 0 || y === 15 || x === 0 || x === 15 || y === 1 || y === 14;
      if (frame) {
        set(x, y, wood[(x + y) % 3]!);
        continue;
      }
      const col = Math.floor((x - 1) / 2);
      const gap = (x - 1) % 2 === 1 && col < 6;
      const short = col % 3 === 2 ? 3 : col % 2 === 0 ? 1 : 2;
      if (y < 2 + short || gap) set(x, y, wood[1]!);
      else {
        const book = books[col % books.length]!;
        const shade = y % 5 === 0 ? -28 : x % 2 === 0 ? 10 : 0;
        set(x, y, [clamp(book[0] + shade), clamp(book[1] + shade), clamp(book[2] + shade)]);
      }
    }
  }
  ctx.putImageData(img, 0, 0);
  return c;
}

function makeSheet(paint: (ctx: CanvasRenderingContext2D, x: number, y: number, face: number) => void): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = 64;
  c.height = 64;
  const ctx = c.getContext("2d")!;
  ctx.imageSmoothingEnabled = false;
  FACE_PX.forEach(([x, y], i) => paint(ctx, x, y, i));
  return c;
}

export type AtlasResult = {
  texture: THREE.CanvasTexture;
  canvas: HTMLCanvasElement;
  icons: Record<number, string>;
};

export async function buildAtlas(): Promise<AtlasResult> {
  const grass = await loadImage(SRC[0]);
  const images: Record<number, HTMLImageElement | HTMLCanvasElement> = { 0: grass };
  await Promise.all(
    Object.entries(SRC).map(async ([k, url]) => {
      const id = Number(k);
      if (id === 0) return;
      images[id] = await loadImage(url);
    }),
  );

  const dirt = document.createElement("canvas");
  dirt.width = 64;
  dirt.height = 64;
  const dctx = dirt.getContext("2d")!;
  dctx.imageSmoothingEnabled = false;
  const dirtTile = extract16(grass, 32, 0);
  for (let y = 0; y < 64; y += 16) {
    for (let x = 0; x < 64; x += 16) dctx.drawImage(dirtTile, x, y);
  }
  images[1] = dirt;

  const bedrock = document.createElement("canvas");
  bedrock.width = 64;
  bedrock.height = 64;
  const bctx = bedrock.getContext("2d")!;
  bctx.imageSmoothingEnabled = false;
  bctx.drawImage(images[2] as CanvasImageSource, 0, 0);
  bctx.fillStyle = "rgba(0,0,0,0.62)";
  bctx.fillRect(0, 0, 64, 64);
  images[8] = bedrock;

  images[9] = makeSheet((ctx, x, y) => paintNoise(ctx, x, y, [214, 186, 118], 22));
  images[10] = makeSheet((ctx, x, y, face) => {
    if (face === 2) paintNoise(ctx, x, y, [236, 242, 248], 10);
    else if (face === 3) paintNoise(ctx, x, y, [168, 176, 186], 12);
    else paintNoise(ctx, x, y, [214, 224, 234], 12);
  });
  images[11] = makeSheet((ctx, x, y) => paintStripes(ctx, x, y, [166, 122, 62], [138, 96, 46]));
  images[12] = makeSheet((ctx, x, y, face) => {
    if (face === 2 || face === 3) paintNoise(ctx, x, y, [46, 110, 48], 16);
    else paintStripes(ctx, x, y, [38, 102, 42], [22, 72, 28]);
  });
  images[13] = makeSheet((ctx, x, y) => paintNoise(ctx, x, y, [168, 152, 132], 18));
  images[14] = makeSheet((ctx, x, y) => paintNoise(ctx, x, y, [148, 82, 186], 22));
  images[15] = makeSheet((ctx, x, y) => paintNoise(ctx, x, y, [128, 122, 118], 20));
  images[16] = makeSheet((ctx, x, y) => paintNoise(ctx, x, y, [18, 10, 28], 10));
  images[17] = makeSheet((ctx, x, y, face) => {
    if (face === 4) paintNoise(ctx, x, y, [48, 48, 52], 8);
    else paintNoise(ctx, x, y, [92, 92, 98], 12);
  });
  images[18] = makeSheet((ctx, x, y) => paintNoise(ctx, x, y, [232, 232, 236], 10));
  images[19] = makeSheet((ctx, x, y, face) => {
    if (face === 2) paintNoise(ctx, x, y, [180, 54, 54], 12);
    else paintStripes(ctx, x, y, [150, 90, 48], [120, 70, 36]);
  });
  images[20] = makeSheet((ctx, x, y) => paintNoise(ctx, x, y, [120, 42, 38], 22));
  images[21] = makeSheet((ctx, x, y) => paintStripes(ctx, x, y, [72, 22, 28], [48, 14, 18]));
  images[22] = bookshelfSheet(images[11] as HTMLCanvasElement);
  images[23] = makeSheet((ctx, x, y, face) => {
    if (face === 2) paintNoise(ctx, x, y, [40, 120, 70], 12);
    else paintNoise(ctx, x, y, [28, 36, 32], 8);
  });
  images[24] = makeSheet((ctx, x, y, face) => {
    if (face === 2) paintFrameEye(ctx, x, y);
    else paintNoise(ctx, x, y, [28, 36, 32], 8);
  });
  images[25] = makeSheet((ctx, x, y) => paintNoise(ctx, x, y, [224, 222, 168], 14));

  const atlas = document.createElement("canvas");
  atlas.width = ATLAS_COLS * TILE;
  atlas.height = ATLAS_ROWS * TILE;
  const actx = atlas.getContext("2d")!;
  actx.imageSmoothingEnabled = false;
  actx.fillStyle = "#3a2a18";
  actx.fillRect(0, 0, atlas.width, atlas.height);

  for (let group = 0; group <= 25; group++) {
    const src = images[group];
    if (!src) continue;
    const fallback = firstPainted(src);
    for (let face = 0; face < FACES_PER; face++) {
      let [sx, sy] = FACE_PX[face]!;
      if (tileOpaqueCount(src, sx, sy) < 40) {
        sx = fallback[0];
        sy = fallback[1];
      }
      const tile = extract16(src, sx, sy);
      const t = group * FACES_PER + face;
      const col = t % ATLAS_COLS;
      const row = Math.floor(t / ATLAS_COLS);
      blitUpscale(actx, tile, col * TILE, row * TILE);
    }
  }

  const texture = new THREE.CanvasTexture(atlas);
  texture.magFilter = THREE.NearestFilter;
  texture.minFilter = THREE.NearestFilter;
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.ClampToEdgeWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.flipY = false;
  texture.generateMipmaps = false;
  texture.needsUpdate = true;

  const icons: Record<number, string> = {};
  for (const def of Object.values(BLOCKS)) {
    if (def.id === 0 || def.id === WATER || def.id === LAVA || def.id === PORTAL) continue;
    icons[def.id] = drawIsoIcon(images[def.atlas] ?? grass);
  }
  icons[STICK] = drawStickIcon();
  for (let id = 21; id <= 77; id++) {
    if (isTool(id) || itemName(id)) icons[id] = drawToolIcon(id);
  }
  icons[PORK] = drawMeatIcon(PORK);
  icons[BEEF] = drawMeatIcon(BEEF);
  icons[MUTTON] = drawMeatIcon(MUTTON);
  icons[CHICKEN_MEAT] = drawMeatIcon(CHICKEN_MEAT);
  icons[COOKED_PORK] = drawMeatIcon(COOKED_PORK);
  icons[COOKED_BEEF] = drawMeatIcon(COOKED_BEEF);
  icons[COOKED_MUTTON] = drawMeatIcon(COOKED_MUTTON);
  icons[COOKED_CHICKEN] = drawMeatIcon(COOKED_CHICKEN);
  icons[RAW_IRON] = drawItemIcon(RAW_IRON);
  icons[RAW_GOLD] = drawItemIcon(RAW_GOLD);
  icons[IRON_INGOT] = drawItemIcon(IRON_INGOT);
  icons[GOLD_INGOT] = drawItemIcon(GOLD_INGOT);
  icons[AMETHYST] = drawItemIcon(AMETHYST);
  icons[BUCKET] = drawItemIcon(BUCKET);
  icons[WATER_BUCKET] = drawItemIcon(WATER_BUCKET);
  icons[LAVA_BUCKET] = drawItemIcon(LAVA_BUCKET);
  icons[FLINT] = drawItemIcon(FLINT);
  icons[FLINT_STEEL] = drawItemIcon(FLINT_STEEL);
  icons[BLAZE_ROD] = drawItemIcon(BLAZE_ROD);
  icons[BLAZE_POWDER] = drawItemIcon(BLAZE_POWDER);
  icons[ENDER_PEARL] = drawItemIcon(ENDER_PEARL);
  icons[EYE_OF_ENDER] = drawItemIcon(EYE_OF_ENDER);
  icons[BOAT] = drawItemIcon(BOAT);
  return { texture, canvas: atlas, icons };
}

function paintFrameEye(ctx: CanvasRenderingContext2D, x: number, y: number) {
  paintNoise(ctx, x, y, [34, 48, 40], 10);
  const img = ctx.getImageData(x, y, 16, 16);
  const d = img.data;
  const set = (px: number, py: number, r: number, g: number, b: number) => {
    const j = (py * 16 + px) * 4;
    d[j] = r;
    d[j + 1] = g;
    d[j + 2] = b;
    d[j + 3] = 255;
  };
  for (let py = 0; py < 16; py++) {
    for (let px = 0; px < 16; px++) {
      const nx = (px + 0.5 - 8) / 5.4;
      const ny = (py + 0.5 - 8) / 3.4;
      const e = nx * nx + ny * ny;
      if (e > 1) continue;
      if (e > 0.78) set(px, py, 16, 20, 18);
      else if (e > 0.34) set(px, py, 232, 214, 92);
      else if (e > 0.1) set(px, py, 28, 148, 58);
      else set(px, py, 6, 10, 8);
    }
  }
  set(6, 6, 245, 255, 220);
  ctx.putImageData(img, x, y);
}

function drawIsoIcon(src: CanvasImageSource): string {
  const size = 64;
  const c = document.createElement("canvas");
  c.width = size;
  c.height = size;
  const ctx = c.getContext("2d")!;
  ctx.imageSmoothingEnabled = false;

  const top = extract16(src, 0, 32);
  const left = extract16(src, 0, 16);
  const right = extract16(src, 16, 0);

  const ox = size / 2;
  const oy = size * 0.22;
  const hw = size * 0.38;
  const hh = size * 0.22;
  const depth = size * 0.42;

  texturedQuad(ctx, top, ox, oy, ox + hw, oy + hh, ox, oy + hh * 2, ox - hw, oy + hh);
  texturedQuad(ctx, left, ox - hw, oy + hh, ox, oy + hh * 2, ox, oy + hh * 2 + depth, ox - hw, oy + hh + depth);
  texturedQuad(ctx, right, ox, oy + hh * 2, ox + hw, oy + hh, ox + hw, oy + hh + depth, ox, oy + hh * 2 + depth);
  return c.toDataURL("image/png");
}

function texturedQuad(
  ctx: CanvasRenderingContext2D,
  tex: HTMLCanvasElement,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  x3: number,
  y3: number,
) {
  const w = tex.width;
  const h = tex.height;
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(x0, y0);
  ctx.lineTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.lineTo(x3, y3);
  ctx.closePath();
  ctx.clip();
  ctx.transform((x1 - x0) / w, (y1 - y0) / w, (x3 - x0) / h, (y3 - y0) / h, x0, y0);
  ctx.drawImage(tex, 0, 0);
  ctx.restore();
}

export function atlasFaceUV(group: number, face: number, u: number, v: number): [number, number] {
  const t = group * FACES_PER + face;
  const col = t % ATLAS_COLS;
  const row = Math.floor(t / ATLAS_COLS);
  const pad = 0.5 / TILE;
  const uu = u < 0.5 ? pad : 1 - pad;
  const vv = v < 0.5 ? pad : 1 - pad;
  return [(col + uu) / ATLAS_COLS, (row + vv) / ATLAS_ROWS];
}
