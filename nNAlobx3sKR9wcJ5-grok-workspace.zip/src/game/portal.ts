import { AIR, OBSIDIAN, PORTAL } from "./types";
import type { World } from "./world";

const W = 4;
const H = 6;

function frameOk(world: World, x: number, y: number, z: number, axis: "x" | "z"): boolean {
  for (let dy = 0; dy < H; dy++) {
    for (let d = 0; d < W; d++) {
      const wx = axis === "x" ? x + d : x;
      const wz = axis === "z" ? z + d : z;
      const edge = dy === 0 || dy === H - 1 || d === 0 || d === W - 1;
      const id = world.getBlock(wx, y + dy, wz);
      if (edge) {
        if (id !== OBSIDIAN) return false;
      } else if (id !== AIR && id !== PORTAL) return false;
    }
  }
  return true;
}

function fill(world: World, x: number, y: number, z: number, axis: "x" | "z", id: number) {
  for (let dy = 1; dy < H - 1; dy++) {
    for (let d = 1; d < W - 1; d++) {
      const wx = axis === "x" ? x + d : x;
      const wz = axis === "z" ? z + d : z;
      world.editBlock(wx, y + dy, wz, id);
    }
  }
}

export function tryLightPortal(world: World, hx: number, hy: number, hz: number): boolean {
  for (const axis of ["x", "z"] as const) {
    for (let oy = 1 - H; oy <= 0; oy++) {
      for (let od = 1 - W; od <= 0; od++) {
        const x = axis === "x" ? hx + od : hx;
        const z = axis === "z" ? hz + od : hz;
        const y = hy + oy;
        if (frameOk(world, x, y, z, axis)) {
          fill(world, x, y, z, axis, PORTAL);
          return true;
        }
      }
    }
  }
  return false;
}

export function breakPortalNear(world: World, x: number, y: number, z: number) {
  const seen = new Set<string>();
  const q: Array<[number, number, number]> = [[x, y, z]];
  while (q.length) {
    const [cx, cy, cz] = q.pop()!;
    const k = `${cx},${cy},${cz}`;
    if (seen.has(k)) continue;
    seen.add(k);
    if (world.getBlock(cx, cy, cz) !== PORTAL) continue;
    world.editBlock(cx, cy, cz, AIR);
    q.push([cx + 1, cy, cz], [cx - 1, cy, cz], [cx, cy + 1, cz], [cx, cy - 1, cz], [cx, cy, cz + 1], [cx, cy, cz - 1]);
  }
}
