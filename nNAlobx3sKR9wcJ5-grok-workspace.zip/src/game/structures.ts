import { hash2 } from "./rng";

export type Room = { x: number; y: number; z: number };

export function strongholds(seed: number): Room[] {
  const rooms: Room[] = [];
  for (let i = 0; i < 3; i++) {
    const ang = (i / 3) * Math.PI * 2 + ((seed % 97) / 97) * 0.9;
    const r = 190 + ((Math.abs(seed) + i * 131) % 240);
    rooms.push({
      x: Math.round(Math.cos(ang) * r),
      y: 12,
      z: Math.round(Math.sin(ang) * r),
    });
  }
  return rooms;
}

export function nearestStronghold(seed: number, x: number, z: number): Room {
  const all = strongholds(seed);
  let best = all[0]!;
  let d = Infinity;
  for (const s of all) {
    const dd = (s.x - x) ** 2 + (s.z - z) ** 2;
    if (dd < d) {
      d = dd;
      best = s;
    }
  }
  return best;
}

export function frameSpots(room: Room): Array<[number, number, number]> {
  const y = room.y + 1;
  const spots: Array<[number, number, number]> = [];
  for (let i = 0; i < 4; i++) {
    spots.push([room.x + 4 + i, y, room.z + 3]);
    spots.push([room.x + 4 + i, y, room.z + 8]);
    spots.push([room.x + 3, y, room.z + 4 + i]);
    spots.push([room.x + 8, y, room.z + 4 + i]);
  }
  return spots;
}

export function portalSpots(room: Room): Array<[number, number, number]> {
  const spots: Array<[number, number, number]> = [];
  for (let dz = 0; dz < 4; dz++) {
    for (let dx = 0; dx < 4; dx++) spots.push([room.x + 4 + dx, room.y + 1, room.z + 4 + dz]);
  }
  return spots;
}

export function fortresses(seed: number): Room[] {
  const out: Room[] = [];
  for (let gz = -2; gz <= 2; gz++) {
    for (let gx = -2; gx <= 2; gx++) {
      if ((Math.abs(gx) + Math.abs(gz)) % 2 !== 0) continue;
      const jx = (hash2(gx, gz, seed) - 0.5) * 50;
      const jz = (hash2(gz, gx, seed + 5) - 0.5) * 50;
      out.push({ x: Math.round(gx * 210 + jx), y: 32, z: Math.round(gz * 210 + jz) });
    }
  }
  return out;
}

export function nearFortress(seed: number, x: number, z: number, pad = 26): Room | null {
  let best: Room | null = null;
  let d = pad * pad;
  for (const f of fortresses(seed)) {
    const dd = (f.x - x) ** 2 + (f.z - z) ** 2;
    if (dd < d) {
      d = dd;
      best = f;
    }
  }
  return best;
}
