import * as THREE from "three";

export type Crystal = { x: number; y: number; z: number; alive: boolean; mesh: THREE.Mesh; base: number };

function box(g: THREE.Group, x: number, y: number, z: number, w: number, h: number, d: number, color: number) {
  const m = new THREE.Mesh(
    new THREE.BoxGeometry(w, h, d),
    new THREE.MeshLambertMaterial({ color }),
  );
  m.position.set(x, y, z);
  g.add(m);
  return m;
}

export class EndBoss {
  group = new THREE.Group();
  crystals: Crystal[] = [];
  dragon = new THREE.Group();
  private wings: THREE.Mesh[] = [];
  private bits: Array<{ mesh: THREE.Object3D; v: THREE.Vector3 }> = [];
  private beam: THREE.Mesh;
  hp = 200;
  maxHp = 200;
  dead = false;
  mode: "fly" | "perch" | "dying" | "gone" = "fly";
  private ang = 0;
  private perchT = 0;
  private nextPerch = 16;
  private healT = 0;
  deathT = 0;
  exitSent = false;
  x = 0;
  y = 48;
  z = 0;
  time = 0;
  perchY = 40;

  constructor() {
    this.buildDragon();
    this.group.add(this.dragon);
    const beam = new THREE.Mesh(
      new THREE.CylinderGeometry(0.35, 1.4, 18, 10, 1, true),
      new THREE.MeshBasicMaterial({ color: 0xf4f7ff, transparent: true, opacity: 0.85, side: THREE.DoubleSide, depthWrite: false }),
    );
    beam.visible = false;
    beam.position.set(0, 42, 0);
    this.beam = beam;
    this.group.add(beam);
  }

  layout(towers: Array<{ x: number; z: number; top: number }>, mask: number, hp: number, dead: boolean) {
    for (const c of this.crystals) {
      this.group.remove(c.mesh);
      c.mesh.geometry.dispose();
    }
    this.crystals = towers.map((t, i) => {
      const mesh = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.55, 0),
        new THREE.MeshLambertMaterial({ color: 0xe7d0ff, emissive: 0xc060ff, emissiveIntensity: 0.85 }),
      );
      const y = t.top + 1.45;
      mesh.position.set(t.x + 0.5, y, t.z + 0.5);
      const alive = !dead && (mask & (1 << i)) !== 0;
      mesh.visible = alive;
      this.group.add(mesh);
      return { x: t.x + 0.5, y, z: t.z + 0.5, alive, mesh, base: y };
    });
    this.hp = dead ? 0 : hp;
    this.dead = dead;
    this.mode = dead ? "gone" : "fly";
    this.dragon.visible = !dead;
    this.beam.visible = false;
  }

  crystalMask() {
    let m = 0;
    this.crystals.forEach((c, i) => {
      if (c.alive) m |= 1 << i;
    });
    return m;
  }

  crystalsLeft() {
    return this.crystals.filter((c) => c.alive).length;
  }

  private buildDragon() {
    const body = 0x241433;
    const wing = 0x5a2d88;
    box(this.dragon, 0, 0, 0, 1.5, 1.1, 3.2, body);
    box(this.dragon, 0, 0.35, -2.1, 0.9, 0.7, 1.3, 0x321848);
    box(this.dragon, 0, 0.55, -2.7, 0.28, 0.18, 0.5, 0x1a1020);
    box(this.dragon, -0.28, 0.72, -2.55, 0.16, 0.16, 0.16, 0xd0a0ff);
    box(this.dragon, 0.28, 0.72, -2.55, 0.16, 0.16, 0.16, 0xd0a0ff);
    for (let i = 0; i < 4; i++) box(this.dragon, 0, 0.05, 1.8 + i * 0.7, 0.7 - i * 0.12, 0.45, 0.6, body);
    const left = box(this.dragon, -2.3, 0.35, -0.2, 3.2, 0.08, 1.5, wing);
    const right = box(this.dragon, 2.3, 0.35, -0.2, 3.2, 0.08, 1.5, wing);
    this.wings = [left, right];
  }

  rayCrystal(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, max: number) {
    let best: { i: number; dist: number } | null = null;
    for (let i = 0; i < this.crystals.length; i++) {
      const c = this.crystals[i]!;
      if (!c.alive) continue;
      const vx = c.x - ox;
      const vy = c.y - oy;
      const vz = c.z - oz;
      const t = vx * dx + vy * dy + vz * dz;
      if (t < 0 || t > max) continue;
      const px = ox + dx * t;
      const py = oy + dy * t;
      const pz = oz + dz * t;
      if ((px - c.x) ** 2 + (py - c.y) ** 2 + (pz - c.z) ** 2 < 0.7 * 0.7 && (!best || t < best.dist)) best = { i, dist: t };
    }
    return best;
  }

  rayDragon(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, max: number) {
    if (this.dead || this.mode === "gone" || this.mode === "dying") return null;
    const vx = this.x - ox;
    const vy = this.y + 0.4 - oy;
    const vz = this.z - oz;
    const t = vx * dx + vy * dy + vz * dz;
    if (t < 0 || t > max) return null;
    const px = ox + dx * t;
    const py = oy + dy * t;
    const pz = oz + dz * t;
    if ((px - this.x) ** 2 + (py - (this.y + 0.4)) ** 2 + (pz - this.z) ** 2 > 2.6 * 2.6) return null;
    return t;
  }

  killCrystal(i: number) {
    const c = this.crystals[i];
    if (!c?.alive) return null;
    c.alive = false;
    c.mesh.visible = false;
    return c;
  }

  hit(dmg: number) {
    if (this.dead || this.mode === "dying" || this.mode === "gone") return false;
    this.hp -= dmg;
    if (this.crystalsLeft() > 0) {
      this.healT = 3.2;
      if (this.hp < 40) this.hp = 40;
    }
    if (this.hp <= 0 && this.crystalsLeft() === 0) {
      this.hp = 0;
      this.beginDeath();
      return true;
    }
    return false;
  }

  private beginDeath() {
    this.mode = "dying";
    this.dead = true;
    this.deathT = 0;
    this.bits = [];
    this.dragon.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        this.bits.push({ mesh: o, v: new THREE.Vector3((Math.random() - 0.5) * 6, 2 + Math.random() * 4, (Math.random() - 0.5) * 6) });
      }
    });
    this.beam.visible = true;
    this.beam.position.set(0, 40, 0);
  }

  update(dt: number) {
    this.time += dt;
    for (let i = 0; i < this.crystals.length; i++) {
      const c = this.crystals[i]!;
      if (!c.alive) continue;
      c.mesh.rotation.y += dt * 0.9;
      c.mesh.position.y = c.base + Math.sin(this.time * 1.7 + i) * 0.16;
      c.y = c.mesh.position.y;
    }
    if (this.mode === "gone") {
      this.dragon.visible = false;
      return null;
    }
    if (this.mode === "dying") {
      this.deathT += dt;
      for (const b of this.bits) {
        b.v.y -= 8 * dt;
        b.mesh.position.addScaledVector(b.v, dt);
        b.mesh.rotation.x += dt * 2;
      }
      this.beam.scale.set(1, 1 + this.deathT * 1.4, 1);
      (this.beam.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.9 - this.deathT / 3.4);
      if (this.deathT > 3.1 && !this.exitSent) {
        this.exitSent = true;
        this.mode = "gone";
        this.dragon.visible = false;
        this.beam.visible = false;
        return "exit" as const;
      }
      return null;
    }
    if (this.healT > 0 && this.crystalsLeft() > 0) {
      this.healT -= dt;
      this.hp = Math.min(this.maxHp, this.hp + dt * 14);
    }
    if (this.mode === "perch") {
      this.perchT -= dt;
      this.x += (0 - this.x) * Math.min(1, dt * 2);
      this.z += (0 - this.z) * Math.min(1, dt * 2);
      this.y += (this.perchY - this.y) * Math.min(1, dt * 2);
      if (this.perchT <= 0) {
        this.mode = "fly";
        this.nextPerch = 14 + Math.random() * 10;
      }
    } else {
      this.ang += dt * 0.35;
      this.nextPerch -= dt;
      this.x = Math.cos(this.ang) * 30;
      this.z = Math.sin(this.ang) * 30;
      this.y = 50 + Math.sin(this.time * 0.8) * 2.2;
      if (this.nextPerch <= 0) {
        this.mode = "perch";
        this.perchT = 6;
      }
    }
    this.dragon.position.set(this.x, this.y, this.z);
    this.dragon.rotation.y = Math.atan2(-Math.cos(this.ang), Math.sin(this.ang));
    const flap = Math.sin(this.time * (this.mode === "perch" ? 2 : 5));
    this.wings[0]!.rotation.z = 0.25 + flap * 0.45;
    this.wings[1]!.rotation.z = -0.25 - flap * 0.45;
    return null;
  }
}
