import {
  AMETHYST,
  AMETHYST_AXE,
  AMETHYST_ORE,
  AMETHYST_PICK,
  AMETHYST_SHOVEL,
  AMETHYST_SWORD,
  BED,
  BEEF,
  BLAZE_POWDER,
  BLAZE_ROD,
  BOAT,
  BUCKET,
  CACTUS,
  CHICKEN_MEAT,
  COAL,
  COOKED_BEEF,
  COOKED_CHICKEN,
  COOKED_MUTTON,
  COOKED_PORK,
  DIA_AXE,
  DIA_PICK,
  DIA_SHOVEL,
  DIA_SWORD,
  DIAMOND,
  DIRT,
  ENDER_PEARL,
  EYE_OF_ENDER,
  FLINT,
  FLINT_STEEL,
  FURNACE,
  GOLD,
  GOLD_AXE,
  GOLD_INGOT,
  GOLD_PICK,
  GOLD_SHOVEL,
  GOLD_SWORD,
  GRASS,
  GRAVEL,
  IRON_AXE,
  IRON_INGOT,
  IRON_ORE,
  IRON_PICK,
  IRON_SHOVEL,
  IRON_SWORD,
  LAVA_BUCKET,
  LEAVES,
  MUTTON,
  OBSIDIAN,
  PLANKS,
  PORK,
  RAW_GOLD,
  RAW_IRON,
  SAND,
  SHIELD,
  SNOW,
  STICK,
  STONE,
  STONE_AXE,
  STONE_PICK,
  STONE_SHOVEL,
  STONE_SWORD,
  WATER_BUCKET,
  WOOD,
  WOOD_AXE,
  WOOD_PICK,
  WOOD_SHOVEL,
  WOOD_SWORD,
  WOOL,
  type ItemStack,
} from "./types";

export type ToolKind = "axe" | "pick" | "shovel" | "sword" | "shield";
export type ToolTier = "wood" | "stone" | "iron" | "gold" | "amethyst" | "diamond";

const TOOLS = new Set([
  WOOD_AXE,
  WOOD_PICK,
  WOOD_SHOVEL,
  WOOD_SWORD,
  STONE_AXE,
  STONE_PICK,
  STONE_SHOVEL,
  STONE_SWORD,
  IRON_AXE,
  IRON_PICK,
  IRON_SHOVEL,
  IRON_SWORD,
  GOLD_AXE,
  GOLD_PICK,
  GOLD_SHOVEL,
  GOLD_SWORD,
  AMETHYST_AXE,
  AMETHYST_PICK,
  AMETHYST_SHOVEL,
  AMETHYST_SWORD,
  DIA_AXE,
  DIA_PICK,
  DIA_SHOVEL,
  DIA_SWORD,
  SHIELD,
  FLINT_STEEL,
]);

const PLACEABLE = new Set([
  GRASS,
  DIRT,
  STONE,
  WOOD,
  LEAVES,
  COAL,
  GOLD,
  DIAMOND,
  SAND,
  SNOW,
  PLANKS,
  CACTUS,
  IRON_ORE,
  AMETHYST_ORE,
  GRAVEL,
  OBSIDIAN,
  FURNACE,
  WOOL,
  BED,
]);

const NAMES: Record<number, string> = {
  [STICK]: "Çubuk",
  [WOOD_AXE]: "Tahta Balta",
  [WOOD_PICK]: "Tahta Kazma",
  [WOOD_SHOVEL]: "Tahta Kürek",
  [WOOD_SWORD]: "Tahta Kılıç",
  [STONE_AXE]: "Taş Balta",
  [STONE_PICK]: "Taş Kazma",
  [STONE_SHOVEL]: "Taş Kürek",
  [STONE_SWORD]: "Taş Kılıç",
  [IRON_AXE]: "Demir Balta",
  [IRON_PICK]: "Demir Kazma",
  [IRON_SHOVEL]: "Demir Kürek",
  [IRON_SWORD]: "Demir Kılıç",
  [GOLD_AXE]: "Altın Balta",
  [GOLD_PICK]: "Altın Kazma",
  [GOLD_SHOVEL]: "Altın Kürek",
  [GOLD_SWORD]: "Altın Kılıç",
  [AMETHYST_AXE]: "Ametist Balta",
  [AMETHYST_PICK]: "Ametist Kazma",
  [AMETHYST_SHOVEL]: "Ametist Kürek",
  [AMETHYST_SWORD]: "Ametist Kılıç",
  [DIA_AXE]: "Elmas Balta",
  [DIA_PICK]: "Elmas Kazma",
  [DIA_SHOVEL]: "Elmas Kürek",
  [DIA_SWORD]: "Elmas Kılıç",
  [SHIELD]: "Kalkan",
  [PORK]: "Domuz Eti",
  [BEEF]: "Sığır Eti",
  [MUTTON]: "Koyun Eti",
  [CHICKEN_MEAT]: "Tavuk Eti",
  [COOKED_PORK]: "Pişmiş Domuz",
  [COOKED_BEEF]: "Biftek",
  [COOKED_MUTTON]: "Pişmiş Koyun",
  [COOKED_CHICKEN]: "Pişmiş Tavuk",
  [RAW_IRON]: "Ham Demir",
  [RAW_GOLD]: "Ham Altın",
  [IRON_INGOT]: "Demir Külçesi",
  [GOLD_INGOT]: "Altın Külçesi",
  [AMETHYST]: "Ametist",
  [BUCKET]: "Kova",
  [WATER_BUCKET]: "Su Kovası",
  [LAVA_BUCKET]: "Lav Kovası",
  [FLINT]: "Çakmak Taşı",
  [FLINT_STEEL]: "Çakmak",
  [BLAZE_ROD]: "Blaze Çubuğu",
  [BLAZE_POWDER]: "Blaze Tozu",
  [ENDER_PEARL]: "Ender Gözü",
  [EYE_OF_ENDER]: "End Gözü",
  [BOAT]: "Tekne",
};

export function isTool(id: number): boolean {
  return TOOLS.has(id);
}

export function isPlaceable(id: number): boolean {
  return PLACEABLE.has(id);
}

export function itemName(id: number): string {
  return NAMES[id] ?? "";
}

export function toolKind(id: number): ToolKind | null {
  if (id === SHIELD) return "shield";
  if (id === WOOD_AXE || id === STONE_AXE || id === IRON_AXE || id === GOLD_AXE || id === AMETHYST_AXE || id === DIA_AXE)
    return "axe";
  if (id === WOOD_PICK || id === STONE_PICK || id === IRON_PICK || id === GOLD_PICK || id === AMETHYST_PICK || id === DIA_PICK)
    return "pick";
  if (
    id === WOOD_SHOVEL ||
    id === STONE_SHOVEL ||
    id === IRON_SHOVEL ||
    id === GOLD_SHOVEL ||
    id === AMETHYST_SHOVEL ||
    id === DIA_SHOVEL
  )
    return "shovel";
  if (id === WOOD_SWORD || id === STONE_SWORD || id === IRON_SWORD || id === GOLD_SWORD || id === AMETHYST_SWORD || id === DIA_SWORD)
    return "sword";
  return null;
}

export function toolTier(id: number): ToolTier | null {
  if (id === SHIELD) return "wood";
  if (id >= WOOD_AXE && id <= WOOD_SWORD) return "wood";
  if (id >= STONE_AXE && id <= STONE_SWORD) return "stone";
  if (id >= GOLD_AXE && id <= GOLD_SWORD) return "gold";
  if (id >= DIA_AXE && id <= DIA_SWORD) return "diamond";
  if (id >= IRON_AXE && id <= IRON_SWORD) return "iron";
  if (id >= AMETHYST_AXE && id <= AMETHYST_SWORD) return "amethyst";
  return null;
}

const TIER_MUL: Record<ToolTier, number> = {
  wood: 0.72,
  stone: 0.48,
  iron: 0.36,
  gold: 0.28,
  amethyst: 0.26,
  diamond: 0.2,
};

const TIER_RANK: Record<ToolTier, number> = {
  wood: 0,
  stone: 1,
  iron: 2,
  gold: 2,
  amethyst: 3,
  diamond: 4,
};

export function mineDuration(blockId: number, hardness: number, held: number): number {
  if (blockId === OBSIDIAN) {
    const kind = toolKind(held);
    const tier = toolTier(held);
    if (kind === "pick" && tier === "diamond") return 9.4;
    return 250;
  }
  const kind = toolKind(held);
  const tier = toolTier(held);
  let mul = 1;
  if (kind && tier) {
    mul = TIER_MUL[tier];
    const woodish = blockId === WOOD || blockId === LEAVES || blockId === PLANKS || blockId === CACTUS;
    const stoneish =
      blockId === STONE ||
      blockId === COAL ||
      blockId === GOLD ||
      blockId === DIAMOND ||
      blockId === IRON_ORE ||
      blockId === AMETHYST_ORE ||
      blockId === FURNACE ||
      blockId === OBSIDIAN;
    const dirtish = blockId === DIRT || blockId === GRASS || blockId === SAND || blockId === SNOW || blockId === GRAVEL;
    if (kind === "axe" && woodish) mul *= 0.45;
    else if (kind === "pick" && stoneish) mul *= 0.4;
    else if (kind === "shovel" && dirtish) mul *= 0.4;
    else if (kind === "sword") mul *= 0.85;
    else if (kind === "shield") mul = 1;
    else mul *= 1.05;
  }
  if (!canHarvest(blockId, held) && isMine(blockId)) mul *= 2.4;
  return Math.max(0.08, hardness * mul);
}

export function isMine(id: number): boolean {
  return (
    id === STONE ||
    id === COAL ||
    id === GOLD ||
    id === DIAMOND ||
    id === IRON_ORE ||
    id === AMETHYST_ORE ||
    id === OBSIDIAN ||
    id === FURNACE
  );
}

export function canHarvest(blockId: number, held: number): boolean {
  const kind = toolKind(held);
  const tier = toolTier(held);
  if (blockId === STONE || blockId === COAL || blockId === FURNACE) return kind === "pick";
  if (blockId === IRON_ORE) return kind === "pick" && tier !== "wood" && tier !== null;
  if (blockId === GOLD || blockId === AMETHYST_ORE || blockId === DIAMOND)
    return kind === "pick" && !!tier && TIER_RANK[tier] >= 2;
  if (blockId === OBSIDIAN) return kind === "pick" && tier === "diamond";
  return true;
}

export function canFinishMine(blockId: number, held: number): boolean {
  if (blockId === GOLD || blockId === DIAMOND || blockId === AMETHYST_ORE || blockId === OBSIDIAN || blockId === IRON_ORE)
    return canHarvest(blockId, held);
  return true;
}

export function itemColor(id: number): number {
  const t = toolTier(id);
  if (t === "diamond") return 0x5ee0c8;
  if (t === "amethyst") return 0xb46cff;
  if (t === "gold") return 0xd4b15a;
  if (t === "iron") return 0xc4c8ce;
  if (t === "stone") return 0x8a93a0;
  if (t === "wood") return 0x8a5a2b;
  if (id === STICK) return 0x6b4423;
  if (id === SHIELD) return 0x7a4e28;
  if (id === PORK || id === COOKED_PORK) return 0xe07a7a;
  if (id === BEEF || id === COOKED_BEEF) return 0xa33c32;
  if (id === MUTTON || id === COOKED_MUTTON) return 0xc45a52;
  if (id === CHICKEN_MEAT || id === COOKED_CHICKEN) return 0xe8c4a0;
  if (id === IRON_INGOT || id === RAW_IRON) return 0xb8bdc4;
  if (id === GOLD_INGOT || id === RAW_GOLD) return 0xe0c05a;
  if (id === AMETHYST) return 0xb46cff;
  if (id === BUCKET || id === WATER_BUCKET || id === LAVA_BUCKET) return 0x8a9098;
  if (id === FLINT || id === FLINT_STEEL) return 0x3a3a3a;
  if (id === BLAZE_ROD || id === BLAZE_POWDER) return 0xf0c040;
  if (id === ENDER_PEARL) return 0x1a6a5a;
  if (id === EYE_OF_ENDER) return 0x49c878;
  if (id === BOAT) return 0x8a5a2a;
  return 0x9aa08a;
}

export function isFood(id: number): boolean {
  return (
    id === PORK ||
    id === BEEF ||
    id === MUTTON ||
    id === CHICKEN_MEAT ||
    id === COOKED_PORK ||
    id === COOKED_BEEF ||
    id === COOKED_MUTTON ||
    id === COOKED_CHICKEN
  );
}

export function foodStats(id: number): { hunger: number; saturation: number } | null {
  if (id === PORK) return { hunger: 3, saturation: 1.8 };
  if (id === BEEF) return { hunger: 3, saturation: 1.8 };
  if (id === MUTTON) return { hunger: 2, saturation: 1.2 };
  if (id === CHICKEN_MEAT) return { hunger: 2, saturation: 1.2 };
  if (id === COOKED_PORK) return { hunger: 8, saturation: 12.8 };
  if (id === COOKED_BEEF) return { hunger: 8, saturation: 12.8 };
  if (id === COOKED_MUTTON) return { hunger: 6, saturation: 9.6 };
  if (id === COOKED_CHICKEN) return { hunger: 6, saturation: 7.2 };
  return null;
}

export function attackDamage(held: number): number {
  const kind = toolKind(held);
  const tier = toolTier(held);
  if (kind === "sword") {
    if (tier === "diamond") return 7;
    if (tier === "amethyst") return 6;
    if (tier === "iron") return 6;
    if (tier === "stone") return 5;
    if (tier === "gold") return 4;
    if (tier === "wood") return 4;
  }
  if (kind === "axe") {
    if (tier === "diamond") return 5;
    if (tier === "amethyst") return 5;
    if (tier === "iron") return 5;
    if (tier === "stone") return 4;
    if (tier === "gold") return 3;
    if (tier === "wood") return 3;
  }
  if (kind === "pick" || kind === "shovel") return 2;
  return 2;
}

export function maxDurability(id: number): number {
  if (id === FLINT_STEEL) return 64;
  if (id === SHIELD) return 336;
  const tier = toolTier(id);
  if (!tier || !toolKind(id)) return 0;
  if (tier === "wood") return 59;
  if (tier === "stone") return 131;
  if (tier === "iron") return 250;
  if (tier === "gold") return 32;
  if (tier === "amethyst") return 400;
  if (tier === "diamond") return 1561;
  return 0;
}

export function makeStack(id: number, count = 1): ItemStack {
  const dur = maxDurability(id);
  return dur > 0 ? { id, count: 1, dur } : { id, count };
}

export function wearStack(slot: ItemStack | null, n = 1): boolean {
  if (!slot) return false;
  const max = maxDurability(slot.id);
  if (max <= 0) return false;
  if (slot.dur == null) slot.dur = max;
  slot.dur -= n;
  return slot.dur <= 0;
}
