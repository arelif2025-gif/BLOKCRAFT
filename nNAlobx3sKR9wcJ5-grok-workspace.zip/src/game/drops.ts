import * as THREE from "three";
import { isSolid } from "./blocks";
import { isPlaceable, isTool, itemColor } from "./items";
import { makeBlockGeometry } from "./mesher";
import { chunkKey, worldToChunk, type World } from "./world";
import type { GroundDrop } from "./types";

type Ent = {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  id: number;
  count: number;
  age: number;
  mesh: THREE.Object3D;
  onGround: boolean;
};

const GRAVITY = 18;
const MAX_FALL = 12;
const SURFACE = 0.08;
const PICK_DELAY = 0.85;
const PICK_RANGE = 1.15;
const LIFETIME = 300;

export class DropWorld {
  group = new THREE.Group();
  private items: Ent[] = [];
  private blockMat: THREE.Material;
  private cache = new Map<number, THREE.BufferGeometry>();

  constructor(blockMat: THREE.Material) {
    this.blockMat = blockMat;
  }

  spawn(x: number, y: number, z: number, id: number, count = 1, launch = true) {
    if (this.items.length > 80) {
      const old = this.items.shift();
      if (old) this.group.remove(old.mesh);
    }
    const mesh = this.makeMesh(id);
    mesh.position.set(x, y, z);
    this.group.add(mesh);
    this.items.push({
      x,
      y,
      z,
      vx: launch ? (Math.random() - 0.5) * 0.9 : 0,
      vy: launch ? 1.4 + Math.random() * 0.4 : 0,
      vz: launch ? (Math.random() - 0.5) * 0.9 : 0,
      id,
      count,
      age: 0,
      mesh,
      onGround: !launch,
    });
  }

  toss(x: number, y: number, z: number, id: number, count: number, vx: number, vy: number, vz: number) {
    this.spawn(x, y, z, id, count, false);
    const e = this.items[this.items.length - 1];
    if (!e) return;
    e.vx = vx;
    e.vy = vy;
    e.vz = vz;
    e.onGround = false;
  }

  load(list: GroundDrop[]) {
    for (const d of list) this.spawn(d.x, d.y, d.z, d.id, d.count, false);
  }

  snapshot(): GroundDrop[] {
    return this.items.map((e) => ({ x: e.x, y: e.y, z: e.z, id: e.id, count: e.count }));
  }

  update(dt: number, world: World, px: number, py: number, pz: number, take: (id: number, n: number) => boolean) {
    if (dt > 0.08) dt = 0.08;
    const keep: Ent[] = [];
    const steps = Math.max(1, Math.ceil(dt / (1 / 90)));
    const h = dt / steps;
    for (const e of this.items) {
      e.age += dt;
      for (let s = 0; s < steps; s++) this.step(e, world, h);

      if (e.y < 0.08) {
        e.y = 0.08;
        e.vy = 0;
        e.vx = 0;
        e.vz = 0;
        e.onGround = true;
      }

      const spin = e.age * 1.6;
      const bob = e.onGround ? Math.sin(e.age * 2.4) * 0.04 : 0;
      e.mesh.position.set(e.x, e.y + 0.16 + bob, e.z);
      e.mesh.rotation.set(0.22, spin, 0.12);

      const dx = e.x - px;
      const dy = e.y - (py + 0.7);
      const dz = e.z - pz;
      const dist = Math.hypot(dx, dy, dz);
      if (e.age > PICK_DELAY && dist < PICK_RANGE) {
        if (take(e.id, e.count)) {
          this.group.remove(e.mesh);
          continue;
        }
      }
      if (e.age > LIFETIME) {
        this.group.remove(e.mesh);
        continue;
      }
      keep.push(e);
    }
    this.items = keep;
  }

  private step(e: Ent, world: World, dt: number) {
    this.unstick(e, world);
    e.vy -= GRAVITY * dt;
    if (e.vy < -MAX_FALL) e.vy = -MAX_FALL;

    if (e.onGround && Math.abs(e.vx) < 0.02 && Math.abs(e.vz) < 0.02 && e.vy <= 0) {
      e.vx = 0;
      e.vz = 0;
      const support = Math.floor(e.y - SURFACE - 0.05);
      if (this.blocked(world, e.x, support, e.z)) {
        e.vy = 0;
        e.y = support + 1 + SURFACE;
        return;
      }
      e.onGround = false;
    }

    this.moveX(e, world, e.vx * dt);
    this.moveZ(e, world, e.vz * dt);
    this.moveY(e, world, e.vy * dt);

    if (e.onGround) {
      e.vx *= 0.72;
      e.vz *= 0.72;
      if (Math.abs(e.vx) < 0.03) e.vx = 0;
      if (Math.abs(e.vz) < 0.03) e.vz = 0;
    }
  }

  private moveX(e: Ent, world: World, dx: number) {
    if (!dx) return;
    const nx = e.x + dx;
    if (this.blocked(world, nx, e.y + SURFACE, e.z) || this.blocked(world, nx, e.y + 0.22, e.z)) {
      e.vx *= -0.2;
      return;
    }
    e.x = nx;
  }

  private moveZ(e: Ent, world: World, dz: number) {
    if (!dz) return;
    const nz = e.z + dz;
    if (this.blocked(world, e.x, e.y + SURFACE, nz) || this.blocked(world, e.x, e.y + 0.22, nz)) {
      e.vz *= -0.2;
      return;
    }
    e.z = nz;
  }

  private moveY(e: Ent, world: World, dy: number) {
    if (!dy) return;
    if (dy < 0) {
      const y0 = e.y;
      const y1 = e.y + dy;
      const from = Math.floor(y0);
      const to = Math.floor(y1);
      for (let by = from; by >= to; by--) {
        if (!this.blocked(world, e.x, by, e.z)) continue;
        const top = by + 1;
        if (y0 >= top - 0.001) {
          e.y = top + SURFACE;
          e.vy = 0;
          e.onGround = true;
          e.vx *= 0.55;
          e.vz *= 0.55;
          return;
        }
      }
      e.y = y1;
      e.onGround = false;
      return;
    }
    const ny = e.y + dy;
    if (this.blocked(world, e.x, ny + 0.28, e.z)) {
      e.vy = 0;
      return;
    }
    e.y = ny;
    e.onGround = false;
  }

  private unstick(e: Ent, world: World) {
    let guard = 0;
    while (guard++ < 12 && this.blocked(world, e.x, e.y, e.z)) {
      const by = Math.floor(e.y);
      e.y = by + 1 + SURFACE;
      e.vy = 0;
      e.onGround = true;
    }
  }

  private blocked(world: World, x: number, y: number, z: number) {
    if (y < 0) return true;
    const ix = Math.floor(x);
    const iy = Math.floor(y);
    const iz = Math.floor(z);
    const [cx, cz] = worldToChunk(ix, iz);
    if (!world.chunks.has(chunkKey(cx, cz))) return true;
    return isSolid(world.getBlock(ix, iy, iz));
  }

  private makeMesh(id: number): THREE.Object3D {
    if (isPlaceable(id)) {
      let geo = this.cache.get(id);
      if (!geo) {
        geo = makeBlockGeometry(id);
        this.cache.set(id, geo);
      }
      const m = new THREE.Mesh(geo, this.blockMat);
      m.scale.setScalar(0.28);
      return m;
    }
    const g = new THREE.Group();
    const col = itemColor(id);
    const box = new THREE.Mesh(
      new THREE.BoxGeometry(isTool(id) ? 0.12 : 0.18, isTool(id) ? 0.32 : 0.18, 0.08),
      new THREE.MeshLambertMaterial({ color: col }),
    );
    g.add(box);
    return g;
  }

  clear() {
    for (const it of this.items) this.group.remove(it.mesh);
    this.items = [];
  }

  dispose() {
    this.group.removeFromParent();
    for (const g of this.cache.values()) g.dispose();
  }
}
