import {
  AMETHYST,
  AMETHYST_AXE,
  AMETHYST_PICK,
  AMETHYST_SHOVEL,
  AMETHYST_SWORD,
  BED,
  BUCKET,
  DIA_AXE,
  DIA_PICK,
  DIA_SHOVEL,
  DIA_SWORD,
  DIAMOND,
  FLINT,
  FLINT_STEEL,
  FURNACE,
  GOLD_AXE,
  GOLD_INGOT,
  GOLD_PICK,
  GOLD_SHOVEL,
  GOLD_SWORD,
  IRON_AXE,
  IRON_INGOT,
  IRON_PICK,
  IRON_SHOVEL,
  IRON_SWORD,
  PLANKS,
  SHIELD,
  STICK,
  STONE,
  STONE_AXE,
  STONE_PICK,
  STONE_SHOVEL,
  STONE_SWORD,
  WOOD,
  WOOD_AXE,
  WOOD_PICK,
  WOOD_SHOVEL,
  WOOD_SWORD,
  WOOL,
  BLAZE_POWDER,
  BLAZE_ROD,
  BOAT,
  ENDER_PEARL,
  EYE_OF_ENDER,
  type ItemStack,
} from "./types";
import { isTool, makeStack } from "./items";

export type Recipe = {
  id: string;
  name: string;
  out: ItemStack;
  shapeless?: ItemStack[];
  shaped?: Array<number | 0>;
};

const S = STICK;

function tools(prefix: string, mat: number, axe: number, pick: number, shovel: number, sword: number): Recipe[] {
  return [
    {
      id: `pick-${mat}`,
      name: `${prefix} Kazma`,
      out: makeStack(pick),
      shaped: [mat, mat, mat, 0, S, 0, 0, S, 0],
    },
    {
      id: `axe-${mat}`,
      name: `${prefix} Balta`,
      out: makeStack(axe),
      shaped: [mat, mat, 0, mat, S, 0, 0, S, 0],
    },
    {
      id: `shovel-${mat}`,
      name: `${prefix} Kürek`,
      out: makeStack(shovel),
      shaped: [0, mat, 0, 0, S, 0, 0, S, 0],
    },
    {
      id: `sword-${mat}`,
      name: `${prefix} Kılıç`,
      out: makeStack(sword),
      shaped: [0, mat, 0, 0, mat, 0, 0, S, 0],
    },
  ];
}

export const RECIPES: Recipe[] = [
  { id: "planks", name: "Tahta ×4", out: { id: PLANKS, count: 4 }, shapeless: [{ id: WOOD, count: 1 }] },
  { id: "sticks", name: "Çubuk ×4", out: { id: STICK, count: 4 }, shapeless: [{ id: PLANKS, count: 1 }] },
  ...tools("Tahta", PLANKS, WOOD_AXE, WOOD_PICK, WOOD_SHOVEL, WOOD_SWORD),
  ...tools("Taş", STONE, STONE_AXE, STONE_PICK, STONE_SHOVEL, STONE_SWORD),
  ...tools("Demir", IRON_INGOT, IRON_AXE, IRON_PICK, IRON_SHOVEL, IRON_SWORD),
  ...tools("Altın", GOLD_INGOT, GOLD_AXE, GOLD_PICK, GOLD_SHOVEL, GOLD_SWORD),
  ...tools("Ametist", AMETHYST, AMETHYST_AXE, AMETHYST_PICK, AMETHYST_SHOVEL, AMETHYST_SWORD),
  ...tools("Elmas", DIAMOND, DIA_AXE, DIA_PICK, DIA_SHOVEL, DIA_SWORD),
  {
    id: "shield",
    name: "Kalkan",
    out: makeStack(SHIELD),
    shaped: [PLANKS, PLANKS, PLANKS, PLANKS, 0, PLANKS, 0, PLANKS, 0],
  },
  {
    id: "furnace",
    name: "Fırın",
    out: { id: FURNACE, count: 1 },
    shapeless: Array.from({ length: 9 }, () => ({ id: STONE, count: 1 })),
  },
  {
    id: "bucket",
    name: "Kova",
    out: { id: BUCKET, count: 1 },
    shaped: [0, 0, 0, IRON_INGOT, 0, IRON_INGOT, 0, IRON_INGOT, 0],
  },
  {
    id: "bed",
    name: "Yatak",
    out: { id: BED, count: 1 },
    shaped: [WOOL, WOOL, WOOL, PLANKS, PLANKS, PLANKS, 0, 0, 0],
  },
  {
    id: "flint-steel",
    name: "Çakmak",
    out: makeStack(FLINT_STEEL),
    shapeless: [
      { id: IRON_INGOT, count: 1 },
      { id: FLINT, count: 1 },
    ],
  },
  {
    id: "boat",
    name: "Tekne",
    out: { id: BOAT, count: 1 },
    shaped: [PLANKS, 0, PLANKS, PLANKS, PLANKS, PLANKS, 0, 0, 0],
  },
  {
    id: "blaze-powder",
    name: "Blaze Tozu ×2",
    out: { id: BLAZE_POWDER, count: 2 },
    shapeless: [{ id: BLAZE_ROD, count: 1 }],
  },
  {
    id: "eye",
    name: "End Gözü",
    out: { id: EYE_OF_ENDER, count: 1 },
    shapeless: [
      { id: ENDER_PEARL, count: 1 },
      { id: BLAZE_POWDER, count: 1 },
    ],
  },
];

function normalizeShape(cells: Array<number | 0>): string {
  const g = cells.map((v) => v || 0);
  const rowHas = [0, 1, 2].map((r) => g[r * 3] || g[r * 3 + 1] || g[r * 3 + 2]);
  const colHas = [0, 1, 2].map((c) => g[c] || g[3 + c] || g[6 + c]);
  const r0 = rowHas[0] ? 0 : rowHas[1] ? 1 : 2;
  const r1 = rowHas[2] ? 2 : rowHas[1] ? 1 : 0;
  const c0 = colHas[0] ? 0 : colHas[1] ? 1 : 2;
  const c1 = colHas[2] ? 2 : colHas[1] ? 1 : 0;
  const parts: number[] = [];
  for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) parts.push(g[r * 3 + c] || 0);
  return `${r1 - r0 + 1}x${c1 - c0 + 1}:${parts.join(",")}`;
}

export function matchRecipe(grid: Array<ItemStack | null>): Recipe | null {
  const filled = grid.filter((s) => s && s.count > 0) as ItemStack[];
  if (!filled.length) return null;

  for (const rec of RECIPES) {
    if (rec.shapeless) {
      if (filled.length !== rec.shapeless.length) continue;
      const used = new Set<number>();
      let ok = true;
      for (const need of rec.shapeless) {
        const i = filled.findIndex((s, idx) => !used.has(idx) && s.id === need.id && s.count >= need.count);
        if (i < 0) {
          ok = false;
          break;
        }
        used.add(i);
      }
      if (ok) return rec;
    }
    if (rec.shaped) {
      if (normalizeShape(grid.map((s) => (s && s.count > 0 ? s.id : 0))) === normalizeShape(rec.shaped)) return rec;
    }
  }
  return null;
}

export function consumeGrid(grid: Array<ItemStack | null>, rec: Recipe) {
  if (rec.shapeless) {
    for (const need of rec.shapeless) {
      const slot = grid.find((s) => s && s.id === need.id && s.count >= need.count);
      if (!slot) continue;
      slot.count -= need.count;
    }
  } else {
    for (let i = 0; i < grid.length; i++) {
      const s = grid[i];
      if (!s) continue;
      s.count -= 1;
    }
  }
  for (let i = 0; i < grid.length; i++) {
    if (grid[i] && grid[i]!.count <= 0) grid[i] = null;
  }
}

export function countItem(bags: Array<Array<ItemStack | null>>, id: number): number {
  let n = 0;
  for (const bag of bags) for (const s of bag) if (s?.id === id) n += s.count;
  return n;
}

export function takeItems(bags: Array<Array<ItemStack | null>>, id: number, n: number): boolean {
  if (countItem(bags, id) < n) return false;
  let left = n;
  for (const bag of bags) {
    for (let i = 0; i < bag.length && left > 0; i++) {
      const s = bag[i];
      if (!s || s.id !== id) continue;
      const take = Math.min(s.count, left);
      s.count -= take;
      left -= take;
      if (s.count <= 0) bag[i] = null;
    }
  }
  return left === 0;
}

export function canCraft(rec: Recipe, bags: Array<Array<ItemStack | null>>): boolean {
  const need = new Map<number, number>();
  if (rec.shapeless) {
    for (const s of rec.shapeless) need.set(s.id, (need.get(s.id) ?? 0) + s.count);
  } else if (rec.shaped) {
    for (const id of rec.shaped) if (id) need.set(id, (need.get(id) ?? 0) + 1);
  }
  for (const [id, n] of need) if (countItem(bags, id) < n) return false;
  return true;
}

export function craftInto(
  rec: Recipe,
  bags: Array<Array<ItemStack | null>>,
  dest: Array<ItemStack | null>,
): boolean {
  if (!canCraft(rec, bags)) return false;
  const need = new Map<number, number>();
  if (rec.shapeless) {
    for (const s of rec.shapeless) need.set(s.id, (need.get(s.id) ?? 0) + s.count);
  } else if (rec.shaped) {
    for (const id of rec.shaped) if (id) need.set(id, (need.get(id) ?? 0) + 1);
  }
  for (const [id, n] of need) takeItems(bags, id, n);
  let left = rec.out.count;
  const outId = rec.out.id;
  const dur = rec.out.dur;
  for (const bag of [dest, ...bags]) {
    for (let i = 0; i < bag.length && left > 0; i++) {
      const s = bag[i];
      if (s && s.id === outId && !isTool(s.id) && s.count < 64) {
        const room = 64 - s.count;
        const take = Math.min(room, left);
        s.count += take;
        left -= take;
      } else if (!s) {
        const take = isTool(outId) ? 1 : Math.min(64, left);
        bag[i] = dur != null ? { id: outId, count: take, dur } : { id: outId, count: take };
        left -= take;
      }
    }
  }
  return left === 0;
}
