export const AIR = 0;
export const GRASS = 1;
export const DIRT = 2;
export const STONE = 3;
export const WOOD = 4;
export const LEAVES = 5;
export const COAL = 6;
export const GOLD = 7;
export const DIAMOND = 8;
export const BEDROCK = 9;
export const SAND = 10;
export const SNOW = 11;
export const WATER = 12;
export const PLANKS = 13;
export const CACTUS = 14;
export const IRON_ORE = 15;
export const AMETHYST_ORE = 16;
export const GRAVEL = 17;
export const LAVA = 18;
export const OBSIDIAN = 19;
export const FURNACE = 44;
export const WOOL = 45;
export const BED = 46;
export const PORTAL = 47;

export const STICK = 20;
export const WOOD_AXE = 21;
export const WOOD_PICK = 22;
export const WOOD_SHOVEL = 23;
export const WOOD_SWORD = 24;
export const STONE_AXE = 25;
export const STONE_PICK = 26;
export const STONE_SHOVEL = 27;
export const STONE_SWORD = 28;
export const GOLD_AXE = 29;
export const GOLD_PICK = 30;
export const GOLD_SHOVEL = 31;
export const GOLD_SWORD = 32;
export const DIA_AXE = 33;
export const DIA_PICK = 34;
export const DIA_SHOVEL = 35;
export const DIA_SWORD = 36;
export const SHIELD = 37;

export const PORK = 40;
export const BEEF = 41;
export const MUTTON = 42;
export const CHICKEN_MEAT = 43;

export const RAW_IRON = 48;
export const RAW_GOLD = 49;
export const IRON_INGOT = 50;
export const GOLD_INGOT = 51;
export const AMETHYST = 52;
export const COOKED_PORK = 53;
export const COOKED_BEEF = 54;
export const COOKED_MUTTON = 55;
export const COOKED_CHICKEN = 56;
export const BUCKET = 57;
export const WATER_BUCKET = 58;
export const LAVA_BUCKET = 59;
export const FLINT = 60;
export const FLINT_STEEL = 61;

export const NETHERRACK = 62;
export const NETHER_BRICK = 63;
export const BOOKSHELF = 64;
export const END_FRAME = 65;
export const END_FRAME_EYE = 66;
export const END_PORTAL = 67;
export const END_STONE = 85;

export const BLAZE_ROD = 80;
export const BLAZE_POWDER = 81;
export const ENDER_PEARL = 82;
export const EYE_OF_ENDER = 83;
export const BOAT = 84;

export const IRON_AXE = 70;
export const IRON_PICK = 71;
export const IRON_SHOVEL = 72;
export const IRON_SWORD = 73;
export const AMETHYST_AXE = 74;
export const AMETHYST_PICK = 75;
export const AMETHYST_SHOVEL = 76;
export const AMETHYST_SWORD = 77;

export const AXE = WOOD_AXE;
export const SWORD = DIA_SWORD;

export const CHUNK_W = 16;
export const CHUNK_H = 64;
export const CHUNK_D = 16;
export const SEA_LEVEL = 18;

export const MAX_STACK = 64;
export const HOTBAR_SIZE = 10;
export const INV_SIZE = 27;
export const ARMOR_SIZE = 4;
export const MAX_HEALTH = 20;
export const MAX_FOOD = 20;
export const CRAFT_SIZE = 9;

export const BIOME_OCEAN = 0;
export const BIOME_PLAINS = 1;
export const BIOME_FOREST = 2;
export const BIOME_DESERT = 3;
export const BIOME_SNOW = 4;

export type BlockId = number;
export type ItemStack = { id: number; count: number; dur?: number };
export type BiomeId = 0 | 1 | 2 | 3 | 4;

export type GamePhase = "title" | "loading" | "playing" | "paused" | "inventory" | "crafting" | "furnace" | "credits";

export type HudSnapshot = {
  health: number;
  food: number;
  air: number;
  hotbar: Array<ItemStack | null>;
  selectedSlot: number;
  inventory: Array<ItemStack | null>;
  armor: Array<ItemStack | null>;
  offhand: ItemStack | null;
  dayPhase: number;
  isDay: boolean;
  fps: number;
  x: number;
  y: number;
  z: number;
  yaw: number;
  targetName: string | null;
  breaking: number;
  held: ItemStack | null;
  canResume: boolean;
  biome: string;
  sneaking: boolean;
  inWater: boolean;
  blocking: boolean;
  sleeping: boolean;
  sleep: number;
  toast: string | null;
};

export type Settings = {
  sensitivity: number;
  renderDistance: number;
  volume: number;
};

export type GroundDrop = {
  x: number;
  y: number;
  z: number;
  id: number;
  count: number;
};

export type FurnaceSave = {
  x: number;
  y: number;
  z: number;
  input: ItemStack | null;
  fuel: ItemStack | null;
  out: ItemStack | null;
  cook: number;
  burn: number;
  burnMax: number;
};
