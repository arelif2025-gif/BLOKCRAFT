import * as THREE from "three";
import { isSolid, isWater } from "./blocks";
import type { Mob } from "./mobs";
import type { World } from "./world";

export type Boat = {
  id: number;
  x: number;
  y: number;
  z: number;
  vx: number;
  vz: number;
  yaw: number;
  vy: number;
  player: boolean;
  rider: Mob | null;
  mesh: THREE.Group;
};

export class BoatWorld {
  group = new THREE.Group();
  boats: Boat[] = [];
  private next = 1;

  spawn(x: number, y: number, z: number): Boat {
    const mesh = new THREE.Group();
    const hull = new THREE.Mesh(
      new THREE.BoxGeometry(0.9, 0.28, 1.35),
      new THREE.MeshLambertMaterial({ color: 0x8a5a2a }),
    );
    hull.position.y = 0.16;
    const rim = new THREE.Mesh(
      new THREE.BoxGeometry(1.02, 0.16, 1.48),
      new THREE.MeshLambertMaterial({ color: 0x6b4120 }),
    );
    rim.position.y = 0.32;
    mesh.add(hull, rim);
    mesh.position.set(x, y, z);
    this.group.add(mesh);
    const boat: Boat = { id: this.next++, x, y, z, vx: 0, vz: 0, vy: 0, yaw: 0, player: false, rider: null, mesh };
    this.boats.push(boat);
    return boat;
  }

  get playerBoat(): Boat | null {
    return this.boats.find((b) => b.player) ?? null;
  }

  drive(dt: number, mx: number, mz: number, yaw: number) {
    const b = this.playerBoat;
    if (!b) return;
    b.yaw = yaw;
    const f = mz * 7.4;
    const s = mx * 4.2;
    const tx = -Math.sin(yaw) * f + Math.cos(yaw) * s;
    const tz = -Math.cos(yaw) * f - Math.sin(yaw) * s;
    b.vx += (tx - b.vx) * Math.min(1, 6 * dt);
    b.vz += (tz - b.vz) * Math.min(1, 6 * dt);
  }

  dismountPlayer() {
    const b = this.playerBoat;
    if (!b) return;
    b.player = false;
    b.vx = 0;
    b.vz = 0;
  }

  mountPlayer(b: Boat) {
    for (const o of this.boats) o.player = false;
    if (b.rider) {
      b.rider.ride = 0;
      b.rider = null;
    }
    b.player = true;
  }

  ray(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, max = 4): { boat: Boat; dist: number } | null {
    let best: { boat: Boat; dist: number } | null = null;
    for (const b of this.boats) {
      const vx = b.x - ox;
      const vy = b.y + 0.3 - oy;
      const vz = b.z - oz;
      const dist = Math.hypot(vx, vy, vz);
      if (dist > max || dist < 0.05) continue;
      const dot = (vx / dist) * dx + (vy / dist) * dy + (vz / dist) * dz;
      if (dot < 0.72) continue;
      if (!best || dist < best.dist) best = { boat: b, dist };
    }
    return best;
  }

  update(dt: number, world: World, mobs: Mob[]) {
    for (const b of this.boats) {
      const sup = this.support(world, b);
      if (sup?.water) {
        b.vy = 0;
        b.y += (sup.y - b.y) * Math.min(1, 8 * dt);
      } else if (sup && b.y <= sup.y + 0.04) {
        b.y = sup.y;
        b.vy = 0;
      } else {
        b.vy -= 20 * dt;
        if (b.vy < -18) b.vy = -18;
        const next = b.y + b.vy * dt;
        if (sup && next < sup.y) {
          b.y = sup.y;
          b.vy = 0;
        } else b.y = next;
      }
      if (!b.player) {
        b.vx *= Math.max(0, 1 - 1.6 * dt);
        b.vz *= Math.max(0, 1 - 1.6 * dt);
      }
      const ox = b.x;
      b.x += b.vx * dt;
      if (this.blocked(world, b)) {
        b.x = ox;
        b.vx = 0;
      }
      const oz = b.z;
      b.z += b.vz * dt;
      if (this.blocked(world, b)) {
        b.z = oz;
        b.vz = 0;
      }
      b.mesh.position.set(b.x, b.y, b.z);
      b.mesh.rotation.y = b.yaw;
      if (b.rider) {
        if (b.rider.hp <= 0) {
          b.rider.ride = 0;
          b.rider = null;
        } else {
          b.rider.x = b.x;
          b.rider.y = b.y + 0.25;
          b.rider.z = b.z;
          b.rider.vx = 0;
          b.rider.vz = 0;
          b.rider.vy = 0;
        }
      }
    }
    for (const m of mobs) {
      if (m.ride) continue;
      for (const b of this.boats) {
        if (b.player || b.rider) continue;
        if (Math.hypot(m.x - b.x, m.z - b.z) < 0.9 && Math.abs(m.y - b.y) < 1.3) {
          b.rider = m;
          m.ride = b.id;
          break;
        }
      }
    }
  }

  private support(world: World, b: Boat): { y: number; water: boolean } | null {
    const ix = Math.floor(b.x);
    const iz = Math.floor(b.z);
    let y = Math.floor(b.y + 0.05);
    if (y < 1) y = 1;
    if (isSolid(world.getBlock(ix, y, iz))) return { y: y + 1, water: false };
    for (let i = 0; i < 8; i++) {
      const yy = y - i;
      if (yy < 1) break;
      const id = world.getBlock(ix, yy, iz);
      if (isWater(id)) {
        let s = yy;
        while (s < 62 && isWater(world.getBlock(ix, s + 1, iz))) s++;
        return { y: s + 0.16, water: true };
      }
      if (isSolid(id)) return { y: yy + 1, water: false };
    }
    return null;
  }

  private blocked(world: World, b: Boat): boolean {
    const y = Math.floor(b.y + 0.25);
    const r = 0.42;
    const spots = [
      [0, 0],
      [r, 0],
      [-r, 0],
      [0, r],
      [0, -r],
    ];
    for (const [ox, oz] of spots) {
      if (isSolid(world.getBlock(Math.floor(b.x + ox), y, Math.floor(b.z + oz)))) return true;
    }
    return false;
  }

  clear() {
    for (const b of this.boats) {
      if (b.rider) b.rider.ride = 0;
      this.group.remove(b.mesh);
    }
    this.boats = [];
  }
}
