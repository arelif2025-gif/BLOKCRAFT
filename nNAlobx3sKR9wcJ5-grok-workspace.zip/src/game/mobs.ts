import * as THREE from "three";
import { isSolid, isWater } from "./blocks";
import { BEEF, BLAZE_ROD, CACTUS, CHICKEN_MEAT, ENDER_PEARL, GOLD_INGOT, LEAVES, MUTTON, PORK, SEA_LEVEL, WOOD, WOOL } from "./types";
import { nearFortress } from "./structures";
import { chunkKey, worldToChunk, type World } from "./world";
import type { DropWorld } from "./drops";

export type MobKind = "pig" | "sheep" | "cow" | "chicken" | "zombie" | "creeper" | "skeleton" | "spider" | "enderman" | "piglin" | "blaze";

export type Mob = {
  kind: MobKind;
  x: number;
  y: number;
  z: number;
  yaw: number;
  vx: number;
  vy: number;
  vz: number;
  hp: number;
  maxHp: number;
  crown: boolean;
  mesh: THREE.Group;
  legs: THREE.Object3D[];
  wings: THREE.Object3D[];
  hurtFlash: THREE.Mesh;
  walkT: number;
  state: "idle" | "walk" | "panic";
  stateT: number;
  wantYaw: number;
  speed: number;
  hurtT: number;
  w: number;
  h: number;
  d: number;
  cool: number;
  fuse: number;
  aggro: number;
  burnMesh: THREE.Mesh | null;
  ride: number;
  tp: number;
};

const DEFS: Record<
  MobKind,
  { hp: number; w: number; h: number; d: number; speed: number; drop: number; dropMin: number; dropMax: number; name: string; dmg: number; reach: number }
> = {
  pig: { hp: 10, w: 0.9, h: 0.9, d: 0.95, speed: 1.05, drop: PORK, dropMin: 1, dropMax: 2, name: "Domuz", dmg: 0, reach: 0 },
  sheep: { hp: 8, w: 0.9, h: 1.3, d: 1.15, speed: 1.0, drop: MUTTON, dropMin: 1, dropMax: 2, name: "Koyun", dmg: 0, reach: 0 },
  cow: { hp: 10, w: 0.95, h: 1.4, d: 1.45, speed: 0.9, drop: BEEF, dropMin: 1, dropMax: 3, name: "İnek", dmg: 0, reach: 0 },
  chicken: { hp: 4, w: 0.4, h: 0.7, d: 0.4, speed: 1.4, drop: CHICKEN_MEAT, dropMin: 1, dropMax: 1, name: "Tavuk", dmg: 0, reach: 0 },
  zombie: { hp: 12, w: 0.6, h: 1.85, d: 0.6, speed: 1.15, drop: 0, dropMin: 0, dropMax: 0, name: "Zombi", dmg: 3, reach: 1.35 },
  creeper: { hp: 12, w: 0.6, h: 1.6, d: 0.6, speed: 1.05, drop: 0, dropMin: 0, dropMax: 0, name: "Creeper", dmg: 0, reach: 2.3 },
  skeleton: { hp: 10, w: 0.6, h: 1.85, d: 0.6, speed: 1.2, drop: 0, dropMin: 0, dropMax: 0, name: "İskelet", dmg: 3, reach: 12 },
  spider: { hp: 8, w: 1.3, h: 0.7, d: 1.3, speed: 1.55, drop: 0, dropMin: 0, dropMax: 0, name: "Örümcek", dmg: 2, reach: 1.25 },
  enderman: { hp: 40, w: 0.6, h: 2.9, d: 0.6, speed: 1.35, drop: ENDER_PEARL, dropMin: 1, dropMax: 1, name: "Enderman", dmg: 7, reach: 1.6 },
  piglin: { hp: 20, w: 0.6, h: 1.9, d: 0.6, speed: 1.1, drop: GOLD_INGOT, dropMin: 0, dropMax: 1, name: "Zombileşmiş Piglin", dmg: 5, reach: 1.4 },
  blaze: { hp: 20, w: 0.7, h: 1.8, d: 0.7, speed: 1.25, drop: BLAZE_ROD, dropMin: 1, dropMax: 5, name: "Blaze", dmg: 5, reach: 14 },
};

const MAX_MOBS = 18;
const KEEP_DIST = 72;
const HOSTILE = new Set<MobKind>(["zombie", "creeper", "skeleton", "spider"]);

const mats = new Map<number, THREE.MeshLambertMaterial>();

function mat(color: number, extra?: { transparent?: boolean; opacity?: number }) {
  const key = color * 10 + (extra?.transparent ? 1 : 0);
  let m = mats.get(key);
  if (!m) {
    m = new THREE.MeshLambertMaterial({
      color,
      transparent: extra?.transparent ?? false,
      opacity: extra?.opacity ?? 1,
    });
    mats.set(key, m);
  }
  return m;
}

function voxel(parent: THREE.Object3D, x: number, y: number, z: number, sx: number, sy: number, sz: number, color: number) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), mat(color));
  mesh.position.set(x, y, z);
  mesh.castShadow = false;
  parent.add(mesh);
  return mesh;
}

function buildPig(crown: boolean) {
  const g = new THREE.Group();
  const pink = 0xf0a8b0;
  const dark = 0xd07a88;
  const snout = 0xf4c0c4;
  const hoof = 0x3a241c;
  voxel(g, 0, 0.58, 0.04, 0.78, 0.5, 0.92, pink);
  voxel(g, 0, 0.78, -0.52, 0.52, 0.5, 0.48, pink);
  voxel(g, 0, 0.68, -0.78, 0.32, 0.22, 0.18, snout);
  voxel(g, -0.07, 0.66, -0.88, 0.07, 0.07, 0.04, 0x5a3038);
  voxel(g, 0.07, 0.66, -0.88, 0.07, 0.07, 0.04, 0x5a3038);
  voxel(g, -0.3, 1.02, -0.5, 0.16, 0.16, 0.08, dark);
  voxel(g, 0.3, 1.02, -0.5, 0.16, 0.16, 0.08, dark);
  voxel(g, -0.14, 0.84, -0.76, 0.1, 0.1, 0.04, 0xffffff);
  voxel(g, 0.14, 0.84, -0.76, 0.1, 0.1, 0.04, 0xffffff);
  voxel(g, -0.14, 0.84, -0.78, 0.055, 0.055, 0.03, 0x1a120c);
  voxel(g, 0.14, 0.84, -0.78, 0.055, 0.055, 0.03, 0x1a120c);
  const fl = voxel(g, -0.22, 0.18, -0.28, 0.2, 0.36, 0.2, pink);
  const fr = voxel(g, 0.22, 0.18, -0.28, 0.2, 0.36, 0.2, pink);
  const bl = voxel(g, -0.22, 0.18, 0.32, 0.2, 0.36, 0.2, pink);
  const br = voxel(g, 0.22, 0.18, 0.32, 0.2, 0.36, 0.2, pink);
  voxel(fl, 0, -0.16, 0, 0.2, 0.08, 0.2, hoof);
  voxel(fr, 0, -0.16, 0, 0.2, 0.08, 0.2, hoof);
  voxel(bl, 0, -0.16, 0, 0.2, 0.08, 0.2, hoof);
  voxel(br, 0, -0.16, 0, 0.2, 0.08, 0.2, hoof);
  voxel(g, 0, 0.72, 0.52, 0.1, 0.1, 0.12, dark);
  if (crown) {
    voxel(g, 0, 1.12, -0.52, 0.56, 0.1, 0.5, 0xf0c44a);
    voxel(g, 0, 1.28, -0.52, 0.12, 0.22, 0.12, 0xffe08a);
    voxel(g, -0.2, 1.24, -0.52, 0.1, 0.16, 0.1, 0xf0c44a);
    voxel(g, 0.2, 1.24, -0.52, 0.1, 0.16, 0.1, 0xf0c44a);
    voxel(g, -0.2, 1.12, -0.52, 0.08, 0.08, 0.08, 0xc04050);
    voxel(g, 0.2, 1.12, -0.52, 0.08, 0.08, 0.08, 0x3a78d4);
    voxel(g, 0, 1.12, -0.52, 0.08, 0.08, 0.08, 0xc04050);
  }
  return { group: g, legs: [fl, fr, bl, br], wings: [] as THREE.Object3D[] };
}

function buildCow() {
  const g = new THREE.Group();
  const hide = 0x4a3428;
  const white = 0xefe6d8;
  const pink = 0xe8a090;
  const hoof = 0x2a1c14;
  voxel(g, 0, 0.85, 0.08, 0.92, 0.7, 1.28, hide);
  voxel(g, 0.18, 0.95, 0.1, 0.42, 0.42, 0.55, white);
  voxel(g, 0, 1.12, -0.72, 0.52, 0.5, 0.42, hide);
  voxel(g, 0, 0.98, -0.96, 0.36, 0.22, 0.16, pink);
  voxel(g, -0.1, 0.96, -1.04, 0.06, 0.06, 0.04, 0x5a3030);
  voxel(g, 0.1, 0.96, -1.04, 0.06, 0.06, 0.04, 0x5a3030);
  voxel(g, -0.16, 1.18, -0.92, 0.1, 0.1, 0.04, 0xffffff);
  voxel(g, 0.16, 1.18, -0.92, 0.1, 0.1, 0.04, 0xffffff);
  voxel(g, -0.16, 1.18, -0.94, 0.05, 0.05, 0.03, 0x1a120c);
  voxel(g, 0.16, 1.18, -0.94, 0.05, 0.05, 0.03, 0x1a120c);
  voxel(g, -0.28, 1.4, -0.7, 0.1, 0.18, 0.08, 0x2c2218);
  voxel(g, 0.28, 1.4, -0.7, 0.1, 0.18, 0.08, 0x2c2218);
  voxel(g, -0.22, 1.38, -0.68, 0.12, 0.1, 0.1, hide);
  voxel(g, 0.22, 1.38, -0.68, 0.12, 0.1, 0.1, hide);
  voxel(g, 0, 0.55, 0.42, 0.28, 0.18, 0.22, pink);
  const fl = voxel(g, -0.28, 0.32, -0.38, 0.2, 0.64, 0.2, hide);
  const fr = voxel(g, 0.28, 0.32, -0.38, 0.2, 0.64, 0.2, hide);
  const bl = voxel(g, -0.28, 0.32, 0.48, 0.2, 0.64, 0.2, hide);
  const br = voxel(g, 0.28, 0.32, 0.48, 0.2, 0.64, 0.2, hide);
  voxel(fl, 0, -0.3, 0, 0.2, 0.1, 0.2, hoof);
  voxel(fr, 0, -0.3, 0, 0.2, 0.1, 0.2, hoof);
  voxel(bl, 0, -0.3, 0, 0.2, 0.1, 0.2, hoof);
  voxel(br, 0, -0.3, 0, 0.2, 0.1, 0.2, hoof);
  return { group: g, legs: [fl, fr, bl, br], wings: [] as THREE.Object3D[] };
}

function buildSheep() {
  const g = new THREE.Group();
  const wool = 0xf4f1ea;
  const woolD = 0xe4dfd4;
  const skin = 0xc4b49a;
  const face = 0xb8a078;
  const hoof = 0x3a2818;
  voxel(g, 0, 0.78, 0.06, 0.95, 0.72, 1.2, wool);
  voxel(g, 0, 0.92, 0.1, 0.7, 0.5, 0.9, woolD);
  voxel(g, 0, 0.92, -0.68, 0.42, 0.42, 0.42, skin);
  voxel(g, 0, 0.82, -0.9, 0.28, 0.22, 0.16, face);
  voxel(g, -0.1, 0.98, -0.88, 0.09, 0.09, 0.04, 0xffffff);
  voxel(g, 0.1, 0.98, -0.88, 0.09, 0.09, 0.04, 0xffffff);
  voxel(g, -0.1, 0.98, -0.9, 0.05, 0.05, 0.03, 0x1a120c);
  voxel(g, 0.1, 0.98, -0.9, 0.05, 0.05, 0.03, 0x1a120c);
  voxel(g, -0.22, 1.16, -0.62, 0.12, 0.12, 0.08, skin);
  voxel(g, 0.22, 1.16, -0.62, 0.12, 0.12, 0.08, skin);
  const fl = voxel(g, -0.24, 0.28, -0.32, 0.18, 0.56, 0.18, skin);
  const fr = voxel(g, 0.24, 0.28, -0.32, 0.18, 0.56, 0.18, skin);
  const bl = voxel(g, -0.24, 0.28, 0.42, 0.18, 0.56, 0.18, skin);
  const br = voxel(g, 0.24, 0.28, 0.42, 0.18, 0.56, 0.18, skin);
  voxel(fl, 0, -0.26, 0, 0.18, 0.08, 0.18, hoof);
  voxel(fr, 0, -0.26, 0, 0.18, 0.08, 0.18, hoof);
  voxel(bl, 0, -0.26, 0, 0.18, 0.08, 0.18, hoof);
  voxel(br, 0, -0.26, 0, 0.18, 0.08, 0.18, hoof);
  return { group: g, legs: [fl, fr, bl, br], wings: [] as THREE.Object3D[] };
}

function buildChicken() {
  const g = new THREE.Group();
  const white = 0xf6f3ea;
  const comb = 0xd03030;
  const beak = 0xf0c030;
  const leg = 0xe0a030;
  voxel(g, 0, 0.38, 0.02, 0.4, 0.32, 0.48, white);
  voxel(g, 0, 0.58, -0.22, 0.28, 0.28, 0.28, white);
  voxel(g, 0, 0.54, -0.4, 0.14, 0.1, 0.14, beak);
  voxel(g, 0, 0.44, -0.36, 0.1, 0.1, 0.08, comb);
  voxel(g, 0, 0.74, -0.22, 0.08, 0.12, 0.08, comb);
  voxel(g, 0, 0.78, -0.22, 0.14, 0.08, 0.06, comb);
  voxel(g, -0.08, 0.62, -0.36, 0.07, 0.07, 0.03, 0xffffff);
  voxel(g, 0.08, 0.62, -0.36, 0.07, 0.07, 0.03, 0xffffff);
  voxel(g, -0.08, 0.62, -0.38, 0.04, 0.04, 0.02, 0x1a120c);
  voxel(g, 0.08, 0.62, -0.38, 0.04, 0.04, 0.02, 0x1a120c);
  const lw = voxel(g, -0.26, 0.4, 0.02, 0.08, 0.22, 0.32, 0xe8e0d0);
  const rw = voxel(g, 0.26, 0.4, 0.02, 0.08, 0.22, 0.32, 0xe8e0d0);
  const fl = voxel(g, -0.08, 0.12, 0.0, 0.06, 0.24, 0.06, leg);
  const fr = voxel(g, 0.08, 0.12, 0.0, 0.06, 0.24, 0.06, leg);
  voxel(fl, 0, -0.12, -0.04, 0.1, 0.03, 0.12, leg);
  voxel(fr, 0, -0.12, -0.04, 0.1, 0.03, 0.12, leg);
  voxel(g, 0, 0.38, 0.28, 0.08, 0.08, 0.12, 0xe8c070);
  return { group: g, legs: [fl, fr], wings: [lw, rw] };
}

function buildZombie() {
  const g = new THREE.Group();
  const skin = 0x4c8a3a;
  const shirt = 0x3a4a86;
  const pants = 0x2a3348;
  voxel(g, 0, 1.05, 0, 0.56, 0.72, 0.32, shirt);
  voxel(g, 0, 1.62, 0.02, 0.48, 0.48, 0.48, skin);
  voxel(g, -0.12, 1.68, -0.24, 0.1, 0.08, 0.04, 0x111);
  voxel(g, 0.12, 1.68, -0.24, 0.1, 0.08, 0.04, 0x111);
  voxel(g, 0, 1.5, -0.24, 0.16, 0.06, 0.04, 0x1a120c);
  const la = voxel(g, -0.4, 1.05, -0.08, 0.18, 0.62, 0.18, skin);
  const ra = voxel(g, 0.4, 1.05, -0.08, 0.18, 0.62, 0.18, skin);
  const ll = voxel(g, -0.14, 0.36, 0, 0.2, 0.72, 0.2, pants);
  const rl = voxel(g, 0.14, 0.36, 0, 0.2, 0.72, 0.2, pants);
  return { group: g, legs: [ll, rl, la, ra], wings: [] as THREE.Object3D[] };
}

function buildCreeper() {
  const g = new THREE.Group();
  const green = 0x3c9a32;
  const dark = 0x1a3a16;
  voxel(g, 0, 0.95, 0, 0.52, 0.78, 0.32, green);
  voxel(g, 0, 1.55, 0.02, 0.48, 0.48, 0.48, green);
  voxel(g, 0, 1.58, -0.24, 0.08, 0.22, 0.04, dark);
  voxel(g, -0.1, 1.64, -0.24, 0.08, 0.1, 0.04, dark);
  voxel(g, 0.1, 1.64, -0.24, 0.08, 0.1, 0.04, dark);
  voxel(g, -0.08, 1.42, -0.24, 0.08, 0.08, 0.04, dark);
  voxel(g, 0.08, 1.42, -0.24, 0.08, 0.08, 0.04, dark);
  const fl = voxel(g, -0.16, 0.28, -0.08, 0.16, 0.56, 0.16, green);
  const fr = voxel(g, 0.16, 0.28, -0.08, 0.16, 0.56, 0.16, green);
  const bl = voxel(g, -0.16, 0.28, 0.12, 0.16, 0.56, 0.16, green);
  const br = voxel(g, 0.16, 0.28, 0.12, 0.16, 0.56, 0.16, green);
  return { group: g, legs: [fl, fr, bl, br], wings: [] as THREE.Object3D[] };
}

function buildSkeleton() {
  const g = new THREE.Group();
  const bone = 0xe8e2d4;
  const dark = 0x2a241c;
  voxel(g, 0, 1.08, 0, 0.4, 0.62, 0.22, bone);
  voxel(g, 0, 1.58, 0, 0.42, 0.42, 0.42, bone);
  voxel(g, -0.1, 1.64, -0.22, 0.1, 0.08, 0.04, 0x111);
  voxel(g, 0.1, 1.64, -0.22, 0.1, 0.08, 0.04, 0x111);
  voxel(g, 0, 1.48, -0.22, 0.16, 0.05, 0.04, dark);
  const la = voxel(g, -0.32, 1.05, 0, 0.1, 0.62, 0.1, bone);
  const ra = voxel(g, 0.32, 1.02, -0.12, 0.1, 0.62, 0.1, bone);
  voxel(ra, 0, -0.1, -0.16, 0.08, 0.42, 0.08, dark);
  voxel(ra, 0.1, 0.16, -0.16, 0.22, 0.06, 0.06, 0x8a5a32);
  const ll = voxel(g, -0.1, 0.36, 0, 0.1, 0.7, 0.1, bone);
  const rl = voxel(g, 0.1, 0.36, 0, 0.1, 0.7, 0.1, bone);
  return { group: g, legs: [ll, rl, la, ra], wings: [] as THREE.Object3D[] };
}

function buildSpider() {
  const g = new THREE.Group();
  const body = 0x2a2420;
  const eye = 0xc04030;
  voxel(g, 0, 0.38, 0.05, 0.7, 0.36, 0.9, body);
  voxel(g, 0, 0.42, -0.48, 0.42, 0.28, 0.36, 0x1a1614);
  voxel(g, -0.1, 0.5, -0.66, 0.08, 0.08, 0.04, eye);
  voxel(g, 0.1, 0.5, -0.66, 0.08, 0.08, 0.04, eye);
  const legs: THREE.Object3D[] = [];
  for (let i = 0; i < 4; i++) {
    const z = -0.28 + i * 0.2;
    legs.push(voxel(g, -0.48, 0.22, z, 0.42, 0.08, 0.08, body));
    legs.push(voxel(g, 0.48, 0.22, z, 0.42, 0.08, 0.08, body));
  }
  return { group: g, legs, wings: [] as THREE.Object3D[] };
}

function buildEnderman() {
  const g = new THREE.Group();
  const black = 0x16141c;
  voxel(g, 0, 1.55, 0, 0.42, 1.5, 0.28, black);
  voxel(g, 0, 2.55, 0, 0.48, 0.48, 0.48, black);
  voxel(g, -0.12, 2.62, -0.24, 0.1, 0.08, 0.04, 0xc060ff);
  voxel(g, 0.12, 2.62, -0.24, 0.1, 0.08, 0.04, 0xc060ff);
  const al = voxel(g, -0.34, 1.5, 0, 0.14, 1.3, 0.14, black);
  const ar = voxel(g, 0.34, 1.5, 0, 0.14, 1.3, 0.14, black);
  const ll = voxel(g, -0.12, 0.55, 0, 0.14, 1.1, 0.14, black);
  const lr = voxel(g, 0.12, 0.55, 0, 0.14, 1.1, 0.14, black);
  return { group: g, legs: [ll, lr], wings: [al, ar] };
}

function buildPiglin() {
  const g = new THREE.Group();
  const skin = 0xd98a74;
  const cloth = 0x8a3a2a;
  voxel(g, 0, 1.05, 0, 0.55, 0.75, 0.32, skin);
  voxel(g, 0, 0.85, 0, 0.58, 0.28, 0.34, cloth);
  voxel(g, 0, 1.62, 0, 0.48, 0.48, 0.48, skin);
  voxel(g, 0, 1.52, -0.26, 0.22, 0.12, 0.12, 0xf0b0a0);
  voxel(g, -0.12, 1.68, -0.24, 0.08, 0.08, 0.04, 0x201410);
  voxel(g, 0.12, 1.68, -0.24, 0.08, 0.08, 0.04, 0x201410);
  voxel(g, 0.42, 0.95, -0.1, 0.1, 0.55, 0.1, 0xe0c050);
  const al = voxel(g, -0.38, 1.05, 0, 0.16, 0.7, 0.16, skin);
  const ar = voxel(g, 0.38, 1.05, 0, 0.16, 0.7, 0.16, skin);
  const ll = voxel(g, -0.14, 0.38, 0, 0.18, 0.75, 0.18, cloth);
  const lr = voxel(g, 0.14, 0.38, 0, 0.18, 0.75, 0.18, cloth);
  return { group: g, legs: [ll, lr, al, ar], wings: [] as THREE.Object3D[] };
}

function buildBlaze() {
  const g = new THREE.Group();
  voxel(g, 0, 1.05, 0, 0.5, 0.5, 0.5, 0xf0c020);
  voxel(g, 0, 1.15, -0.28, 0.12, 0.08, 0.04, 0xfff0a0);
  const rods: THREE.Object3D[] = [];
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    rods.push(voxel(g, Math.cos(a) * 0.38, 0.7 + (i % 3) * 0.28, Math.sin(a) * 0.38, 0.08, 0.42, 0.08, 0xffb020));
  }
  return { group: g, legs: rods, wings: [] as THREE.Object3D[] };
}

function buildModel(kind: MobKind, crown: boolean) {
  if (kind === "pig") return buildPig(crown);
  if (kind === "cow") return buildCow();
  if (kind === "sheep") return buildSheep();
  if (kind === "zombie") return buildZombie();
  if (kind === "creeper") return buildCreeper();
  if (kind === "skeleton") return buildSkeleton();
  if (kind === "spider") return buildSpider();
  if (kind === "enderman") return buildEnderman();
  if (kind === "piglin") return buildPiglin();
  if (kind === "blaze") return buildBlaze();
  return buildChicken();
}

export function mobName(kind: MobKind, crown: boolean) {
  if (kind === "pig" && crown) return "Kral Domuz";
  return DEFS[kind].name;
}

export class MobWorld {
  group = new THREE.Group();
  mobs: Mob[] = [];
  private spawnT = 0.6;
  private hostileT = 1.2;
  private shots: Array<{ x: number; y: number; z: number; vx: number; vy: number; vz: number; life: number; dmg: number; mesh: THREE.Mesh }> = [];

  spawn(kind: MobKind, x: number, y: number, z: number, crown = false) {
    if (this.mobs.length >= MAX_MOBS) return null;
    const def = DEFS[kind];
    const built = buildModel(kind, crown);
    const flash = new THREE.Mesh(
      new THREE.BoxGeometry(def.w * 1.15, def.h * 1.1, def.d * 1.15),
      new THREE.MeshBasicMaterial({ color: 0xff4422, transparent: true, opacity: 0.35, depthWrite: false }),
    );
    flash.position.y = def.h * 0.5;
    flash.visible = false;
    built.group.add(flash);
    let burnMesh: THREE.Mesh | null = null;
    if (HOSTILE.has(kind)) {
      burnMesh = new THREE.Mesh(
        new THREE.BoxGeometry(def.w * 0.85, def.h * 0.72, def.d * 0.85),
        mat(0xff6a12, { transparent: true, opacity: 0.55 }),
      );
      burnMesh.position.y = def.h * 0.48;
      burnMesh.visible = false;
      built.group.add(burnMesh);
    }
    built.group.position.set(x, y, z);
    this.group.add(built.group);
    const m: Mob = {
      kind,
      x,
      y,
      z,
      yaw: Math.random() * Math.PI * 2,
      vx: 0,
      vy: 0,
      vz: 0,
      hp: def.hp,
      maxHp: def.hp,
      crown,
      mesh: built.group,
      legs: built.legs,
      wings: built.wings,
      hurtFlash: flash,
      walkT: Math.random() * 10,
      state: "idle",
      stateT: 0.6 + Math.random() * 1.4,
      wantYaw: Math.random() * Math.PI * 2,
      speed: def.speed,
      hurtT: 0,
      w: def.w,
      h: def.h,
      d: def.d,
      cool: 0.4,
      fuse: 0,
      aggro: 0,
      burnMesh,
      ride: 0,
      tp: 0,
    };
    this.mobs.push(m);
    return m;
  }

  update(
    dt: number,
    world: World,
    px: number,
    py: number,
    pz: number,
    drops: DropWorld | null,
    hooks: { sound: (kind: MobKind) => void; hurt: (n: number) => void; isDay: boolean; boom: (x: number, y: number, z: number) => void; look: { x: number; y: number; z: number }; eyeY: number; peaceful?: boolean },
  ) {
    this.spawnT -= dt;
    if (this.spawnT <= 0) {
      this.spawnT = 2.4 + Math.random() * 1.6;
      if (!hooks.peaceful) {
        if (world.kind === "nether") this.trySpawnNether(world, px, pz);
        else if (world.kind !== "end") this.trySpawn(world, px, pz);
      } else if (world.kind === "overworld") this.trySpawn(world, px, pz);
    }
    this.hostileT -= dt;
    if (this.hostileT <= 0 && !hooks.peaceful) {
      this.hostileT = 2.8 + Math.random() * 2.2;
      if (world.kind === "nether") this.trySpawnNether(world, px, pz);
      else if (world.kind !== "end") this.trySpawnHostile(world, px, pz, hooks.isDay);
    }
    this.cull(px, pz);
    this.updateShots(dt, world, px, py, pz, hooks.hurt);

    for (let i = this.mobs.length - 1; i >= 0; i--) {
      const m = this.mobs[i]!;
      m.hurtT = Math.max(0, m.hurtT - dt);
      m.hurtFlash.visible = m.hurtT > 0;
      m.stateT -= dt;

      m.cool = Math.max(0, m.cool - dt);
      if (m.ride) {
        m.mesh.position.set(m.x, m.y, m.z);
        m.mesh.rotation.y = m.yaw;
        continue;
      }
      if (m.tp) {
        m.tp = 0;
        if (!m.ride) this.teleport(m, world);
      }
      if (HOSTILE.has(m.kind)) this.sunBurn(m, world, hooks.isDay, dt);
      this.separate(m, dt);
      this.ai(m, world, px, py, pz, dt, hooks);
      this.physics(m, world, dt);
      this.animate(m, dt);

      m.mesh.position.set(m.x, m.y, m.z);
      m.mesh.rotation.y = m.yaw;
      if (m.kind === "creeper" && m.fuse > 0) {
        const swell = 1 + Math.sin(m.fuse * 18) * 0.06 * m.fuse;
        m.mesh.scale.setScalar(swell);
        m.hurtFlash.visible = m.fuse > 0.45;
      } else m.mesh.scale.setScalar(1);

      if (m.hp <= 0) this.kill(i, drops);
    }
    void hooks.sound;
  }

  hit(m: Mob, dmg: number, ax: number, az: number) {
    m.hp -= dmg;
    m.hurtT = 0.22;
    const dx = m.x - ax;
    const dz = m.z - az;
    const len = Math.hypot(dx, dz) || 1;
    m.vx = (dx / len) * 3.4;
    m.vz = (dz / len) * 3.4;
    m.vy = Math.min(2.1, m.vy + 1.6);
    m.wantYaw = Math.atan2(dx, dz);
    if (m.kind === "enderman" && !m.ride) m.tp = 1;
    if (m.kind === "piglin") {
      m.aggro = 16;
      for (const o of this.mobs) {
        if (o !== m && o.kind === "piglin" && Math.hypot(o.x - m.x, o.z - m.z) < 18) o.aggro = 16;
      }
    }
    if (HOSTILE.has(m.kind) || m.kind === "enderman" || m.kind === "blaze" || m.kind === "piglin") {
      m.aggro = 8;
      m.state = "walk";
      m.stateT = 0.4;
    } else {
      m.state = "panic";
      m.stateT = 1 + Math.random() * 0.5;
    }
  }

  raycast(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, max: number): { mob: Mob; dist: number } | null {
    let best: { mob: Mob; dist: number } | null = null;
    for (const m of this.mobs) {
      const t = rayAabb(ox, oy, oz, dx, dy, dz, m.x - m.w * 0.5 - 0.2, m.y, m.z - m.d * 0.5 - 0.2, m.w + 0.4, m.h + 0.15, m.d + 0.4, max);
      if (t != null && (!best || t < best.dist)) best = { mob: m, dist: t };
    }
    return best;
  }

  nearestInLook(px: number, py: number, pz: number, dx: number, dy: number, dz: number, maxDist: number) {
    let best: { mob: Mob; dist: number } | null = null;
    for (const m of this.mobs) {
      const vx = m.x - px;
      const vy = m.y + m.h * 0.5 - py;
      const vz = m.z - pz;
      const dist = Math.hypot(vx, vy, vz);
      if (dist > maxDist || dist < 0.05) continue;
      const dot = (vx / dist) * dx + (vy / dist) * dy + (vz / dist) * dz;
      if (dot < 0.62) continue;
      if (!best || dist < best.dist) best = { mob: m, dist };
    }
    return best;
  }

  private kill(i: number, drops: DropWorld | null) {
    const m = this.mobs[i]!;
    const def = DEFS[m.kind];
    if (m.kind === "blaze") {
      const n = 1 + Math.floor(Math.random() * 5);
      drops?.spawn(m.x, m.y + 0.5, m.z, BLAZE_ROD, n);
    } else {
      const n = def.dropMin + Math.floor(Math.random() * (def.dropMax - def.dropMin + 1));
      const extra = m.crown ? 1 : 0;
      if (def.drop && n + extra > 0) drops?.spawn(m.x, m.y + 0.4, m.z, def.drop, n + extra);
    }
    if (m.kind === "sheep") drops?.spawn(m.x + 0.2, m.y + 0.35, m.z, WOOL, 1 + Math.floor(Math.random() * 2));
    this.group.remove(m.mesh);
    this.disposeMesh(m.mesh);
    this.mobs.splice(i, 1);
  }

  private ai(
    m: Mob,
    world: World,
    px: number,
    py: number,
    pz: number,
    dt: number,
    hooks: { hurt: (n: number) => void; boom: (x: number, y: number, z: number) => void; look: { x: number; y: number; z: number }; eyeY: number },
  ) {
    if (m.kind === "enderman") {
      this.endermanAi(m, world, px, py, pz, dt, hooks);
      return;
    }
    if (m.kind === "blaze") {
      this.blazeAi(m, world, px, py, pz, dt, hooks);
      return;
    }
    if (m.kind === "piglin") {
      this.piglinAi(m, world, px, py, pz, dt, hooks);
      return;
    }
    if (HOSTILE.has(m.kind)) {
      this.hostileAi(m, world, px, py, pz, dt, hooks);
      return;
    }
    if (m.state === "panic") {
      const dx = m.x - px;
      const dz = m.z - pz;
      m.wantYaw = Math.atan2(dx, dz);
      if (m.stateT <= 0) {
        m.state = "walk";
        m.stateT = 1.2;
      }
    } else if (m.stateT <= 0) {
      if (m.state === "idle") {
        m.state = "walk";
        m.stateT = 1.8 + Math.random() * 2.8;
        m.wantYaw = Math.random() * Math.PI * 2;
      } else {
        m.state = "idle";
        m.stateT = 1.2 + Math.random() * 2.6;
      }
    }

    const turn = m.state === "panic" ? 8 : 3.2;
    let a = m.wantYaw - m.yaw;
    while (a > Math.PI) a -= Math.PI * 2;
    while (a < -Math.PI) a += Math.PI * 2;
    m.yaw += a * Math.min(1, turn * dt);

    const moving = m.state === "walk" || m.state === "panic";
    const spd = m.state === "panic" ? m.speed * 2.15 : m.state === "walk" ? m.speed : 0;
    if (moving && spd) {
      const fx = -Math.sin(m.yaw);
      const fz = -Math.cos(m.yaw);
      const nx = m.x + fx * 0.7;
      const nz = m.z + fz * 0.7;
      if (this.blockedAhead(world, nx, m.y, nz, m.h) === "wall") {
        m.wantYaw += (Math.random() > 0.5 ? 1 : -1) * (0.7 + Math.random());
      } else {
        m.vx += (fx * spd - m.vx) * Math.min(1, 6 * dt);
        m.vz += (fz * spd - m.vz) * Math.min(1, 6 * dt);
      }
    } else {
      m.vx *= Math.max(0, 1 - 8 * dt);
      m.vz *= Math.max(0, 1 - 8 * dt);
    }
  }

  private separate(m: Mob, dt: number) {
    for (const o of this.mobs) {
      if (o === m) continue;
      const dx = m.x - o.x;
      const dz = m.z - o.z;
      const d = Math.hypot(dx, dz);
      const min = (m.w + o.w) * 0.55;
      if (d < 0.05 || d > min) continue;
      const f = ((min - d) / min) * 2.2 * dt;
      m.vx += (dx / d) * f;
      m.vz += (dz / d) * f;
    }
  }

  private physics(m: Mob, world: World, dt: number) {
    if (m.kind === "blaze") {
      m.vy += (0.15 - m.vy) * Math.min(1, 3 * dt);
      if (m.vy > 1.4) m.vy = 1.4;
      if (m.vy < -1.4) m.vy = -1.4;
    } else if (this.inWater(world, m)) {
      m.vy -= 6 * dt;
      const surface = this.waterTop(world, m);
      if (surface != null && m.y + m.h * 0.45 < surface) m.vy += 14 * dt;
      else m.vy += (0.15 - m.vy) * Math.min(1, 4 * dt);
      if (m.vy < -1.1) m.vy = -1.1;
      if (m.vy > 2.6) m.vy = 2.6;
    } else {
      m.vy -= 26 * dt;
      if (m.vy < -18) m.vy = -18;
    }
    this.stepMove(m, world, m.vx * dt, m.vz * dt);
    const before = m.y;
    m.y += m.vy * dt;
    if (this.aabbSolid(world, m)) {
      m.y = before;
      if (m.vy < 0) {
        let guard = 0;
        while (guard++ < 6 && !this.aabbSolid(world, m)) m.y -= 0.05;
        if (this.aabbSolid(world, m)) m.y += 0.05;
      }
      m.vy = 0;
    }
    if (m.y < 0.1) {
      m.y = 0.1;
      m.vy = 0;
    }
  }

  private stepMove(m: Mob, world: World, dx: number, dz: number) {
    if (dx === 0 && dz === 0) return;
    const ox = m.x;
    const oz = m.z;
    const oy = m.y;
    m.x += dx;
    m.z += dz;
    if (!this.aabbSolid(world, m)) return;
    m.x = ox;
    m.z = oz;
    const foot = Math.floor(oy + 0.05);
    const ax = Math.floor(ox + Math.sign(dx || 0) * Math.max(0.32, m.w * 0.48));
    const az = Math.floor(oz + Math.sign(dz || 0) * Math.max(0.32, m.d * 0.48));
    const low = this.blocked(world, ax, foot, az);
    const high = this.blocked(world, ax, foot + 1, az);
    const one = low && !high;
    let room = !high;
    const need = Math.max(1, Math.ceil(m.h - 0.08));
    for (let i = 1; i <= need; i++) {
      if (this.blocked(world, ax, foot + i, az)) room = false;
    }
    if (one && room) {
      if (m.vy < 1.2) m.vy = 8;
      return;
    }
    m.vx = 0;
    m.vz = 0;
  }

  private animate(m: Mob, dt: number) {
    const spd = Math.hypot(m.vx, m.vz);
    if (spd > 0.15) m.walkT += dt * spd * 7;
    const swing = Math.sin(m.walkT) * Math.min(0.7, spd * 0.45);
    if (m.legs[0]) m.legs[0].rotation.x = swing;
    if (m.legs[1]) m.legs[1].rotation.x = -swing;
    if (m.legs[2]) m.legs[2].rotation.x = -swing;
    if (m.legs[3]) m.legs[3].rotation.x = swing;
    const flap = m.kind === "chicken" ? Math.sin(m.walkT * 2.2) * 0.45 : 0;
    if (m.wings[0]) m.wings[0].rotation.z = 0.25 + flap;
    if (m.wings[1]) m.wings[1].rotation.z = -0.25 - flap;
  }

  private aabbSolid(world: World, m: Mob) {
    const x0 = Math.floor(m.x - m.w * 0.45);
    const x1 = Math.floor(m.x + m.w * 0.45);
    const y0 = Math.floor(m.y + 0.05);
    const y1 = Math.floor(m.y + m.h - 0.05);
    const z0 = Math.floor(m.z - m.d * 0.45);
    const z1 = Math.floor(m.z + m.d * 0.45);
    for (let y = y0; y <= y1; y++) {
      for (let z = z0; z <= z1; z++) {
        for (let x = x0; x <= x1; x++) {
          if (this.blocked(world, x, y, z)) return true;
        }
      }
    }
    return false;
  }

  private blockedAhead(world: World, x: number, y: number, z: number, h: number): "wall" | "step" | "clear" {
    const ix = Math.floor(x);
    const iz = Math.floor(z);
    const iy = Math.floor(y + 0.1);
    if (isWater(world.getBlock(ix, iy, iz)) || isWater(world.getBlock(ix, iy - 1, iz))) return "clear";
    const low = this.blocked(world, ix, iy, iz);
    const high = this.blocked(world, ix, iy + 1, iz);
    if (low && high) return "wall";
    if (low) return "step";
    const below = world.getBlock(ix, iy - 1, iz);
    if (!isSolid(below) && !isWater(below)) return "wall";
    const drop = y - this.surfaceY(world, ix, iz);
    if (drop > 2.2) return "wall";
    void h;
    return "clear";
  }

  private inWater(world: World, m: Mob) {
    const x = Math.floor(m.x);
    const z = Math.floor(m.z);
    const y = Math.floor(m.y + 0.2);
    return isWater(world.getBlock(x, y, z)) || isWater(world.getBlock(x, y + 1, z));
  }

  private waterTop(world: World, m: Mob) {
    const x = Math.floor(m.x);
    const z = Math.floor(m.z);
    let top = -1;
    const y0 = Math.max(0, Math.floor(m.y) - 1);
    for (let y = y0; y <= y0 + 5; y++) {
      if (isWater(world.getBlock(x, y, z))) top = y;
    }
    return top < 0 ? null : top + 0.9;
  }

  private blocked(world: World, x: number, y: number, z: number) {
    if (y < 0) return true;
    const [cx, cz] = worldToChunk(x, z);
    if (!world.chunks.has(chunkKey(cx, cz))) return true;
    const id = world.getBlock(x, y, z);
    return isSolid(id);
  }

  private surfaceY(world: World, x: number, z: number) {
    for (let y = 60; y >= 1; y--) {
      if (isSolid(world.getBlock(x, y, z)) && !isSolid(world.getBlock(x, y + 1, z))) return y + 1;
    }
    return world.heightAt(x, z) + 1;
  }

  private hostileAi(
    m: Mob,
    world: World,
    px: number,
    py: number,
    pz: number,
    dt: number,
    hooks: { hurt: (n: number) => void; boom: (x: number, y: number, z: number) => void },
  ) {
    const dx = px - m.x;
    const dy = py + 0.9 - (m.y + m.h * 0.6);
    const dz = pz - m.z;
    const dist = Math.hypot(dx, dz);
    const see = dist < 18 && Math.abs(dy) < 6 && this.sees(world, m.x, m.y + m.h * 0.75, m.z, px, py + 1.1, pz);
    if (see) m.aggro = 7;
    else m.aggro = Math.max(0, m.aggro - dt);
    const def = DEFS[m.kind];
    if (m.aggro > 0) {
      m.wantYaw = Math.atan2(-dx, -dz);
      m.state = "walk";
      if (m.kind === "creeper" && dist < def.reach && Math.abs(dy) < 2) {
        m.fuse += dt;
        m.vx *= Math.max(0, 1 - 10 * dt);
        m.vz *= Math.max(0, 1 - 10 * dt);
        if (m.fuse >= 1.35) {
          hooks.boom(m.x, m.y + 0.6, m.z);
          m.hp = 0;
        }
      } else {
        m.fuse = Math.max(0, m.fuse - dt * 1.5);
        const stop = m.kind === "skeleton" ? 7.5 : def.reach * 0.75;
        if (dist > stop) {
          const fx = -Math.sin(m.wantYaw);
          const fz = -Math.cos(m.wantYaw);
          m.vx += (fx * m.speed * 1.35 - m.vx) * Math.min(1, 7 * dt);
          m.vz += (fz * m.speed * 1.35 - m.vz) * Math.min(1, 7 * dt);
        } else {
          m.vx *= Math.max(0, 1 - 8 * dt);
          m.vz *= Math.max(0, 1 - 8 * dt);
        }
        if (m.cool <= 0 && Math.abs(dy) < 2.2) {
          if (m.kind === "skeleton" && dist > 3.2 && dist < def.reach && see) {
            this.shoot(m, px, py + 1.05, pz);
            m.cool = 1.35;
          } else if (m.kind !== "skeleton" && m.kind !== "creeper" && dist < def.reach + 0.35) {
            hooks.hurt(def.dmg);
            m.cool = m.kind === "spider" ? 0.7 : 0.9;
          }
        }
      }
    } else {
      m.fuse = Math.max(0, m.fuse - dt);
      if (m.stateT <= 0) {
        m.state = m.state === "idle" ? "walk" : "idle";
        m.stateT = 1.2 + Math.random() * 2;
        m.wantYaw = Math.random() * Math.PI * 2;
      }
      const spd = m.state === "walk" ? m.speed * 0.65 : 0;
      const fx = -Math.sin(m.yaw);
      const fz = -Math.cos(m.yaw);
      if (spd && this.blockedAhead(world, m.x + fx * 0.6, m.y, m.z + fz * 0.6, m.h) !== "wall") {
        m.vx += (fx * spd - m.vx) * Math.min(1, 5 * dt);
        m.vz += (fz * spd - m.vz) * Math.min(1, 5 * dt);
      } else {
        m.vx *= Math.max(0, 1 - 8 * dt);
        m.vz *= Math.max(0, 1 - 8 * dt);
        if (spd) m.wantYaw += 1.1;
      }
    }
    let a = m.wantYaw - m.yaw;
    while (a > Math.PI) a -= Math.PI * 2;
    while (a < -Math.PI) a += Math.PI * 2;
    m.yaw += a * Math.min(1, 8 * dt);
  }

  private sunBurn(m: Mob, world: World, isDay: boolean, dt: number) {
    const wet = isWater(world.getBlock(Math.floor(m.x), Math.floor(m.y), Math.floor(m.z)));
    const burn = isDay && !wet && this.seesSky(world, m);
    if (m.burnMesh) m.burnMesh.visible = burn;
    if (!burn) return;
    m.hurtT = 0.15;
    m.hp -= dt * 2.2;
  }

  private seesSky(world: World, m: Mob) {
    const x = Math.floor(m.x);
    const z = Math.floor(m.z);
    const y0 = Math.floor(m.y + m.h);
    for (let y = y0; y < y0 + 14; y++) {
      if (y > 62) return true;
      const id = world.getBlock(x, y, z);
      if (isSolid(id) && id !== LEAVES) return false;
    }
    return true;
  }

  private sees(world: World, x0: number, y0: number, z0: number, x1: number, y1: number, z1: number) {
    const dx = x1 - x0;
    const dy = y1 - y0;
    const dz = z1 - z0;
    const dist = Math.hypot(dx, dy, dz);
    const steps = Math.max(1, Math.ceil(dist * 2));
    for (let i = 1; i < steps; i++) {
      const t = i / steps;
      const x = Math.floor(x0 + dx * t);
      const y = Math.floor(y0 + dy * t);
      const z = Math.floor(z0 + dz * t);
      const id = world.getBlock(x, y, z);
      if (isSolid(id) && id !== LEAVES) return false;
    }
    return true;
  }

  private shoot(m: Mob, px: number, py: number, pz: number, dmg = DEFS.skeleton.dmg) {
    const ox = m.x;
    const oy = m.y + m.h * 0.72;
    const oz = m.z;
    const dx = px - ox;
    const dy = py - oy;
    const dz = pz - oz;
    const len = Math.hypot(dx, dy, dz) || 1;
    const sp = 16;
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(m.kind === "blaze" ? 0.16 : 0.08, m.kind === "blaze" ? 0.16 : 0.08, m.kind === "blaze" ? 0.16 : 0.42),
      mat(m.kind === "blaze" ? 0xffaa22 : 0xf3efe4),
    );
    mesh.position.set(ox, oy, oz);
    this.group.add(mesh);
    this.shots.push({ x: ox, y: oy, z: oz, vx: (dx / len) * sp, vy: (dy / len) * sp, vz: (dz / len) * sp, life: 2.4, dmg, mesh });
  }

  private updateShots(dt: number, world: World, px: number, py: number, pz: number, hurt: (n: number) => void) {
    for (let i = this.shots.length - 1; i >= 0; i--) {
      const s = this.shots[i]!;
      s.life -= dt;
      s.vy -= 4 * dt;
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      s.z += s.vz * dt;
      s.mesh.position.set(s.x, s.y, s.z);
      const hitP = Math.abs(s.x - px) < 0.45 && Math.abs(s.z - pz) < 0.45 && s.y > py && s.y < py + 1.75;
      const solid = isSolid(world.getBlock(Math.floor(s.x), Math.floor(s.y), Math.floor(s.z)));
      if (hitP || solid || s.life <= 0 || s.y < 0) {
        if (hitP) hurt(s.dmg);
        this.group.remove(s.mesh);
        s.mesh.geometry.dispose();
        this.shots.splice(i, 1);
      }
    }
  }

  private trySpawn(world: World, px: number, pz: number) {
    if (this.mobs.length >= MAX_MOBS) return;
    let animals = 0;
    for (const m of this.mobs) if (!HOSTILE.has(m.kind)) animals++;
    if (animals >= 7) return;
    for (let n = 0; n < 8; n++) {
      const ang = Math.random() * Math.PI * 2;
      const r = 16 + Math.random() * 28;
      const x = Math.floor(px + Math.cos(ang) * r) + 0.5;
      const z = Math.floor(pz + Math.sin(ang) * r) + 0.5;
      const biome = world.biomeAt(Math.floor(x), Math.floor(z));
      if (biome === 0) continue;
      const y = this.surfaceY(world, Math.floor(x), Math.floor(z));
      if (y < SEA_LEVEL) continue;
      const ground = world.getBlock(Math.floor(x), y - 1, Math.floor(z));
      if (!isSolid(ground) || isWater(world.getBlock(Math.floor(x), y, Math.floor(z)))) continue;
      if (ground === LEAVES || ground === WOOD || ground === CACTUS) continue;
      if (biome === 3 && Math.random() > 0.15) continue;
      let near = false;
      for (const o of this.mobs) {
        if (Math.hypot(o.x - x, o.z - z) < 8) {
          near = true;
          break;
        }
      }
      if (near) continue;
      const roll = Math.random();
      const kind: MobKind = roll < 0.3 ? "pig" : roll < 0.55 ? "sheep" : roll < 0.8 ? "cow" : "chicken";
      const crown = kind === "pig" && Math.random() < 0.05;
      this.spawn(kind, x, y + 0.02, z, crown);
      return;
    }
  }

  private trySpawnHostile(world: World, px: number, pz: number, isDay: boolean) {
    let hostiles = 0;
    for (const m of this.mobs) if (HOSTILE.has(m.kind)) hostiles++;
    if (hostiles >= 7 || this.mobs.length >= MAX_MOBS) return;
    for (let n = 0; n < 10; n++) {
      const ang = Math.random() * Math.PI * 2;
      const r = 14 + Math.random() * 26;
      const x = Math.floor(px + Math.cos(ang) * r);
      const z = Math.floor(pz + Math.sin(ang) * r);
      const [cx, cz] = worldToChunk(x, z);
      if (!world.chunks.has(chunkKey(cx, cz))) continue;
      const top = this.surfaceY(world, x, z);
      let y = -1;
      if (!isDay && top >= SEA_LEVEL) {
        const ground = world.getBlock(x, top - 1, z);
        if (isSolid(ground) && !isWater(world.getBlock(x, top, z)) && ground !== LEAVES && ground !== CACTUS) y = top;
      }
      if (y < 0) {
        for (let k = 0; k < 8; k++) {
          const cy = 4 + Math.floor(Math.random() * Math.max(2, top - 8));
          if (cy > top - 4) continue;
          if (!isSolid(world.getBlock(x, cy, z)) && !isSolid(world.getBlock(x, cy + 1, z)) && isSolid(world.getBlock(x, cy - 1, z))) {
            y = cy;
            break;
          }
        }
      }
      if (y < 2) continue;
      let near = false;
      for (const o of this.mobs) {
        if (Math.hypot(o.x - (x + 0.5), o.z - (z + 0.5)) < 7) {
          near = true;
          break;
        }
      }
      if (near) continue;
      const roll = Math.random();
      const kind: MobKind = roll < 0.34 ? "zombie" : roll < 0.58 ? "skeleton" : roll < 0.8 ? "spider" : "creeper";
      this.spawn(kind, x + 0.5, y + 0.02, z + 0.5, false);
      return;
    }
  }

  seedAround(world: World, px: number, pz: number, peaceful = false) {
    if (world.kind === "end") return;
    if (world.kind === "nether" && peaceful) return;
    const nether = world.kind === "nether";
    for (let i = 0; i < 18 && this.mobs.length < 6; i++) {
      if (nether) this.trySpawnNether(world, px, pz);
      else this.trySpawn(world, px, pz);
    }
  }

  private trySpawnNether(world: World, px: number, pz: number) {
    if (this.mobs.length >= MAX_MOBS) return;
    for (let n = 0; n < 8; n++) {
      const ang = Math.random() * Math.PI * 2;
      const r = 12 + Math.random() * 24;
      const x = Math.floor(px + Math.cos(ang) * r);
      const z = Math.floor(pz + Math.sin(ang) * r);
      const [cx, cz] = worldToChunk(x, z);
      if (!world.chunks.has(chunkKey(cx, cz))) continue;
      const fort = nearFortress(world.seed, x, z, 30);
      let y = -1;
      if (fort && Math.random() < 0.65) {
        y = fort.y + 1;
        if (isSolid(world.getBlock(x, y, z)) || isSolid(world.getBlock(x, y + 1, z))) y = -1;
      }
      if (y < 0) {
        const top = this.surfaceY(world, x, z);
        if (top < 4) continue;
        const ground = world.getBlock(x, top - 1, z);
        if (!isSolid(ground) || isWater(world.getBlock(x, top, z))) continue;
        y = top;
      }
      let near = false;
      for (const o of this.mobs) {
        if (Math.hypot(o.x - (x + 0.5), o.z - (z + 0.5)) < 7) {
          near = true;
          break;
        }
      }
      if (near) continue;
      const kind: MobKind = fort && y === fort.y + 1 ? "blaze" : Math.random() < 0.45 ? "enderman" : "piglin";
      this.spawn(kind, x + 0.5, y + 0.05, z + 0.5, false);
      return;
    }
  }

  private teleport(m: Mob, world: World) {
    for (let i = 0; i < 14; i++) {
      const nx = m.x + (Math.random() - 0.5) * 22;
      const nz = m.z + (Math.random() - 0.5) * 22;
      const ix = Math.floor(nx);
      const iz = Math.floor(nz);
      const [cx, cz] = worldToChunk(ix, iz);
      if (!world.chunks.has(chunkKey(cx, cz))) continue;
      const y = this.surfaceY(world, ix, iz);
      if (y < 2) continue;
      if (isSolid(world.getBlock(ix, y, iz)) || isSolid(world.getBlock(ix, y + 1, iz))) continue;
      if (!isSolid(world.getBlock(ix, y - 1, iz))) continue;
      m.x = ix + 0.5;
      m.y = y + 0.05;
      m.z = iz + 0.5;
      m.vx = m.vz = 0;
      return;
    }
  }

  private endermanAi(
    m: Mob,
    world: World,
    px: number,
    py: number,
    pz: number,
    dt: number,
    hooks: { hurt: (n: number) => void; look: { x: number; y: number; z: number }; eyeY: number },
  ) {
    const ex = m.x;
    const ey = m.y + m.h * 0.86;
    const ez = m.z;
    const vx = ex - px;
    const vy = ey - hooks.eyeY;
    const vz = ez - pz;
    const dist3 = Math.hypot(vx, vy, vz) || 1;
    const dot = (vx / dist3) * hooks.look.x + (vy / dist3) * hooks.look.y + (vz / dist3) * hooks.look.z;
    if (dot > 0.9 && dist3 < 26) m.aggro = 12;
    else m.aggro = Math.max(0, m.aggro - dt * 0.15);
    const dx = px - m.x;
    const dz = pz - m.z;
    const dist = Math.hypot(dx, dz);
    if (m.aggro > 0) {
      m.wantYaw = Math.atan2(-dx, -dz);
      if (dist > 2.2) {
        const fx = -Math.sin(m.wantYaw);
        const fz = -Math.cos(m.wantYaw);
        m.vx += (fx * m.speed * 1.4 - m.vx) * Math.min(1, 7 * dt);
        m.vz += (fz * m.speed * 1.4 - m.vz) * Math.min(1, 7 * dt);
      }
      if (m.cool <= 0 && dist < 2.1 && Math.abs(py - m.y) < 3) {
        hooks.hurt(DEFS.enderman.dmg);
        m.cool = 0.8;
      }
    } else {
      m.vx *= Math.max(0, 1 - 6 * dt);
      m.vz *= Math.max(0, 1 - 6 * dt);
      if (m.stateT <= 0) {
        m.stateT = 2 + Math.random() * 2;
        m.wantYaw = Math.random() * Math.PI * 2;
      }
    }
    let a = m.wantYaw - m.yaw;
    while (a > Math.PI) a -= Math.PI * 2;
    while (a < -Math.PI) a += Math.PI * 2;
    m.yaw += a * Math.min(1, 6 * dt);
  }

  private blazeAi(
    m: Mob,
    world: World,
    px: number,
    py: number,
    pz: number,
    dt: number,
    hooks: { hurt: (n: number) => void },
  ) {
    const dx = px - m.x;
    const dz = pz - m.z;
    const dist = Math.hypot(dx, dz);
    const see = dist < 20 && this.sees(world, m.x, m.y + 1, m.z, px, py + 1, pz);
    if (see) m.aggro = 8;
    else m.aggro = Math.max(0, m.aggro - dt);
    if (m.aggro > 0) {
      m.wantYaw = Math.atan2(-dx, -dz);
      const stop = dist < 5 ? -1 : dist > 10 ? 1 : 0;
      const fx = -Math.sin(m.wantYaw) * stop;
      const fz = -Math.cos(m.wantYaw) * stop;
      m.vx += (fx * m.speed - m.vx) * Math.min(1, 4 * dt);
      m.vz += (fz * m.speed - m.vz) * Math.min(1, 4 * dt);
      m.vy += (py + 1.2 - m.y - m.vy) * Math.min(1, 2 * dt);
      if (m.cool <= 0 && see && dist < 16) {
        this.shoot(m, px, py + 1, pz, 5);
        m.cool = 1.1;
      }
    } else {
      m.vx *= Math.max(0, 1 - 4 * dt);
      m.vz *= Math.max(0, 1 - 4 * dt);
    }
    let a = m.wantYaw - m.yaw;
    while (a > Math.PI) a -= Math.PI * 2;
    while (a < -Math.PI) a += Math.PI * 2;
    m.yaw += a * Math.min(1, 5 * dt);
    void hooks;
  }

  private piglinAi(m: Mob, world: World, px: number, py: number, pz: number, dt: number, hooks: { hurt: (n: number) => void }) {
    const dx = px - m.x;
    const dz = pz - m.z;
    const dist = Math.hypot(dx, dz);
    if (m.aggro > 0) {
      m.aggro = Math.max(0, m.aggro - dt * 0.04);
      m.wantYaw = Math.atan2(-dx, -dz);
      if (dist > 1.7) {
        const fx = -Math.sin(m.wantYaw);
        const fz = -Math.cos(m.wantYaw);
        m.vx += (fx * m.speed * 1.3 - m.vx) * Math.min(1, 6 * dt);
        m.vz += (fz * m.speed * 1.3 - m.vz) * Math.min(1, 6 * dt);
      }
      if (m.cool <= 0 && dist < 1.7 && Math.abs(py - m.y) < 2) {
        hooks.hurt(DEFS.piglin.dmg);
        m.cool = 0.9;
      }
    } else if (m.stateT <= 0) {
      m.state = m.state === "idle" ? "walk" : "idle";
      m.stateT = 1.4 + Math.random() * 2;
      m.wantYaw = Math.random() * Math.PI * 2;
    }
    if (m.aggro <= 0 && m.state === "walk") {
      const fx = -Math.sin(m.yaw);
      const fz = -Math.cos(m.yaw);
      if (this.blockedAhead(world, m.x + fx * 0.6, m.y, m.z + fz * 0.6, m.h) === "wall") m.wantYaw += 1.2;
      else {
        m.vx += (fx * m.speed * 0.7 - m.vx) * Math.min(1, 5 * dt);
        m.vz += (fz * m.speed * 0.7 - m.vz) * Math.min(1, 5 * dt);
      }
    } else if (m.aggro <= 0) {
      m.vx *= Math.max(0, 1 - 8 * dt);
      m.vz *= Math.max(0, 1 - 8 * dt);
    }
    let a = m.wantYaw - m.yaw;
    while (a > Math.PI) a -= Math.PI * 2;
    while (a < -Math.PI) a += Math.PI * 2;
    m.yaw += a * Math.min(1, 6 * dt);
  }

  private cull(px: number, pz: number) {
    for (let i = this.mobs.length - 1; i >= 0; i--) {
      const m = this.mobs[i]!;
      if (Math.hypot(m.x - px, m.z - pz) > KEEP_DIST) {
        this.group.remove(m.mesh);
        this.disposeMesh(m.mesh);
        this.mobs.splice(i, 1);
      }
    }
  }

  private disposeMesh(root: THREE.Object3D) {
    root.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (mesh.isMesh) mesh.geometry.dispose();
    });
  }

  clear() {
    for (const m of this.mobs) {
      this.group.remove(m.mesh);
      this.disposeMesh(m.mesh);
    }
    for (const s of this.shots) {
      this.group.remove(s.mesh);
      s.mesh.geometry.dispose();
    }
    this.shots = [];
    this.mobs = [];
  }

  dispose() {
    for (const m of this.mobs) this.disposeMesh(m.mesh);
    for (const s of this.shots) {
      this.group.remove(s.mesh);
      s.mesh.geometry.dispose();
    }
    this.shots = [];
    this.mobs = [];
    this.group.removeFromParent();
  }
}

function rayAabb(
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  minx: number,
  miny: number,
  minz: number,
  w: number,
  h: number,
  d: number,
  max: number,
): number | null {
  const invX = dx !== 0 ? 1 / dx : 1e12;
  const invY = dy !== 0 ? 1 / dy : 1e12;
  const invZ = dz !== 0 ? 1 / dz : 1e12;
  let tmin = 0;
  let tmax = max;
  const ax = ((dx >= 0 ? minx : minx + w) - ox) * invX;
  const bx = ((dx >= 0 ? minx + w : minx) - ox) * invX;
  tmin = Math.max(tmin, Math.min(ax, bx));
  tmax = Math.min(tmax, Math.max(ax, bx));
  const ay = ((dy >= 0 ? miny : miny + h) - oy) * invY;
  const by = ((dy >= 0 ? miny + h : miny) - oy) * invY;
  tmin = Math.max(tmin, Math.min(ay, by));
  tmax = Math.min(tmax, Math.max(ay, by));
  const az = ((dz >= 0 ? minz : minz + d) - oz) * invZ;
  const bz = ((dz >= 0 ? minz + d : minz) - oz) * invZ;
  tmin = Math.max(tmin, Math.min(az, bz));
  tmax = Math.min(tmax, Math.max(az, bz));
  if (tmax >= tmin && tmin <= max) return tmin < 0 ? tmax : tmin;
  return null;
}
