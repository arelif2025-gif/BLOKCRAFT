export class GameAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  volume = 0.7;

  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AC({ latencyHint: "interactive" });
      this.master = this.ctx.createGain();
      this.master.gain.value = this.volume;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  setVolume(v: number) {
    this.volume = v;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(v, this.ctx.currentTime, 0.02);
    }
  }

  private beep(freq: number, dur: number, type: OscillatorType, gain = 0.12, slide?: number) {
    if (!this.ctx || !this.master || this.volume <= 0.01) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, slide), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain * this.volume, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g);
    g.connect(this.master);
    osc.start(t);
    osc.stop(t + dur + 0.02);
    osc.onended = () => {
      osc.disconnect();
      g.disconnect();
    };
  }

  private noise(dur: number, gain = 0.18) {
    if (!this.ctx || !this.master || this.volume <= 0.01) return;
    const n = Math.max(1, Math.floor(this.ctx.sampleRate * dur));
    const buf = this.ctx.createBuffer(1, n, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < n; i++) data[i] = Math.random() * 2 - 1;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const g = this.ctx.createGain();
    const t = this.ctx.currentTime;
    g.gain.setValueAtTime(gain * this.volume, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    const f = this.ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 1400;
    src.connect(f);
    f.connect(g);
    g.connect(this.master);
    src.start(t);
    src.stop(t + dur);
    src.onended = () => {
      src.disconnect();
      f.disconnect();
      g.disconnect();
    };
  }

  place() {
    this.beep(180, 0.07, "square", 0.1);
  }
  break() {
    this.noise(0.12, 0.22);
  }
  jump() {
    this.beep(420, 0.14, "square", 0.08, 180);
  }
  hurt() {
    this.beep(160, 0.2, "sawtooth", 0.14, 70);
  }
  pickup() {
    this.beep(760, 0.08, "triangle", 0.08, 1140);
  }
  step() {
    this.noise(0.04, 0.05);
  }
  click() {
    this.beep(520, 0.04, "square", 0.05);
  }
  swing() {
    this.beep(220, 0.1, "sawtooth", 0.06, 80);
  }
  eat() {
    this.beep(280, 0.09, "triangle", 0.07, 180);
    this.noise(0.08, 0.04);
  }
  oink() {
    this.beep(240, 0.16, "square", 0.08, 140);
  }
  cluck() {
    this.beep(620, 0.08, "square", 0.06, 480);
  }
  moo() {
    this.beep(140, 0.22, "sawtooth", 0.07, 90);
  }
  snore() {
    this.beep(90, 0.35, "sine", 0.05, 70);
  }
  growl() {
    this.beep(90, 0.22, "sawtooth", 0.09, 50);
  }
  bones() {
    this.beep(520, 0.08, "square", 0.05, 280);
  }
  hiss() {
    this.noise(0.28, 0.08);
  }
  skitter() {
    this.beep(180, 0.06, "square", 0.05, 90);
  }
  boom() {
    this.noise(0.35, 0.28);
    this.beep(70, 0.3, "sawtooth", 0.12, 40);
  }
}
