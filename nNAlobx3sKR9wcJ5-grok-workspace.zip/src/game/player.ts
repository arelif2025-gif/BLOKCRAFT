import { isLava, isSolid, isWater, solidTop } from "./blocks";
import type { World } from "./world";

const WALK = 4.4;
const SPRINT = 6.4;
const SNEAK = 1.55;
const SWIM = 2.1;
const LAVA_MOVE = 1.15;
const GRAVITY = 28;
const JUMP = 8.6;
const WIDTH = 0.6;
const HEIGHT = 1.8;
const SNEAK_HEIGHT = 1.5;
const EYE = 1.62;
const SNEAK_EYE = 1.22;
const STEP_UP = 0.55;
const WATER_STEP = 1.25;

export class Player {
  x = 0.5;
  y = 40;
  z = 0.5;
  vx = 0;
  vy = 0;
  vz = 0;
  yaw = 0;
  pitch = 0;
  onGround = false;
  sprinting = false;
  sneaking = false;
  inWater = false;
  inLava = false;
  swimBob = 0;
  private coyote = 0;
  private jumpBuf = 0;
  bob = 0;
  dist = 0;
  dive = 0;
  private swimT = 0;

  get eyeY() {
    const base = this.y + (this.sneaking && !this.inWater ? SNEAK_EYE : EYE);
    return base + this.swimBob;
  }

  halfW() {
    return WIDTH * 0.5;
  }

  height() {
    return this.sneaking && !this.inWater ? SNEAK_HEIGHT : HEIGHT;
  }

  setSpawn(x: number, y: number, z: number) {
    this.x = x;
    this.y = y;
    this.z = z;
    this.vx = this.vy = this.vz = 0;
  }

  look(dx: number, dy: number, sensitivity: number) {
    this.yaw -= dx * 0.0022 * sensitivity;
    this.pitch -= dy * 0.0022 * sensitivity;
    const lim = Math.PI / 2 - 0.04;
    if (this.pitch > lim) this.pitch = lim;
    if (this.pitch < -lim) this.pitch = -lim;
  }

  forward(): { x: number; z: number } {
    return { x: -Math.sin(this.yaw), z: -Math.cos(this.yaw) };
  }

  right(): { x: number; z: number } {
    return { x: Math.cos(this.yaw), z: -Math.sin(this.yaw) };
  }

  sampleWater(world: World) {
    const ix = Math.floor(this.x);
    const iz = Math.floor(this.z);
    const feet = world.getBlock(ix, Math.floor(this.y + 0.35), iz);
    const mid = world.getBlock(ix, Math.floor(this.y + 1.05), iz);
    const head = world.getBlock(ix, Math.floor(this.y + 1.5), iz);
    this.inWater = isWater(feet) || isWater(mid) || isWater(head);
    this.inLava = isLava(feet) || isLava(mid) || isLava(head);
    return this.inWater;
  }

  step(
    dt: number,
    world: World,
    moveX: number,
    moveZ: number,
    jump: boolean,
    sneak: boolean,
    sprint: boolean,
    canSprint = true,
  ) {
    this.sampleWater(world);
    if (this.inWater) this.sneaking = sneak;
    else {
      const want = sneak;
      if (!want && this.sneaking) {
        const old = this.sneaking;
        this.sneaking = false;
        if (this.aabbHits(world, this.x, this.y, this.z)) this.sneaking = old;
      } else this.sneaking = want;
    }

    const f = this.forward();
    const r = this.right();
    const mag = Math.hypot(moveX, moveZ);
    let ix = 0;
    let iz = 0;
    if (mag > 1e-4) {
      const nx = moveX / mag;
      const nz = moveZ / mag;
      if (this.inWater) {
        const h = Math.cos(this.pitch);
        ix = f.x * nz * h + r.x * nx;
        iz = f.z * nz * h + r.z * nx;
        this.dive = nz * Math.sin(this.pitch);
      } else {
        ix = f.x * nz + r.x * nx;
        iz = f.z * nz + r.z * nx;
        this.dive = 0;
      }
    } else this.dive = 0;
    this.sprinting = sprint && canSprint && !this.sneaking && !this.inWater && !this.inLava && mag > 0.1;
    const speed = this.inLava ? LAVA_MOVE : this.inWater ? SWIM : this.sneaking ? SNEAK : this.sprinting ? SPRINT : WALK;
    const accel = this.inLava || this.inWater ? 14 : this.onGround ? 40 : 12;
    const targetX = ix * speed;
    const targetZ = iz * speed;
    this.vx += (targetX - this.vx) * Math.min(1, accel * dt);
    this.vz += (targetZ - this.vz) * Math.min(1, accel * dt);
    if (mag < 0.05 && this.onGround && !this.inWater) {
      this.vx *= Math.max(0, 1 - 12 * dt);
      this.vz *= Math.max(0, 1 - 12 * dt);
    }

    this.coyote = this.onGround ? 0.1 : Math.max(0, this.coyote - dt);
    if (jump) this.jumpBuf = 0.12;
    else this.jumpBuf = Math.max(0, this.jumpBuf - dt);

    if (this.inLava) {
      this.vy -= 6 * dt;
      if (this.vy > 1.2) this.vy = 1.2;
      if (this.vy < -1.8) this.vy = -1.8;
      if (jump) this.vy += 8 * dt;
      this.swimBob = Math.sin(this.swimT * 2.2) * 0.03;
      this.swimT += dt;
    } else if (this.inWater) {
      this.swimT += dt;
      const moving = mag > 0.12;
      if (moving && Math.abs(this.dive) > 0.12) {
        const targetVy = this.dive * speed;
        this.vy += (targetVy - this.vy) * Math.min(1, 8 * dt);
      } else if (jump) this.vy += 12 * dt;
      else if (this.sneaking) this.vy -= 8 * dt;
      else if (moving) this.vy += (0.22 - this.vy) * Math.min(1, 5 * dt);
      else this.vy += (0.45 - this.vy) * Math.min(1, 3 * dt);
      if (this.vy > 4.4) this.vy = 4.4;
      if (this.vy < -4.2) this.vy = -4.2;
      this.swimBob = moving ? Math.sin(this.swimT * 2.2) * 0.018 : Math.sin(this.swimT * 1.2) * 0.008;
    } else {
      this.swimBob *= Math.max(0, 1 - 8 * dt);
      this.vy -= GRAVITY * dt;
      if (this.vy < -42) this.vy = -42;
      if (this.jumpBuf > 0 && this.coyote > 0) {
        this.vy = JUMP;
        this.onGround = false;
        this.coyote = 0;
        this.jumpBuf = 0;
      }
    }

    const steps = Math.max(1, Math.ceil((Math.hypot(this.vx, this.vy, this.vz) * dt) / 0.2));
    const sdt = dt / steps;
    let landedHard = 0;
    for (let i = 0; i < steps; i++) {
      const ox = this.x;
      const oz = this.z;
      this.x += this.vx * sdt;
      this.resolve(world, "x", ox);
      if (this.sneaking && !this.inWater && this.onGround && !this.hasGround(world)) {
        this.x = ox;
        this.vx = 0;
      }
      this.z += this.vz * sdt;
      this.resolve(world, "z", oz);
      if (this.sneaking && !this.inWater && this.onGround && !this.hasGround(world)) {
        this.z = oz;
        this.vz = 0;
      }
      const beforeY = this.y;
      this.y += this.vy * sdt;
      const wasUp = this.vy;
      this.resolve(world, "y", beforeY);
      if (this.onGround && wasUp < -13 && beforeY > this.y - 0.01) {
        landedHard = Math.max(landedHard, -wasUp);
      }
    }

    const spd = Math.hypot(this.vx, this.vz);
    if (this.onGround && spd > 0.6 && !this.inWater) {
      this.dist += spd * dt * (this.sprinting ? 0.62 : 1);
      const amp = this.sprinting ? 0.28 : 0.7;
      this.bob = Math.sin(this.dist * 7.2) * Math.min(1, spd / WALK) * amp;
    } else {
      this.bob *= Math.max(0, 1 - 10 * dt);
    }
    return landedHard;
  }

  private hasGround(world: World): boolean {
    const hw = this.halfW() - 0.02;
    const y = Math.floor(this.y - 0.08);
    for (let z = Math.floor(this.z - hw); z <= Math.floor(this.z + hw); z++) {
      for (let x = Math.floor(this.x - hw); x <= Math.floor(this.x + hw); x++) {
        if (isSolid(world.getBlock(x, y, z))) return true;
      }
    }
    return false;
  }

  private resolve(world: World, axis: "x" | "y" | "z", prev: number) {
    const hw = this.halfW();
    const h = this.height();
    if (axis === "y") this.onGround = false;

    const minX = this.x - hw;
    const maxX = this.x + hw;
    const minY = this.y;
    const maxY = this.y + h;
    const minZ = this.z - hw;
    const maxZ = this.z + hw;
    const x0 = Math.floor(minX);
    const x1 = Math.floor(maxX);
    const y0 = Math.floor(minY);
    const y1 = Math.floor(maxY);
    const z0 = Math.floor(minZ);
    const z1 = Math.floor(maxZ);

    let pushPos = 0;
    let pushNeg = 0;
    let stepBlock: [number, number, number] | null = null;
    let bestStep = 99;

    for (let y = y0; y <= y1; y++) {
      for (let z = z0; z <= z1; z++) {
        for (let x = x0; x <= x1; x++) {
          const id = world.getBlock(x, y, z);
          if (!isSolid(id)) continue;
          const top = y + solidTop(id);
          if (maxX <= x || minX >= x + 1 || maxY <= y || minY >= top || maxZ <= z || minZ >= z + 1) continue;
          if (axis === "x" || axis === "z") {
            const step = top - this.y;
            if (step > 0 && step < bestStep) {
              bestStep = step;
              stepBlock = [x, y, z];
            }
          }
          if (axis === "x") {
            if (x + 0.5 >= this.x) pushNeg = Math.max(pushNeg, maxX - x);
            else pushPos = Math.max(pushPos, x + 1 - minX);
          } else if (axis === "z") {
            if (z + 0.5 >= this.z) pushNeg = Math.max(pushNeg, maxZ - z);
            else pushPos = Math.max(pushPos, z + 1 - minZ);
          } else if (top - 0.5 >= this.y + h * 0.5) {
            pushNeg = Math.max(pushNeg, maxY - y);
          } else {
            pushPos = Math.max(pushPos, top - minY);
          }
        }
      }
    }

    const wedged = pushPos > 1e-6 && pushNeg > 1e-6;
    if (axis !== "y" && stepBlock && this.tryStep(world, stepBlock[0], stepBlock[1], stepBlock[2])) return;

    if (wedged) {
      if (axis === "x") {
        this.x = prev;
        this.vx = 0;
      } else if (axis === "z") {
        this.z = prev;
        this.vz = 0;
      } else {
        this.y = prev;
        this.vy = 0;
        this.onGround = true;
      }
      return;
    }

    const EPS = 1e-4;
    if (axis === "x") {
      if (pushPos > 0) this.x += pushPos + EPS;
      else if (pushNeg > 0) this.x -= pushNeg + EPS;
      if (pushPos > 0 || pushNeg > 0) this.vx = 0;
    } else if (axis === "z") {
      if (pushPos > 0) this.z += pushPos + EPS;
      else if (pushNeg > 0) this.z -= pushNeg + EPS;
      if (pushPos > 0 || pushNeg > 0) this.vz = 0;
    } else if (pushPos > 0) {
      this.y += pushPos + EPS;
      this.vy = 0;
      this.onGround = true;
    } else if (pushNeg > 0) {
      this.y -= pushNeg + EPS;
      this.vy = 0;
    }
  }

  private tryStep(world: World, bx: number, by: number, bz: number): boolean {
    if (this.sneaking && !this.inWater) return false;
    if (!this.onGround && !this.inWater) return false;
    const hw = this.halfW();
    const id = world.getBlock(bx, by, bz);
    const step = by + solidTop(id) - this.y;
    const maxStep = this.inWater ? WATER_STEP : STEP_UP;
    if (step <= 0 || step > maxStep) return false;
    const ny = this.y + step + 0.01;
    if (this.aabbHits(world, this.x, ny, this.z, hw)) return false;
    const above = world.getBlock(bx, by + 1, bz);
    if (isSolid(above)) return false;
    this.y = ny;
    if (this.inWater) this.vy = Math.max(this.vy, 2.2);
    return true;
  }

  aabbHits(world: World, x: number, y: number, z: number, hw = this.halfW()): boolean {
    const minX = x - hw;
    const maxX = x + hw;
    const minY = y;
    const maxY = y + this.height();
    const minZ = z - hw;
    const maxZ = z + hw;
    for (let iy = Math.floor(minY); iy <= Math.floor(maxY); iy++) {
      for (let iz = Math.floor(minZ); iz <= Math.floor(maxZ); iz++) {
        for (let ix = Math.floor(minX); ix <= Math.floor(maxX); ix++) {
          const id = world.getBlock(ix, iy, iz);
          if (!isSolid(id)) continue;
          const top = iy + solidTop(id);
          if (maxY <= iy || minY >= top || maxX <= ix || minX >= ix + 1 || maxZ <= iz || minZ >= iz + 1) continue;
          return true;
        }
      }
    }
    return false;
  }
}
