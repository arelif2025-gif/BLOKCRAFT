import {
  AIR,
  AMETHYST,
  AMETHYST_ORE,
  BED,
  BEDROCK,
  CACTUS,
  COAL,
  DIAMOND,
  DIRT,
  FURNACE,
  GOLD,
  GRASS,
  GRAVEL,
  IRON_ORE,
  LAVA,
  LEAVES,
  OBSIDIAN,
  PLANKS,
  PORTAL,
  NETHERRACK,
  NETHER_BRICK,
  BOOKSHELF,
  END_FRAME,
  END_FRAME_EYE,
  END_PORTAL,
  END_STONE,
  RAW_GOLD,
  RAW_IRON,
  SAND,
  SNOW,
  STONE,
  WATER,
  WOOD,
  WOOL,
} from "./types";
import { itemName as toolName } from "./items";

export type BlockDef = {
  id: number;
  name: string;
  nameTr: string;
  solid: boolean;
  opaque: boolean;
  breakable: boolean;
  hardness: number;
  atlas: number;
  drops: number;
};

function solid(
  id: number,
  name: string,
  nameTr: string,
  atlas: number,
  hardness: number,
  extra: Partial<BlockDef> = {},
): BlockDef {
  return {
    id,
    name,
    nameTr,
    solid: true,
    opaque: true,
    breakable: true,
    hardness,
    atlas,
    drops: id,
    ...extra,
  };
}

export const BLOCKS: Record<number, BlockDef> = {
  [AIR]: {
    id: AIR,
    name: "Air",
    nameTr: "Hava",
    solid: false,
    opaque: false,
    breakable: false,
    hardness: 0,
    atlas: 0,
    drops: AIR,
  },
  [GRASS]: solid(GRASS, "Grass", "Çim", 0, 0.55, { drops: DIRT }),
  [DIRT]: solid(DIRT, "Dirt", "Toprak", 1, 0.5),
  [STONE]: solid(STONE, "Stone", "Taş", 2, 1.4),
  [WOOD]: solid(WOOD, "Wood", "Odun", 3, 0.9),
  [LEAVES]: solid(LEAVES, "Leaves", "Yaprak", 4, 0.25),
  [COAL]: solid(COAL, "Coal Ore", "Kömür", 5, 1.8),
  [GOLD]: solid(GOLD, "Gold Ore", "Altın Cevheri", 6, 2.2, { drops: RAW_GOLD }),
  [DIAMOND]: solid(DIAMOND, "Diamond Ore", "Elmas", 7, 2.8),
  [BEDROCK]: solid(BEDROCK, "Bedrock", "Kaya", 8, 999, { breakable: false, drops: AIR }),
  [SAND]: solid(SAND, "Sand", "Kum", 9, 0.45),
  [SNOW]: solid(SNOW, "Snow", "Kar", 10, 0.4),
  [WATER]: {
    id: WATER,
    name: "Water",
    nameTr: "Su",
    solid: false,
    opaque: false,
    breakable: false,
    hardness: 0,
    atlas: 0,
    drops: AIR,
  },
  [PLANKS]: solid(PLANKS, "Planks", "Tahta", 11, 0.7),
  [CACTUS]: solid(CACTUS, "Cactus", "Kaktüs", 12, 0.35),
  [IRON_ORE]: solid(IRON_ORE, "Iron Ore", "Demir Cevheri", 13, 2.0, { drops: RAW_IRON }),
  [AMETHYST_ORE]: solid(AMETHYST_ORE, "Amethyst Ore", "Ametist Cevheri", 14, 2.4, { drops: AMETHYST }),
  [GRAVEL]: solid(GRAVEL, "Gravel", "Çakıl", 15, 0.5),
  [LAVA]: {
    id: LAVA,
    name: "Lava",
    nameTr: "Lav",
    solid: false,
    opaque: false,
    breakable: false,
    hardness: 0,
    atlas: 0,
    drops: AIR,
  },
  [OBSIDIAN]: solid(OBSIDIAN, "Obsidian", "Obsidyen", 16, 12, { drops: OBSIDIAN }),
  [FURNACE]: solid(FURNACE, "Furnace", "Fırın", 17, 1.6),
  [WOOL]: solid(WOOL, "Wool", "Yün", 18, 0.4),
  [BED]: solid(BED, "Bed", "Yatak", 19, 0.35),
  [PORTAL]: {
    id: PORTAL,
    name: "Portal",
    nameTr: "Portal",
    solid: false,
    opaque: false,
    breakable: true,
    hardness: 0.15,
    atlas: 0,
    drops: AIR,
  },
  [NETHERRACK]: solid(NETHERRACK, "Netherrack", "Nether Taşı", 20, 0.5),
  [NETHER_BRICK]: solid(NETHER_BRICK, "Nether Brick", "Nether Tuğlası", 21, 1.2),
  [BOOKSHELF]: solid(BOOKSHELF, "Bookshelf", "Kitaplık", 22, 0.6, { drops: PLANKS }),
  [END_FRAME]: solid(END_FRAME, "End Frame", "End Çerçevesi", 23, 4, { opaque: false }),
  [END_FRAME_EYE]: solid(END_FRAME_EYE, "End Frame", "End Çerçevesi", 24, 4, { opaque: false, drops: END_FRAME }),
  [END_PORTAL]: {
    id: END_PORTAL,
    name: "End Portal",
    nameTr: "End Portalı",
    solid: false,
    opaque: false,
    breakable: false,
    hardness: 0,
    atlas: 0,
    drops: AIR,
  },
  [END_STONE]: solid(END_STONE, "End Stone", "End Taşı", 25, 1.5),
};

export const PLACEABLE = [
  GRASS,
  DIRT,
  STONE,
  WOOD,
  LEAVES,
  COAL,
  GOLD,
  DIAMOND,
  SAND,
  SNOW,
  PLANKS,
  CACTUS,
  IRON_ORE,
  AMETHYST_ORE,
  GRAVEL,
  OBSIDIAN,
  FURNACE,
  WOOL,
  BED,
];

export function isSolid(id: number): boolean {
  return BLOCKS[id]?.solid ?? false;
}

export function isOpaque(id: number): boolean {
  return BLOCKS[id]?.opaque ?? false;
}

export function solidTop(id: number): number {
  return id === END_FRAME || id === END_FRAME_EYE ? 0.84 : 1;
}

export function isWater(id: number): boolean {
  return id === WATER;
}

export function isLava(id: number): boolean {
  return id === LAVA;
}

export function isFluid(id: number): boolean {
  return id === WATER || id === LAVA;
}

export function blockName(id: number): string {
  const tool = toolName(id);
  if (tool) return tool;
  return BLOCKS[id]?.nameTr ?? "";
}
