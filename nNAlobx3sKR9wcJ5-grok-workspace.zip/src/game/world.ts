import { createNoise2D, createNoise3D } from "simplex-noise";
import { isOpaque, isSolid } from "./blocks";
import { hash2, mulberry32 } from "./rng";
import { fortresses, frameSpots, strongholds, type Room } from "./structures";
import {
  AIR,
  AMETHYST_ORE,
  BEDROCK,
  BIOME_DESERT,
  BIOME_FOREST,
  BIOME_OCEAN,
  BIOME_PLAINS,
  BIOME_SNOW,
  BOOKSHELF,
  CACTUS,
  CHUNK_D,
  CHUNK_H,
  CHUNK_W,
  COAL,
  DIAMOND,
  DIRT,
  END_FRAME,
  END_STONE,
  ENDER_PEARL,
  GOLD,
  GOLD_INGOT,
  GRASS,
  GRAVEL,
  IRON_INGOT,
  IRON_ORE,
  LAVA,
  LEAVES,
  NETHERRACK,
  NETHER_BRICK,
  OBSIDIAN,
  SAND,
  SEA_LEVEL,
  SNOW,
  STONE,
  WATER,
  WOOD,
  type BiomeId,
  type BlockId,
} from "./types";

export function chunkKey(cx: number, cz: number): string {
  return `${cx},${cz}`;
}

export function worldToChunk(x: number, z: number): [number, number, number, number] {
  const cx = Math.floor(x / CHUNK_W);
  const cz = Math.floor(z / CHUNK_D);
  const lx = x - cx * CHUNK_W;
  const lz = z - cz * CHUNK_D;
  return [cx, cz, lx, lz];
}

export const BIOME_NAME = ["Okyanus", "Ova", "Orman", "Çöl", "Kar"];

export class World {
  seed: number;
  kind: "overworld" | "nether" | "end";
  chunks = new Map<string, Uint8Array>();
  dirty = new Set<string>();
  private generating = new Set<string>();
  private flow = new Map<string, number>();
  private lavaFlow = new Map<string, number>();
  private pendingWater = new Set<string>();
  private pendingLava = new Set<string>();
  private changes = new Map<string, Map<string, number>>();
  rooms: Room[] = [];
  forts: Room[] = [];
  loot: Array<{ x: number; y: number; z: number; id: number; count: number }> = [];
  endTowers: Array<{ x: number; z: number; top: number }> = [];
  private isles: Array<{ x: number; z: number; r: number; y: number }> = [];
  private looted = new Set<string>();
  private noise2: (x: number, y: number) => number;
  private noise3: (x: number, y: number, z: number) => number;

  constructor(seed: number, kind: "overworld" | "nether" | "end" = "overworld") {
    this.seed = seed;
    this.kind = kind;
    const rng = mulberry32(seed);
    this.noise2 = createNoise2D(rng);
    this.noise3 = createNoise3D(rng);
    this.rooms = kind === "overworld" ? strongholds(seed) : [];
    this.forts = kind === "nether" ? fortresses(seed) : [];
    if (kind === "overworld") this.buryStrongholds();
    if (kind === "end") this.planEnd();
  }

  biomeAt(wx: number, wz: number): BiomeId {
    const continent = this.noise2(wx * 0.0034, wz * 0.0034);
    const temp = this.noise2(wx * 0.0052 + 90, wz * 0.0052);
    const rain = this.noise2(wx * 0.006 + 21, wz * 0.006);
    if (continent < -0.16) return BIOME_OCEAN;
    if (temp > 0.3) return BIOME_DESERT;
    if (temp < -0.3) return BIOME_SNOW;
    if (rain > 0.06) return BIOME_FOREST;
    return BIOME_PLAINS;
  }

  heightAt(wx: number, wz: number): number {
    const n =
      this.noise2(wx * 0.018, wz * 0.018) * 8 +
      this.noise2(wx * 0.05, wz * 0.05) * 3.2 +
      this.noise2(wx * 0.12, wz * 0.12) * 1.2;
    const b = this.biomeAt(wx, wz);
    let base = 20;
    let amp = 1;
    if (b === BIOME_OCEAN) {
      base = 11;
      amp = 0.45;
    } else if (b === BIOME_DESERT) {
      base = 18;
      amp = 0.7;
    } else if (b === BIOME_SNOW) {
      base = 24;
      amp = 1.25;
    } else if (b === BIOME_FOREST) {
      base = 21;
      amp = 1;
    } else {
      base = 20;
      amp = 0.75;
    }
    return Math.max(6, Math.min(CHUNK_H - 10, Math.floor(base + n * amp)));
  }

  findSpawn(): [number, number, number] {
    for (let r = 0; r <= 96; r += 3) {
      const steps = r === 0 ? 1 : 10;
      for (let i = 0; i < steps; i++) {
        const a = (i / steps) * Math.PI * 2 + r * 0.2;
        const wx = Math.round(Math.cos(a) * r);
        const wz = Math.round(Math.sin(a) * r);
        if (this.biomeAt(wx, wz) === BIOME_OCEAN) continue;
        const h = this.heightAt(wx, wz);
        if (h >= SEA_LEVEL - 1) return [wx + 0.5, h + 1.05, wz + 0.5];
      }
    }
    const h = this.heightAt(0, 0);
    return [0.5, h + 1.05, 0.5];
  }

  ensureChunk(cx: number, cz: number): Uint8Array {
    const k = chunkKey(cx, cz);
    let data = this.chunks.get(k);
    if (data) return data;
    if (this.generating.has(k)) {
      data = new Uint8Array(CHUNK_W * CHUNK_H * CHUNK_D);
      this.chunks.set(k, data);
      return data;
    }
    this.generating.add(k);
    data = this.kind === "nether" ? this.generateNether(cx, cz) : this.kind === "end" ? this.generateEnd(cx, cz) : this.generate(cx, cz);
    this.replayChunk(cx, cz, data);
    this.generating.delete(k);
    this.chunks.set(k, data);
    this.dirty.add(k);
    return data;
  }

  remember(x: number, y: number, z: number, id: number) {
    const [cx, cz, lx, lz] = worldToChunk(Math.floor(x), Math.floor(z));
    const ck = chunkKey(cx, cz);
    let bucket = this.changes.get(ck);
    if (!bucket) {
      bucket = new Map();
      this.changes.set(ck, bucket);
    }
    bucket.set(`${lx},${Math.floor(y)},${lz}`, id);
  }

  editBlock(x: number, y: number, z: number, id: BlockId): boolean {
    if (y < 0 || y >= CHUNK_H) return false;
    x = Math.floor(x);
    y = Math.floor(y);
    z = Math.floor(z);
    this.remember(x, y, z, id);
    const [cx, cz] = worldToChunk(x, z);
    if (!this.chunks.has(chunkKey(cx, cz))) {
      this.ensureChunk(cx, cz);
      return this.getBlock(x, y, z) === id;
    }
    if (this.getBlock(x, y, z) === id) return true;
    return this.setBlock(x, y, z, id) || this.getBlock(x, y, z) === id;
  }

  loadEdits(edits: Array<[number, number, number, number]>) {
    for (const [x, y, z, id] of edits) this.remember(x, y, z, id);
  }

  exportEdits(): Array<[number, number, number, number]> {
    const out: Array<[number, number, number, number]> = [];
    for (const [ck, bucket] of this.changes) {
      const [cx, cz] = ck.split(",").map(Number);
      for (const [lk, id] of bucket) {
        const [lx, y, lz] = lk.split(",").map(Number);
        out.push([cx! * CHUNK_W + lx!, y!, cz! * CHUNK_D + lz!, id]);
      }
    }
    return out;
  }

  private replayChunk(cx: number, cz: number, data: Uint8Array) {
    const bucket = this.changes.get(chunkKey(cx, cz));
    if (!bucket) return;
    for (const [lk, id] of bucket) {
      const [lx, y, lz] = lk.split(",").map(Number);
      if (y! < 0 || y! >= CHUNK_H) continue;
      data[this.index(lx!, y!, lz!)] = id;
    }
  }

  planEnd() {
    this.isles = [{ x: 0, z: 0, r: 32, y: 34 }];
    this.endTowers = [];
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2 + 0.2;
      this.endTowers.push({ x: Math.round(Math.cos(a) * 20), z: Math.round(Math.sin(a) * 20), top: 52 });
    }
    for (let i = 0; i < 22; i++) {
      const a = hash2(i, 3, this.seed) * Math.PI * 2;
      const rad = 58 + hash2(i, 9, this.seed) * 170;
      const r = 7 + hash2(i, 4, this.seed) * 8;
      this.isles.push({
        x: Math.round(Math.cos(a) * rad),
        z: Math.round(Math.sin(a) * rad),
        r,
        y: 24 + Math.floor(hash2(i, 6, this.seed) * 12),
      });
    }
  }

  endSurface(wx: number, wz: number): number | null {
    let best: number | null = null;
    for (const isle of this.isles) {
      const dx = wx - isle.x;
      const dz = wz - isle.z;
      const d = Math.hypot(dx, dz);
      if (d > isle.r) continue;
      const edge = 1 - d / isle.r;
      const n = this.noise2(wx * 0.07, wz * 0.07) * 1.6;
      const h = Math.floor(isle.y + edge * 5 + n);
      if (best == null || h > best) best = h;
    }
    return best;
  }

  private generateEnd(cx: number, cz: number): Uint8Array {
    const data = new Uint8Array(CHUNK_W * CHUNK_H * CHUNK_D);
    const ox = cx * CHUNK_W;
    const oz = cz * CHUNK_D;
    for (let lz = 0; lz < CHUNK_D; lz++) {
      for (let lx = 0; lx < CHUNK_W; lx++) {
        const wx = ox + lx;
        const wz = oz + lz;
        const h = this.endSurface(wx, wz);
        if (h == null) continue;
        const top = Math.max(1, Math.min(CHUNK_H - 2, h));
        for (let y = Math.max(1, top - 5); y <= top; y++) this.setLocal(data, lx, y, lz, END_STONE);
        for (const tower of this.endTowers) {
          if (tower.x !== wx || tower.z !== wz) continue;
          for (let y = top + 1; y <= tower.top; y++) this.setLocal(data, lx, y, lz, OBSIDIAN);
        }
      }
    }
    return data;
  }

  private generateNether(cx: number, cz: number): Uint8Array {
    const data = new Uint8Array(CHUNK_W * CHUNK_H * CHUNK_D);
    const ox = cx * CHUNK_W;
    const oz = cz * CHUNK_D;
    for (let z = 0; z < CHUNK_D; z++) {
      for (let x = 0; x < CHUNK_W; x++) {
        const wx = ox + x;
        const wz = oz + z;
        const n = this.noise2(wx * 0.035, wz * 0.035);
        const n2 = this.noise2(wx * 0.11 + 8, wz * 0.11);
        const h = 12 + Math.floor((n + 1) * 9 + n2 * 3);
        const ceil = 46 + Math.floor((n2 + 1) * 5);
        for (let y = 0; y < CHUNK_H; y++) {
          let id = AIR;
          if (y === 0 || y === CHUNK_H - 1) id = BEDROCK;
          else if (y >= ceil) id = NETHERRACK;
          else if (y > h) id = y <= 11 ? LAVA : AIR;
          else {
            const cave = this.noise3(wx * 0.08, y * 0.09, wz * 0.08);
            if (cave > 0.74 && y > 14 && y < h - 2) id = AIR;
            else id = NETHERRACK;
          }
          data[this.index(x, y, z)] = id;
        }
      }
    }
    for (let z = 0; z < CHUNK_D; z++) {
      for (let x = 0; x < CHUNK_W; x++) {
        for (let y = 2; y < 20; y++) {
          if (this.getLocal(data, x, y, z) === LAVA) this.scheduleLavaAround(ox + x, y, oz + z);
        }
      }
    }
    this.stampFortress(data, cx, cz);
    return data;
  }

  private generate(cx: number, cz: number): Uint8Array {
    const data = new Uint8Array(CHUNK_W * CHUNK_H * CHUNK_D);
    const ox = cx * CHUNK_W;
    const oz = cz * CHUNK_D;
    const trees: Array<[number, number, number, BiomeId]> = [];
    const cacti: Array<[number, number, number]> = [];

    for (let z = 0; z < CHUNK_D; z++) {
      for (let x = 0; x < CHUNK_W; x++) {
        const wx = ox + x;
        const wz = oz + z;
        const biome = this.biomeAt(wx, wz);
        const h = this.heightAt(wx, wz);
        for (let y = 0; y < CHUNK_H; y++) {
          let id = AIR;
          if (y === 0) id = BEDROCK;
          else if (y > h) {
            if (y <= SEA_LEVEL && (biome === BIOME_OCEAN || h < SEA_LEVEL)) id = WATER;
            else id = AIR;
          } else if (y === h) {
            if (biome === BIOME_OCEAN) id = SAND;
            else if (biome === BIOME_DESERT) id = SAND;
            else if (biome === BIOME_SNOW) id = SNOW;
            else id = GRASS;
          } else if (y >= h - 3) {
            if (biome === BIOME_OCEAN || biome === BIOME_DESERT) {
              const g = hash2(wx, y * 13 + wz, this.seed);
              id = g < 0.42 ? GRAVEL : SAND;
            } else id = DIRT;
          } else {
            id = STONE;
            const cave = this.noise3(wx * 0.055, y * 0.07, wz * 0.055);
            if (cave > 0.8 && y > 5 && y < h - 6) {
              id = AIR;
              const caveBelow = this.noise3(wx * 0.055, (y - 1) * 0.07, wz * 0.055);
              if (y <= 11 && (y <= 6 || caveBelow <= 0.8)) {
                const lavaN = this.noise3(wx * 0.09 + 7, y * 0.12, wz * 0.09);
                if (lavaN > 0.08) id = LAVA;
              }
            } else {
              const ore = this.noise3(wx * 0.13 + 40, y * 0.13, wz * 0.13);
              if (y < 8 && ore > 0.8) id = OBSIDIAN;
              else if (y < 10 && ore > 0.72) id = DIAMOND;
              else if (y < 14 && ore > 0.69) id = AMETHYST_ORE;
              else if (y < 16 && ore > 0.66) id = GOLD;
              else if (y < 22 && ore > 0.58) id = IRON_ORE;
              else if (y < 28 && ore > 0.6) id = COAL;
            }
          }
          data[x + z * CHUNK_W + y * CHUNK_W * CHUNK_D] = id;
        }
        const top = this.getLocal(data, x, h, z);
        const roll = hash2(wx, wz, this.seed);
        if (biome === BIOME_FOREST && top === GRASS && roll < 0.085) trees.push([x, h, z, biome]);
        else if (biome === BIOME_PLAINS && top === GRASS && roll < 0.016) trees.push([x, h, z, biome]);
        else if (biome === BIOME_SNOW && top === SNOW && roll < 0.03) trees.push([x, h, z, biome]);
        else if (biome === BIOME_DESERT && top === SAND && h >= SEA_LEVEL && roll < 0.005) cacti.push([x, h, z]);
      }
    }

    for (const t of trees) this.plantTree(data, cx, cz, t[0], t[1], t[2], t[3]);
    for (const c of cacti) this.plantCactus(data, c[0], c[1], c[2]);
    for (let z = 0; z < CHUNK_D; z++) {
      for (let x = 0; x < CHUNK_W; x++) {
        for (let y = 2; y < 14; y++) {
          if (this.getLocal(data, x, y, z) === LAVA) this.scheduleLavaAround(ox + x, y, oz + z);
        }
      }
    }
    this.stampStronghold(data, cx, cz);
    return data;
  }

  private putCell(data: Uint8Array, ox: number, oz: number, x: number, y: number, z: number, id: number) {
    const lx = x - ox;
    const lz = z - oz;
    if (lx < 0 || lz < 0 || lx >= CHUNK_W || lz >= CHUNK_D || y < 1 || y >= CHUNK_H - 1) return;
    this.setLocal(data, lx, y, lz, id);
  }

  private buryStrongholds() {
    for (const room of this.rooms) {
      let placed = false;
      for (let ring = 0; ring <= 160 && !placed; ring += 10) {
        const steps = ring === 0 ? 1 : 10;
        for (let i = 0; i < steps; i++) {
          const a = (i / steps) * Math.PI * 2 + room.x * 0.01;
          const tx = Math.round(room.x + Math.cos(a) * ring);
          const tz = Math.round(room.z + Math.sin(a) * ring);
          const spots: Array<[number, number]> = [
            [tx + 6, tz + 6],
            [tx + 16, tz + 6],
            [tx + 2, tz + 2],
            [tx + 20, tz + 10],
          ];
          if (spots.some(([sx, sz]) => this.biomeAt(sx, sz) === BIOME_OCEAN)) continue;
          const minH = Math.min(...spots.map(([sx, sz]) => this.heightAt(sx, sz)));
          if (minH < SEA_LEVEL + 3) continue;
          room.x = tx;
          room.z = tz;
          room.y = Math.max(5, minH - 15);
          placed = true;
          break;
        }
      }
      if (!placed) {
        const h = this.heightAt(room.x + 6, room.z + 6);
        room.y = Math.max(4, Math.min(h, SEA_LEVEL - 2) - 12);
      }
    }
  }

  private capRoof(data: Uint8Array, ox: number, oz: number, x: number, z: number, roof: number) {
    for (let y = roof + 1; y <= roof + 4; y++) {
      const lx = x - ox;
      const lz = z - oz;
      if (lx < 0 || lz < 0 || lx >= CHUNK_W || lz >= CHUNK_D || y >= CHUNK_H - 1) continue;
      const cur = this.getLocal(data, lx, y, lz);
      if (cur === WATER || cur === AIR) this.setLocal(data, lx, y, lz, STONE);
    }
  }

  private stampStronghold(data: Uint8Array, cx: number, cz: number) {
    const ox = cx * CHUNK_W;
    const oz = cz * CHUNK_D;
    for (const room of this.rooms) {
      if (room.x + 28 < ox || room.x > ox + CHUNK_W + 2) continue;
      if (room.z + 14 < oz || room.z > oz + CHUNK_D + 2) continue;
      for (let dy = 0; dy <= 6; dy++) {
        for (let dz = 0; dz <= 12; dz++) {
          for (let dx = 0; dx <= 12; dx++) {
            const edge = dx === 0 || dx === 12 || dz === 0 || dz === 12 || dy === 0 || dy === 6;
            const door = dz === 0 && dx >= 5 && dx <= 7 && dy >= 1 && dy <= 3;
            const toLib = dx === 12 && dz >= 5 && dz <= 7 && dy >= 1 && dy <= 3;
            let id = AIR;
            if (edge && !door && !toLib) id = STONE;
            if (dy === 0 && dx >= 4 && dx <= 7 && dz >= 4 && dz <= 7) id = LAVA;
            this.putCell(data, ox, oz, room.x + dx, room.y + dy, room.z + dz, id);
          }
        }
      }
      for (const [x, y, z] of frameSpots(room)) this.putCell(data, ox, oz, x, y, z, END_FRAME);
      for (let x = room.x; x <= room.x + 12; x++) {
        for (let z = room.z; z <= room.z + 12; z++) this.capRoof(data, ox, oz, x, z, room.y + 6);
      }
      for (let dy = 0; dy <= 5; dy++) {
        for (let dz = 0; dz <= 8; dz++) {
          for (let dx = 0; dx <= 8; dx++) {
            const edge = dx === 0 || dx === 8 || dz === 0 || dz === 8 || dy === 0 || dy === 5;
            const door = dx === 0 && dz >= 3 && dz <= 5 && dy >= 1 && dy <= 3;
            let id = AIR;
            if (edge && !door) id = dy >= 1 && dy <= 3 && dy !== 5 ? BOOKSHELF : STONE;
            if (dy === 0 || dy === 5) id = STONE;
            if (door) id = AIR;
            this.putCell(data, ox, oz, room.x + 12 + dx, room.y + dy, room.z + 2 + dz, id);
          }
        }
      }
      for (let x = room.x + 12; x <= room.x + 20; x++) {
        for (let z = room.z + 2; z <= room.z + 10; z++) this.capRoof(data, ox, oz, x, z, room.y + 5);
      }
      const key = `${room.x},${room.z}`;
      if (!this.looted.has(key)) {
        this.looted.add(key);
        this.loot.push(
          { x: room.x + 18, y: room.y + 1, z: room.z + 6, id: IRON_INGOT, count: 4 },
          { x: room.x + 17, y: room.y + 1, z: room.z + 5, id: GOLD_INGOT, count: 2 },
          { x: room.x + 19, y: room.y + 1, z: room.z + 7, id: DIAMOND, count: 1 },
          { x: room.x + 18, y: room.y + 1, z: room.z + 4, id: ENDER_PEARL, count: 1 },
        );
      }
    }
  }

  private stampFortress(data: Uint8Array, cx: number, cz: number) {
    const ox = cx * CHUNK_W;
    const oz = cz * CHUNK_D;
    for (const fort of this.forts) {
      if (Math.abs(fort.x - (ox + 8)) > 40 || Math.abs(fort.z - (oz + 8)) > 40) continue;
      const carve = (x: number, z: number) => {
        if (Math.abs(x - fort.x) > 30 && Math.abs(z - fort.z) > 30) return;
        const onX = Math.abs(z - fort.z) <= 2 && Math.abs(x - fort.x) <= 28;
        const onZ = Math.abs(x - fort.x) <= 2 && Math.abs(z - fort.z) <= 28;
        const room = Math.abs(x - fort.x) <= 4 && Math.abs(z - fort.z) <= 4;
        if (!onX && !onZ && !room) return;
        for (let dy = 0; dy <= 5; dy++) {
          const edge =
            dy === 0 ||
            dy === 5 ||
            (onX && Math.abs(z - fort.z) === 2) ||
            (onZ && Math.abs(x - fort.x) === 2) ||
            (room && (Math.abs(x - fort.x) === 4 || Math.abs(z - fort.z) === 4));
          const inside = room && Math.abs(x - fort.x) < 4 && Math.abs(z - fort.z) < 4;
          const id = edge && !(inside && dy > 0 && dy < 5) ? NETHER_BRICK : AIR;
          this.putCell(data, ox, oz, x, fort.y + dy, z, dy === 0 ? NETHER_BRICK : id);
        }
      };
      for (let x = ox - 1; x < ox + CHUNK_W + 1; x++) {
        for (let z = oz - 1; z < oz + CHUNK_D + 1; z++) carve(x, z);
      }
    }
  }

  private plantTree(data: Uint8Array, cx: number, cz: number, lx: number, ground: number, lz: number, biome: BiomeId) {
    const ox = cx * CHUNK_W;
    const oz = cz * CHUNK_D;
    const topId = this.getLocal(data, lx, ground, lz);
    if (topId !== GRASS && topId !== SNOW) return;
    const spruce = biome === BIOME_SNOW;
    const h = spruce ? 6 + Math.floor(hash2(ox + lx, oz + lz, this.seed + 9) * 3) : 4 + Math.floor(hash2(ox + lx, oz + lz, this.seed + 9) * 2);
    for (let i = 1; i <= h; i++) this.setLocal(data, lx, ground + i, lz, WOOD);
    const top = ground + h;
    const rad = spruce ? 2 : 2;
    for (let dy = spruce ? -3 : -2; dy <= 2; dy++) {
      for (let dx = -rad; dx <= rad; dx++) {
        for (let dz = -rad; dz <= rad; dz++) {
          if (spruce) {
            const layer = Math.abs(dy);
            const r = layer <= 0 ? 0 : layer === 1 ? 1 : 2;
            if (Math.abs(dx) > r || Math.abs(dz) > r) continue;
            if (Math.abs(dx) === r && Math.abs(dz) === r && r > 0) continue;
          } else if (Math.abs(dx) === 2 && Math.abs(dz) === 2 && dy < 1) continue;
          const x = lx + dx;
          const y = top + dy;
          const z = lz + dz;
          if (x < 0 || z < 0 || x >= CHUNK_W || z >= CHUNK_D || y < 0 || y >= CHUNK_H) continue;
          if (this.getLocal(data, x, y, z) === AIR) this.setLocal(data, x, y, z, LEAVES);
        }
      }
    }
  }

  private plantCactus(data: Uint8Array, lx: number, ground: number, lz: number) {
    if (ground < SEA_LEVEL) return;
    if (this.getLocal(data, lx, ground, lz) !== SAND) return;
    if (this.getLocal(data, lx, ground + 1, lz) !== AIR) return;
    for (const [dx, dz] of [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ] as const) {
      const n = this.getLocal(data, lx + dx, ground + 1, lz + dz);
      if (n === WATER || n === CACTUS) return;
    }
    const h = 2 + Math.floor(hash2(lx, lz, this.seed + 3) * 2);
    for (let i = 1; i <= h; i++) {
      if (ground + i >= CHUNK_H) break;
      if (this.getLocal(data, lx, ground + i, lz) !== AIR) break;
      this.setLocal(data, lx, ground + i, lz, CACTUS);
    }
  }

  index(x: number, y: number, z: number): number {
    return x + z * CHUNK_W + y * CHUNK_W * CHUNK_D;
  }

  getLocal(data: Uint8Array, x: number, y: number, z: number): number {
    if (y < 0 || y >= CHUNK_H || x < 0 || z < 0 || x >= CHUNK_W || z >= CHUNK_D) return AIR;
    return data[this.index(x, y, z)] ?? AIR;
  }

  setLocal(data: Uint8Array, x: number, y: number, z: number, id: number) {
    if (y < 0 || y >= CHUNK_H || x < 0 || z < 0 || x >= CHUNK_W || z >= CHUNK_D) return;
    data[this.index(x, y, z)] = id;
  }

  getBlock(x: number, y: number, z: number): BlockId {
    if (y < 0) return this.kind === "end" ? AIR : BEDROCK;
    if (y >= CHUNK_H) return AIR;
    const [cx, cz, lx, lz] = worldToChunk(x, z);
    const data = this.chunks.get(chunkKey(cx, cz));
    if (!data) return AIR;
    return data[this.index(lx, y, lz)] ?? AIR;
  }

  setBlock(x: number, y: number, z: number, id: BlockId): boolean {
    if (y < 0 || y >= CHUNK_H) return false;
    const [cx, cz, lx, lz] = worldToChunk(x, z);
    const data = this.ensureChunk(cx, cz);
    const i = this.index(lx, y, lz);
    const prev = data[i] ?? AIR;
    if (prev === id) return false;
    if ((prev === WATER && id === LAVA) || (prev === LAVA && id === WATER)) {
      data[i] = AIR;
      this.flow.delete(this.cellKey(x, y, z));
      this.lavaFlow.delete(this.cellKey(x, y, z));
      this.markDirty(cx, cz, lx, lz);
      this.scheduleWaterAround(x, y, z);
      this.scheduleLavaAround(x, y, z);
      return true;
    }
    data[i] = id;
    if (prev === WATER || id !== WATER) this.flow.delete(this.cellKey(x, y, z));
    if (prev === LAVA || id !== LAVA) this.lavaFlow.delete(this.cellKey(x, y, z));
    this.markDirty(cx, cz, lx, lz);
    this.scheduleWaterAround(x, y, z);
    this.scheduleLavaAround(x, y, z);
    this.mixFluids(x, y, z);
    return true;
  }

  private markDirty(cx: number, cz: number, lx: number, lz: number) {
    this.dirty.add(chunkKey(cx, cz));
    if (lx === 0) this.dirty.add(chunkKey(cx - 1, cz));
    if (lx === CHUNK_W - 1) this.dirty.add(chunkKey(cx + 1, cz));
    if (lz === 0) this.dirty.add(chunkKey(cx, cz - 1));
    if (lz === CHUNK_D - 1) this.dirty.add(chunkKey(cx, cz + 1));
  }

  private mixFluids(x: number, y: number, z: number) {
    const id = this.getBlock(x, y, z);
    if (id !== WATER && id !== LAVA) return;
    const other = id === WATER ? LAVA : WATER;
    const dirs = [
      [1, 0, 0],
      [-1, 0, 0],
      [0, 1, 0],
      [0, -1, 0],
      [0, 0, 1],
      [0, 0, -1],
    ];
    for (const [dx, dy, dz] of dirs) {
      const nx = x + dx;
      const ny = y + dy;
      const nz = z + dz;
      if (this.getBlock(nx, ny, nz) === other) {
        this.clearFluid(x, y, z);
        this.clearFluid(nx, ny, nz);
        return;
      }
    }
  }

  private clearFluid(x: number, y: number, z: number) {
    if (y < 0 || y >= CHUNK_H) return;
    const [cx, cz, lx, lz] = worldToChunk(x, z);
    const data = this.chunks.get(chunkKey(cx, cz));
    if (!data) return;
    const i = this.index(lx, y, lz);
    const prev = data[i] ?? AIR;
    if (prev !== WATER && prev !== LAVA) return;
    data[i] = AIR;
    this.flow.delete(this.cellKey(x, y, z));
    this.lavaFlow.delete(this.cellKey(x, y, z));
    this.markDirty(cx, cz, lx, lz);
    this.scheduleWaterAround(x, y, z);
    this.scheduleLavaAround(x, y, z);
  }

  cellKey(x: number, y: number, z: number) {
    return `${x},${y},${z}`;
  }

  setSource(x: number, y: number, z: number) {
    x = Math.floor(x);
    y = Math.floor(y);
    z = Math.floor(z);
    const id = this.getBlock(x, y, z);
    if (id === WATER) {
      this.setFlow(x, y, z, 7);
      this.scheduleWaterAround(x, y, z);
    } else if (id === LAVA) {
      this.setLavaFlow(x, y, z, 7);
      this.scheduleLavaAround(x, y, z);
    }
  }

  isWaterSource(x: number, y: number, z: number): boolean {
    if (this.getBlock(x, y, z) !== WATER) return false;
    const raw = this.flow.get(this.cellKey(x, y, z));
    return raw === undefined || raw === 7;
  }

  isLavaSource(x: number, y: number, z: number): boolean {
    if (this.getBlock(x, y, z) !== LAVA) return false;
    const raw = this.lavaFlow.get(this.cellKey(x, y, z));
    return raw === undefined || raw === 7;
  }

  waterLevel(x: number, y: number, z: number): number {
    if (this.getBlock(x, y, z) !== WATER) return -1;
    const raw = this.flow.get(this.cellKey(x, y, z));
    if (raw === undefined || raw === 7) return 7;
    if (raw >= 8) return Math.min(6, raw - 8);
    return raw;
  }

  waterHeight(x: number, y: number, z: number): number {
    if (this.getBlock(x, y, z) !== WATER) return 0;
    const raw = this.flow.get(this.cellKey(x, y, z)) ?? 7;
    if (raw >= 8) return 1;
    if (raw === 7) return 0.9;
    return Math.max(0.12, (raw + 1) / 8);
  }

  scheduleWater(x: number, y: number, z: number) {
    if (y < 1 || y >= CHUNK_H) return;
    this.pendingWater.add(this.cellKey(x, y, z));
  }

  scheduleWaterAround(x: number, y: number, z: number) {
    this.scheduleWater(x, y, z);
    this.scheduleWater(x + 1, y, z);
    this.scheduleWater(x - 1, y, z);
    this.scheduleWater(x, y, z + 1);
    this.scheduleWater(x, y, z - 1);
    this.scheduleWater(x, y + 1, z);
    this.scheduleWater(x, y - 1, z);
  }

  private setFlow(x: number, y: number, z: number, level: number) {
    this.flow.set(this.cellKey(x, y, z), level);
    const [cx, cz] = worldToChunk(x, z);
    this.dirty.add(chunkKey(cx, cz));
  }

  private flowPower(raw: number | undefined): number {
    if (raw === undefined) return 7;
    if (raw >= 8) return raw - 8;
    return raw;
  }

  private flowRank(raw: number | undefined): number {
    if (raw === undefined || raw === 7) return 70;
    if (raw >= 8) return raw - 8;
    return raw;
  }

  private placeFlow(x: number, y: number, z: number, level: number) {
    if (y < 1 || y >= CHUNK_H) return;
    const id = this.getBlock(x, y, z);
    if (id === LAVA) {
      this.clearFluid(x, y, z);
      return;
    }
    if (id !== AIR && id !== WATER) return;
    if (id === WATER && this.flowRank(this.flow.get(this.cellKey(x, y, z))) >= this.flowRank(level)) return;
    if (id !== WATER) this.setBlock(x, y, z, WATER);
    this.setFlow(x, y, z, level);
    this.scheduleWaterAround(x, y, z);
  }

  private expectedWater(x: number, y: number, z: number): number {
    if (this.getBlock(x, y + 1, z) === WATER) {
      return this.flowPower(this.flow.get(this.cellKey(x, y + 1, z))) + 8;
    }
    let best = -1;
    for (const [dx, dz] of [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ] as const) {
      const nx = x + dx;
      const nz = z + dz;
      if (this.getBlock(nx, y, nz) !== WATER) continue;
      if (this.getBlock(nx, y - 1, nz) === AIR) continue;
      const power = this.flowPower(this.flow.get(this.cellKey(nx, y, nz)));
      if (power <= 0) continue;
      best = Math.max(best, power - 1);
    }
    return best;
  }

  private tryInfiniteWater(x: number, y: number, z: number) {
    if (!isSolid(this.getBlock(x, y - 1, z))) return;
    let sources = 0;
    for (const [dx, dz] of [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ] as const) {
      if (this.isWaterSource(x + dx, y, z + dz)) sources++;
    }
    if (sources < 2) return;
    this.setBlock(x, y, z, WATER);
    this.setFlow(x, y, z, 7);
    this.scheduleWaterAround(x, y, z);
  }

  tickWater(budget = 40) {
    if (!this.pendingWater.size) return;
    const queue = [...this.pendingWater];
    this.pendingWater.clear();
    let n = 0;
    for (const k of queue) {
      if (n++ >= budget) {
        this.pendingWater.add(k);
        continue;
      }
      const p = k.split(",").map(Number);
      this.updateWaterCell(p[0]!, p[1]!, p[2]!);
    }
  }

  lavaLevel(x: number, y: number, z: number): number {
    if (this.getBlock(x, y, z) !== LAVA) return -1;
    const raw = this.lavaFlow.get(this.cellKey(x, y, z));
    if (raw === undefined || raw === 7) return 7;
    if (raw >= 8) return Math.min(6, raw - 8);
    return raw;
  }

  lavaHeight(x: number, y: number, z: number): number {
    if (this.getBlock(x, y, z) !== LAVA) return 0;
    const raw = this.lavaFlow.get(this.cellKey(x, y, z)) ?? 7;
    if (raw >= 8) return 1;
    if (raw === 7) return 0.92;
    return Math.max(0.18, (raw + 1) / 9);
  }

  scheduleLava(x: number, y: number, z: number) {
    if (y < 1 || y >= CHUNK_H) return;
    this.pendingLava.add(this.cellKey(x, y, z));
  }

  scheduleLavaAround(x: number, y: number, z: number) {
    this.scheduleLava(x, y, z);
    this.scheduleLava(x + 1, y, z);
    this.scheduleLava(x - 1, y, z);
    this.scheduleLava(x, y, z + 1);
    this.scheduleLava(x, y, z - 1);
    this.scheduleLava(x, y + 1, z);
    this.scheduleLava(x, y - 1, z);
  }

  tickLava(budget = 24) {
    if (!this.pendingLava.size) return;
    const queue = [...this.pendingLava];
    this.pendingLava.clear();
    let n = 0;
    for (const k of queue) {
      if (n++ >= budget) {
        this.pendingLava.add(k);
        continue;
      }
      const p = k.split(",").map(Number);
      this.updateLavaCell(p[0]!, p[1]!, p[2]!);
    }
  }

  private setLavaFlow(x: number, y: number, z: number, level: number) {
    this.lavaFlow.set(this.cellKey(x, y, z), level);
    const [cx, cz] = worldToChunk(x, z);
    this.dirty.add(chunkKey(cx, cz));
  }

  private placeLava(x: number, y: number, z: number, level: number) {
    if (y < 1 || y >= CHUNK_H) return;
    const id = this.getBlock(x, y, z);
    if (id === WATER) {
      this.clearFluid(x, y, z);
      return;
    }
    if (id !== AIR && id !== LAVA) return;
    if (id === LAVA && this.flowRank(this.lavaFlow.get(this.cellKey(x, y, z))) >= this.flowRank(level)) return;
    if (id !== LAVA) this.setBlock(x, y, z, LAVA);
    this.setLavaFlow(x, y, z, level);
    this.scheduleLavaAround(x, y, z);
  }

  private expectedLava(x: number, y: number, z: number): number {
    if (this.getBlock(x, y + 1, z) === LAVA) {
      return this.flowPower(this.lavaFlow.get(this.cellKey(x, y + 1, z))) + 8;
    }
    let best = -1;
    for (const [dx, dz] of [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ] as const) {
      const nx = x + dx;
      const nz = z + dz;
      if (this.getBlock(nx, y, nz) !== LAVA) continue;
      if (this.getBlock(nx, y - 1, nz) === AIR) continue;
      const power = this.flowPower(this.lavaFlow.get(this.cellKey(nx, y, nz)));
      if (power <= 0) continue;
      best = Math.max(best, power - 1);
    }
    return best;
  }

  private updateLavaCell(x: number, y: number, z: number) {
    const id = this.getBlock(x, y, z);
    if (id !== LAVA) return;
    this.mixFluids(x, y, z);
    if (this.getBlock(x, y, z) !== LAVA) return;
    const key = this.cellKey(x, y, z);
    const stored = this.lavaFlow.get(key);
    const source = stored === undefined || stored === 7;
    if (!source) {
      const expect = this.expectedLava(x, y, z);
      if (expect < 0) {
        this.setBlock(x, y, z, AIR);
        return;
      }
      if (stored !== expect) this.setLavaFlow(x, y, z, expect);
    }
    const power = this.flowPower(this.lavaFlow.get(key));
    const below = this.getBlock(x, y - 1, z);
    if (below === WATER) {
      this.clearFluid(x, y - 1, z);
      return;
    }
    if (below === AIR) {
      this.placeLava(x, y - 1, z, power + 8);
      return;
    }
    if (power <= 0) return;
    const next = power - 1;
    this.placeLava(x + 1, y, z, next);
    this.placeLava(x - 1, y, z, next);
    this.placeLava(x, y, z + 1, next);
    this.placeLava(x, y, z - 1, next);
  }

  private updateWaterCell(x: number, y: number, z: number) {
    const id = this.getBlock(x, y, z);
    if (id === AIR) {
      this.tryInfiniteWater(x, y, z);
      return;
    }
    if (id !== WATER) return;
    this.mixFluids(x, y, z);
    if (this.getBlock(x, y, z) !== WATER) return;
    const key = this.cellKey(x, y, z);
    const stored = this.flow.get(key);
    const source = stored === undefined || stored === 7;
    if (!source) {
      const expect = this.expectedWater(x, y, z);
      if (expect < 0) {
        this.setBlock(x, y, z, AIR);
        return;
      }
      if (stored !== expect) this.setFlow(x, y, z, expect);
    }
    const power = this.flowPower(this.flow.get(key));
    if (this.getBlock(x, y - 1, z) === AIR) {
      this.placeFlow(x, y - 1, z, power + 8);
      return;
    }
    if (power <= 0) return;
    const next = power - 1;
    this.placeFlow(x + 1, y, z, next);
    this.placeFlow(x - 1, y, z, next);
    this.placeFlow(x, y, z + 1, next);
    this.placeFlow(x, y, z - 1, next);
  }

  solid(x: number, y: number, z: number): boolean {
    return isSolid(this.getBlock(Math.floor(x), Math.floor(y), Math.floor(z)));
  }

  opaque(x: number, y: number, z: number): boolean {
    return isOpaque(this.getBlock(x, y, z));
  }

  unloadFar(pcx: number, pcz: number, radius: number): string[] {
    const removed: string[] = [];
    for (const k of this.chunks.keys()) {
      const [cx, cz] = k.split(",").map(Number);
      if (Math.max(Math.abs(cx - pcx), Math.abs(cz - pcz)) > radius + 1) {
        this.chunks.delete(k);
        this.dirty.delete(k);
        removed.push(k);
      }
    }
    return removed;
  }

  applyEdits(edits: Array<[number, number, number, number]>) {
    for (const [x, y, z, id] of edits) {
      this.ensureChunk(Math.floor(x / CHUNK_W), Math.floor(z / CHUNK_D));
      this.setBlock(x, y, z, id);
    }
  }
}
