import {
  COAL,
  COOKED_BEEF,
  COOKED_CHICKEN,
  COOKED_MUTTON,
  COOKED_PORK,
  GOLD,
  GOLD_INGOT,
  IRON_INGOT,
  IRON_ORE,
  PLANKS,
  RAW_GOLD,
  RAW_IRON,
  STICK,
  WOOD,
  type FurnaceSave,
} from "./types";
import { BEEF, CHICKEN_MEAT, MUTTON, PORK } from "./types";

export const COOK_TIME = 10;

const SMELT: Record<number, number> = {
  [RAW_IRON]: IRON_INGOT,
  [RAW_GOLD]: GOLD_INGOT,
  [IRON_ORE]: IRON_INGOT,
  [GOLD]: GOLD_INGOT,
  [PORK]: COOKED_PORK,
  [BEEF]: COOKED_BEEF,
  [MUTTON]: COOKED_MUTTON,
  [CHICKEN_MEAT]: COOKED_CHICKEN,
};

export function smeltResult(id: number): number {
  return SMELT[id] ?? 0;
}

export function fuelSeconds(id: number): number {
  if (id === COAL) return 80;
  if (id === WOOD) return 15;
  if (id === PLANKS) return 15;
  if (id === STICK) return 5;
  return 0;
}

export function emptyFurnace(x: number, y: number, z: number): FurnaceSave {
  return { x, y, z, input: null, fuel: null, out: null, cook: 0, burn: 0, burnMax: 0 };
}

export function tickFurnace(f: FurnaceSave, dt: number) {
  const src = f.input;
  const product = src ? smeltResult(src.id) : 0;
  const canOut = product > 0 && (!f.out || (f.out.id === product && f.out.count < 64));

  if (f.burn > 0) f.burn = Math.max(0, f.burn - dt);

  if (f.burn <= 0 && canOut) {
    const fuel = f.fuel;
    const t = fuel ? fuelSeconds(fuel.id) : 0;
    if (t > 0 && fuel) {
      fuel.count -= 1;
      if (fuel.count <= 0) f.fuel = null;
      f.burnMax = t;
      f.burn = t;
    }
  }

  if (!canOut || f.burn <= 0) {
    f.cook = canOut ? Math.max(0, f.cook - dt * 2) : 0;
    return;
  }

  f.cook += dt;
  if (f.cook >= COOK_TIME && src) {
    f.cook -= COOK_TIME;
    src.count -= 1;
    if (src.count <= 0) f.input = null;
    if (!f.out) f.out = { id: product, count: 1 };
    else f.out.count += 1;
  }
}
