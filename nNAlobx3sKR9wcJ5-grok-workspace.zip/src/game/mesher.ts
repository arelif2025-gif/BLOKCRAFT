import * as THREE from "three";
import { atlasFaceUV } from "./atlas";
import { BLOCKS, isOpaque } from "./blocks";
import { AIR, CHUNK_D, CHUNK_H, CHUNK_W, END_FRAME, END_FRAME_EYE, END_PORTAL, LAVA, PORTAL, WATER } from "./types";
import { World, chunkKey } from "./world";

const SHADE = [0.78, 0.78, 1.0, 0.55, 0.86, 0.7];

const FACES: Array<{
  dx: number;
  dy: number;
  dz: number;
  corners: number[][];
  uv: number[][];
}> = [
  {
    dx: 1,
    dy: 0,
    dz: 0,
    corners: [
      [1, 1, 1],
      [1, 1, 0],
      [1, 0, 1],
      [1, 0, 0],
    ],
    uv: [
      [0, 0],
      [1, 0],
      [0, 1],
      [1, 1],
    ],
  },
  {
    dx: -1,
    dy: 0,
    dz: 0,
    corners: [
      [0, 1, 0],
      [0, 1, 1],
      [0, 0, 0],
      [0, 0, 1],
    ],
    uv: [
      [0, 0],
      [1, 0],
      [0, 1],
      [1, 1],
    ],
  },
  {
    dx: 0,
    dy: 1,
    dz: 0,
    corners: [
      [0, 1, 0],
      [1, 1, 0],
      [0, 1, 1],
      [1, 1, 1],
    ],
    uv: [
      [1, 1],
      [0, 1],
      [1, 0],
      [0, 0],
    ],
  },
  {
    dx: 0,
    dy: -1,
    dz: 0,
    corners: [
      [0, 0, 1],
      [1, 0, 1],
      [0, 0, 0],
      [1, 0, 0],
    ],
    uv: [
      [1, 0],
      [0, 0],
      [1, 1],
      [0, 1],
    ],
  },
  {
    dx: 0,
    dy: 0,
    dz: 1,
    corners: [
      [0, 1, 1],
      [1, 1, 1],
      [0, 0, 1],
      [1, 0, 1],
    ],
    uv: [
      [0, 0],
      [1, 0],
      [0, 1],
      [1, 1],
    ],
  },
  {
    dx: 0,
    dy: 0,
    dz: -1,
    corners: [
      [1, 1, 0],
      [0, 1, 0],
      [1, 0, 0],
      [0, 0, 0],
    ],
    uv: [
      [0, 0],
      [1, 0],
      [0, 1],
      [1, 1],
    ],
  },
];

function pushFace(
  positions: number[],
  normals: number[],
  uvs: number[],
  colors: number[],
  indices: number[],
  x: number,
  y: number,
  z: number,
  fi: number,
  atlas: number,
  centered: boolean,
) {
  const face = FACES[fi]!;
  const shade = SHADE[fi]!;
  const base = positions.length / 3;
  for (let i = 0; i < 4; i++) {
    const c = face.corners[i]!;
    const ox = centered ? c[0]! - 0.5 : x + c[0]!;
    const oy = centered ? c[1]! - 0.5 : y + c[1]!;
    const oz = centered ? c[2]! - 0.5 : z + c[2]!;
    positions.push(ox, oy, oz);
    normals.push(face.dx, face.dy, face.dz);
    const su = face.uv[i]![0]!;
    const sv = face.uv[i]![1]!;
    const [uu, vv] = atlasFaceUV(atlas, fi, su, sv);
    uvs.push(uu, vv);
    colors.push(shade, shade, shade);
  }
  indices.push(base, base + 2, base + 1, base + 2, base + 3, base + 1);
}

export function meshChunk(world: World, cx: number, cz: number): THREE.BufferGeometry | null {
  const data = world.chunks.get(chunkKey(cx, cz));
  if (!data) return null;
  const ox = cx * CHUNK_W;
  const oz = cz * CHUNK_D;

  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const colors: number[] = [];
  const indices: number[] = [];

  const neighbor = (x: number, y: number, z: number): number => {
    if (y < 0 || y >= CHUNK_H) return y < 0 ? 9 : AIR;
    if (x >= 0 && z >= 0 && x < CHUNK_W && z < CHUNK_D) {
      return data[x + z * CHUNK_W + y * CHUNK_W * CHUNK_D] ?? AIR;
    }
    return world.getBlock(ox + x, y, oz + z);
  };

  for (let y = 0; y < CHUNK_H; y++) {
    for (let z = 0; z < CHUNK_D; z++) {
      for (let x = 0; x < CHUNK_W; x++) {
        const id = data[x + z * CHUNK_W + y * CHUNK_W * CHUNK_D] ?? AIR;
        if (id === AIR || id === WATER || id === LAVA || id === PORTAL || id === END_PORTAL || id === END_FRAME || id === END_FRAME_EYE) continue;
        const def = BLOCKS[id];
        if (!def) continue;
        for (let fi = 0; fi < FACES.length; fi++) {
          const face = FACES[fi]!;
          const nid = neighbor(x + face.dx, y + face.dy, z + face.dz);
          if (isOpaque(nid)) continue;
          if (nid === id && !def.opaque) continue;
          pushFace(positions, normals, uvs, colors, indices, ox + x, y, oz + z, fi, def.atlas, false);
        }
      }
    }
  }

  if (indices.length === 0) return null;
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute("normal", new THREE.Float32BufferAttribute(normals, 3));
  geo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
  geo.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
  geo.setIndex(indices);
  geo.computeBoundingSphere();
  return geo;
}

export function makeBlockGeometry(blockId: number): THREE.BufferGeometry {
  const def = BLOCKS[blockId] ?? BLOCKS[1]!;
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const colors: number[] = [];
  const indices: number[] = [];
  for (let fi = 0; fi < FACES.length; fi++) {
    pushFace(positions, normals, uvs, colors, indices, 0, 0, 0, fi, def.atlas, true);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute("normal", new THREE.Float32BufferAttribute(normals, 3));
  geo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
  geo.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
  geo.setIndex(indices);
  return geo;
}

export function meshWater(world: World, cx: number, cz: number): THREE.BufferGeometry | null {
  return meshFluid(world, cx, cz, WATER, (x, y, z) => world.waterHeight(x, y, z), [1, 1, 1]);
}

export function meshLava(world: World, cx: number, cz: number): THREE.BufferGeometry | null {
  return meshFluid(world, cx, cz, LAVA, (x, y, z) => world.lavaHeight(x, y, z), [1.2, 0.55, 0.18]);
}

function meshFluid(
  world: World,
  cx: number,
  cz: number,
  fluid: number,
  heightAt: (x: number, y: number, z: number) => number,
  shadeMul: [number, number, number],
): THREE.BufferGeometry | null {
  const data = world.chunks.get(chunkKey(cx, cz));
  if (!data) return null;
  const ox = cx * CHUNK_W;
  const oz = cz * CHUNK_D;
  const positions: number[] = [];
  const normals: number[] = [];
  const colors: number[] = [];
  const indices: number[] = [];

  const neighbor = (x: number, y: number, z: number): number => {
    if (y < 0 || y >= CHUNK_H) return y < 0 ? 9 : AIR;
    if (x >= 0 && z >= 0 && x < CHUNK_W && z < CHUNK_D) {
      return data[x + z * CHUNK_W + y * CHUNK_W * CHUNK_D] ?? AIR;
    }
    return world.getBlock(ox + x, y, oz + z);
  };

  const shade = [0.7, 0.7, 1, 0.45, 0.82, 0.62];
  for (let y = 0; y < CHUNK_H; y++) {
    for (let z = 0; z < CHUNK_D; z++) {
      for (let x = 0; x < CHUNK_W; x++) {
        const id = data[x + z * CHUNK_W + y * CHUNK_W * CHUNK_D] ?? AIR;
        if (id !== fluid) continue;
        const above = neighbor(x, y + 1, z);
        const h = above === fluid ? 1 : heightAt(ox + x, y, oz + z);
        for (let fi = 0; fi < FACES.length; fi++) {
          const face = FACES[fi]!;
          const nid = neighbor(x + face.dx, y + face.dy, z + face.dz);
          if (nid === fluid || isOpaque(nid)) continue;
          const base = positions.length / 3;
          const s = shade[fi]!;
          const dip = 0.12 * Math.min(1, 1 - h);
          for (let i = 0; i < 4; i++) {
            const c = face.corners[i]!;
            const py = y + c[1]! * h;
            positions.push(ox + x + c[0]!, py, oz + z + c[2]!);
            normals.push(face.dx, face.dy, face.dz);
            colors.push(s * shadeMul[0]! * (1 - dip), s * shadeMul[1]! * (1 - dip * 0.4), s * shadeMul[2]!);
          }
          indices.push(base, base + 2, base + 1, base + 2, base + 3, base + 1);
        }
      }
    }
  }
  if (indices.length === 0) return null;
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute("normal", new THREE.Float32BufferAttribute(normals, 3));
  geo.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
  geo.setIndex(indices);
  geo.computeBoundingSphere();
  return geo;
}

export function meshPortal(world: World, cx: number, cz: number): THREE.BufferGeometry | null {
  const data = world.chunks.get(chunkKey(cx, cz));
  if (!data) return null;
  const ox = cx * CHUNK_W;
  const oz = cz * CHUNK_D;
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const colors: number[] = [];
  const indices: number[] = [];
  const neighbor = (x: number, y: number, z: number): number => {
    if (y < 0 || y >= CHUNK_H) return AIR;
    if (x >= 0 && z >= 0 && x < CHUNK_W && z < CHUNK_D) return data[x + z * CHUNK_W + y * CHUNK_W * CHUNK_D] ?? AIR;
    return world.getBlock(ox + x, y, oz + z);
  };
  for (let y = 0; y < CHUNK_H; y++) {
    for (let z = 0; z < CHUNK_D; z++) {
      for (let x = 0; x < CHUNK_W; x++) {
        const id = data[x + z * CHUNK_W + y * CHUNK_W * CHUNK_D] ?? AIR;
        if (id !== PORTAL && id !== END_PORTAL) continue;
        const end = id === END_PORTAL;
        for (let fi = 0; fi < FACES.length; fi++) {
          const face = FACES[fi]!;
          const nid = neighbor(x + face.dx, y + face.dy, z + face.dz);
          if (nid === id || isOpaque(nid)) continue;
          const base = positions.length / 3;
          for (let i = 0; i < 4; i++) {
            const c = face.corners[i]!;
            positions.push(ox + x + c[0]!, y + c[1]!, oz + z + c[2]!);
            normals.push(face.dx, face.dy, face.dz);
            uvs.push(c[0]!, c[1]!);
            colors.push(end ? 0.15 : 0.85, end ? 0.02 : 0.35, end ? 0.22 : 1);
          }
          indices.push(base, base + 2, base + 1, base + 2, base + 3, base + 1);
        }
      }
    }
  }
  if (!indices.length) return null;
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute("normal", new THREE.Float32BufferAttribute(normals, 3));
  geo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
  geo.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
  geo.setIndex(indices);
  geo.computeBoundingSphere();
  return geo;
}
