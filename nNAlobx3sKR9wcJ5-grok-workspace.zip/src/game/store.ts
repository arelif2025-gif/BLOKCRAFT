import { create } from "zustand";
import {
  ARMOR_SIZE,
  HOTBAR_SIZE,
  INV_SIZE,
  MAX_FOOD,
  MAX_HEALTH,
  type GamePhase,
  type HudSnapshot,
  type ItemStack,
  type Settings,
} from "./types";

const emptySlots = (n: number): Array<ItemStack | null> => Array.from({ length: n }, () => null);

const defaultHud = (): HudSnapshot => ({
  health: MAX_HEALTH,
  food: MAX_FOOD,
  air: 10,
  hotbar: emptySlots(HOTBAR_SIZE),
  selectedSlot: 0,
  inventory: emptySlots(INV_SIZE),
  armor: emptySlots(ARMOR_SIZE),
  offhand: null,
  dayPhase: 0.28,
  isDay: true,
  fps: 0,
  x: 0,
  y: 0,
  z: 0,
  yaw: 0,
  targetName: null,
  breaking: 0,
  held: null,
  canResume: false,
  biome: "Ova",
  sneaking: false,
  inWater: false,
  blocking: false,
  sleeping: false,
  sleep: 0,
  toast: null,
});

export type GameStore = {
  phase: GamePhase;
  loading: number;
  hud: HudSnapshot;
  settings: Settings;
  isMobile: boolean;
  pointerLocked: boolean;
  clickToPlay: boolean;
  loadError: string | null;
  setPhase: (p: GamePhase) => void;
  setLoading: (n: number) => void;
  patchHud: (p: Partial<HudSnapshot>) => void;
  setSettings: (s: Partial<Settings>) => void;
  setMobile: (v: boolean) => void;
  setPointerLocked: (v: boolean) => void;
  setClickToPlay: (v: boolean) => void;
  setLoadError: (v: string | null) => void;
  resetHud: () => void;
};

export const useGameStore = create<GameStore>((set) => ({
  phase: "title",
  loading: 0,
  hud: defaultHud(),
  settings: { sensitivity: 1.4, renderDistance: 4, volume: 0.7 },
  isMobile: false,
  pointerLocked: false,
  clickToPlay: false,
  loadError: null,
  setPhase: (phase) => set({ phase }),
  setLoading: (loading) => set({ loading }),
  patchHud: (p) => set((s) => ({ hud: { ...s.hud, ...p } })),
  setSettings: (s) => set((st) => ({ settings: { ...st.settings, ...s } })),
  setMobile: (isMobile) => set({ isMobile }),
  setPointerLocked: (pointerLocked) => set({ pointerLocked }),
  setClickToPlay: (clickToPlay) => set({ clickToPlay }),
  setLoadError: (loadError) => set({ loadError }),
  resetHud: () => set({ hud: defaultHud(), loading: 0, clickToPlay: false, pointerLocked: false }),
}));

export const gameStore = useGameStore;
