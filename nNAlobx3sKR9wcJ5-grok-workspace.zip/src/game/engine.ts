import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import { buildAtlas } from "./atlas";
import { GameAudio } from "./audio";
import { BLOCKS, blockName, isFluid, isSolid, isWater } from "./blocks";
import { Input } from "./input";
import { addItem, emptyGrid, takeOne } from "./inventory";
import { isPlaceable, isTool, mineDuration, toolKind, canHarvest, canFinishMine, isFood, foodStats, attackDamage, itemColor, wearStack } from "./items";
import { makeBlockGeometry, meshChunk, meshWater, meshLava, meshPortal } from "./mesher";
import { ParticlePool } from "./particles";
import { Player } from "./player";
import { voxelRaycast, type VoxelHit } from "./raycast";
import { loadSave, loadWorld, loadLook, newSave, writeSave, SAVE_VERSION, PANTS, SHIRTS, SKINS, type SaveData } from "./save";
import { gameStore } from "./store";
import { modelForItem } from "./tools";
import { BoatWorld } from "./boats";
import { DropWorld } from "./drops";
import { frameSpots, portalSpots, strongholds } from "./structures";
import { MobWorld, mobName } from "./mobs";
import { canCraft, consumeGrid, craftInto, matchRecipe, RECIPES, type Recipe } from "./craft";
import { EndBoss } from "./endboss";
import { emptyFurnace, tickFurnace } from "./furnace";
import { breakPortalNear, tryLightPortal } from "./portal";
import {
  AIR,
  BED,
  BEDROCK,
  BUCKET,
  CHUNK_W,
  CHUNK_D,
  CRAFT_SIZE,
  END_FRAME,
  END_FRAME_EYE,
  END_PORTAL,
  ENDER_PEARL,
  EYE_OF_ENDER,
  BOAT,
  FLINT,
  FLINT_STEEL,
  FURNACE,
  GRAVEL,
  LAVA,
  LAVA_BUCKET,
  MAX_FOOD,
  MAX_HEALTH,
  OBSIDIAN,
  PORTAL,
  NETHERRACK,
  SHIELD,
  STONE,
  WATER,
  WATER_BUCKET,
  type FurnaceSave,
  type ItemStack,
} from "./types";
import { BIOME_NAME, World, chunkKey } from "./world";

const DAY_LEN = 420;
const FIXED = 1 / 60;

export class GameEngine {
  canvas: HTMLCanvasElement;
  renderer: THREE.WebGLRenderer;
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  world: World;
  player = new Player();
  input = new Input();
  audio = new GameAudio();
  private yawObj = new THREE.Object3D();
  private material: THREE.MeshLambertMaterial | null = null;
  private waterMat: THREE.MeshLambertMaterial | null = null;
  private lavaMat: THREE.MeshLambertMaterial | null = null;
  private portalMat: THREE.MeshLambertMaterial | null = null;
  private chunkMeshes = new Map<string, THREE.Mesh>();
  private frameGroups = new Map<string, THREE.Group>();
  private frameTpl: THREE.Group | null = null;
  private frameEye: THREE.Group | null = null;
  private waterMeshes = new Map<string, THREE.Mesh>();
  private lavaMeshes = new Map<string, THREE.Mesh>();
  private portalMeshes = new Map<string, THREE.Mesh>();
  private sun: THREE.DirectionalLight;
  private hemi: THREE.HemisphereLight;
  private ambient: THREE.AmbientLight;
  private sunMesh: THREE.Mesh;
  private moonMesh: THREE.Mesh;
  private stars: THREE.Points;
  private highlight: THREE.LineSegments;
  private crackMesh: THREE.Mesh;
  private hand = new THREE.Group();
  private vmScene = new THREE.Scene();
  private vmCam = new THREE.PerspectiveCamera(52, 1, 0.05, 3);
  private blockView: THREE.Mesh;
  private toolViews = new Map<number, THREE.Group>();
  private shieldView: THREE.Group | null = null;
  private activeTool: THREE.Group | null = null;
  private drops: DropWorld | null = null;
  private boats = new BoatWorld();
  private tosses: Array<{ kind: "pearl" | "eye"; x: number; y: number; z: number; vx: number; vy: number; vz: number; tx: number; tz: number; mesh: THREE.Mesh }> = [];
  private mobs = new MobWorld();
  private particles: ParticlePool | null = null;
  private crackMats: THREE.MeshBasicMaterial[] = [];
  worldTime = 80;
  health = MAX_HEALTH;
  food = MAX_FOOD;
  air = 10;
  saturation = 5;
  private exhaust = 0;
  private eatT = 0;
  private attackCd = 0;
  private regenT = 0;
  private starveT = 0;
  private drownT = 0;
  private meatView: THREE.Mesh | null = null;
  hotbar: Array<ItemStack | null> = [];
  inventory: Array<ItemStack | null> = [];
  armor: Array<ItemStack | null> = [];
  offhand: ItemStack | null = null;
  craftGrid: Array<ItemStack | null> = emptyGrid(CRAFT_SIZE);
  selected = 0;
  private furnaces = new Map<string, FurnaceSave>();
  private furnaceAt: string | null = null;
  private lavaHurt = 0;
  private edits: Array<[number, number, number, number]> = [];
  private dim: "overworld" | "nether" | "end" = "overworld";
  private overworld: World | null = null;
  private nether: World | null = null;
  private end: World | null = null;
  private endBoss = new EndBoss();
  private avatar: THREE.Group | null = null;
  private avatarLegs: THREE.Object3D[] = [];
  private thirdPerson = false;
  private shots: string[] = [];
  private shotT = 20;
  private broken = 0;
  private kills = 0;
  private sawNether = false;
  private voidT = 0;
  private saveId = "";
  private worldName = "Dünya";
  private monsters = true;
  private bonus = false;
  private ow = { x: 0.5, y: 40, z: 0.5 };
  private nd: { x: number; y: number; z: number } | null = null;
  private portalT = 0;
  private portalLock = 0;
  private switching = false;
  private seed = 1;
  private saveTimer = 0;
  private stepTimer = 0;
  private acc = 0;
  private last = 0;
  private running = false;
  private disposed = false;
  private target: VoxelHit | null = null;
  private breakT = 0;
  private breakKey = "";
  private placeCd = 0;
  private hudT = 0;
  private fpsAccum = 0;
  private fpsFrames = 0;
  private fps = 0;
  private hurtFlash = 0;
  private hurtDir = 1;
  private icons: Record<number, string> = {};
  private meshQueue: string[] = [];
  private viewGeoCache = new Map<number, THREE.BufferGeometry>();
  private lastCx = 99999;
  private lastCz = 99999;
  private swingT = 0;
  private onResize: () => void;
  private onLockChange: () => void;
  private onLockError: () => void;
  private spawnX = 0.5;
  private spawnY = 40;
  private spawnZ = 0.5;
  private homeX = 0.5;
  private homeY = 40;
  private homeZ = 0.5;
  private bedBlock: { x: number; y: number; z: number } | null = null;
  private sleeping = false;
  private sleepT = 0;
  private toast = "";
  private toastT = 0;
  private snoreT = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: false,
      powerPreference: "high-performance",
      alpha: false,
    });
    this.renderer.setClearColor(0x7ec8e3, 1);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.shadowMap.enabled = false;
    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.Fog(0x7ec8e3, 40, 110);
    this.camera = new THREE.PerspectiveCamera(72, 1, 0.08, 220);
    this.yawObj.add(this.camera);
    this.scene.add(this.yawObj);

    this.hemi = new THREE.HemisphereLight(0xb8d8ff, 0x3d4a2a, 0.7);
    this.scene.add(this.hemi);
    this.ambient = new THREE.AmbientLight(0xffffff, 0.38);
    this.scene.add(this.ambient);
    this.sun = new THREE.DirectionalLight(0xfff4d2, 1.15);
    this.sun.position.set(40, 80, 20);
    this.scene.add(this.sun);

    this.sunMesh = new THREE.Mesh(
      new THREE.SphereGeometry(8, 12, 12),
      new THREE.MeshBasicMaterial({ color: 0xffe7a0, fog: false, depthWrite: false }),
    );
    this.moonMesh = new THREE.Mesh(
      new THREE.SphereGeometry(5, 10, 10),
      new THREE.MeshBasicMaterial({ color: 0xdde6ff, fog: false, depthWrite: false }),
    );
    this.scene.add(this.sunMesh, this.moonMesh);

    const starGeo = new THREE.BufferGeometry();
    const starPos = new Float32Array(900);
    for (let i = 0; i < 300; i++) {
      const th = Math.random() * Math.PI * 2;
      const ph = Math.acos(2 * Math.random() - 1);
      const r = 160;
      starPos[i * 3] = r * Math.sin(ph) * Math.cos(th);
      starPos[i * 3 + 1] = r * Math.cos(ph);
      starPos[i * 3 + 2] = r * Math.sin(ph) * Math.sin(th);
    }
    starGeo.setAttribute("position", new THREE.BufferAttribute(starPos, 3));
    this.stars = new THREE.Points(
      starGeo,
      new THREE.PointsMaterial({ color: 0xffffff, size: 1.4, fog: false, transparent: true, opacity: 0 }),
    );
    this.scene.add(this.stars);

    const box = new THREE.BoxGeometry(1.002, 1.002, 1.002);
    this.highlight = new THREE.LineSegments(
      new THREE.EdgesGeometry(box),
      new THREE.LineBasicMaterial({ color: 0x111111, transparent: true, opacity: 0.85 }),
    );
    this.highlight.visible = false;
    this.scene.add(this.highlight);

    this.crackMesh = new THREE.Mesh(
      box,
      new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false }),
    );
    this.crackMesh.visible = false;
    this.scene.add(this.crackMesh);

    this.endBoss.group.visible = false;
    this.scene.add(this.endBoss.group);
    this.avatar = this.buildAvatar();
    this.avatar.visible = false;
    this.scene.add(this.avatar);

    this.blockView = new THREE.Mesh(new THREE.BoxGeometry(0.01, 0.01, 0.01), new THREE.MeshLambertMaterial());
    this.blockView.frustumCulled = false;
    this.blockView.visible = false;
    this.hand.add(this.blockView);
    this.hand.frustumCulled = false;
    this.hand.visible = false;
    this.vmScene.add(this.hand);
    const vmKey = new THREE.DirectionalLight(0xfff3d4, 1.15);
    vmKey.position.set(0.35, 0.9, 0.55);
    this.vmScene.add(vmKey);
    this.vmScene.add(new THREE.HemisphereLight(0xe8f2ff, 0x3d4a2a, 0.55));
    this.vmScene.add(new THREE.AmbientLight(0xffffff, 0.4));

    this.world = new World(1);
    this.input.attach(canvas);

    this.onResize = () => this.resize();
    this.onLockChange = () => {
      const locked = document.pointerLockElement === this.canvas;
      gameStore.getState().setPointerLocked(locked);
      if (!locked && gameStore.getState().phase === "playing" && !gameStore.getState().isMobile && !this.sleeping) {
        gameStore.getState().setClickToPlay(true);
      }
    };
    this.onLockError = () => {
      window.setTimeout(() => {
        const st = gameStore.getState();
        if (st.phase === "playing" && !st.isMobile && document.pointerLockElement !== this.canvas) {
          st.setClickToPlay(true);
        }
      }, 80);
    };
    window.addEventListener("resize", this.onResize);
    document.addEventListener("pointerlockchange", this.onLockChange);
    document.addEventListener("pointerlockerror", this.onLockError);
    this.resize();
  }

  async init(opts: { id?: string; resume?: boolean } = {}) {
    const atlas = await buildAtlas();
    if (this.disposed) {
      atlas.texture.dispose();
      return;
    }
    this.icons = atlas.icons;
    this.material = new THREE.MeshLambertMaterial({
      map: atlas.texture,
      vertexColors: true,
      side: THREE.FrontSide,
    });
    (this.blockView.material as THREE.Material).dispose();
    this.blockView.material = this.material.clone();
    (this.blockView.material as THREE.MeshLambertMaterial).vertexColors = true;
    this.waterMat = new THREE.MeshLambertMaterial({
      color: 0x2a6ea8,
      transparent: true,
      opacity: 0.48,
      vertexColors: true,
      side: THREE.FrontSide,
      depthWrite: true,
    });
    this.lavaMat = new THREE.MeshLambertMaterial({
      color: 0xe07020,
      transparent: true,
      opacity: 0.88,
      vertexColors: true,
      emissive: 0xc04010,
      emissiveIntensity: 0.45,
      side: THREE.FrontSide,
      depthWrite: true,
    });
    this.portalMat = new THREE.MeshLambertMaterial({
      color: 0xb14cff,
      transparent: true,
      opacity: 0.52,
      vertexColors: true,
      emissive: 0x7a20c8,
      emissiveIntensity: 0.7,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.drops = new DropWorld(this.material);
    this.scene.add(this.drops.group);
    this.scene.add(this.boats.group);
    this.scene.add(this.mobs.group);
    this.particles = new ParticlePool(
      new THREE.MeshLambertMaterial({ color: 0x6b4a28, vertexColors: false }),
    );
    this.scene.add(this.particles.mesh);

    this.crackMats = [0.25, 0.45, 0.65, 0.85].map((p) => {
      const tex = new THREE.CanvasTexture(makeCrack(p));
      tex.magFilter = THREE.NearestFilter;
      tex.minFilter = THREE.NearestFilter;
      tex.flipY = false;
      return new THREE.MeshBasicMaterial({
        map: tex,
        transparent: true,
        opacity: 0.85,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -2,
      });
    });

    const data = opts.id ? loadWorld(opts.id) : opts.resume ? loadSave() : newSave();
    if (!data) throw new Error("Kayıt bulunamadı");
    this.saveId = data.id || "legacy";
    this.worldName = data.name || "Dünya";
    this.monsters = data.monsters !== false;
    this.bonus = !!data.bonus;
    const brandNew = data.edits.length === 0 && data.x === 0.5 && data.y === 40 && data.z === 0.5;
    this.applySave(data);
    this.overworld = new World(this.seed, "overworld");
    this.nether = new World(this.seed + 7919, "nether");
    this.end = new World(this.seed + 4400, "end");
    this.overworld.loadEdits(data.edits);
    this.nether.loadEdits(data.netherEdits ?? []);
    this.end.loadEdits(data.endEdits ?? []);
    this.dim = data.dim === "nether" ? "nether" : data.dim === "end" ? "end" : "overworld";
    this.world = this.dim === "nether" ? this.nether : this.dim === "end" ? this.end : this.overworld;
    this.endBoss.layout(this.end.endTowers, data.crystalMask ?? 255, data.dragonHp ?? 200, data.dragonDead ?? false);
    this.endBoss.perchY = (this.end.endSurface(0, 0) ?? 36) + 2.2;
    this.endBoss.group.visible = this.dim === "end";
    this.broken = data.broken ?? 0;
    this.kills = data.kills ?? 0;
    this.sawNether = data.sawNether ?? false;
    this.ow = { x: data.owX ?? data.x, y: data.owY ?? data.y, z: data.owZ ?? data.z };
    this.nd = data.ndX != null && data.ndY != null && data.ndZ != null ? { x: data.ndX, y: data.ndY, z: data.ndZ } : null;
    if (brandNew && this.dim === "overworld") {
      const [sx, sy, sz] = this.world.findSpawn();
      this.player.setSpawn(sx, sy, sz);
      this.spawnX = sx;
      this.spawnY = sy;
      this.spawnZ = sz;
      this.homeX = sx;
      this.homeY = sy;
      this.homeZ = sz;
    }
    await this.loadEndFrame();
    await this.generateAround(true);
    this.refreshBedSpawn();
    await this.meshAllDirty();
    this.drops?.load(data.drops ?? []);
    this.mobs.seedAround(this.world, this.player.x, this.player.z, !this.monsters);
    this.syncCamera();
    this.pushHud(true);
    this.exposeControls();
  }

  private applySave(data: SaveData) {
    this.seed = data.seed;
    this.player.x = data.x;
    this.player.y = data.y;
    this.player.z = data.z;
    this.player.yaw = data.yaw;
    this.player.pitch = data.pitch;
    this.health = data.health;
    this.food = data.food ?? MAX_FOOD;
    this.saturation = data.saturation ?? 5;
    this.worldTime = data.worldTime;
    this.hotbar = data.hotbar.map((s) => (s ? { ...s } : null));
    this.inventory = data.inventory.map((s) => (s ? { ...s } : null));
    this.armor = data.armor.map((s) => (s ? { ...s } : null));
    this.offhand = data.offhand ? { ...data.offhand } : null;
    this.edits = data.edits.slice();
    this.dim = data.dim === "nether" ? "nether" : data.dim === "end" ? "end" : "overworld";
    this.craftGrid = emptyGrid(CRAFT_SIZE);
    this.homeX = data.homeX ?? data.x;
    this.homeY = data.homeY ?? data.y;
    this.homeZ = data.homeZ ?? data.z;
    this.spawnX = this.homeX;
    this.spawnY = this.homeY;
    this.spawnZ = this.homeZ;
    if (data.bedX != null && data.bedY != null && data.bedZ != null) {
      this.bedBlock = { x: data.bedX, y: data.bedY, z: data.bedZ };
    } else this.bedBlock = null;
    this.furnaces.clear();
    for (const f of data.furnaces ?? []) {
      this.furnaces.set(`${f.x},${f.y},${f.z}`, {
        ...f,
        input: f.input ? { ...f.input } : null,
        fuel: f.fuel ? { ...f.fuel } : null,
        out: f.out ? { ...f.out } : null,
      });
    }
    gameStore.getState().setSettings(data.settings);
    gameStore.getState().patchHud({ canResume: true });
  }

  snapshot(): SaveData {
    const settings = gameStore.getState().settings;
    return {
      version: SAVE_VERSION,
      seed: this.seed,
      x: this.player.x,
      y: this.player.y,
      z: this.player.z,
      yaw: this.player.yaw,
      pitch: this.player.pitch,
      health: this.health,
      food: this.food,
      saturation: this.saturation,
      worldTime: this.worldTime,
      hotbar: this.hotbar.map((s) => (s ? { ...s } : null)),
      inventory: this.inventory.map((s) => (s ? { ...s } : null)),
      armor: this.armor.map((s) => (s ? { ...s } : null)),
      offhand: this.offhand ? { ...this.offhand } : null,
      edits: this.overworld?.exportEdits() ?? this.edits,
      netherEdits: this.nether?.exportEdits() ?? [],
      endEdits: this.end?.exportEdits() ?? [],
      dim: this.dim,
      owX: this.dim === "overworld" ? this.player.x : this.ow.x,
      owY: this.dim === "overworld" ? this.player.y : this.ow.y,
      owZ: this.dim === "overworld" ? this.player.z : this.ow.z,
      ndX: this.dim === "nether" ? this.player.x : (this.nd?.x ?? null),
      ndY: this.dim === "nether" ? this.player.y : (this.nd?.y ?? null),
      ndZ: this.dim === "nether" ? this.player.z : (this.nd?.z ?? null),
      dragonHp: this.endBoss.hp,
      crystalMask: this.endBoss.crystalMask(),
      dragonDead: this.endBoss.dead,
      broken: this.broken,
      kills: this.kills,
      sawNether: this.sawNether,
      id: this.saveId,
      name: this.worldName,
      monsters: this.monsters,
      bonus: this.bonus,
      settings,
      drops: this.drops?.snapshot() ?? [],
      furnaces: [...this.furnaces.values()].map((f) => ({
        ...f,
        input: f.input ? { ...f.input } : null,
        fuel: f.fuel ? { ...f.fuel } : null,
        out: f.out ? { ...f.out } : null,
      })),
      homeX: this.homeX,
      homeY: this.homeY,
      homeZ: this.homeZ,
      bedX: this.bedBlock?.x ?? null,
      bedY: this.bedBlock?.y ?? null,
      bedZ: this.bedBlock?.z ?? null,
    };
  }

  save() {
    writeSave(this.snapshot());
    gameStore.getState().patchHud({ canResume: true });
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.last = performance.now();
    this.renderer.setAnimationLoop((t) => this.frame(t));
  }

  stop() {
    this.running = false;
    this.renderer.setAnimationLoop(null);
  }

  requestLock() {
    this.audio.unlock();
    const p = this.canvas.requestPointerLock?.({ unadjustedMovement: true } as PointerLockOptions);
    if (p && typeof (p as Promise<void>).catch === "function") {
      (p as Promise<void>).catch(() => {
        this.canvas.requestPointerLock?.();
      });
    }
    gameStore.getState().setClickToPlay(false);
  }

  private resize() {
    const w = Math.max(1, this.canvas.clientWidth);
    const h = Math.max(1, this.canvas.clientHeight);
    const mobile = gameStore.getState().isMobile;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, mobile ? 1.15 : 1.5));
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.vmCam.aspect = w / h;
    this.vmCam.updateProjectionMatrix();
  }

  private frame(now: number) {
    if (this.disposed) return;
    const dt = Math.min((now - this.last) / 1000, 0.1);
    this.last = now;
    this.fpsAccum += dt;
    this.fpsFrames++;
    if (this.fpsAccum >= 0.4) {
      this.fps = this.fpsFrames / this.fpsAccum;
      this.fpsAccum = 0;
      this.fpsFrames = 0;
    }

    const phase = gameStore.getState().phase;
    const playing = phase === "playing";

    if (playing && !this.sleeping) this.worldTime += dt;
    if (this.toastT > 0) this.toastT = Math.max(0, this.toastT - dt);

    if (playing) {
      this.acc += dt;
      let steps = 0;
      while (this.acc >= FIXED && steps < 5) {
        this.fixed(FIXED);
        this.acc -= FIXED;
        steps++;
      }
      if (this.acc > FIXED * 5) this.acc = 0;
      this.updateLook();
      if (!this.sleeping) {
        this.updateTarget();
        this.updateBreakPlace(dt);
      }
      this.drops?.update(dt, this.world, this.player.x, this.player.y, this.player.z, (id, n) => {
        const left = addItem(this.hotbar, this.inventory, id, n);
        if (left < n) this.audio.pickup();
        return left === 0;
      });
      this.particles?.update(dt);
      if (this.dim === "end") {
        const ev = this.endBoss.update(dt);
        if (ev === "exit") this.openExit();
      }
      this.saveTimer += dt;
      if (this.saveTimer > 18) {
        this.saveTimer = 0;
        this.save();
      }
    } else {
      this.acc = 0;
      this.input.consumeLook();
      this.world.tickWater(24);
    }

    this.flushMeshes(this.switching ? 8 : playing ? 2 : 6);
    if (phase !== "paused" && phase !== "title" && phase !== "loading") this.tickFurnaces(dt);
    this.updateDay();
    this.syncCamera(dt);
    this.updateViewmodel(dt, playing);
    this.hurtFlash = Math.max(0, this.hurtFlash - dt);
    this.renderer.render(this.scene, this.camera);
    if (playing && !this.switching) {
      this.shotT -= dt;
      if (this.shotT <= 0 && this.shots.length < 6) {
        this.shotT = 30;
        const was = this.thirdPerson;
        this.thirdPerson = true;
        this.syncCamera(dt);
        this.renderer.render(this.scene, this.camera);
        try {
          this.shots.push(this.canvas.toDataURL("image/jpeg", 0.62));
        } catch {
          /* canvas may be empty on the first frames */
        }
        this.thirdPerson = was;
        this.syncCamera(dt);
        this.renderer.render(this.scene, this.camera);
      }
    }
    if (this.hand.visible) {
      this.renderer.autoClear = false;
      this.renderer.clearDepth();
      this.renderer.render(this.vmScene, this.vmCam);
      this.renderer.autoClear = true;
    }

    this.hudT += dt;
    if (this.hudT > 0.08) {
      this.hudT = 0;
      this.pushHud(false);
    }
    this.handleCraftKey();
    this.input.endFrame();
  }

  private handleCraftKey() {
    return;
  }

  private updateLook() {
    const st = gameStore.getState();
    if (st.phase !== "playing" || this.sleeping) return;
    const look = this.input.consumeLook();
    const locked = st.pointerLocked;
    const mobile = st.isMobile;
    if (locked || mobile || this.input.isDown("Mouse0") || this.input.isDown("Mouse2")) {
      this.player.look(look.dx, look.dy, st.settings.sensitivity);
    } else {
      this.input.lookDx = 0;
      this.input.lookDy = 0;
    }
  }

  private fixed(dt: number) {
    let mx = 0;
    let mz = 0;
    if (this.input.isDown("KeyA") || this.input.isDown("ArrowLeft")) mx -= 1;
    if (this.input.isDown("KeyD") || this.input.isDown("ArrowRight")) mx += 1;
    if (this.input.isDown("KeyW") || this.input.isDown("ArrowUp")) mz += 1;
    if (this.input.isDown("KeyS") || this.input.isDown("ArrowDown")) mz -= 1;
    mx += this.input.touchMoveX;
    mz += this.input.touchMoveY;
    if (mx > 1) mx = 1;
    if (mx < -1) mx = -1;
    if (mz > 1) mz = 1;
    if (mz < -1) mz = -1;

    if (this.input.justPressed("KeyC")) this.thirdPerson = !this.thirdPerson;

    if (this.sleeping) {
      this.sleepT += dt;
      this.player.vx = this.player.vy = this.player.vz = 0;
      this.snoreT -= dt;
      if (this.snoreT <= 0) {
        this.snoreT = 1.15;
        this.audio.snore();
      }
      if (this.sleepT >= 4.2) this.finishSleep();
      return;
    }

    const jump = this.input.justPressed("Space") || (this.player.inWater && this.input.isDown("Space"));
    const sneak = this.input.isDown("ShiftLeft") || this.input.isDown("ShiftRight");
    const sprint = this.input.isDown("SprintKey");
    if (this.boats.playerBoat && sneak) {
      this.boats.dismountPlayer();
      this.player.y += 0.6;
    } else if (this.boats.playerBoat) {
      this.boats.drive(dt, mx, mz, this.player.yaw);
    }
    this.boats.update(dt, this.world, this.mobs.mobs);
    if (this.boats.playerBoat) {
      const b = this.boats.playerBoat;
      this.player.x = b.x;
      this.player.y = b.y + 0.15;
      this.player.z = b.z;
      this.player.vx = this.player.vy = this.player.vz = 0;
      this.player.onGround = true;
      this.player.inWater = false;
    }
    const riding = !!this.boats.playerBoat;
    const wasGround = this.player.onGround;
    const distBefore = this.player.dist;
    const landed = riding ? 0 : this.player.step(dt, this.world, mx, mz, jump, sneak, sprint, this.food > 6);
    if (jump && this.player.vy > 0 && !this.player.inWater) {
      this.audio.jump();
      this.addExhaust(this.player.sprinting ? 0.2 : 0.05);
    }
    this.addExhaust((this.player.dist - distBefore) * (this.player.sprinting ? 0.1 : 0.01));
    void wasGround;
    let fall = landed;
    if (this.offhand?.id === SHIELD && sneak) fall *= 0.28;
    if (fall > 13) this.damage(Math.min(10, Math.floor((fall - 13) * 0.55)));

    this.stepTimer += dt;
    if (this.player.onGround && Math.hypot(this.player.vx, this.player.vz) > 1.4 && this.stepTimer > (this.player.sprinting ? 0.32 : 0.44)) {
      this.stepTimer = 0;
      this.audio.step();
    }

    if (this.dim === "end" && this.player.y < 6) {
      this.voidT += dt;
      if (this.voidT > 0.7) {
        this.voidT = 0;
        this.damage(1);
      }
    } else if (this.player.y < -8) {
      this.voidT = 0;
      this.health = MAX_HEALTH;
      this.food = MAX_FOOD;
      this.air = 10;
      this.drownT = 0;
      this.saturation = 5;
      this.player.setSpawn(this.spawnX, this.spawnY, this.spawnZ);
      this.audio.hurt();
    } else this.voidT = 0;

    const wheel = this.input.consumeWheel();
    if (wheel) {
      this.selected = (this.selected + wheel + 10) % 10;
    }
    for (let i = 0; i < 9; i++) {
      if (this.input.justPressed(`Digit${i + 1}`)) this.selected = i;
    }
    if (this.input.justPressed("Digit0")) this.selected = 9;
    if (this.input.justPressed("Tab")) this.dropHeld();

    const pcx = Math.floor(this.player.x / CHUNK_W);
    const pcz = Math.floor(this.player.z / CHUNK_W);
    if (pcx !== this.lastCx || pcz !== this.lastCz) this.streamChunks(pcx, pcz);
    this.world.tickWater(48);
    this.world.tickLava(28);
    if (this.player.inLava) {
      this.lavaHurt += dt;
      if (this.lavaHurt >= 0.5) {
        this.lavaHurt = 0;
        this.damage(4);
      }
    } else this.lavaHurt = 0;
    this.tickBreath(dt);
    this.attackCd = Math.max(0, this.attackCd - dt);
    this.tickHunger(dt);
    const phase = ((this.worldTime / DAY_LEN) % 1 + 1) % 1;
    const isDay = this.dim === "overworld" && Math.sin(phase * Math.PI * 2) > 0.05;
    this.tickPortal(dt);
    const look = this.lookDir();
    this.mobs.update(dt, this.world, this.player.x, this.player.y, this.player.z, this.drops, {
      isDay,
      look,
      eyeY: this.player.eyeY,
      peaceful: !this.monsters,
      sound: (kind) => {
        if (kind === "chicken") this.audio.cluck();
        else if (kind === "cow") this.audio.moo();
        else if (kind === "zombie") this.audio.growl();
        else if (kind === "skeleton") this.audio.bones();
        else if (kind === "creeper") this.audio.hiss();
        else if (kind === "spider") this.audio.skitter();
        else this.audio.oink();
      },
      hurt: (n) => {
        if (this.player.sneaking && this.offhand?.id === SHIELD) n = Math.max(1, Math.round(n * 0.35));
        this.damage(n);
      },
      boom: (x, y, z) => this.mobBoom(x, y, z),
    });
    this.tickToss(dt);
    while (this.world.loot.length) {
      const it = this.world.loot.pop()!;
      this.drops?.spawn(it.x + 0.5, it.y + 0.45, it.z + 0.5, it.id, it.count, false);
    }
  }

  private updateTarget() {
    const f = this.lookDir();
    const held = this.hotbar[this.selected]?.id ?? 0;
    const fluids = held === BUCKET || held === WATER_BUCKET || held === LAVA_BUCKET;
    this.target = voxelRaycast(
      this.world,
      this.player.x,
      this.player.eyeY,
      this.player.z,
      f.x,
      f.y,
      f.z,
      6.2,
      fluids ? (id) => isSolid(id) || isFluid(id) : isSolid,
    );
    if (this.target) {
      this.highlight.visible = true;
      this.highlight.position.set(this.target.x + 0.5, this.target.y + 0.5, this.target.z + 0.5);
      const mh = this.mobs.raycast(this.player.x, this.player.eyeY, this.player.z, f.x, f.y, f.z, 4.6);
      if (mh) {
        const bd = Math.hypot(this.target.x + 0.5 - this.player.x, this.target.y + 0.5 - this.player.eyeY, this.target.z + 0.5 - this.player.z);
        if (mh.dist < bd) this.highlight.visible = false;
      }
    } else {
      this.highlight.visible = false;
    }
  }

  private lookDir() {
    const cy = Math.cos(this.player.pitch);
    return {
      x: -Math.sin(this.player.yaw) * cy,
      y: Math.sin(this.player.pitch),
      z: -Math.cos(this.player.yaw) * cy,
    };
  }

  private dropHeld() {
    const stack = this.hotbar[this.selected];
    if (!stack || !this.drops) return;
    const look = this.lookDir();
    this.drops.toss(
      this.player.x + look.x * 0.45,
      this.player.y + 1.15,
      this.player.z + look.z * 0.45,
      stack.id,
      stack.count,
      look.x * 4.4,
      look.y * 3.2 + 1.4,
      look.z * 4.4,
    );
    this.hotbar[this.selected] = null;
  }

  private updateBreakPlace(dt: number) {
    this.placeCd = Math.max(0, this.placeCd - dt);
    const breaking = this.input.isDown("Mouse0");
    const justHit = this.input.justPressed("Mouse0");
    const placing = this.input.justPressed("Mouse2") || (this.input.isDown("Mouse2") && this.placeCd <= 0);
    const held = this.hotbar[this.selected]?.id ?? 0;
    const look = this.lookDir();
    if (justHit && (held === ENDER_PEARL || held === EYE_OF_ENDER)) {
      if (held === EYE_OF_ENDER && this.target && (this.world.getBlock(this.target.x, this.target.y, this.target.z) === END_FRAME || this.world.getBlock(this.target.x, this.target.y, this.target.z) === END_FRAME_EYE)) {
        this.insertEye(this.target.x, this.target.y, this.target.z);
        return;
      }
      this.throwEye(held === EYE_OF_ENDER ? "eye" : "pearl");
      return;
    }
    if (justHit && held === BOAT) {
      this.placeBoat();
      return;
    }
    let mobHit = this.mobs.raycast(this.player.x, this.player.eyeY, this.player.z, look.x, look.y, look.z, 4.6);
    if (!mobHit) mobHit = this.mobs.nearestInLook(this.player.x, this.player.eyeY, this.player.z, look.x, look.y, look.z, 3.1);
    const blockDist = this.target
      ? Math.hypot(this.target.x + 0.5 - this.player.x, this.target.y + 0.5 - this.player.eyeY, this.target.z + 0.5 - this.player.z)
      : 99;
    const boatHit = this.boats.ray(this.player.x, this.player.eyeY, this.player.z, look.x, look.y, look.z, 4.2);
    if (this.dim === "end" && justHit) {
      const crystal = this.endBoss.rayCrystal(this.player.x, this.player.eyeY, this.player.z, look.x, look.y, look.z, 6);
      const dragonDist = this.endBoss.rayDragon(this.player.x, this.player.eyeY, this.player.z, look.x, look.y, look.z, 6.5);
      if (crystal && crystal.dist < blockDist && (dragonDist == null || crystal.dist < dragonDist)) {
        this.blastCrystal(crystal.i);
        this.swingT = 0.22;
        this.audio.swing();
        return;
      }
      if (dragonDist != null && dragonDist < blockDist + 0.4 && this.attackCd <= 0) {
        this.attackCd = 0.5;
        this.swingT = 0.22;
        this.audio.swing();
        const healed = this.endBoss.crystalsLeft() > 0;
        const died = this.endBoss.hit(attackDamage(held) || 1);
        this.particles?.burst(this.endBoss.x, this.endBoss.y + 0.6, this.endBoss.z, 8);
        this.showToast(died ? "Ejderha düşüyor" : healed ? "Ejderha canını yeniledi" : `Ejderha ${Math.ceil(this.endBoss.hp)}`);
        this.wearHeld();
        return;
      }
    }
    if (justHit && boatHit && boatHit.dist + 0.2 < blockDist) {
      this.boats.mountPlayer(boatHit.boat);
      this.showToast("Tekneye bindin");
      return;
    }

    const mobFirst = mobHit != null && mobHit.dist < 4.2 && (mobHit.dist < blockDist + 0.45 || mobHit.dist < 2.4);
    if ((justHit || breaking) && mobFirst && mobHit && this.attackCd <= 0) {
      this.attackCd = 0.55;
      this.swingT = 0.22;
      this.audio.swing();
      this.addExhaust(0.1);
      this.mobs.hit(mobHit.mob, attackDamage(held), this.player.x, this.player.z);
      if (mobHit.mob.hp <= 0) this.kills++;
      if (mobHit.mob.kind === "chicken") this.audio.cluck();
      else if (mobHit.mob.kind === "cow") this.audio.moo();
      else if (mobHit.mob.kind === "zombie") this.audio.growl();
      else if (mobHit.mob.kind === "skeleton") this.audio.bones();
      else if (mobHit.mob.kind === "creeper") this.audio.hiss();
      else if (mobHit.mob.kind === "spider") this.audio.skitter();
      else this.audio.oink();
      this.particles?.burst(mobHit.mob.x, mobHit.mob.y + 0.4, mobHit.mob.z, 8);
      this.wearHeld();
      this.breakT = 0;
      this.crackMesh.visible = false;
      return;
    }

    if (justHit && held === FLINT_STEEL && this.target) {
      const t = this.target;
      const lit =
        tryLightPortal(this.world, t.x, t.y, t.z) ||
        tryLightPortal(this.world, t.x + t.nx, t.y + t.ny, t.z + t.nz);
      this.wearHeld();
      if (lit) {
        this.audio.place();
        this.showToast("Portal açıldı");
      } else this.showToast("Obsidyen çerçeve 4 eninde 6 boyunda olmalı");
      this.breakT = 0;
      this.crackMesh.visible = false;
      return;
    }

    if (isFood(held) && this.food < MAX_FOOD && this.input.isDown("Mouse2")) {
      this.eatT += dt;
      if (this.eatT >= 1.32) {
        this.eatT = 0;
        const stats = foodStats(held);
        if (stats) {
          takeOne(this.hotbar, this.selected);
          this.food = Math.min(MAX_FOOD, this.food + stats.hunger);
          this.saturation = Math.min(this.food, this.saturation + stats.saturation);
          this.audio.eat();
        }
      }
      this.breakT = 0;
      this.crackMesh.visible = false;
      return;
    }
    this.eatT = 0;

    if (breaking && this.target && !(mobHit && mobHit.dist < blockDist)) {
      const key = `${this.target.x},${this.target.y},${this.target.z}`;
      if (key !== this.breakKey) {
        this.breakKey = key;
        this.breakT = 0;
      }
      const id = this.world.getBlock(this.target.x, this.target.y, this.target.z);
      const def = BLOCKS[id];
      if (def && def.breakable) {
        if (this.breakT <= 0 && isTool(held)) this.audio.swing();
        this.breakT += dt;
        const dur = this.mineTime(id, def.hardness, held);
        const p = Math.min(1, this.breakT / dur);
        this.crackMesh.visible = p > 0.02;
        this.crackMesh.position.set(this.target.x + 0.5, this.target.y + 0.5, this.target.z + 0.5);
        const mi = Math.min(this.crackMats.length - 1, Math.floor(p * this.crackMats.length));
        this.crackMesh.material = this.crackMats[mi]!;
        if (!canFinishMine(id, held)) {
          if (this.breakT > dur * 0.9) this.breakT = dur * 0.9;
        } else if (p >= 1) {
          const drop = canHarvest(id, held) ? def.drops : AIR;
          const finalDrop = id === GRAVEL && drop === GRAVEL && Math.random() < 0.25 ? FLINT : drop;
          this.breakBlock(this.target.x, this.target.y, this.target.z, finalDrop);
          this.wearHeld();
          this.addExhaust(0.005);
          this.breakT = 0;
        }
      } else {
        this.breakT = 0;
        this.crackMesh.visible = false;
      }
    } else {
      this.breakT = 0;
      this.breakKey = "";
      this.crackMesh.visible = false;
    }

    if (placing && this.target && !isFood(held)) {
      this.useOnTarget();
      this.placeCd = 0.22;
    }
  }

  private addExhaust(n: number) {
    if (n <= 0) return;
    this.exhaust += n;
    while (this.exhaust >= 4) {
      this.exhaust -= 4;
      if (this.saturation > 0) this.saturation = Math.max(0, this.saturation - 1);
      else this.food = Math.max(0, this.food - 1);
    }
  }

  private tickHunger(dt: number) {
    if (this.food >= 18 && this.health < MAX_HEALTH) {
      this.regenT += dt;
      if (this.regenT >= 4) {
        this.regenT = 0;
        this.health = Math.min(MAX_HEALTH, this.health + 1);
        this.addExhaust(6);
      }
    } else this.regenT = 0;

    if (this.food <= 0) {
      this.starveT += dt;
      if (this.starveT >= 4) {
        this.starveT = 0;
        this.damage(1);
      }
    } else this.starveT = 0;
  }

  private wearHeld(n = 1) {
    const s = this.hotbar[this.selected];
    if (wearStack(s, n)) {
      this.hotbar[this.selected] = null;
      this.audio.break();
    }
  }

  private tickFurnaces(dt: number) {
    for (const f of this.furnaces.values()) tickFurnace(f, dt);
  }

  activeFurnace(): FurnaceSave | null {
    if (!this.furnaceAt) return null;
    return this.furnaces.get(this.furnaceAt) ?? null;
  }

  setFurnaceSlot(which: "input" | "fuel" | "out", s: ItemStack | null) {
    const f = this.activeFurnace();
    if (!f) return;
    if (which === "input") f.input = s;
    else if (which === "fuel") f.fuel = s;
    else f.out = s;
  }

  private openFurnace(x: number, y: number, z: number) {
    const k = `${x},${y},${z}`;
    if (!this.furnaces.has(k)) this.furnaces.set(k, emptyFurnace(x, y, z));
    this.furnaceAt = k;
    document.exitPointerLock?.();
    gameStore.getState().setPhase("furnace");
    gameStore.getState().setClickToPlay(false);
  }

  private trySleep() {
    const t = this.target;
    if (!t) return;
    this.setBedSpawn(t.x, t.y, t.z);
    const phase = ((this.worldTime / DAY_LEN) % 1 + 1) % 1;
    const sunY = Math.sin(phase * Math.PI * 2);
    if (sunY > 0.05) return;
    this.sleeping = true;
    this.sleepT = 0;
    this.snoreT = 0.4;
    this.player.setSpawn(t.x + 0.5, t.y + 0.12, t.z + 0.5);
    this.player.pitch = 0.2;
    document.exitPointerLock?.();
    gameStore.getState().setClickToPlay(false);
    this.pushHud(true);
  }

  wake() {
    if (!this.sleeping) return;
    this.sleeping = false;
    this.sleepT = 0;
    this.standBesideBed();
    this.pushHud(true);
  }

  private finishSleep() {
    this.sleeping = false;
    this.sleepT = 4.2;
    this.worldTime = 80;
    this.health = Math.min(MAX_HEALTH, this.health + 2);
    this.standBesideBed();
    this.showToast("Günaydın");
    this.pushHud(true);
  }

  private standBesideBed() {
    const b = this.bedBlock;
    if (!b) return;
    this.player.setSpawn(b.x + 0.5, b.y + 1.05, b.z + 1.4);
    this.player.pitch = 0;
  }

  private setBedSpawn(x: number, y: number, z: number) {
    this.bedBlock = { x, y, z };
    this.spawnX = x + 0.5;
    this.spawnY = y + 1.05;
    this.spawnZ = z + 0.5;
    this.showToast("Yeniden doğma noktası ayarlandı");
  }

  private refreshBedSpawn() {
    const b = this.bedBlock;
    if (!b || this.world.getBlock(b.x, b.y, b.z) !== BED) {
      this.bedBlock = null;
      this.spawnX = this.homeX;
      this.spawnY = this.homeY;
      this.spawnZ = this.homeZ;
      return;
    }
    this.spawnX = b.x + 0.5;
    this.spawnY = b.y + 1.05;
    this.spawnZ = b.z + 0.5;
  }

  private showToast(msg: string) {
    this.toast = msg;
    this.toastT = 3.2;
    this.pushHud(true);
  }

  private useOnTarget() {
    const t = this.target;
    if (!t) return;
    const bid = this.world.getBlock(t.x, t.y, t.z);
    const held = this.hotbar[this.selected];
    const hid = held?.id ?? 0;
    if (bid === FURNACE) {
      this.openFurnace(t.x, t.y, t.z);
      return;
    }
    if (bid === BED) {
      this.trySleep();
      return;
    }
    if (hid === EYE_OF_ENDER && (bid === END_FRAME || bid === END_FRAME_EYE)) {
      this.insertEye(t.x, t.y, t.z);
      return;
    }
    if (hid === FLINT_STEEL) {
      if (tryLightPortal(this.world, t.x, t.y, t.z) || tryLightPortal(this.world, t.x + t.nx, t.y + t.ny, t.z + t.nz)) {
        this.wearHeld();
        this.audio.place();
        return;
      }
    }
    if (hid === BUCKET && (bid === WATER || bid === LAVA)) {
      const source = bid === WATER ? this.world.isWaterSource(t.x, t.y, t.z) : this.world.isLavaSource(t.x, t.y, t.z);
      if (!source) return;
      this.world.editBlock(t.x, t.y, t.z, AIR);
      this.giveBucket(bid === WATER ? WATER_BUCKET : LAVA_BUCKET);
      this.audio.place();
      return;
    }
    if (hid === WATER_BUCKET || hid === LAVA_BUCKET) {
      const px = t.x + t.nx;
      const py = t.y + t.ny;
      const pz = t.z + t.nz;
      const place = hid === WATER_BUCKET ? WATER : LAVA;
      const cur = this.world.getBlock(px, py, pz);
      if (cur !== AIR && cur !== place) return;
      this.world.editBlock(px, py, pz, place);
      this.world.setSource(px, py, pz);
      this.giveBucket(BUCKET);
      this.audio.place();
      return;
    }
    this.tryPlace();
  }

  private breakBlock(x: number, y: number, z: number, drop: number) {
    const prev = this.world.getBlock(x, y, z);
    if (!this.world.editBlock(x, y, z, AIR)) return;
    this.broken++;
    this.audio.break();
    this.particles?.burst(x, y, z, 12);
    if (prev === FURNACE) this.furnaces.delete(`${x},${y},${z}`);
    if (prev === BED && this.bedBlock && this.bedBlock.x === x && this.bedBlock.y === y && this.bedBlock.z === z) {
      this.bedBlock = null;
      this.spawnX = this.homeX;
      this.spawnY = this.homeY;
      this.spawnZ = this.homeZ;
      this.showToast("Yatak kırıldı");
    }
    if (prev === PORTAL || prev === OBSIDIAN) {
      breakPortalNear(this.world, x + 1, y, z);
      breakPortalNear(this.world, x - 1, y, z);
      breakPortalNear(this.world, x, y + 1, z);
      breakPortalNear(this.world, x, y - 1, z);
      breakPortalNear(this.world, x, y, z + 1);
      breakPortalNear(this.world, x, y, z - 1);
    }
    if (drop && drop !== AIR) {
      this.drops?.spawn(x + 0.5, y + 0.42, z + 0.5, drop, 1);
    }
  }

  private giveBucket(id: number) {
    const held = this.hotbar[this.selected];
    if (held && held.count > 1) {
      held.count -= 1;
      addItem(this.hotbar, this.inventory, id, 1);
    } else this.hotbar[this.selected] = { id, count: 1 };
  }

  private tryPlace() {
    const t = this.target;
    if (!t) return;
    const stack = this.hotbar[this.selected];
    if (!stack || !isPlaceable(stack.id)) return;
    const px = t.x + t.nx;
    const py = t.y + t.ny;
    const pz = t.z + t.nz;
    if (isSolid(this.world.getBlock(px, py, pz))) return;
    const cur = this.world.getBlock(px, py, pz);
    if (cur !== AIR && cur !== WATER && cur !== LAVA) return;
    const hw = this.player.halfW();
    if (boxesOverlap(this.player.x - hw, this.player.y, this.player.z - hw, hw * 2, this.player.height(), hw * 2, px, py, pz, 1, 1, 1)) {
      return;
    }
    if (!this.world.editBlock(px, py, pz, stack.id)) return;
    if (stack.id === FURNACE) this.furnaces.set(`${px},${py},${pz}`, emptyFurnace(px, py, pz));
    if (stack.id === BED) this.setBedSpawn(px, py, pz);
    takeOne(this.hotbar, this.selected);
    this.audio.place();
    this.addExhaust(0.005);
  }

  private mobBoom(x: number, y: number, z: number) {
    const R = 2.3;
    for (let dy = -2; dy <= 2; dy++) {
      for (let dz = -2; dz <= 2; dz++) {
        for (let dx = -2; dx <= 2; dx++) {
          if (dx * dx + dy * dy + dz * dz > R * R) continue;
          const bx = Math.floor(x) + dx;
          const by = Math.floor(y) + dy;
          const bz = Math.floor(z) + dz;
          const id = this.world.getBlock(bx, by, bz);
          if (id === AIR || id === BEDROCK || id === OBSIDIAN) continue;
          const def = BLOCKS[id];
          if (!def?.breakable || def.hardness > 5) continue;
          this.world.editBlock(bx, by, bz, AIR);
        }
      }
    }
    const d = Math.hypot(this.player.x - x, this.player.y + 0.9 - y, this.player.z - z);
    if (d < 5.2) this.damage(Math.max(2, Math.round((5.2 - d) * 2.4)));
    this.particles?.burst(x, y, z, 26);
    this.audio.boom();
  }

  private mineTime(id: number, hardness: number, held: number) {
    const base = mineDuration(id, hardness, held);
    return this.player.inWater ? base * 1.85 : base;
  }

  private tickBreath(dt: number) {
    const ix = Math.floor(this.player.x);
    const iz = Math.floor(this.player.z);
    const head = this.world.getBlock(ix, Math.floor(this.player.y + 1.5), iz);
    const under = isWater(head) && !this.boats.playerBoat;
    if (under) {
      this.air = Math.max(0, this.air - dt * (10 / 15));
      if (this.air <= 0) {
        this.drownT += dt;
        if (this.drownT >= 1) {
          this.drownT = 0;
          this.damage(2);
        }
      }
    } else {
      this.drownT = 0;
      this.air = Math.min(10, this.air + dt * 4);
    }
  }

  private damage(n: number) {
    if (n <= 0) return;
    this.health = Math.max(0, this.health - n);
    this.hurtFlash = 0.32;
    this.hurtDir = Math.random() < 0.5 ? -1 : 1;
    this.audio.hurt();
    if (this.health <= 0) {
      if (this.dim === "end") {
        this.respawnFromEnd();
        return;
      }
      this.health = MAX_HEALTH;
      this.food = MAX_FOOD;
      this.air = 10;
      this.drownT = 0;
      this.saturation = 5;
      this.exhaust = 0;
      this.player.setSpawn(this.spawnX, this.spawnY, this.spawnZ);
    }
  }

  private async generateAround(blocking: boolean) {
    const dist = gameStore.getState().settings.renderDistance;
    const pcx = Math.floor(this.player.x / CHUNK_W);
    const pcz = Math.floor(this.player.z / CHUNK_W);
    const jobs: Array<[number, number, number]> = [];
    for (let dz = -dist - 1; dz <= dist + 1; dz++) {
      for (let dx = -dist - 1; dx <= dist + 1; dx++) {
        jobs.push([pcx + dx, pcz + dz, Math.abs(dx) + Math.abs(dz)]);
      }
    }
    jobs.sort((a, b) => a[2] - b[2]);
    let i = 0;
    for (const [cx, cz] of jobs) {
      this.world.ensureChunk(cx, cz);
      this.world.dirty.add(`${cx},${cz}`);
      i++;
      if (blocking && i % 8 === 0) {
        gameStore.getState().setLoading((i / jobs.length) * 0.55);
        await yieldFrame();
        if (this.disposed) return;
      }
    }
  }

  private async meshAllDirty() {
    const keys = [...this.world.dirty];
    keys.sort((a, b) => {
      const [ax, az] = a.split(",").map(Number);
      const [bx, bz] = b.split(",").map(Number);
      const pcx = Math.floor(this.player.x / CHUNK_W);
      const pcz = Math.floor(this.player.z / CHUNK_W);
      return Math.abs(ax! - pcx) + Math.abs(az! - pcz) - (Math.abs(bx! - pcx) + Math.abs(bz! - pcz));
    });
    const total = Math.max(1, keys.length);
    let i = 0;
    for (const k of keys) {
      this.world.dirty.delete(k);
      const [cx, cz] = k.split(",").map(Number);
      this.rebuildChunk(cx!, cz!);
      i++;
      if (i % 6 === 0) {
        gameStore.getState().setLoading(0.55 + (i / total) * 0.45);
        await yieldFrame();
        if (this.disposed) return;
      }
    }
    this.meshQueue = [];
    gameStore.getState().setLoading(1);
  }

  private streamChunks(pcx: number, pcz: number) {
    this.lastCx = pcx;
    this.lastCz = pcz;
    const dist = gameStore.getState().settings.renderDistance;
    for (let dz = -dist; dz <= dist; dz++) {
      for (let dx = -dist; dx <= dist; dx++) {
        const cx = pcx + dx;
        const cz = pcz + dz;
        this.world.ensureChunk(cx, cz);
      }
    }
    const removed = this.world.unloadFar(pcx, pcz, dist);
    for (const k of removed) this.disposeChunkMesh(k);
  }

  private flushMeshes(budget: number) {
    if (this.world.dirty.size) {
      const keys = [...this.world.dirty];
      keys.sort((a, b) => {
        const [ax, az] = a.split(",").map(Number);
        const [bx, bz] = b.split(",").map(Number);
        const pcx = Math.floor(this.player.x / CHUNK_W);
        const pcz = Math.floor(this.player.z / CHUNK_W);
        return Math.abs(ax! - pcx) + Math.abs(az! - pcz) - (Math.abs(bx! - pcx) + Math.abs(bz! - pcz));
      });
      this.meshQueue = keys;
    }
    let n = 0;
    while (n < budget && this.meshQueue.length) {
      const k = this.meshQueue.shift()!;
      if (!this.world.dirty.has(k)) continue;
      this.world.dirty.delete(k);
      const [cx, cz] = k.split(",").map(Number);
      this.rebuildChunk(cx!, cz!);
      n++;
    }
  }

  private rebuildChunk(cx: number, cz: number) {
    const k = chunkKey(cx, cz);
    this.disposeChunkMesh(k);
    if (!this.material) return;
    const geo = meshChunk(this.world, cx, cz);
    if (geo) {
      const mesh = new THREE.Mesh(geo, this.material);
      mesh.matrixAutoUpdate = false;
      mesh.updateMatrix();
      this.scene.add(mesh);
      this.chunkMeshes.set(k, mesh);
    }
    if (this.waterMat) {
      const wgeo = meshWater(this.world, cx, cz);
      if (wgeo) {
        const wm = new THREE.Mesh(wgeo, this.waterMat);
        wm.matrixAutoUpdate = false;
        wm.updateMatrix();
        this.scene.add(wm);
        this.waterMeshes.set(k, wm);
      }
    }
    if (this.lavaMat) {
      const lgeo = meshLava(this.world, cx, cz);
      if (lgeo) {
        const lm = new THREE.Mesh(lgeo, this.lavaMat);
        lm.matrixAutoUpdate = false;
        lm.updateMatrix();
        this.scene.add(lm);
        this.lavaMeshes.set(k, lm);
      }
    }
    if (this.portalMat) {
      const pgeo = meshPortal(this.world, cx, cz);
      if (pgeo) {
        const pm = new THREE.Mesh(pgeo, this.portalMat);
        pm.matrixAutoUpdate = false;
        pm.updateMatrix();
        this.scene.add(pm);
        this.portalMeshes.set(k, pm);
      }
    }
    this.syncFrames(cx, cz);
  }

  private async loadEndFrame() {
    try {
      const gltf = await new GLTFLoader().loadAsync("/models/end-frame.gltf");
      gltf.scene.updateMatrixWorld(true);
      const buckets = new Map<THREE.Material, THREE.BufferGeometry[]>();
      gltf.scene.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        if (!mesh.isMesh) return;
        const geo = mesh.geometry.clone();
        geo.applyMatrix4(mesh.matrixWorld);
        const mat = (Array.isArray(mesh.material) ? mesh.material[0] : mesh.material) as THREE.Material;
        const list = buckets.get(mat) ?? [];
        list.push(geo);
        buckets.set(mat, list);
      });
      const group = new THREE.Group();
      for (const [src, geos] of buckets) {
        const merged = mergeGeometries(geos, false);
        if (!merged) continue;
        const std = src as THREE.MeshStandardMaterial;
        if (std.map) {
          std.map.magFilter = THREE.NearestFilter;
          std.map.minFilter = THREE.NearestFilter;
          std.map.colorSpace = THREE.SRGBColorSpace;
          std.map.needsUpdate = true;
        }
        const mat = new THREE.MeshLambertMaterial({
          map: std.map ?? null,
          color: std.color ?? 0xffffff,
          alphaTest: 0.05,
          side: THREE.DoubleSide,
        });
        const mesh = new THREE.Mesh(merged, mat);
        mesh.castShadow = false;
        mesh.receiveShadow = false;
        group.add(mesh);
        for (const g of geos) g.dispose();
      }
      this.frameTpl = group;
      const eye = new THREE.Group();
      const shell = new THREE.Mesh(
        new THREE.SphereGeometry(0.12, 8, 6),
        new THREE.MeshLambertMaterial({ color: 0x49e090, emissive: 0x145c32, emissiveIntensity: 0.35 }),
      );
      shell.scale.set(1, 0.55, 1);
      const pupil = new THREE.Mesh(
        new THREE.SphereGeometry(0.045, 6, 5),
        new THREE.MeshLambertMaterial({ color: 0x102018 }),
      );
      pupil.position.set(0, 0.05, 0);
      eye.add(shell, pupil);
      eye.position.set(0, 0.7, 0);
      this.frameEye = eye;
    } catch (err) {
      console.warn("end frame model", err);
    }
  }

  private syncFrames(cx: number, cz: number) {
    const k = chunkKey(cx, cz);
    this.clearFrames(k);
    if (!this.frameTpl) return;
    const data = this.world.chunks.get(k);
    if (!data) return;
    const ox = cx * CHUNK_W;
    const oz = cz * CHUNK_D;
    const root = new THREE.Group();
    let n = 0;
    for (let y = 0; y < 64; y++) {
      for (let z = 0; z < CHUNK_D; z++) {
        for (let x = 0; x < CHUNK_W; x++) {
          const id = data[x + z * CHUNK_W + y * CHUNK_W * CHUNK_D] ?? 0;
          if (id !== END_FRAME && id !== END_FRAME_EYE) continue;
          const wx = ox + x;
          const wz = oz + z;
          const inst = this.frameTpl.clone(true);
          inst.position.set(wx + 0.5, y + 0.002, wz + 0.5);
          inst.rotation.y = this.frameYaw(wx, y, wz);
          if (id === END_FRAME_EYE && this.frameEye) inst.add(this.frameEye.clone(true));
          root.add(inst);
          n++;
        }
      }
    }
    if (!n) return;
    this.scene.add(root);
    this.frameGroups.set(k, root);
  }

  private frameYaw(x: number, y: number, z: number) {
    const isFrame = (bx: number, bz: number) => {
      const id = this.world.getBlock(bx, y, bz);
      return id === END_FRAME || id === END_FRAME_EYE;
    };
    let sx = 0;
    let sz = 0;
    let n = 0;
    for (let dz = -6; dz <= 6; dz++) {
      for (let dx = -6; dx <= 6; dx++) {
        if (!isFrame(x + dx, z + dz)) continue;
        sx += dx;
        sz += dz;
        n++;
      }
    }
    if (!n) return 0;
    const dx = sx / n;
    const dz = sz / n;
    if (Math.abs(dx) > Math.abs(dz)) return dx > 0 ? Math.PI / 2 : -Math.PI / 2;
    return dz > 0 ? 0 : Math.PI;
  }

  private clearFrames(k: string) {
    const g = this.frameGroups.get(k);
    if (!g) return;
    this.scene.remove(g);
    this.frameGroups.delete(k);
  }

  private disposeChunkMesh(k: string) {
    this.clearFrames(k);
    const m = this.chunkMeshes.get(k);
    if (m) {
      this.scene.remove(m);
      m.geometry.dispose();
      this.chunkMeshes.delete(k);
    }
    const w = this.waterMeshes.get(k);
    if (w) {
      this.scene.remove(w);
      w.geometry.dispose();
      this.waterMeshes.delete(k);
    }
    const lv = this.lavaMeshes.get(k);
    if (lv) {
      this.scene.remove(lv);
      lv.geometry.dispose();
      this.lavaMeshes.delete(k);
    }
    const p = this.portalMeshes.get(k);
    if (p) {
      this.scene.remove(p);
      p.geometry.dispose();
      this.portalMeshes.delete(k);
    }
  }

  private placeBoat() {
    const dir = this.lookDir();
    const t = this.target;
    const x = t ? t.x + t.nx + 0.5 : this.player.x + dir.x * 2;
    const y = t ? t.y + t.ny : this.player.y;
    const z = t ? t.z + t.nz + 0.5 : this.player.z + dir.z * 2;
    const boat = this.boats.spawn(x, y + 0.1, z);
    boat.yaw = this.player.yaw;
    takeOne(this.hotbar, this.selected);
    this.boats.mountPlayer(boat);
    this.audio.place();
    this.showToast("Tekne");
  }

  private throwEye(kind: "pearl" | "eye") {
    const dir = this.lookDir();
    let vx = dir.x * 14;
    let vy = dir.y * 14 + 1.4;
    let vz = dir.z * 14;
    let tx = 0;
    let tz = 0;
    if (kind === "eye") {
      const rooms = this.world.rooms.length ? this.world.rooms : strongholds(this.seed);
      let s = rooms[0]!;
      let best = Infinity;
      for (const room of rooms) {
        const dd = (room.x - this.player.x) ** 2 + (room.z - this.player.z) ** 2;
        if (dd < best) {
          best = dd;
          s = room;
        }
      }
      tx = s.x + 6.5;
      tz = s.z + 6.5;
      const dx = tx - this.player.x;
      const dz = tz - this.player.z;
      const len = Math.hypot(dx, dz) || 1;
      vx = (dx / len) * 12;
      vz = (dz / len) * 12;
      vy = 6.5;
    }
    const mesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.14, 8, 6),
      new THREE.MeshLambertMaterial({ color: kind === "eye" ? 0x3dce74 : 0x146656, emissive: kind === "eye" ? 0x145c32 : 0x062820 }),
    );
    mesh.position.set(this.player.x, this.player.eyeY, this.player.z);
    this.scene.add(mesh);
    this.tosses.push({ kind, x: this.player.x, y: this.player.eyeY, z: this.player.z, vx, vy, vz, tx, tz, mesh });
    takeOne(this.hotbar, this.selected);
    this.audio.swing();
  }

  private tickToss(dt: number) {
    for (let i = this.tosses.length - 1; i >= 0; i--) {
      const t = this.tosses[i]!;
      if (t.kind === "eye") {
        const dx = t.tx - t.x;
        const dz = t.tz - t.z;
        const d = Math.hypot(dx, dz);
        if (d < 16) t.vy = -10;
        else {
          t.vx += ((dx / d) * 12 - t.vx) * Math.min(1, 3 * dt);
          t.vz += ((dz / d) * 12 - t.vz) * Math.min(1, 3 * dt);
          t.vy -= 7 * dt;
        }
      } else t.vy -= 16 * dt;
      const px = t.x;
      const py = t.y;
      const pz = t.z;
      t.x += t.vx * dt;
      t.y += t.vy * dt;
      t.z += t.vz * dt;
      t.mesh.position.set(t.x, t.y, t.z);
      const solid = t.y < 1 || isSolid(this.world.getBlock(Math.floor(t.x), Math.floor(t.y), Math.floor(t.z)));
      if (!solid) continue;
      if (t.kind === "pearl") {
        const tx = px;
        const ty = Math.max(1, py);
        const tz = pz;
        if (!isSolid(this.world.getBlock(Math.floor(tx), Math.floor(ty), Math.floor(tz)))) {
          this.player.setSpawn(tx, ty, tz);
          this.showToast("Işınlandın");
        }
      } else if (Math.hypot(t.tx - t.x, t.tz - t.z) < 18) {
        this.showToast("End gözü tapınağa gömüldü");
      } else this.drops?.spawn(px, py + 0.2, pz, EYE_OF_ENDER, 1, false);
      this.scene.remove(t.mesh);
      t.mesh.geometry.dispose();
      (t.mesh.material as THREE.Material).dispose();
      this.tosses.splice(i, 1);
    }
  }

  private insertEye(x: number, y: number, z: number) {
    if (this.world.getBlock(x, y, z) !== END_FRAME) {
      this.showToast("Bu çerçevede göz var");
      return;
    }
    this.world.editBlock(x, y, z, END_FRAME_EYE);
    takeOne(this.hotbar, this.selected);
    this.audio.place();
    for (const room of this.world.rooms) {
      const frames = frameSpots(room);
      if (!frames.some(([fx, fy, fz]) => fx === x && fy === y && fz === z)) continue;
      if (frames.every(([fx, fy, fz]) => this.world.getBlock(fx, fy, fz) === END_FRAME_EYE)) {
        for (const [px, py, pz] of portalSpots(room)) this.world.editBlock(px, py, pz, END_PORTAL);
        this.showToast("End portalı açıldı");
      } else this.showToast("End gözü yerleştirildi");
      return;
    }
    this.showToast("End gözü yerleştirildi");
  }

  private tickPortal(dt: number) {
    if (this.switching) return;
    if (this.portalLock > 0) {
      this.portalLock -= dt;
      this.portalT = 0;
      return;
    }
    const x = Math.floor(this.player.x);
    const y = Math.floor(this.player.y);
    const z = Math.floor(this.player.z);
    const here = this.world.getBlock(x, y, z);
    const above = this.world.getBlock(x, y + 1, z);
    const nether = here === PORTAL || above === PORTAL;
    const endGate = here === END_PORTAL || above === END_PORTAL;
    if (!nether && !endGate) {
      this.portalT = 0;
      return;
    }
    this.portalT += dt;
    if (this.portalT < 0.85) return;
    this.portalT = 0;
    this.portalLock = 3.2;
    if (endGate && this.dim === "overworld") this.enterEnd();
    else if (endGate && this.dim === "end") this.startCredits();
    else if (nether && this.dim !== "end") void this.switchDimension();
  }

  private async switchDimension() {
    if (this.switching || !this.overworld || !this.nether || !this.end) return;
    if (this.dim === "overworld") {
      this.ow = { x: this.player.x, y: this.player.y, z: this.player.z };
      this.sawNether = true;
      if (!this.nd) {
        const nx = Math.floor(this.ow.x / 8);
        const nz = Math.floor(this.ow.z / 8);
        const py = 26;
        this.carveNetherPortal(nx, py, nz);
        this.nd = { x: nx + 1.5, y: py + 0.05, z: nz + 0.5 };
      }
      await this.arrive("nether", this.nd.x, this.nd.y, this.nd.z, "Nether");
    } else if (this.dim === "nether") {
      this.nd = { x: this.player.x, y: this.player.y, z: this.player.z };
      await this.arrive("overworld", this.ow.x, this.ow.y + 0.05, this.ow.z, "Üst dünya");
    }
  }

  private enterEnd() {
    if (this.dim !== "overworld" || this.switching || !this.end) return;
    this.ow = { x: this.player.x, y: this.player.y, z: this.player.z };
    const y = (this.end.endSurface(6, 6) ?? 36) + 1.15;
    void this.arrive("end", 6.5, y, 6.5, "End");
  }

  private respawnFromEnd() {
    if (this.switching) return;
    this.health = MAX_HEALTH;
    this.food = MAX_FOOD;
    this.air = 10;
    this.drownT = 0;
    this.saturation = 5;
    this.exhaust = 0;
    let x = this.homeX;
    let y = this.homeY;
    let z = this.homeZ;
    let msg = "Dünyada doğdun";
    const bed = this.bedBlock;
    if (bed && this.overworld?.getBlock(bed.x, bed.y, bed.z) === BED) {
      x = bed.x + 0.5;
      y = bed.y + 0.2;
      z = bed.z + 0.5;
      msg = "Yatağında doğdun";
    }
    void this.arrive("overworld", x, y, z, msg);
  }

  private startCredits() {
    document.exitPointerLock?.();
    gameStore.getState().setClickToPlay(false);
    gameStore.getState().setPhase("credits");
  }

  creditsView() {
    return { lines: this.storyLines(), shots: this.shots.slice() };
  }

  returnFromCredits() {
    gameStore.getState().setPhase("playing");
    this.portalLock = 3.5;
    void this.arrive("overworld", this.ow.x, this.ow.y + 0.2, this.ow.z, "Üst dünya");
    this.requestLock();
  }

  private storyLines() {
    const lines = ["Bir zamanlar üst dünyada bir gezgin uyanmıştı."];
    if (this.broken > 4) lines.push(`${this.broken} bloğu elleriyle kırmış, taşı ve toprağı yol etmişti.`);
    if (this.kills > 0) lines.push(`Yoluna çıkan ${this.kills} canlıyı geri püskürtmüştü.`);
    if (this.sawNether) lines.push("Obsidyen bir kapıdan geçmiş, Nether'ın sıcaklığına inmişti.");
    lines.push("On altı end gözünü çerçevelere koyunca ortada bir portal açıldı.");
    lines.push("End'in boşluğuna adım attı. Altında ada yoktu; sadece karanlık.");
    lines.push("Büyük adanın çevresinde sekiz kule duruyordu. Üstlerinde kristaller dönüyordu.");
    if (this.endBoss.crystalsLeft() === 0) lines.push("Kristalleri bir bir patlattı. Ejderha artık iyileşemiyordu.");
    lines.push("Ejderha parçalandı. Ortasından bir ışık yükseldi.");
    lines.push("Adanın ortasında ana kayadan bir kapı kaldı. Gezgin içeri girdi.");
    return lines;
  }

  private blastCrystal(i: number) {
    const c = this.endBoss.killCrystal(i);
    if (!c) return;
    this.audio.boom();
    this.particles?.burst(c.x, c.y, c.z, 18);
    const px = this.player.x;
    const py = this.player.y + 0.9;
    const pz = this.player.z;
    const dist = Math.hypot(px - c.x, py - c.y, pz - c.z);
    if (dist < 8.5) {
      const blocked = this.occluded(c.x, c.y, c.z, px, py, pz);
      this.damage(blocked ? 3 : 8);
      const dx = px - c.x;
      const dz = pz - c.z;
      const len = Math.hypot(dx, dz) || 1;
      const kick = blocked ? 3 : 8;
      this.player.vx += (dx / len) * kick;
      this.player.vz += (dz / len) * kick;
      this.player.vy = Math.max(this.player.vy, blocked ? 2.2 : 5.4);
    }
    for (const m of this.mobs.mobs) {
      const md = Math.hypot(m.x - c.x, m.y - c.y, m.z - c.z);
      if (md > 7) continue;
      m.hp -= 8;
      const dx = m.x - c.x;
      const dz = m.z - c.z;
      const len = Math.hypot(dx, dz) || 1;
      m.vx += (dx / len) * 7;
      m.vz += (dz / len) * 7;
      m.vy = 4;
    }
  }

  private occluded(x: number, y: number, z: number, px: number, py: number, pz: number) {
    const steps = 8;
    for (let i = 1; i < steps; i++) {
      const t = i / steps;
      const bx = Math.floor(x + (px - x) * t);
      const by = Math.floor(y + (py - y) * t);
      const bz = Math.floor(z + (pz - z) * t);
      if (isSolid(this.world.getBlock(bx, by, bz))) return true;
    }
    return false;
  }

  private openExit() {
    const w = this.end;
    if (!w) return;
    const y = w.endSurface(0, 0) ?? 34;
    for (let dz = -1; dz <= 1; dz++) {
      for (let dx = -1; dx <= 1; dx++) w.editBlock(dx, y, dz, BEDROCK);
    }
    w.editBlock(0, y + 1, 0, END_PORTAL);
    this.portalLock = 2.4;
    this.showToast("Çıkış portalı açıldı");
  }

  private async arrive(next: "overworld" | "nether" | "end", x: number, y: number, z: number, toast: string) {
    if (this.switching || !this.overworld || !this.nether || !this.end) return;
    this.switching = true;
    this.dim = next;
    this.world = next === "nether" ? this.nether : next === "end" ? this.end : this.overworld;
    this.player.setSpawn(x, y, z);
    this.player.vx = this.player.vy = this.player.vz = 0;
    this.endBoss.group.visible = next === "end";
    this.showToast(toast);
    this.dropMeshes();
    this.mobs.clear();
    this.boats.clear();
    for (const t of this.tosses) {
      this.scene.remove(t.mesh);
      t.mesh.geometry.dispose();
    }
    this.tosses = [];
    this.drops?.clear();
    this.meshQueue = [];
    this.lastCx = 99999;
    this.lastCz = 99999;
    await this.generateAround(false);
    this.stepOutOfPortal();
    const dist = gameStore.getState().settings.renderDistance;
    const pcx = Math.floor(this.player.x / CHUNK_W);
    const pcz = Math.floor(this.player.z / CHUNK_W);
    for (let dz = -dist - 1; dz <= dist + 1; dz++) {
      for (let dx = -dist - 1; dx <= dist + 1; dx++) {
        this.world.ensureChunk(pcx + dx, pcz + dz);
        this.world.dirty.add(`${pcx + dx},${pcz + dz}`);
      }
    }
    await this.meshAllDirty();
    this.mobs.seedAround(this.world, this.player.x, this.player.z, !this.monsters);
    this.syncCamera();
    this.save();
    this.switching = false;
  }

  private carveNetherPortal(x: number, y: number, z: number) {
    const w = this.nether;
    if (!w) return;
    for (let dy = 0; dy < 7; dy++) {
      for (let dx = -1; dx <= 4; dx++) {
        for (let dz = -2; dz <= 2; dz++) w.editBlock(x + dx, y + dy, z + dz, AIR);
      }
    }
    for (let dx = -1; dx <= 4; dx++) {
      for (let dz = -2; dz <= 2; dz++) w.editBlock(x + dx, y - 1, z + dz, NETHERRACK);
    }
    for (let dy = 0; dy < 6; dy++) {
      for (let dx = 0; dx < 4; dx++) {
        const edge = dy === 0 || dy === 5 || dx === 0 || dx === 3;
        w.editBlock(x + dx, y + dy, z, edge ? OBSIDIAN : PORTAL);
      }
    }
  }

  private stepOutOfPortal() {
    const x = Math.floor(this.player.x);
    const y = Math.floor(this.player.y);
    const z = Math.floor(this.player.z);
    const gate = (bx: number, by: number, bz: number) => {
      const id = this.world.getBlock(bx, by, bz);
      return id === PORTAL || id === END_PORTAL;
    };
    const inside = gate(x, y, z) || gate(x, y + 1, z);
    if (!inside) return;
    const dirs: Array<[number, number]> = [[0, 2], [0, -2], [3, 0], [-3, 0], [0, 3], [0, -3]];
    for (const [dx, dz] of dirs) {
      const nx = x + dx;
      const nz = z + dz;
      if (gate(nx, y, nz) || gate(nx, y + 1, nz)) continue;
      if (isSolid(this.world.getBlock(nx, y, nz)) || isSolid(this.world.getBlock(nx, y + 1, nz))) continue;
      const below = this.world.getBlock(nx, y - 1, nz);
      if (below === LAVA || below === WATER || !isSolid(below)) continue;
      this.player.x = nx + 0.5;
      this.player.z = nz + 0.5;
      return;
    }
  }

  private buildAvatar() {
    const g = new THREE.Group();
    const look = loadLook();
    const skin = SKINS[look.skin] ?? SKINS[0];
    const shirt = SHIRTS[look.shirt] ?? SHIRTS[0];
    const pants = PANTS[look.pants] ?? PANTS[0];
    const part = (x: number, y: number, z: number, w: number, h: number, d: number, color: number) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshLambertMaterial({ color }));
      m.position.set(x, y, z);
      g.add(m);
      return m;
    };
    part(0, 1.62, 0, 0.5, 0.5, 0.5, skin);
    part(0, 1.05, 0, 0.5, 0.72, 0.28, shirt);
    const armL = part(-0.38, 1.05, 0, 0.22, 0.72, 0.22, skin);
    const armR = part(0.38, 1.05, 0, 0.22, 0.72, 0.22, skin);
    const legL = part(-0.14, 0.36, 0, 0.22, 0.72, 0.22, pants);
    const legR = part(0.14, 0.36, 0, 0.22, 0.72, 0.22, pants);
    this.avatarLegs = [legL, legR, armL, armR];
    return g;
  }

  private syncAvatar() {
    const a = this.avatar;
    if (!a) return;
    a.position.set(this.player.x, this.player.y, this.player.z);
    a.rotation.y = this.player.yaw;
    const swing = Math.sin(this.player.bob * 1.4) * 0.6;
    const [legL, legR, armL, armR] = this.avatarLegs;
    if (legL && legR && armL && armR) {
      legL.rotation.x = swing;
      legR.rotation.x = -swing;
      armL.rotation.x = -swing;
      armR.rotation.x = swing;
    }
  }

  private dropMeshes() {
    const keys = new Set([
      ...this.chunkMeshes.keys(),
      ...this.waterMeshes.keys(),
      ...this.lavaMeshes.keys(),
      ...this.portalMeshes.keys(),
    ]);
    for (const k of keys) this.disposeChunkMesh(k);
  }

  private updateDay() {
    if (this.dim === "end") {
      const sky = new THREE.Color(0x07010f);
      this.scene.background = sky;
      (this.scene.fog as THREE.Fog).color.copy(sky);
      (this.scene.fog as THREE.Fog).near = 18;
      (this.scene.fog as THREE.Fog).far = 90;
      this.hemi.color.set(0x6a4a88);
      this.hemi.groundColor.set(0x120818);
      this.hemi.intensity = 0.45;
      this.ambient.color.set(0xcbb7e0);
      this.ambient.intensity = 0.32;
      this.sun.intensity = 0.18;
      this.sun.color.set(0xd8c0ff);
      this.stars.visible = true;
      (this.stars.material as THREE.PointsMaterial).opacity = 0.7;
      this.sunMesh.visible = false;
      this.moonMesh.visible = false;
      gameStore.getState().patchHud({ dayPhase: 0.82, isDay: false });
      return;
    }
    if (this.dim === "nether") {
      const sky = new THREE.Color(0x140606);
      this.scene.background = sky;
      (this.scene.fog as THREE.Fog).color.copy(sky);
      (this.scene.fog as THREE.Fog).near = 8;
      (this.scene.fog as THREE.Fog).far = 48;
      this.hemi.color.set(0xff5530);
      this.hemi.groundColor.set(0x2a0806);
      this.hemi.intensity = 0.55;
      this.ambient.color.set(0xff6644);
      this.ambient.intensity = 0.38;
      this.sun.intensity = 0.22;
      this.sun.color.set(0xff5533);
      this.stars.visible = false;
      this.sunMesh.visible = false;
      this.moonMesh.visible = false;
      gameStore.getState().patchHud({ dayPhase: 0.75, isDay: false });
      if (this.portalMat) {
        const t = this.worldTime * 6;
        this.portalMat.emissiveIntensity = 0.7 + Math.sin(t) * 0.25;
        this.portalMat.opacity = 0.55;
      }
      return;
    }
    this.hemi.color.set(0xb8d8ff);
    this.hemi.groundColor.set(0x3d4a2a);
    this.ambient.color.set(0xffffff);
    this.stars.visible = true;
    const phase = ((this.worldTime / DAY_LEN) % 1 + 1) % 1;
    const ang = phase * Math.PI * 2;
    const sunY = Math.sin(ang);
    const sunX = Math.cos(ang);
    const day = Math.max(0, sunY);
    const dusk = Math.max(0, 1 - Math.abs(sunY) * 3);
    const skyDay = new THREE.Color(0x79c4e0);
    const skyDusk = new THREE.Color(0xe07a48);
    const skyNight = new THREE.Color(0x050712);
    const sky = skyNight.clone().lerp(skyDay, day);
    sky.lerp(skyDusk, dusk * 0.7);
    this.scene.background = sky;
    (this.scene.fog as THREE.Fog).color.copy(sky);
    const dist = gameStore.getState().settings.renderDistance;
    (this.scene.fog as THREE.Fog).near = dist * 8;
    (this.scene.fog as THREE.Fog).far = dist * 16 + 24;

    this.sun.position.set(sunX * 80, sunY * 80, 30);
    this.sun.intensity = 0.12 + day * 1.05;
    this.sun.color.set(dusk > 0.2 ? 0xffc089 : 0xfff3d0);
    this.hemi.intensity = 0.22 + day * 0.55;
    this.ambient.intensity = 0.16 + day * 0.28;
    (this.stars.material as THREE.PointsMaterial).opacity = Math.max(0, 0.85 - day * 1.6);

    const px = this.player.x;
    const py = this.player.y;
    const pz = this.player.z;
    this.sunMesh.position.set(px + sunX * 140, py + sunY * 140, pz + 40);
    this.moonMesh.position.set(px - sunX * 140, py - sunY * 140, pz - 30);
    this.sunMesh.visible = sunY > -0.15;
    this.moonMesh.visible = sunY < 0.15;
    this.stars.position.set(px, py, pz);

    gameStore.getState().patchHud({ dayPhase: phase, isDay: sunY > 0.05 });
    if (this.portalMat) {
      const t = this.worldTime * 6;
      this.portalMat.emissiveIntensity = 0.55 + Math.sin(t) * 0.28;
      this.portalMat.opacity = 0.42 + Math.sin(t * 1.3) * 0.12;
    }
  }

  private syncCamera(dt = 0.016) {
    if (this.sleeping && this.bedBlock) {
      const b = this.bedBlock;
      const lie = Math.min(1, this.sleepT / 1.1);
      this.yawObj.position.set(b.x + 0.5, b.y + 1.35 - lie * 0.35, b.z + 1.15);
      this.yawObj.rotation.set(0, Math.PI, 0);
      this.camera.position.set(0, 0, 0);
      this.camera.rotation.set(-0.15 + lie * 0.85, 0, Math.sin(this.sleepT * 1.4) * 0.04);
      return;
    }
    this.syncAvatar();
    const tilt = (this.hurtFlash / 0.32) ** 2 * 0.05 * this.hurtDir;
    if (this.thirdPerson && !this.sleeping) {
      const dir = this.lookDir();
      let dist = 4.4;
      for (let t = 0.45; t < dist; t += 0.28) {
        const bx = Math.floor(this.player.x - dir.x * t);
        const by = Math.floor(this.player.eyeY - dir.y * t);
        const bz = Math.floor(this.player.z - dir.z * t);
        if (isSolid(this.world.getBlock(bx, by, bz))) {
          dist = Math.max(0.7, t - 0.2);
          break;
        }
      }
      this.yawObj.position.set(this.player.x - dir.x * dist, this.player.eyeY - dir.y * dist, this.player.z - dir.z * dist);
      this.yawObj.rotation.set(0, this.player.yaw, 0);
      this.camera.position.set(0, 0, 0);
      this.camera.rotation.set(this.player.pitch, 0, tilt);
      if (this.avatar) this.avatar.visible = true;
    } else {
      this.yawObj.position.set(this.player.x, this.player.eyeY, this.player.z);
      this.yawObj.rotation.set(0, this.player.yaw, 0);
      const bob = this.player.bob * 0.02;
      this.camera.position.set(0, bob, 0);
      this.camera.rotation.set(this.player.pitch, 0, tilt);
      if (this.avatar) this.avatar.visible = false;
    }
    this.vmCam.rotation.z = tilt;
    const wantFov = this.player.sprinting ? 74 : 72;
    this.camera.fov += (wantFov - this.camera.fov) * Math.min(1, dt * 4);
    if (Math.abs(this.camera.fov - wantFov) > 0.02) this.camera.updateProjectionMatrix();
  }

  private updateViewmodel(dt: number, playing: boolean) {
    const id = this.hotbar[this.selected]?.id ?? 0;
    const tool = isTool(id);
    const kind = toolKind(id);
    const blocking = playing && this.player.sneaking && this.offhand?.id === SHIELD;
    const show = playing && !this.sleeping && !this.thirdPerson && (id > 0 || blocking);
    this.hand.visible = show;

    if (this.activeTool) this.activeTool.visible = false;
    this.blockView.visible = false;
    if (this.shieldView) this.shieldView.visible = false;
    if (this.meatView) this.meatView.visible = false;

    if (show && tool && kind && kind !== "shield") {
      let g = this.toolViews.get(id);
      if (!g) {
        g = modelForItem(id) ?? undefined;
        if (g) {
          this.toolViews.set(id, g);
          this.hand.add(g);
        }
      }
      if (g) {
        g.visible = true;
        this.activeTool = g;
      }
    } else if (show && id > 0 && isPlaceable(id)) {
      this.blockView.visible = true;
      let geo = this.viewGeoCache.get(id);
      if (!geo) {
        geo = makeBlockGeometry(id);
        this.viewGeoCache.set(id, geo);
      }
      if (this.blockView.geometry !== geo) this.blockView.geometry = geo;
    } else if (show && id > 0 && !tool && !isPlaceable(id)) {
      if (!this.meatView) {
        this.meatView = new THREE.Mesh(
          new THREE.BoxGeometry(0.22, 0.14, 0.28),
          new THREE.MeshLambertMaterial({ color: itemColor(id) }),
        );
        this.hand.add(this.meatView);
      }
      (this.meatView.material as THREE.MeshLambertMaterial).color.setHex(itemColor(id));
      this.meatView.visible = true;
    }

    if (blocking) {
      if (!this.shieldView) {
        this.shieldView = modelForItem(SHIELD);
        if (this.shieldView) this.vmScene.add(this.shieldView);
      }
      if (this.shieldView) {
        this.shieldView.visible = true;
        this.shieldView.scale.setScalar(0.42);
        this.shieldView.position.set(-0.18, -0.12, -0.42);
        this.shieldView.rotation.set(-0.15, 0.35, 0.08);
      }
    }

    const attacking = playing && this.input.isDown("Mouse0");
    if (attacking) this.swingT += dt * (tool ? 16 : 12);
    else this.swingT *= Math.max(0, 1 - dt * 8);
    const swing = Math.sin(this.swingT) * (attacking ? 1 : 0.2);
    const bob = playing ? this.player.bob * 0.04 : 0;

    if (kind === "sword") {
      this.hand.scale.setScalar(0.26);
      this.hand.position.set(0.3, -0.2 + bob, -0.54);
      this.hand.rotation.set(-0.32 + swing * 1.15, 0.16, 0.26 + swing * 0.5);
    } else if (kind === "axe" || kind === "pick" || kind === "shovel") {
      this.hand.scale.setScalar(0.28);
      this.hand.position.set(0.32, -0.24 + bob, -0.52);
      this.hand.rotation.set(-0.65 + swing * 0.9, 0.38, 0.4 + swing * 0.7);
    } else if (kind === "shield") {
      this.hand.scale.setScalar(0.4);
      this.hand.position.set(0.22, -0.18 + bob, -0.48);
      this.hand.rotation.set(-0.2, 0.4, 0.1);
    } else if (this.blockView.visible) {
      this.hand.scale.setScalar(0.13);
      this.hand.position.set(0.38, -0.28 + bob, -0.66);
      this.hand.rotation.set(0.18 + swing * 0.22, 0.62, 0.12 + swing * 0.22);
    } else if (this.meatView?.visible) {
      this.hand.scale.setScalar(0.9);
      this.hand.position.set(0.32, -0.22 + bob, -0.55);
      this.hand.rotation.set(0.2 + swing * 0.2, 0.4, 0.1);
    }
  }

  private pushHud(force: boolean) {
    const t = this.target ? this.world.getBlock(this.target.x, this.target.y, this.target.z) : AIR;
    const look = this.lookDir();
    const mh = this.mobs.raycast(this.player.x, this.player.eyeY, this.player.z, look.x, look.y, look.z, 4.6);
    const blockDist = this.target
      ? Math.hypot(this.target.x + 0.5 - this.player.x, this.target.y + 0.5 - this.player.eyeY, this.target.z + 0.5 - this.player.z)
      : 99;
    let name = t && t !== AIR ? blockName(t) : null;
    if (mh && mh.dist < blockDist) name = mobName(mh.mob.kind, mh.mob.crown);
    gameStore.getState().patchHud({
      health: this.health,
      food: this.food,
      air: this.air,
      hotbar: this.hotbar.map((s) => (s ? { ...s } : null)),
      selectedSlot: this.selected,
      inventory: this.inventory.map((s) => (s ? { ...s } : null)),
      armor: this.armor.map((s) => (s ? { ...s } : null)),
      offhand: this.offhand ? { ...this.offhand } : null,
      fps: Math.round(this.fps),
      x: this.player.x,
      y: this.player.y,
      z: this.player.z,
      yaw: this.player.yaw,
      targetName: name,
      breaking:
        this.target && this.breakT > 0
          ? Math.min(1, this.breakT / this.mineTime(t, BLOCKS[t]?.hardness || 1, this.hotbar[this.selected]?.id ?? 0))
          : 0,
      held: this.hotbar[this.selected] ? { ...this.hotbar[this.selected]! } : null,
      canResume: true,
      biome: BIOME_NAME[this.world.biomeAt(Math.floor(this.player.x), Math.floor(this.player.z))] ?? "Ova",
      sneaking: this.player.sneaking,
      inWater: this.player.inWater,
      blocking: this.player.sneaking && this.offhand?.id === SHIELD,
      sleeping: this.sleeping,
      sleep: Math.min(1, this.sleepT / 4.2),
      toast: this.toastT > 0 ? this.toast : null,
    });
    void force;
  }

  refreshHud() {
    this.pushHud(true);
  }

  iconsMap() {
    return this.icons;
  }

  setRenderDistance(n: number) {
    gameStore.getState().setSettings({ renderDistance: n });
    this.lastCx = 99999;
    this.lastCz = 99999;
  }

  interactInventory(
    from: "hotbar" | "inv" | "armor" | "offhand",
    fi: number,
    to: "hotbar" | "inv" | "armor" | "offhand",
    ti: number,
  ) {
    const bag = (which: typeof from, i: number): { arr: Array<ItemStack | null>; index: number } => {
      if (which === "hotbar") return { arr: this.hotbar, index: i };
      if (which === "inv") return { arr: this.inventory, index: i };
      if (which === "armor") return { arr: this.armor, index: i };
      return { arr: [this.offhand], index: 0 };
    };
    const a = bag(from, fi);
    const b = bag(to, ti);
    const sa = a.arr[a.index];
    const sb = b.arr[b.index];
    if (sa && sb && sa.id === sb.id && !isTool(sa.id)) {
      const room = 64 - sb.count;
      const take = Math.min(room, sa.count);
      sb.count += take;
      sa.count -= take;
      if (sa.count <= 0) a.arr[a.index] = null;
    } else {
      a.arr[a.index] = sb;
      b.arr[b.index] = sa;
    }
    if (from === "offhand") this.offhand = a.arr[0] ?? null;
    if (to === "offhand") this.offhand = b.arr[0] ?? null;
    this.audio.click();
    this.pushHud(true);
  }

  dumpCraftBack() {
    for (let i = 0; i < this.craftGrid.length; i++) {
      const s = this.craftGrid[i];
      if (!s) continue;
      addItem(this.hotbar, this.inventory, s.id, s.count);
      this.craftGrid[i] = null;
    }
    this.pushHud(true);
  }

  craftRecipe(id: string): boolean {
    const rec = RECIPES.find((r) => r.id === id);
    if (!rec) return false;
    const ok = craftInto(rec, [this.hotbar, this.inventory], this.hotbar);
    if (ok) this.audio.pickup();
    this.pushHud(true);
    return ok;
  }

  takeCraftResult() {
    const rec = matchRecipe(this.craftGrid);
    if (!rec) return;
    consumeGrid(this.craftGrid, rec);
    addItem(this.hotbar, this.inventory, rec.out.id, rec.out.count);
    this.audio.pickup();
    this.pushHud(true);
  }

  matchedCraft(): Recipe | null {
    return matchRecipe(this.craftGrid);
  }

  canMake(id: string): boolean {
    const rec = RECIPES.find((r) => r.id === id);
    if (!rec) return false;
    return canCraft(rec, [this.hotbar, this.inventory]);
  }

  private exposeControls() {
    window.__controlsTest = {
      getYaw: () => this.player.yaw,
      getSpeed: () => Math.hypot(this.player.vx, this.player.vz),
      getPosition: () => ({ x: this.player.x, y: this.player.y, z: this.player.z }),
      setKeys: (codes: string[]) => {
        if (!codes.length) this.input.clearInjected();
        else this.input.setKeys(codes);
      },
      setSteer: (v: number) => {
        if (v > 0.1) this.input.setKeys(["KeyW", "KeyA"]);
        else if (v < -0.1) this.input.setKeys(["KeyW", "KeyD"]);
        else this.input.setKeys(["KeyW"]);
      },
    };
  }

  dispose() {
    this.disposed = true;
    this.stop();
    this.save();
    window.removeEventListener("resize", this.onResize);
    document.removeEventListener("pointerlockchange", this.onLockChange);
    document.removeEventListener("pointerlockerror", this.onLockError);
    this.input.dispose();
    for (const k of [...this.chunkMeshes.keys()]) this.disposeChunkMesh(k);
    this.drops?.dispose();
    this.mobs.dispose();
    this.waterMat?.dispose();
    this.lavaMat?.dispose();
    this.portalMat?.dispose();
    for (const k of [...this.waterMeshes.keys()]) this.disposeChunkMesh(k);
    this.particles?.dispose();
    this.material?.map?.dispose();
    this.material?.dispose();
    for (const m of this.crackMats) {
      m.map?.dispose();
      m.dispose();
    }
    for (const g of this.viewGeoCache.values()) g.dispose();
    this.blockView.geometry.dispose();
    (this.blockView.material as THREE.Material).dispose();
    for (const g of this.toolViews.values()) {
      g.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.isMesh) m.geometry.dispose();
      });
    }
    this.shieldView?.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) m.geometry.dispose();
    });
    this.highlight.geometry.dispose();
    (this.highlight.material as THREE.Material).dispose();
    this.sunMesh.geometry.dispose();
    (this.sunMesh.material as THREE.Material).dispose();
    this.moonMesh.geometry.dispose();
    (this.moonMesh.material as THREE.Material).dispose();
    this.stars.geometry.dispose();
    (this.stars.material as THREE.Material).dispose();
    this.renderer.dispose();
    if (window.__controlsTest) delete window.__controlsTest;
  }
}

function boxesOverlap(
  ax: number,
  ay: number,
  az: number,
  aw: number,
  ah: number,
  ad: number,
  bx: number,
  by: number,
  bz: number,
  bw: number,
  bh: number,
  bd: number,
) {
  return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by && az < bz + bd && az + ad > bz;
}

function makeCrack(p: number): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = 32;
  c.height = 32;
  const ctx = c.getContext("2d")!;
  ctx.clearRect(0, 0, 32, 32);
  ctx.strokeStyle = "rgba(20,16,12,0.92)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  const n = 3 + Math.floor(p * 6);
  for (let i = 0; i < n; i++) {
    ctx.moveTo(16, 16);
    const a = (i / n) * Math.PI * 2 + p;
    ctx.lineTo(16 + Math.cos(a) * (8 + p * 12), 16 + Math.sin(a) * (8 + p * 12));
  }
  ctx.stroke();
  return c;
}

function yieldFrame() {
  return new Promise<void>((r) => requestAnimationFrame(() => r()));
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      getPosition?: () => { x: number; y: number; z: number };
      setKeys?: (codes: string[]) => void;
      setSteer?: (v: number) => void;
    };
    __blokEngine?: GameEngine;
  }
}
