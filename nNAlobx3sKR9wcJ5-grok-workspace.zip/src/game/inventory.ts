import { isTool, maxDurability } from "./items";
import { MAX_STACK, type ItemStack } from "./types";

export function emptyGrid(n: number): Array<ItemStack | null> {
  return Array.from({ length: n }, () => null);
}

export function cloneStack(s: ItemStack | null): ItemStack | null {
  return s ? { id: s.id, count: s.count, dur: s.dur } : null;
}

export function addItem(
  dest: Array<ItemStack | null>,
  extra: Array<ItemStack | null> | null,
  id: number,
  count: number,
): number {
  const bags = extra ? [dest, extra] : [dest];
  let left = count;
  if (!isTool(id)) {
    for (const bag of bags) {
      for (const slot of bag) {
        if (slot && slot.id === id && slot.count < MAX_STACK) {
          const take = Math.min(MAX_STACK - slot.count, left);
          slot.count += take;
          left -= take;
          if (left <= 0) return 0;
        }
      }
    }
  }
  for (const bag of bags) {
    for (let i = 0; i < bag.length; i++) {
      if (!bag[i]) {
        const take = isTool(id) ? 1 : Math.min(MAX_STACK, left);
        const dur = maxDurability(id);
        bag[i] = dur > 0 ? { id, count: take, dur } : { id, count: take };
        left -= take;
        if (left <= 0) return 0;
      }
    }
  }
  return left;
}

export function takeOne(slots: Array<ItemStack | null>, index: number): number | null {
  const s = slots[index];
  if (!s) return null;
  const id = s.id;
  s.count -= 1;
  if (s.count <= 0) slots[index] = null;
  return id;
}

export function mergeOrSwap(
  a: Array<ItemStack | null>,
  ia: number,
  b: Array<ItemStack | null>,
  ib: number,
) {
  const sa = a[ia];
  const sb = b[ib];
  if (!sa && !sb) return;
  if (sa && sb && sa.id === sb.id && !isTool(sa.id)) {
    const take = Math.min(MAX_STACK - sb.count, sa.count);
    sb.count += take;
    sa.count -= take;
    if (sa.count <= 0) a[ia] = null;
    return;
  }
  a[ia] = sb;
  b[ib] = sa;
}

export function starterHotbar(): Array<ItemStack | null> {
  return emptyGrid(10);
}
