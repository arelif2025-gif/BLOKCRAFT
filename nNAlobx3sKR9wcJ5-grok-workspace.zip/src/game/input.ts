const GAME_CODES = new Set([
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
  "Space",
  "ShiftLeft",
  "ShiftRight",
  "KeyE",
  "Escape",
  "Tab",
  "KeyP",
  "Period",
  "NumpadDecimal",
  "Slash",
  "Digit1",
  "Digit2",
  "Digit3",
  "Digit4",
  "Digit5",
  "Digit6",
  "Digit7",
  "Digit8",
  "Digit9",
  "Digit0",
  "ArrowUp",
  "ArrowDown",
  "ArrowLeft",
  "ArrowRight",
]);

export class Input {
  keys = new Set<string>();
  private injected: string[] | null = null;
  private prev = new Set<string>();
  lookDx = 0;
  lookDy = 0;
  wheel = 0;
  touchMoveX = 0;
  touchMoveY = 0;
  private listeners: Array<() => void> = [];

  attach(target: HTMLElement) {
    const sprintKey = (e: KeyboardEvent) => e.key === '"' || e.code === "Backquote";
    const onDown = (e: KeyboardEvent) => {
      if (sprintKey(e)) {
        this.keys.add("SprintKey");
        e.preventDefault();
        if (e.code !== "Backquote") return;
      }
      if (e.repeat) {
        if (GAME_CODES.has(e.code)) e.preventDefault();
        return;
      }
      this.keys.add(e.code);
      if (GAME_CODES.has(e.code)) e.preventDefault();
    };
    const onUp = (e: KeyboardEvent) => {
      this.keys.delete(e.code);
      if (sprintKey(e)) {
        this.keys.delete("SprintKey");
        e.preventDefault();
      }
    };
    const onBlur = () => {
      this.keys.clear();
    };
    const onMouseDown = (e: MouseEvent) => {
      this.keys.add(`Mouse${e.button}`);
    };
    const onMouseUp = (e: MouseEvent) => {
      this.keys.delete(`Mouse${e.button}`);
    };
    const onMove = (e: MouseEvent) => {
      this.lookDx += e.movementX;
      this.lookDy += e.movementY;
    };
    const onWheel = (e: WheelEvent) => {
      this.wheel += Math.sign(e.deltaY);
      e.preventDefault();
    };
    const onContext = (e: Event) => e.preventDefault();
    const onVis = () => {
      if (document.hidden) this.keys.clear();
    };

    window.addEventListener("keydown", onDown);
    window.addEventListener("keyup", onUp);
    window.addEventListener("blur", onBlur);
    document.addEventListener("visibilitychange", onVis);
    target.addEventListener("mousedown", onMouseDown);
    window.addEventListener("mouseup", onMouseUp);
    window.addEventListener("mousemove", onMove);
    target.addEventListener("wheel", onWheel, { passive: false });
    target.addEventListener("contextmenu", onContext);

    this.listeners.push(() => {
      window.removeEventListener("keydown", onDown);
      window.removeEventListener("keyup", onUp);
      window.removeEventListener("blur", onBlur);
      document.removeEventListener("visibilitychange", onVis);
      target.removeEventListener("mousedown", onMouseDown);
      window.removeEventListener("mouseup", onMouseUp);
      window.removeEventListener("mousemove", onMove);
      target.removeEventListener("wheel", onWheel);
      target.removeEventListener("contextmenu", onContext);
    });
  }

  setKeys(codes: string[]) {
    this.injected = codes.slice();
  }

  clearInjected() {
    this.injected = null;
  }

  isDown(code: string): boolean {
    if (this.injected) return this.injected.includes(code);
    return this.keys.has(code);
  }

  justPressed(code: string): boolean {
    return this.isDown(code) && !this.prev.has(code);
  }

  consumeLook(): { dx: number; dy: number } {
    const d = { dx: this.lookDx, dy: this.lookDy };
    this.lookDx = 0;
    this.lookDy = 0;
    return d;
  }

  consumeWheel(): number {
    const w = this.wheel;
    this.wheel = 0;
    return w;
  }

  addLook(dx: number, dy: number) {
    this.lookDx += dx;
    this.lookDy += dy;
  }

  endFrame() {
    this.prev = new Set(this.injected ?? this.keys);
  }

  dispose() {
    for (const off of this.listeners) off();
    this.listeners = [];
    this.keys.clear();
  }
}
