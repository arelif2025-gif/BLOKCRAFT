import * as THREE from "three";

type Particle = {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  max: number;
  scale: number;
};

export class ParticlePool {
  mesh: THREE.InstancedMesh;
  private dummy = new THREE.Object3D();
  private items: Particle[] = [];
  private max: number;

  constructor(material: THREE.Material, max = 80) {
    this.max = max;
    const geo = new THREE.BoxGeometry(0.12, 0.12, 0.12);
    this.mesh = new THREE.InstancedMesh(geo, material, max);
    this.mesh.frustumCulled = false;
    this.mesh.count = 0;
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.mesh.visible = true;
  }

  burst(x: number, y: number, z: number, n = 10) {
    for (let i = 0; i < n; i++) {
      if (this.items.length >= this.max) this.items.shift();
      this.items.push({
        x: x + Math.random() * 0.6 + 0.2,
        y: y + Math.random() * 0.6 + 0.2,
        z: z + Math.random() * 0.6 + 0.2,
        vx: (Math.random() - 0.5) * 4,
        vy: Math.random() * 3 + 1.5,
        vz: (Math.random() - 0.5) * 4,
        life: 0,
        max: 0.45 + Math.random() * 0.35,
        scale: 0.7 + Math.random() * 0.6,
      });
    }
  }

  update(dt: number) {
    const live: Particle[] = [];
    for (const p of this.items) {
      p.life += dt;
      if (p.life >= p.max) continue;
      p.vy -= 18 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      live.push(p);
    }
    this.items = live;
    const n = this.items.length;
    this.mesh.count = n;
    for (let i = 0; i < n; i++) {
      const p = this.items[i]!;
      const t = 1 - p.life / p.max;
      this.dummy.position.set(p.x, p.y, p.z);
      this.dummy.scale.setScalar(p.scale * t);
      this.dummy.rotation.set(p.life * 6, p.life * 4, 0);
      this.dummy.updateMatrix();
      this.mesh.setMatrixAt(i, this.dummy.matrix);
    }
    this.mesh.instanceMatrix.needsUpdate = true;
  }

  dispose() {
    this.mesh.geometry.dispose();
    (this.mesh.material as THREE.Material).dispose();
    this.mesh.removeFromParent();
  }
}
