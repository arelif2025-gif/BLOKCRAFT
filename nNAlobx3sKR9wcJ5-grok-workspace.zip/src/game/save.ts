import { ARMOR_SIZE, COOKED_PORK, CRAFT_SIZE, HOTBAR_SIZE, INV_SIZE, MAX_FOOD, MAX_HEALTH, PLANKS, WOOD_PICK, type FurnaceSave, type GroundDrop, type ItemStack, type Settings } from "./types";
import { emptyGrid, starterHotbar } from "./inventory";

const KEY = "blokcraft-save-v1";
export const SAVE_VERSION = 7;

export type SaveData = {
  version: number;
  seed: number;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  health: number;
  food: number;
  saturation: number;
  worldTime: number;
  hotbar: Array<ItemStack | null>;
  inventory: Array<ItemStack | null>;
  armor: Array<ItemStack | null>;
  offhand: ItemStack | null;
  edits: Array<[number, number, number, number]>;
  netherEdits: Array<[number, number, number, number]>;
  endEdits: Array<[number, number, number, number]>;
  dim: "overworld" | "nether" | "end";
  owX: number;
  owY: number;
  owZ: number;
  ndX: number | null;
  ndY: number | null;
  ndZ: number | null;
  settings: Settings;
  drops: GroundDrop[];
  furnaces: FurnaceSave[];
  homeX: number;
  homeY: number;
  homeZ: number;
  bedX: number | null;
  bedY: number | null;
  bedZ: number | null;
  dragonHp: number;
  crystalMask: number;
  dragonDead: boolean;
  broken: number;
  kills: number;
  sawNether: boolean;
  id: string;
  name: string;
  monsters: boolean;
  bonus: boolean;
};

function defaults(seed: number): SaveData {
  return {
    version: SAVE_VERSION,
    seed,
    x: 0.5,
    y: 40,
    z: 0.5,
    yaw: 0,
    pitch: 0,
    health: MAX_HEALTH,
    food: MAX_FOOD,
    saturation: 5,
    worldTime: 80,
    hotbar: starterHotbar(),
    inventory: emptyGrid(INV_SIZE),
    armor: emptyGrid(ARMOR_SIZE),
    offhand: null,
    edits: [],
    netherEdits: [],
    endEdits: [],
    dim: "overworld",
    owX: 0.5,
    owY: 40,
    owZ: 0.5,
    ndX: null,
    ndY: null,
    ndZ: null,
    settings: { sensitivity: 1.4, renderDistance: 4, volume: 0.7 },
    drops: [],
    furnaces: [],
    homeX: 0.5,
    homeY: 40,
    homeZ: 0.5,
    bedX: null,
    bedY: null,
    bedZ: null,
    dragonHp: 200,
    crystalMask: 255,
    dragonDead: false,
    broken: 0,
    kills: 0,
    sawNether: false,
    id: "",
    name: "Dünya",
    monsters: true,
    bonus: false,
  };
}

export type Look = { skin: number; shirt: number; pants: number };
export const SKINS = [0xc48a62, 0xe0ac69, 0x8d5524, 0x3b2414, 0xf3d2b5];
export const SHIRTS = [0x3b6ea5, 0x2f6b3a, 0x8a3030, 0xc4a35a, 0x5a3d73, 0x3a3a3a];
export const PANTS = [0x2d3344, 0x1e3a2f, 0x4a3728, 0x243044, 0x3d2a3a];

export type WorldOptions = {
  name: string;
  seed: number;
  start: "dawn" | "day" | "night";
  bonus: boolean;
  monsters: boolean;
};

export type WorldCard = {
  id: string;
  name: string;
  seed: number;
  created: number;
  updated: number;
  worldTime: number;
};

const LOOK_KEY = "blokcraft-look";
const INDEX_KEY = "blokcraft-worlds";

function worldKey(id: string) {
  return `blokcraft-world-${id}`;
}

export function loadLook(): Look {
  try {
    const raw = localStorage.getItem(LOOK_KEY);
    const parsed = raw ? (JSON.parse(raw) as Look) : null;
    return {
      skin: clampIndex(parsed?.skin, SKINS.length, 0),
      shirt: clampIndex(parsed?.shirt, SHIRTS.length, 0),
      pants: clampIndex(parsed?.pants, PANTS.length, 0),
    };
  } catch {
    return { skin: 0, shirt: 0, pants: 0 };
  }
}

export function saveLook(look: Look) {
  try {
    localStorage.setItem(LOOK_KEY, JSON.stringify(look));
  } catch {
    /* ignore */
  }
}

function clampIndex(n: unknown, len: number, fallback: number) {
  return typeof n === "number" && n >= 0 && n < len ? Math.floor(n) : fallback;
}

export function parseSeed(text: string): number {
  const t = text.trim();
  if (!t) return Math.floor(Math.random() * 1e9) + 1;
  if (/^\d+$/.test(t)) {
    const n = Number(t);
    return n > 0 ? Math.floor(n) % 2147483646 || 1 : 1;
  }
  let h = 2166136261;
  for (let i = 0; i < t.length; i++) h = Math.imul(h ^ t.charCodeAt(i), 16777619);
  return (h >>> 0) % 2147483646 + 1;
}

function readIndex(): WorldCard[] {
  try {
    const raw = localStorage.getItem(INDEX_KEY);
    const parsed = raw ? (JSON.parse(raw) as WorldCard[]) : [];
    return Array.isArray(parsed) ? parsed.filter((c) => c && typeof c.id === "string") : [];
  } catch {
    return [];
  }
}

function writeIndex(cards: WorldCard[]) {
  localStorage.setItem(INDEX_KEY, JSON.stringify(cards));
}

function cardOf(data: SaveData, prev?: WorldCard): WorldCard {
  return {
    id: data.id,
    name: data.name || "Dünya",
    seed: data.seed,
    created: prev?.created ?? Date.now(),
    updated: Date.now(),
    worldTime: data.worldTime,
  };
}

export function listWorlds(): WorldCard[] {
  migrateLegacy();
  return readIndex().sort((a, b) => b.updated - a.updated);
}

export function loadWorld(id: string): SaveData | null {
  migrateLegacy();
  try {
    const raw = localStorage.getItem(worldKey(id));
    if (!raw) return null;
    const parsed = JSON.parse(raw) as SaveData;
    const data = normalize(parsed);
    data.id = id;
    return data;
  } catch {
    return null;
  }
}

export function createWorld(opts: WorldOptions): string {
  const id = Math.random().toString(36).slice(2, 10);
  const data = defaults(opts.seed);
  data.id = id;
  data.name = opts.name.trim().slice(0, 32) || "Yeni dünya";
  data.worldTime = opts.start === "night" ? 315 : opts.start === "dawn" ? 12 : 80;
  data.monsters = opts.monsters;
  data.bonus = opts.bonus;
  if (opts.bonus) {
    data.hotbar[0] = { id: WOOD_PICK, count: 1, dur: 59 };
    data.hotbar[1] = { id: PLANKS, count: 32 };
    data.hotbar[2] = { id: COOKED_PORK, count: 8 };
  }
  const cards = readIndex().filter((c) => c.id !== id);
  cards.unshift(cardOf(data));
  localStorage.setItem(worldKey(id), JSON.stringify(data));
  writeIndex(cards);
  return id;
}

export function deleteWorld(id: string) {
  const cards = readIndex().filter((c) => c.id !== id);
  writeIndex(cards);
  localStorage.removeItem(worldKey(id));
  if (id === "legacy") localStorage.removeItem(KEY);
}

function migrateLegacy() {
  if (readIndex().length) return;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return;
    const data = normalize(JSON.parse(raw) as SaveData);
    data.id = "legacy";
    data.name = data.name && data.name !== "Dünya" ? data.name : "İlk dünya";
    localStorage.setItem(worldKey(data.id), JSON.stringify(data));
    writeIndex([cardOf(data)]);
  } catch {
    /* ignore broken legacy save */
  }
}

export function newSave(seed?: number): SaveData {
  return defaults(seed ?? (Math.floor(Math.random() * 1e9) + 1));
}

function normalize(parsed: SaveData): SaveData {
  const base = defaults(typeof parsed?.seed === "number" ? parsed.seed : 1);
  const merged: SaveData = { ...base, ...parsed, version: SAVE_VERSION };
  if (!Array.isArray(merged.hotbar) || merged.hotbar.length !== HOTBAR_SIZE) merged.hotbar = starterHotbar();
  if (!Array.isArray(merged.inventory) || merged.inventory.length !== INV_SIZE) merged.inventory = emptyGrid(INV_SIZE);
  if (!Array.isArray(merged.armor) || merged.armor.length !== ARMOR_SIZE) merged.armor = emptyGrid(ARMOR_SIZE);
  if (!Array.isArray(merged.edits)) merged.edits = [];
  if (!Array.isArray(merged.netherEdits)) merged.netherEdits = [];
  if (!Array.isArray(merged.endEdits)) merged.endEdits = [];
  if (merged.dim !== "nether" && merged.dim !== "end") merged.dim = "overworld";
  if (typeof merged.owX !== "number") merged.owX = merged.x;
  if (typeof merged.owY !== "number") merged.owY = merged.y;
  if (typeof merged.owZ !== "number") merged.owZ = merged.z;
  if (!Array.isArray(merged.drops)) merged.drops = [];
  if (!Array.isArray(merged.furnaces)) merged.furnaces = [];
  if (typeof merged.homeX !== "number") merged.homeX = merged.x;
  if (typeof merged.homeY !== "number") merged.homeY = merged.y;
  if (typeof merged.homeZ !== "number") merged.homeZ = merged.z;
  if (typeof merged.bedX !== "number") merged.bedX = null;
  if (typeof merged.bedY !== "number") merged.bedY = null;
  if (typeof merged.bedZ !== "number") merged.bedZ = null;
  if (typeof merged.dragonHp !== "number") merged.dragonHp = 200;
  if (typeof merged.crystalMask !== "number") merged.crystalMask = 255;
  if (typeof merged.dragonDead !== "boolean") merged.dragonDead = false;
  if (typeof merged.broken !== "number") merged.broken = 0;
  if (typeof merged.kills !== "number") merged.kills = 0;
  if (typeof merged.sawNether !== "boolean") merged.sawNether = false;
  if (typeof merged.id !== "string") merged.id = "";
  if (typeof merged.name !== "string" || !merged.name.trim()) merged.name = "Dünya";
  if (typeof merged.monsters !== "boolean") merged.monsters = true;
  if (typeof merged.bonus !== "boolean") merged.bonus = false;
  if (typeof merged.saturation !== "number") merged.saturation = 5;
  if ((parsed?.version ?? 0) < 3) {
    merged.hotbar = starterHotbar();
    merged.inventory = emptyGrid(INV_SIZE);
    merged.offhand = null;
  }
  void CRAFT_SIZE;
  return merged;
}

export function loadSave(): SaveData | null {
  const worlds = listWorlds();
  const first = worlds[0];
  return first ? loadWorld(first.id) : null;
}

export function writeSave(data: SaveData) {
  try {
    const id = data.id || "legacy";
    data.id = id;
    localStorage.setItem(worldKey(id), JSON.stringify({ ...data, version: SAVE_VERSION }));
    const cards = readIndex();
    const prev = cards.find((c) => c.id === id);
    const next = cards.filter((c) => c.id !== id);
    next.unshift(cardOf({ ...data, id }, prev));
    writeIndex(next);
    if (id === "legacy") localStorage.setItem(KEY, JSON.stringify({ ...data, version: SAVE_VERSION }));
  } catch {
    /* quota / private mode */
  }
}

export function hasSave(): boolean {
  try {
    return Boolean(localStorage.getItem(KEY));
  } catch {
    return false;
  }
}

export function clearSave() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}
