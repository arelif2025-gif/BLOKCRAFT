import * as THREE from "three";
import { toolKind, toolTier, type ToolKind, type ToolTier } from "./items";
import { AMETHYST, BEEF, BLAZE_POWDER, BLAZE_ROD, BOAT, BUCKET, CHICKEN_MEAT, COOKED_BEEF, COOKED_CHICKEN, COOKED_MUTTON, COOKED_PORK, ENDER_PEARL, EYE_OF_ENDER, FLINT, FLINT_STEEL, GOLD_INGOT, IRON_INGOT, LAVA_BUCKET, MUTTON, PORK, RAW_GOLD, RAW_IRON, SHIELD, STICK, WATER_BUCKET } from "./types";

export { isTool, isPlaceable, itemName, mineDuration } from "./items";
export { AXE, SWORD } from "./types";

const mats = new Map<number, THREE.MeshLambertMaterial>();

function mat(color: number, emissive = 0): THREE.MeshLambertMaterial {
  const key = color * 10 + (emissive ? 1 : 0);
  let m = mats.get(key);
  if (!m) {
    m = new THREE.MeshLambertMaterial({
      color,
      emissive: emissive ? color : 0x000000,
      emissiveIntensity: emissive ? 0.32 : 0,
    });
    mats.set(key, m);
  }
  return m;
}

function voxel(parent: THREE.Object3D, x: number, y: number, z: number, sx: number, sy: number, sz: number, color: number, glow = false) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), mat(color, glow ? 1 : 0));
  mesh.position.set(x, y, z);
  mesh.frustumCulled = false;
  parent.add(mesh);
}

const TIER_HEAD: Record<ToolTier, { head: number; edge: number; glow: boolean }> = {
  wood: { head: 0x8a5a2b, edge: 0xc4a36a, glow: false },
  stone: { head: 0x8a93a0, edge: 0xc5cdd6, glow: false },
  iron: { head: 0xc4c8ce, edge: 0xe8ecf0, glow: false },
  gold: { head: 0xd4b15a, edge: 0xffe08a, glow: false },
  amethyst: { head: 0xb46cff, edge: 0xe0b8ff, glow: true },
  diamond: { head: 0x5ee0c8, edge: 0xc6fff8, glow: true },
};

export function buildToolModel(kind: ToolKind, tier: ToolTier): THREE.Group {
  const g = new THREE.Group();
  const wood = 0x6b4423;
  const wrap = 0x5c3a1e;
  const t = TIER_HEAD[tier];
  if (kind === "axe") {
    voxel(g, 0, 0, 0, 0.065, 0.78, 0.065, wood);
    voxel(g, 0, -0.12, 0, 0.08, 0.16, 0.08, wrap);
    voxel(g, 0, 0.34, 0, 0.1, 0.09, 0.1, t.head, t.glow);
    voxel(g, 0.16, 0.36, 0, 0.28, 0.16, 0.05, t.head, t.glow);
    voxel(g, 0.3, 0.36, 0, 0.07, 0.22, 0.04, t.edge, t.glow);
  } else if (kind === "pick") {
    voxel(g, 0, 0, 0, 0.06, 0.78, 0.06, wood);
    voxel(g, 0, 0.34, 0, 0.1, 0.08, 0.1, t.head, t.glow);
    voxel(g, 0, 0.4, 0, 0.42, 0.08, 0.08, t.head, t.glow);
    voxel(g, 0.22, 0.36, 0, 0.08, 0.16, 0.08, t.edge, t.glow);
    voxel(g, -0.22, 0.36, 0, 0.08, 0.16, 0.08, t.edge, t.glow);
  } else if (kind === "shovel") {
    voxel(g, 0, 0, 0, 0.055, 0.72, 0.055, wood);
    voxel(g, 0, 0.34, 0, 0.16, 0.22, 0.04, t.head, t.glow);
    voxel(g, 0, 0.46, 0, 0.12, 0.08, 0.03, t.edge, t.glow);
  } else if (kind === "sword") {
    voxel(g, 0, 0.28, 0, 0.05, 0.62, 0.04, t.head, t.glow);
    voxel(g, 0, 0.28, 0, 0.018, 0.56, 0.018, t.edge, t.glow);
    voxel(g, 0, 0.02, 0, 0.22, 0.045, 0.045, 0xd4b15a);
    voxel(g, 0, -0.2, 0, 0.05, 0.32, 0.05, wrap);
    voxel(g, 0, -0.38, 0, 0.08, 0.07, 0.08, 0xd4b15a);
  } else {
    voxel(g, 0, 0.08, 0, 0.42, 0.52, 0.06, 0x7a4e28);
    voxel(g, 0, 0.08, 0.02, 0.34, 0.42, 0.04, 0xc4a36a);
    voxel(g, 0, 0.08, 0.03, 0.12, 0.12, 0.03, t.head, t.glow);
  }
  g.traverse((o) => {
    o.frustumCulled = false;
  });
  return g;
}

export function modelForItem(id: number): THREE.Group | null {
  if (id === SHIELD) return buildToolModel("shield", "wood");
  const k = toolKind(id);
  const t = toolTier(id);
  if (!k || !t || k === "shield") return null;
  return buildToolModel(k, t);
}

function iconCanvas(draw: (ctx: CanvasRenderingContext2D) => void): string {
  const c = document.createElement("canvas");
  c.width = 64;
  c.height = 64;
  const ctx = c.getContext("2d")!;
  ctx.imageSmoothingEnabled = false;
  draw(ctx);
  return c.toDataURL("image/png");
}

function px(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, color: string) {
  ctx.fillStyle = color;
  ctx.fillRect(x, y, w, h);
}

const TIER_HEX: Record<ToolTier, { a: string; b: string }> = {
  wood: { a: "#8a5a2b", b: "#c4a36a" },
  stone: { a: "#8a93a0", b: "#c5cdd6" },
  iron: { a: "#c4c8ce", b: "#e8ecf0" },
  gold: { a: "#d4b15a", b: "#ffe08a" },
  amethyst: { a: "#b46cff", b: "#e0b8ff" },
  diamond: { a: "#5ee0c8", b: "#c6fff8" },
};

function dot(ctx: CanvasRenderingContext2D, x: number, y: number, color: string) {
  px(ctx, x * 4, y * 4, 4, 4, color);
}

export function drawToolIcon(id: number): string {
  const kind = toolKind(id);
  const tier = toolTier(id) ?? "wood";
  const col = TIER_HEX[tier];
  return iconCanvas((ctx) => {
    const wood = "#6b4423";
    const dark = "#3d2814";
    const a = col.a;
    const b = col.b;
    if (kind === "pick") {
      for (let y = 6; y <= 14; y++) dot(ctx, 7, y, y > 12 ? dark : wood);
      for (let x = 2; x <= 12; x++) dot(ctx, x, 3, a);
      dot(ctx, 2, 4, b);
      dot(ctx, 3, 4, b);
      dot(ctx, 2, 5, b);
      dot(ctx, 11, 4, b);
      dot(ctx, 12, 4, b);
      dot(ctx, 12, 5, b);
      dot(ctx, 6, 3, b);
      dot(ctx, 8, 3, b);
    } else if (kind === "axe") {
      for (let y = 5; y <= 14; y++) dot(ctx, 6, y, y > 12 ? dark : wood);
      for (let y = 2; y <= 7; y++) dot(ctx, 8, y, a);
      for (let y = 3; y <= 6; y++) dot(ctx, 9, y, a);
      for (let y = 3; y <= 6; y++) dot(ctx, 10, y, b);
      dot(ctx, 11, 4, b);
      dot(ctx, 11, 5, b);
      dot(ctx, 7, 2, a);
      dot(ctx, 7, 7, a);
    } else if (kind === "shovel") {
      for (let y = 7; y <= 14; y++) dot(ctx, 7, y, y > 12 ? dark : wood);
      for (let y = 2; y <= 6; y++) for (let x = 5; x <= 9; x++) dot(ctx, x, y, y === 2 || y === 6 ? b : a);
      dot(ctx, 6, 1, b);
      dot(ctx, 7, 1, b);
      dot(ctx, 8, 1, b);
    } else if (kind === "sword") {
      for (let y = 1; y <= 9; y++) dot(ctx, 7, y, a);
      for (let y = 2; y <= 8; y++) dot(ctx, 8, y, b);
      dot(ctx, 7, 0, b);
      for (let x = 4; x <= 11; x++) dot(ctx, x, 10, "#d4b15a");
      for (let y = 11; y <= 14; y++) dot(ctx, 7, y, dark);
      dot(ctx, 7, 15, "#d4b15a");
    } else {
      for (let y = 2; y <= 13; y++) for (let x = 3; x <= 12; x++) dot(ctx, x, y, "#7a4e28");
      for (let y = 3; y <= 12; y++) for (let x = 4; x <= 11; x++) dot(ctx, x, y, "#c4a36a");
      for (let y = 6; y <= 9; y++) for (let x = 6; x <= 9; x++) dot(ctx, x, y, a);
      dot(ctx, 7, 7, b);
      dot(ctx, 8, 8, b);
    }
  });
}

export function drawStickIcon(): string {
  return iconCanvas((ctx) => {
    for (let y = 2; y <= 13; y++) dot(ctx, 8, y, y < 4 ? "#c4a36a" : "#8a5a2b");
    dot(ctx, 7, 12, "#5c3a1e");
    dot(ctx, 7, 13, "#5c3a1e");
  });
}

export function drawMeatIcon(id: number): string {
  const cooked = id >= 53 && id <= 56;
  const chicken = id === 43 || id === 56;
  const meat = cooked ? (chicken ? "#e0b070" : "#8a3c28") : chicken ? "#f0d0b0" : "#d06050";
  const fat = cooked ? "#c47848" : "#f0b0a0";
  return iconCanvas((ctx) => {
    if (chicken) {
      for (let y = 3; y <= 12; y++) dot(ctx, 6 + Math.floor((y - 3) / 5), y, "#f4f0e4");
      for (let y = 3; y <= 7; y++) for (let x = 8; x <= 12; x++) dot(ctx, x, y, meat);
      dot(ctx, 9, 4, fat);
      dot(ctx, 11, 5, fat);
      return;
    }
    for (let y = 4; y <= 11; y++) {
      for (let x = 3; x <= 12; x++) {
        if (x + y < 9 || x + (12 - y) < 6) continue;
        dot(ctx, x, y, meat);
      }
    }
    dot(ctx, 5, 6, fat);
    dot(ctx, 6, 7, fat);
    dot(ctx, 8, 5, fat);
    for (let x = 2; x <= 5; x++) dot(ctx, x, 12, "#f4f0e6");
    dot(ctx, 2, 11, "#f4f0e6");
    dot(ctx, 5, 11, "#f4f0e6");
  });
}

export function drawItemIcon(id: number): string {
  return iconCanvas((ctx) => {
    const fillBar = (top: string, mid: string, bot: string) => {
      for (let x = 3; x <= 12; x++) dot(ctx, x, 6, top);
      for (let y = 7; y <= 9; y++) for (let x = 2; x <= 13; x++) dot(ctx, x, y, mid);
      for (let x = 3; x <= 12; x++) dot(ctx, x, 10, bot);
    };
    if (id === IRON_INGOT) fillBar("#e8ecf0", "#c4c8ce", "#8a9098");
    else if (id === GOLD_INGOT) fillBar("#ffe08a", "#d4b15a", "#8a6a28");
    else if (id === RAW_IRON || id === RAW_GOLD) {
      const c = id === RAW_GOLD ? "#c4a050" : "#b8a090";
      const h = id === RAW_GOLD ? "#ffe08a" : "#e4dcd4";
      for (const [x, y] of [
        [5, 5], [6, 4], [7, 4], [8, 5], [9, 6], [8, 7], [7, 8], [6, 8], [5, 7], [4, 6], [6, 6], [7, 6], [8, 6], [6, 5], [7, 7],
      ] as const) dot(ctx, x, y, c);
      dot(ctx, 6, 5, h);
      dot(ctx, 8, 7, h);
    } else if (id === AMETHYST) {
      dot(ctx, 7, 2, "#e0b8ff");
      dot(ctx, 6, 3, "#e0b8ff");
      dot(ctx, 7, 3, "#f4e4ff");
      dot(ctx, 8, 3, "#b46cff");
      for (let x = 5; x <= 9; x++) dot(ctx, x, 4, "#b46cff");
      for (let x = 4; x <= 10; x++) dot(ctx, x, 5, "#9a4ae0");
      for (let x = 5; x <= 9; x++) dot(ctx, x, 6, "#6a2aa0");
      dot(ctx, 6, 7, "#6a2aa0");
      dot(ctx, 7, 7, "#6a2aa0");
      dot(ctx, 8, 7, "#6a2aa0");
    } else if (id === BUCKET || id === WATER_BUCKET || id === LAVA_BUCKET) {
      const liq = id === WATER_BUCKET ? "#2a6ec8" : id === LAVA_BUCKET ? "#e07020" : "";
      for (let y = 4; y <= 11; y++) {
        dot(ctx, 4, y, "#8a9098");
        dot(ctx, 11, y, "#8a9098");
      }
      for (let x = 4; x <= 11; x++) dot(ctx, x, 11, "#6e767e");
      for (let x = 5; x <= 10; x++) dot(ctx, x, 3, "#d0d4da");
      dot(ctx, 7, 2, "#d0d4da");
      dot(ctx, 8, 2, "#d0d4da");
      if (liq) for (let y = 7; y <= 10; y++) for (let x = 5; x <= 10; x++) dot(ctx, x, y, liq);
    } else if (id === FLINT) {
      dot(ctx, 8, 3, "#5a5a5a");
      dot(ctx, 7, 4, "#3a3a3a");
      dot(ctx, 8, 4, "#5a5a5a");
      dot(ctx, 6, 5, "#2a2a2a");
      dot(ctx, 7, 5, "#3a3a3a");
      dot(ctx, 8, 5, "#3a3a3a");
      dot(ctx, 9, 5, "#1a1a1a");
      dot(ctx, 7, 6, "#2a2a2a");
      dot(ctx, 8, 6, "#1a1a1a");
      dot(ctx, 6, 7, "#1a1a1a");
    } else if (id === FLINT_STEEL) {
      for (let x = 3; x <= 11; x++) dot(ctx, x, 8, "#d0d4da");
      for (let y = 4; y <= 8; y++) dot(ctx, 11, y, "#9aa0a8");
      dot(ctx, 4, 6, "#3a3a3a");
      dot(ctx, 5, 5, "#5a5a5a");
      dot(ctx, 5, 6, "#2a2a2a");
      dot(ctx, 6, 7, "#1a1a1a");
    } else if (id === BLAZE_ROD) {
      for (let y = 2; y <= 13; y++) dot(ctx, 7, y, y % 2 ? "#f0c040" : "#e09020");
      dot(ctx, 6, 5, "#ffe080");
      dot(ctx, 8, 8, "#ffe080");
      dot(ctx, 6, 11, "#ffd060");
    } else if (id === BLAZE_POWDER) {
      dot(ctx, 6, 6, "#f0c040");
      dot(ctx, 8, 5, "#ffe080");
      dot(ctx, 9, 7, "#e09020");
      dot(ctx, 7, 8, "#fff0a0");
      dot(ctx, 5, 8, "#e0a030");
      dot(ctx, 8, 9, "#f0c040");
    } else if (id === ENDER_PEARL) {
      for (let y = 4; y <= 11; y++) for (let x = 4; x <= 11; x++) {
        const dx = x - 7.5;
        const dy = y - 7.5;
        if (dx * dx + dy * dy <= 14) dot(ctx, x, y, "#14685a");
      }
      dot(ctx, 6, 6, "#8ef0d8");
      dot(ctx, 7, 6, "#c8fff0");
    } else if (id === EYE_OF_ENDER) {
      for (let y = 4; y <= 11; y++) for (let x = 4; x <= 11; x++) {
        const dx = x - 7.5;
        const dy = y - 7.5;
        if (dx * dx + dy * dy <= 14) dot(ctx, x, y, "#14705c");
      }
      for (let y = 6; y <= 9; y++) for (let x = 6; x <= 9; x++) dot(ctx, x, y, "#e8e090");
      dot(ctx, 7, 7, "#2a9a48");
      dot(ctx, 8, 7, "#2a9a48");
      dot(ctx, 7, 8, "#061208");
    } else if (id === BOAT) {
      for (let x = 3; x <= 12; x++) dot(ctx, x, 8, "#6b4120");
      for (let x = 4; x <= 11; x++) dot(ctx, x, 7, "#8a5a2a");
      for (let x = 5; x <= 10; x++) dot(ctx, x, 6, "#a06a32");
      dot(ctx, 12, 7, "#8a5a2a");
      dot(ctx, 13, 8, "#6b4120");
    } else if (id === STICK) {
      for (let y = 2; y <= 13; y++) dot(ctx, 8, y, y < 4 ? "#c4a36a" : "#8a5a2b");
    } else {
      for (let y = 5; y <= 10; y++) for (let x = 5; x <= 10; x++) dot(ctx, x, y, "#9aa08a");
    }
  });
}

export function drawAxeIcon(): string {
  return drawToolIcon(21);
}

export function drawSwordIcon(): string {
  return drawToolIcon(36);
}
