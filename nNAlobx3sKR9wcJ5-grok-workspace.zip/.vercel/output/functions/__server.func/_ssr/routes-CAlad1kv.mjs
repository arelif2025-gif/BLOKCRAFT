import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Play, c as Hammer, d as Backpack, f as ArrowLeft, i as Square, l as Flame, o as Pickaxe, r as Trash2, s as Pause, t as User, u as Dices } from "../_libs/lucide-react.mjs";
import { A as PerspectiveCamera, C as MathUtils, D as NearestFilter, E as MeshLambertMaterial, F as SphereGeometry, I as Vector3, M as PointsMaterial, N as SRGBColorSpace, O as Object3D, P as Scene, S as LineSegments, T as MeshBasicMaterial, _ as Fog, a as Box3, b as InstancedMesh, c as BufferGeometry, d as Color, f as CylinderGeometry, g as Float32BufferAttribute, h as EdgesGeometry, i as AmbientLight, j as Points, k as OctahedronGeometry, l as CanvasTexture, m as DynamicDrawUsage, n as mergeGeometries, o as BoxGeometry, p as DirectionalLight, r as WebGLRenderer, s as BufferAttribute, t as GLTFLoader, u as ClampToEdgeWrapping, v as Group, w as Mesh, x as LineBasicMaterial, y as HemisphereLight } from "../_libs/three.mjs";
import { n as createNoise3D, t as createNoise2D } from "../_libs/simplex-noise.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CAlad1kv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TOOLS = /* @__PURE__ */ new Set([
	21,
	22,
	23,
	24,
	25,
	26,
	27,
	28,
	70,
	71,
	72,
	73,
	29,
	30,
	31,
	32,
	74,
	75,
	76,
	77,
	33,
	34,
	35,
	36,
	37,
	61
]);
var PLACEABLE = /* @__PURE__ */ new Set([
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8,
	10,
	11,
	13,
	14,
	15,
	16,
	17,
	19,
	44,
	45,
	46
]);
var NAMES = {
	[20]: "Çubuk",
	[21]: "Tahta Balta",
	[22]: "Tahta Kazma",
	[23]: "Tahta Kürek",
	[24]: "Tahta Kılıç",
	[25]: "Taş Balta",
	[26]: "Taş Kazma",
	[27]: "Taş Kürek",
	[28]: "Taş Kılıç",
	[70]: "Demir Balta",
	[71]: "Demir Kazma",
	[72]: "Demir Kürek",
	[73]: "Demir Kılıç",
	[29]: "Altın Balta",
	[30]: "Altın Kazma",
	[31]: "Altın Kürek",
	[32]: "Altın Kılıç",
	[74]: "Ametist Balta",
	[75]: "Ametist Kazma",
	[76]: "Ametist Kürek",
	[77]: "Ametist Kılıç",
	[33]: "Elmas Balta",
	[34]: "Elmas Kazma",
	[35]: "Elmas Kürek",
	[36]: "Elmas Kılıç",
	[37]: "Kalkan",
	[40]: "Domuz Eti",
	[41]: "Sığır Eti",
	[42]: "Koyun Eti",
	[43]: "Tavuk Eti",
	[53]: "Pişmiş Domuz",
	[54]: "Biftek",
	[55]: "Pişmiş Koyun",
	[56]: "Pişmiş Tavuk",
	[48]: "Ham Demir",
	[49]: "Ham Altın",
	[50]: "Demir Külçesi",
	[51]: "Altın Külçesi",
	[52]: "Ametist",
	[57]: "Kova",
	[58]: "Su Kovası",
	[59]: "Lav Kovası",
	[60]: "Çakmak Taşı",
	[61]: "Çakmak",
	[80]: "Blaze Çubuğu",
	[81]: "Blaze Tozu",
	[82]: "Ender Gözü",
	[83]: "End Gözü",
	[84]: "Tekne"
};
function isTool(id) {
	return TOOLS.has(id);
}
function isPlaceable(id) {
	return PLACEABLE.has(id);
}
function itemName(id) {
	return NAMES[id] ?? "";
}
function toolKind(id) {
	if (id === 37) return "shield";
	if (id === 21 || id === 25 || id === 70 || id === 29 || id === 74 || id === 33) return "axe";
	if (id === 22 || id === 26 || id === 71 || id === 30 || id === 75 || id === 34) return "pick";
	if (id === 23 || id === 27 || id === 72 || id === 31 || id === 76 || id === 35) return "shovel";
	if (id === 24 || id === 28 || id === 73 || id === 32 || id === 77 || id === 36) return "sword";
	return null;
}
function toolTier(id) {
	if (id === 37) return "wood";
	if (id >= 21 && id <= 24) return "wood";
	if (id >= 25 && id <= 28) return "stone";
	if (id >= 29 && id <= 32) return "gold";
	if (id >= 33 && id <= 36) return "diamond";
	if (id >= 70 && id <= 73) return "iron";
	if (id >= 74 && id <= 77) return "amethyst";
	return null;
}
var TIER_MUL = {
	wood: .72,
	stone: .48,
	iron: .36,
	gold: .28,
	amethyst: .26,
	diamond: .2
};
var TIER_RANK = {
	wood: 0,
	stone: 1,
	iron: 2,
	gold: 2,
	amethyst: 3,
	diamond: 4
};
function mineDuration(blockId, hardness, held) {
	if (blockId === 19) {
		const kind = toolKind(held);
		const tier = toolTier(held);
		if (kind === "pick" && tier === "diamond") return 9.4;
		return 250;
	}
	const kind = toolKind(held);
	const tier = toolTier(held);
	let mul = 1;
	if (kind && tier) {
		mul = TIER_MUL[tier];
		const woodish = blockId === 4 || blockId === 5 || blockId === 13 || blockId === 14;
		const stoneish = blockId === 3 || blockId === 6 || blockId === 7 || blockId === 8 || blockId === 15 || blockId === 16 || blockId === 44 || blockId === 19;
		const dirtish = blockId === 2 || blockId === 1 || blockId === 10 || blockId === 11 || blockId === 17;
		if (kind === "axe" && woodish) mul *= .45;
		else if (kind === "pick" && stoneish) mul *= .4;
		else if (kind === "shovel" && dirtish) mul *= .4;
		else if (kind === "sword") mul *= .85;
		else if (kind === "shield") mul = 1;
		else mul *= 1.05;
	}
	if (!canHarvest(blockId, held) && isMine(blockId)) mul *= 2.4;
	return Math.max(.08, hardness * mul);
}
function isMine(id) {
	return id === 3 || id === 6 || id === 7 || id === 8 || id === 15 || id === 16 || id === 19 || id === 44;
}
function canHarvest(blockId, held) {
	const kind = toolKind(held);
	const tier = toolTier(held);
	if (blockId === 3 || blockId === 6 || blockId === 44) return kind === "pick";
	if (blockId === 15) return kind === "pick" && tier !== "wood" && tier !== null;
	if (blockId === 7 || blockId === 16 || blockId === 8) return kind === "pick" && !!tier && TIER_RANK[tier] >= 2;
	if (blockId === 19) return kind === "pick" && tier === "diamond";
	return true;
}
function canFinishMine(blockId, held) {
	if (blockId === 7 || blockId === 8 || blockId === 16 || blockId === 19 || blockId === 15) return canHarvest(blockId, held);
	return true;
}
function itemColor(id) {
	const t = toolTier(id);
	if (t === "diamond") return 6217928;
	if (t === "amethyst") return 11824383;
	if (t === "gold") return 13939034;
	if (t === "iron") return 12896462;
	if (t === "stone") return 9081760;
	if (t === "wood") return 9067051;
	if (id === 20) return 7029795;
	if (id === 37) return 8015400;
	if (id === 40 || id === 53) return 14711418;
	if (id === 41 || id === 54) return 10697778;
	if (id === 42 || id === 55) return 12868178;
	if (id === 43 || id === 56) return 15254688;
	if (id === 50 || id === 48) return 12107204;
	if (id === 51 || id === 49) return 14729306;
	if (id === 52) return 11824383;
	if (id === 57 || id === 58 || id === 59) return 9080984;
	if (id === 60 || id === 61) return 3815994;
	if (id === 80 || id === 81) return 15777856;
	if (id === 82) return 1731162;
	if (id === 83) return 4835448;
	if (id === 84) return 9067050;
	return 10133642;
}
function isFood(id) {
	return id === 40 || id === 41 || id === 42 || id === 43 || id === 53 || id === 54 || id === 55 || id === 56;
}
function foodStats(id) {
	if (id === 40) return {
		hunger: 3,
		saturation: 1.8
	};
	if (id === 41) return {
		hunger: 3,
		saturation: 1.8
	};
	if (id === 42) return {
		hunger: 2,
		saturation: 1.2
	};
	if (id === 43) return {
		hunger: 2,
		saturation: 1.2
	};
	if (id === 53) return {
		hunger: 8,
		saturation: 12.8
	};
	if (id === 54) return {
		hunger: 8,
		saturation: 12.8
	};
	if (id === 55) return {
		hunger: 6,
		saturation: 9.6
	};
	if (id === 56) return {
		hunger: 6,
		saturation: 7.2
	};
	return null;
}
function attackDamage(held) {
	const kind = toolKind(held);
	const tier = toolTier(held);
	if (kind === "sword") {
		if (tier === "diamond") return 7;
		if (tier === "amethyst") return 6;
		if (tier === "iron") return 6;
		if (tier === "stone") return 5;
		if (tier === "gold") return 4;
		if (tier === "wood") return 4;
	}
	if (kind === "axe") {
		if (tier === "diamond") return 5;
		if (tier === "amethyst") return 5;
		if (tier === "iron") return 5;
		if (tier === "stone") return 4;
		if (tier === "gold") return 3;
		if (tier === "wood") return 3;
	}
	if (kind === "pick" || kind === "shovel") return 2;
	return 2;
}
function maxDurability(id) {
	if (id === 61) return 64;
	if (id === 37) return 336;
	const tier = toolTier(id);
	if (!tier || !toolKind(id)) return 0;
	if (tier === "wood") return 59;
	if (tier === "stone") return 131;
	if (tier === "iron") return 250;
	if (tier === "gold") return 32;
	if (tier === "amethyst") return 400;
	if (tier === "diamond") return 1561;
	return 0;
}
function makeStack(id, count = 1) {
	const dur = maxDurability(id);
	return dur > 0 ? {
		id,
		count: 1,
		dur
	} : {
		id,
		count
	};
}
function wearStack(slot, n = 1) {
	if (!slot) return false;
	const max = maxDurability(slot.id);
	if (max <= 0) return false;
	if (slot.dur == null) slot.dur = max;
	slot.dur -= n;
	return slot.dur <= 0;
}
function solid(id, name, nameTr, atlas, hardness, extra = {}) {
	return {
		id,
		name,
		nameTr,
		solid: true,
		opaque: true,
		breakable: true,
		hardness,
		atlas,
		drops: id,
		...extra
	};
}
var BLOCKS = {
	[0]: {
		id: 0,
		name: "Air",
		nameTr: "Hava",
		solid: false,
		opaque: false,
		breakable: false,
		hardness: 0,
		atlas: 0,
		drops: 0
	},
	[1]: solid(1, "Grass", "Çim", 0, .55, { drops: 2 }),
	[2]: solid(2, "Dirt", "Toprak", 1, .5),
	[3]: solid(3, "Stone", "Taş", 2, 1.4),
	[4]: solid(4, "Wood", "Odun", 3, .9),
	[5]: solid(5, "Leaves", "Yaprak", 4, .25),
	[6]: solid(6, "Coal Ore", "Kömür", 5, 1.8),
	[7]: solid(7, "Gold Ore", "Altın Cevheri", 6, 2.2, { drops: 49 }),
	[8]: solid(8, "Diamond Ore", "Elmas", 7, 2.8),
	[9]: solid(9, "Bedrock", "Kaya", 8, 999, {
		breakable: false,
		drops: 0
	}),
	[10]: solid(10, "Sand", "Kum", 9, .45),
	[11]: solid(11, "Snow", "Kar", 10, .4),
	[12]: {
		id: 12,
		name: "Water",
		nameTr: "Su",
		solid: false,
		opaque: false,
		breakable: false,
		hardness: 0,
		atlas: 0,
		drops: 0
	},
	[13]: solid(13, "Planks", "Tahta", 11, .7),
	[14]: solid(14, "Cactus", "Kaktüs", 12, .35),
	[15]: solid(15, "Iron Ore", "Demir Cevheri", 13, 2, { drops: 48 }),
	[16]: solid(16, "Amethyst Ore", "Ametist Cevheri", 14, 2.4, { drops: 52 }),
	[17]: solid(17, "Gravel", "Çakıl", 15, .5),
	[18]: {
		id: 18,
		name: "Lava",
		nameTr: "Lav",
		solid: false,
		opaque: false,
		breakable: false,
		hardness: 0,
		atlas: 0,
		drops: 0
	},
	[19]: solid(19, "Obsidian", "Obsidyen", 16, 12, { drops: 19 }),
	[44]: solid(44, "Furnace", "Fırın", 17, 1.6),
	[45]: solid(45, "Wool", "Yün", 18, .4),
	[46]: solid(46, "Bed", "Yatak", 19, .35),
	[47]: {
		id: 47,
		name: "Portal",
		nameTr: "Portal",
		solid: false,
		opaque: false,
		breakable: true,
		hardness: .15,
		atlas: 0,
		drops: 0
	},
	[62]: solid(62, "Netherrack", "Nether Taşı", 20, .5),
	[63]: solid(63, "Nether Brick", "Nether Tuğlası", 21, 1.2),
	[64]: solid(64, "Bookshelf", "Kitaplık", 22, .6, { drops: 13 }),
	[65]: solid(65, "End Frame", "End Çerçevesi", 23, 4, { opaque: false }),
	[66]: solid(66, "End Frame", "End Çerçevesi", 24, 4, {
		opaque: false,
		drops: 65
	}),
	[67]: {
		id: 67,
		name: "End Portal",
		nameTr: "End Portalı",
		solid: false,
		opaque: false,
		breakable: false,
		hardness: 0,
		atlas: 0,
		drops: 0
	},
	[85]: solid(85, "End Stone", "End Taşı", 25, 1.5)
};
function isSolid(id) {
	return BLOCKS[id]?.solid ?? false;
}
function isOpaque(id) {
	return BLOCKS[id]?.opaque ?? false;
}
function solidTop(id) {
	return id === 65 || id === 66 ? .84 : 1;
}
function isWater(id) {
	return id === 12;
}
function isLava(id) {
	return id === 18;
}
function isFluid(id) {
	return id === 12 || id === 18;
}
function blockName(id) {
	const tool = itemName(id);
	if (tool) return tool;
	return BLOCKS[id]?.nameTr ?? "";
}
var mats$1 = /* @__PURE__ */ new Map();
function mat$1(color, emissive = 0) {
	const key = color * 10 + (emissive ? 1 : 0);
	let m = mats$1.get(key);
	if (!m) {
		m = new MeshLambertMaterial({
			color,
			emissive: emissive ? color : 0,
			emissiveIntensity: emissive ? .32 : 0
		});
		mats$1.set(key, m);
	}
	return m;
}
function voxel$1(parent, x, y, z, sx, sy, sz, color, glow = false) {
	const mesh = new Mesh(new BoxGeometry(sx, sy, sz), mat$1(color, glow ? 1 : 0));
	mesh.position.set(x, y, z);
	mesh.frustumCulled = false;
	parent.add(mesh);
}
var TIER_HEAD = {
	wood: {
		head: 9067051,
		edge: 12886890,
		glow: false
	},
	stone: {
		head: 9081760,
		edge: 12963286,
		glow: false
	},
	iron: {
		head: 12896462,
		edge: 15265008,
		glow: false
	},
	gold: {
		head: 13939034,
		edge: 16769162,
		glow: false
	},
	amethyst: {
		head: 11824383,
		edge: 14727423,
		glow: true
	},
	diamond: {
		head: 6217928,
		edge: 13041656,
		glow: true
	}
};
function buildToolModel(kind, tier) {
	const g = new Group();
	const wood = 7029795;
	const wrap = 6044190;
	const t = TIER_HEAD[tier];
	if (kind === "axe") {
		voxel$1(g, 0, 0, 0, .065, .78, .065, wood);
		voxel$1(g, 0, -.12, 0, .08, .16, .08, wrap);
		voxel$1(g, 0, .34, 0, .1, .09, .1, t.head, t.glow);
		voxel$1(g, .16, .36, 0, .28, .16, .05, t.head, t.glow);
		voxel$1(g, .3, .36, 0, .07, .22, .04, t.edge, t.glow);
	} else if (kind === "pick") {
		voxel$1(g, 0, 0, 0, .06, .78, .06, wood);
		voxel$1(g, 0, .34, 0, .1, .08, .1, t.head, t.glow);
		voxel$1(g, 0, .4, 0, .42, .08, .08, t.head, t.glow);
		voxel$1(g, .22, .36, 0, .08, .16, .08, t.edge, t.glow);
		voxel$1(g, -.22, .36, 0, .08, .16, .08, t.edge, t.glow);
	} else if (kind === "shovel") {
		voxel$1(g, 0, 0, 0, .055, .72, .055, wood);
		voxel$1(g, 0, .34, 0, .16, .22, .04, t.head, t.glow);
		voxel$1(g, 0, .46, 0, .12, .08, .03, t.edge, t.glow);
	} else if (kind === "sword") {
		voxel$1(g, 0, .28, 0, .05, .62, .04, t.head, t.glow);
		voxel$1(g, 0, .28, 0, .018, .56, .018, t.edge, t.glow);
		voxel$1(g, 0, .02, 0, .22, .045, .045, 13939034);
		voxel$1(g, 0, -.2, 0, .05, .32, .05, wrap);
		voxel$1(g, 0, -.38, 0, .08, .07, .08, 13939034);
	} else {
		voxel$1(g, 0, .08, 0, .42, .52, .06, 8015400);
		voxel$1(g, 0, .08, .02, .34, .42, .04, 12886890);
		voxel$1(g, 0, .08, .03, .12, .12, .03, t.head, t.glow);
	}
	g.traverse((o) => {
		o.frustumCulled = false;
	});
	return g;
}
function modelForItem(id) {
	if (id === 37) return buildToolModel("shield", "wood");
	const k = toolKind(id);
	const t = toolTier(id);
	if (!k || !t || k === "shield") return null;
	return buildToolModel(k, t);
}
function iconCanvas(draw) {
	const c = document.createElement("canvas");
	c.width = 64;
	c.height = 64;
	const ctx = c.getContext("2d");
	ctx.imageSmoothingEnabled = false;
	draw(ctx);
	return c.toDataURL("image/png");
}
function px(ctx, x, y, w, h, color) {
	ctx.fillStyle = color;
	ctx.fillRect(x, y, w, h);
}
var TIER_HEX = {
	wood: {
		a: "#8a5a2b",
		b: "#c4a36a"
	},
	stone: {
		a: "#8a93a0",
		b: "#c5cdd6"
	},
	iron: {
		a: "#c4c8ce",
		b: "#e8ecf0"
	},
	gold: {
		a: "#d4b15a",
		b: "#ffe08a"
	},
	amethyst: {
		a: "#b46cff",
		b: "#e0b8ff"
	},
	diamond: {
		a: "#5ee0c8",
		b: "#c6fff8"
	}
};
function dot(ctx, x, y, color) {
	px(ctx, x * 4, y * 4, 4, 4, color);
}
function drawToolIcon(id) {
	const kind = toolKind(id);
	const col = TIER_HEX[toolTier(id) ?? "wood"];
	return iconCanvas((ctx) => {
		const wood = "#6b4423";
		const dark = "#3d2814";
		const a = col.a;
		const b = col.b;
		if (kind === "pick") {
			for (let y = 6; y <= 14; y++) dot(ctx, 7, y, y > 12 ? dark : wood);
			for (let x = 2; x <= 12; x++) dot(ctx, x, 3, a);
			dot(ctx, 2, 4, b);
			dot(ctx, 3, 4, b);
			dot(ctx, 2, 5, b);
			dot(ctx, 11, 4, b);
			dot(ctx, 12, 4, b);
			dot(ctx, 12, 5, b);
			dot(ctx, 6, 3, b);
			dot(ctx, 8, 3, b);
		} else if (kind === "axe") {
			for (let y = 5; y <= 14; y++) dot(ctx, 6, y, y > 12 ? dark : wood);
			for (let y = 2; y <= 7; y++) dot(ctx, 8, y, a);
			for (let y = 3; y <= 6; y++) dot(ctx, 9, y, a);
			for (let y = 3; y <= 6; y++) dot(ctx, 10, y, b);
			dot(ctx, 11, 4, b);
			dot(ctx, 11, 5, b);
			dot(ctx, 7, 2, a);
			dot(ctx, 7, 7, a);
		} else if (kind === "shovel") {
			for (let y = 7; y <= 14; y++) dot(ctx, 7, y, y > 12 ? dark : wood);
			for (let y = 2; y <= 6; y++) for (let x = 5; x <= 9; x++) dot(ctx, x, y, y === 2 || y === 6 ? b : a);
			dot(ctx, 6, 1, b);
			dot(ctx, 7, 1, b);
			dot(ctx, 8, 1, b);
		} else if (kind === "sword") {
			for (let y = 1; y <= 9; y++) dot(ctx, 7, y, a);
			for (let y = 2; y <= 8; y++) dot(ctx, 8, y, b);
			dot(ctx, 7, 0, b);
			for (let x = 4; x <= 11; x++) dot(ctx, x, 10, "#d4b15a");
			for (let y = 11; y <= 14; y++) dot(ctx, 7, y, dark);
			dot(ctx, 7, 15, "#d4b15a");
		} else {
			for (let y = 2; y <= 13; y++) for (let x = 3; x <= 12; x++) dot(ctx, x, y, "#7a4e28");
			for (let y = 3; y <= 12; y++) for (let x = 4; x <= 11; x++) dot(ctx, x, y, "#c4a36a");
			for (let y = 6; y <= 9; y++) for (let x = 6; x <= 9; x++) dot(ctx, x, y, a);
			dot(ctx, 7, 7, b);
			dot(ctx, 8, 8, b);
		}
	});
}
function drawStickIcon() {
	return iconCanvas((ctx) => {
		for (let y = 2; y <= 13; y++) dot(ctx, 8, y, y < 4 ? "#c4a36a" : "#8a5a2b");
		dot(ctx, 7, 12, "#5c3a1e");
		dot(ctx, 7, 13, "#5c3a1e");
	});
}
function drawMeatIcon(id) {
	const cooked = id >= 53 && id <= 56;
	const chicken = id === 43 || id === 56;
	const meat = cooked ? chicken ? "#e0b070" : "#8a3c28" : chicken ? "#f0d0b0" : "#d06050";
	const fat = cooked ? "#c47848" : "#f0b0a0";
	return iconCanvas((ctx) => {
		if (chicken) {
			for (let y = 3; y <= 12; y++) dot(ctx, 6 + Math.floor((y - 3) / 5), y, "#f4f0e4");
			for (let y = 3; y <= 7; y++) for (let x = 8; x <= 12; x++) dot(ctx, x, y, meat);
			dot(ctx, 9, 4, fat);
			dot(ctx, 11, 5, fat);
			return;
		}
		for (let y = 4; y <= 11; y++) for (let x = 3; x <= 12; x++) {
			if (x + y < 9 || x + (12 - y) < 6) continue;
			dot(ctx, x, y, meat);
		}
		dot(ctx, 5, 6, fat);
		dot(ctx, 6, 7, fat);
		dot(ctx, 8, 5, fat);
		for (let x = 2; x <= 5; x++) dot(ctx, x, 12, "#f4f0e6");
		dot(ctx, 2, 11, "#f4f0e6");
		dot(ctx, 5, 11, "#f4f0e6");
	});
}
function drawItemIcon(id) {
	return iconCanvas((ctx) => {
		const fillBar = (top, mid, bot) => {
			for (let x = 3; x <= 12; x++) dot(ctx, x, 6, top);
			for (let y = 7; y <= 9; y++) for (let x = 2; x <= 13; x++) dot(ctx, x, y, mid);
			for (let x = 3; x <= 12; x++) dot(ctx, x, 10, bot);
		};
		if (id === 50) fillBar("#e8ecf0", "#c4c8ce", "#8a9098");
		else if (id === 51) fillBar("#ffe08a", "#d4b15a", "#8a6a28");
		else if (id === 48 || id === 49) {
			const c = id === 49 ? "#c4a050" : "#b8a090";
			const h = id === 49 ? "#ffe08a" : "#e4dcd4";
			for (const [x, y] of [
				[5, 5],
				[6, 4],
				[7, 4],
				[8, 5],
				[9, 6],
				[8, 7],
				[7, 8],
				[6, 8],
				[5, 7],
				[4, 6],
				[6, 6],
				[7, 6],
				[8, 6],
				[6, 5],
				[7, 7]
			]) dot(ctx, x, y, c);
			dot(ctx, 6, 5, h);
			dot(ctx, 8, 7, h);
		} else if (id === 52) {
			dot(ctx, 7, 2, "#e0b8ff");
			dot(ctx, 6, 3, "#e0b8ff");
			dot(ctx, 7, 3, "#f4e4ff");
			dot(ctx, 8, 3, "#b46cff");
			for (let x = 5; x <= 9; x++) dot(ctx, x, 4, "#b46cff");
			for (let x = 4; x <= 10; x++) dot(ctx, x, 5, "#9a4ae0");
			for (let x = 5; x <= 9; x++) dot(ctx, x, 6, "#6a2aa0");
			dot(ctx, 6, 7, "#6a2aa0");
			dot(ctx, 7, 7, "#6a2aa0");
			dot(ctx, 8, 7, "#6a2aa0");
		} else if (id === 57 || id === 58 || id === 59) {
			const liq = id === 58 ? "#2a6ec8" : id === 59 ? "#e07020" : "";
			for (let y = 4; y <= 11; y++) {
				dot(ctx, 4, y, "#8a9098");
				dot(ctx, 11, y, "#8a9098");
			}
			for (let x = 4; x <= 11; x++) dot(ctx, x, 11, "#6e767e");
			for (let x = 5; x <= 10; x++) dot(ctx, x, 3, "#d0d4da");
			dot(ctx, 7, 2, "#d0d4da");
			dot(ctx, 8, 2, "#d0d4da");
			if (liq) for (let y = 7; y <= 10; y++) for (let x = 5; x <= 10; x++) dot(ctx, x, y, liq);
		} else if (id === 60) {
			dot(ctx, 8, 3, "#5a5a5a");
			dot(ctx, 7, 4, "#3a3a3a");
			dot(ctx, 8, 4, "#5a5a5a");
			dot(ctx, 6, 5, "#2a2a2a");
			dot(ctx, 7, 5, "#3a3a3a");
			dot(ctx, 8, 5, "#3a3a3a");
			dot(ctx, 9, 5, "#1a1a1a");
			dot(ctx, 7, 6, "#2a2a2a");
			dot(ctx, 8, 6, "#1a1a1a");
			dot(ctx, 6, 7, "#1a1a1a");
		} else if (id === 61) {
			for (let x = 3; x <= 11; x++) dot(ctx, x, 8, "#d0d4da");
			for (let y = 4; y <= 8; y++) dot(ctx, 11, y, "#9aa0a8");
			dot(ctx, 4, 6, "#3a3a3a");
			dot(ctx, 5, 5, "#5a5a5a");
			dot(ctx, 5, 6, "#2a2a2a");
			dot(ctx, 6, 7, "#1a1a1a");
		} else if (id === 80) {
			for (let y = 2; y <= 13; y++) dot(ctx, 7, y, y % 2 ? "#f0c040" : "#e09020");
			dot(ctx, 6, 5, "#ffe080");
			dot(ctx, 8, 8, "#ffe080");
			dot(ctx, 6, 11, "#ffd060");
		} else if (id === 81) {
			dot(ctx, 6, 6, "#f0c040");
			dot(ctx, 8, 5, "#ffe080");
			dot(ctx, 9, 7, "#e09020");
			dot(ctx, 7, 8, "#fff0a0");
			dot(ctx, 5, 8, "#e0a030");
			dot(ctx, 8, 9, "#f0c040");
		} else if (id === 82) {
			for (let y = 4; y <= 11; y++) for (let x = 4; x <= 11; x++) {
				const dx = x - 7.5;
				const dy = y - 7.5;
				if (dx * dx + dy * dy <= 14) dot(ctx, x, y, "#14685a");
			}
			dot(ctx, 6, 6, "#8ef0d8");
			dot(ctx, 7, 6, "#c8fff0");
		} else if (id === 83) {
			for (let y = 4; y <= 11; y++) for (let x = 4; x <= 11; x++) {
				const dx = x - 7.5;
				const dy = y - 7.5;
				if (dx * dx + dy * dy <= 14) dot(ctx, x, y, "#14705c");
			}
			for (let y = 6; y <= 9; y++) for (let x = 6; x <= 9; x++) dot(ctx, x, y, "#e8e090");
			dot(ctx, 7, 7, "#2a9a48");
			dot(ctx, 8, 7, "#2a9a48");
			dot(ctx, 7, 8, "#061208");
		} else if (id === 84) {
			for (let x = 3; x <= 12; x++) dot(ctx, x, 8, "#6b4120");
			for (let x = 4; x <= 11; x++) dot(ctx, x, 7, "#8a5a2a");
			for (let x = 5; x <= 10; x++) dot(ctx, x, 6, "#a06a32");
			dot(ctx, 12, 7, "#8a5a2a");
			dot(ctx, 13, 8, "#6b4120");
		} else if (id === 20) for (let y = 2; y <= 13; y++) dot(ctx, 8, y, y < 4 ? "#c4a36a" : "#8a5a2b");
		else for (let y = 5; y <= 10; y++) for (let x = 5; x <= 10; x++) dot(ctx, x, y, "#9aa08a");
	});
}
var FACE_PX = [
	[0, 16],
	[16, 16],
	[0, 32],
	[32, 0],
	[16, 0],
	[0, 0]
];
var SRC = {
	0: "/textures/grass.png",
	2: "/textures/stone.png",
	3: "/textures/wood.png",
	4: "/textures/leaves.png",
	5: "/textures/coal.png",
	6: "/textures/gold.png",
	7: "/textures/diamond.png"
};
function loadImage(src) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.crossOrigin = "anonymous";
		img.onload = () => resolve(img);
		img.onerror = () => reject(/* @__PURE__ */ new Error(`texture ${src}`));
		img.src = src;
	});
}
function extract16(src, sx, sy) {
	const c = document.createElement("canvas");
	c.width = 16;
	c.height = 16;
	const ctx = c.getContext("2d");
	ctx.imageSmoothingEnabled = false;
	ctx.drawImage(src, sx, sy, 16, 16, 0, 0, 16, 16);
	const img = ctx.getImageData(0, 0, 16, 16);
	const d = img.data;
	for (let i = 0; i < d.length; i += 4) d[i + 3] = 255;
	ctx.putImageData(img, 0, 0);
	return c;
}
function tileOpaqueCount(src, sx, sy) {
	const c = document.createElement("canvas");
	c.width = 16;
	c.height = 16;
	const ctx = c.getContext("2d");
	ctx.drawImage(src, sx, sy, 16, 16, 0, 0, 16, 16);
	const d = ctx.getImageData(0, 0, 16, 16).data;
	let n = 0;
	for (let i = 3; i < d.length; i += 4) if (d[i] > 16) n++;
	return n;
}
function firstPainted(src) {
	for (const [x, y] of FACE_PX) if (tileOpaqueCount(src, x, y) > 40) return [x, y];
	return [0, 0];
}
function blitUpscale(dst, tile, dx, dy) {
	dst.imageSmoothingEnabled = false;
	dst.drawImage(tile, 0, 0, 16, 16, dx, dy, 32, 32);
}
function clamp(n) {
	return n < 0 ? 0 : n > 255 ? 255 : n | 0;
}
function paintNoise(ctx, x, y, rgb, spread) {
	const img = ctx.createImageData(16, 16);
	const d = img.data;
	for (let i = 0; i < 256; i++) {
		const n = (Math.random() - .5) * spread;
		const j = i * 4;
		d[j] = clamp(rgb[0] + n);
		d[j + 1] = clamp(rgb[1] + n);
		d[j + 2] = clamp(rgb[2] + n);
		d[j + 3] = 255;
	}
	ctx.putImageData(img, x, y);
}
function paintStripes(ctx, x, y, a, b) {
	const img = ctx.createImageData(16, 16);
	const d = img.data;
	for (let py = 0; py < 16; py++) for (let px = 0; px < 16; px++) {
		const stripe = Math.floor(px / 4) % 2 === 0;
		const n = (Math.random() - .5) * 14;
		const c = stripe ? a : b;
		const j = (py * 16 + px) * 4;
		d[j] = clamp(c[0] + n);
		d[j + 1] = clamp(c[1] + n);
		d[j + 2] = clamp(c[2] + n);
		d[j + 3] = 255;
	}
	ctx.putImageData(img, x, y);
}
function bookshelfSheet(planks) {
	const c = document.createElement("canvas");
	c.width = 64;
	c.height = 64;
	const ctx = c.getContext("2d");
	ctx.imageSmoothingEnabled = false;
	const side = bookshelfSide();
	const top = extract16(planks, 0, 32);
	const bottom = extract16(planks, 32, 0);
	ctx.drawImage(side, 0, 16);
	ctx.drawImage(side, 16, 16);
	ctx.drawImage(top, 0, 32);
	ctx.drawImage(bottom, 32, 0);
	ctx.drawImage(side, 16, 0);
	ctx.drawImage(side, 0, 0);
	return c;
}
function bookshelfSide() {
	const c = document.createElement("canvas");
	c.width = 16;
	c.height = 16;
	const ctx = c.getContext("2d");
	const img = ctx.createImageData(16, 16);
	const d = img.data;
	const wood = [
		[
			186,
			148,
			92
		],
		[
			150,
			112,
			64
		],
		[
			112,
			78,
			42
		]
	];
	const books = [
		[
			168,
			48,
			42
		],
		[
			46,
			78,
			158
		],
		[
			42,
			122,
			58
		],
		[
			92,
			58,
			36
		],
		[
			128,
			52,
			146
		],
		[
			186,
			146,
			48
		],
		[
			38,
			112,
			124
		],
		[
			156,
			78,
			42
		]
	];
	const set = (x, y, rgb) => {
		const j = (y * 16 + x) * 4;
		d[j] = rgb[0];
		d[j + 1] = rgb[1];
		d[j + 2] = rgb[2];
		d[j + 3] = 255;
	};
	for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
		if (y === 0 || y === 15 || x === 0 || x === 15 || y === 1 || y === 14) {
			set(x, y, wood[(x + y) % 3]);
			continue;
		}
		const col = Math.floor((x - 1) / 2);
		const gap = (x - 1) % 2 === 1 && col < 6;
		const short = col % 3 === 2 ? 3 : col % 2 === 0 ? 1 : 2;
		if (y < 2 + short || gap) set(x, y, wood[1]);
		else {
			const book = books[col % books.length];
			const shade = y % 5 === 0 ? -28 : x % 2 === 0 ? 10 : 0;
			set(x, y, [
				clamp(book[0] + shade),
				clamp(book[1] + shade),
				clamp(book[2] + shade)
			]);
		}
	}
	ctx.putImageData(img, 0, 0);
	return c;
}
function makeSheet(paint) {
	const c = document.createElement("canvas");
	c.width = 64;
	c.height = 64;
	const ctx = c.getContext("2d");
	ctx.imageSmoothingEnabled = false;
	FACE_PX.forEach(([x, y], i) => paint(ctx, x, y, i));
	return c;
}
async function buildAtlas() {
	const grass = await loadImage(SRC[0]);
	const images = { 0: grass };
	await Promise.all(Object.entries(SRC).map(async ([k, url]) => {
		const id = Number(k);
		if (id === 0) return;
		images[id] = await loadImage(url);
	}));
	const dirt = document.createElement("canvas");
	dirt.width = 64;
	dirt.height = 64;
	const dctx = dirt.getContext("2d");
	dctx.imageSmoothingEnabled = false;
	const dirtTile = extract16(grass, 32, 0);
	for (let y = 0; y < 64; y += 16) for (let x = 0; x < 64; x += 16) dctx.drawImage(dirtTile, x, y);
	images[1] = dirt;
	const bedrock = document.createElement("canvas");
	bedrock.width = 64;
	bedrock.height = 64;
	const bctx = bedrock.getContext("2d");
	bctx.imageSmoothingEnabled = false;
	bctx.drawImage(images[2], 0, 0);
	bctx.fillStyle = "rgba(0,0,0,0.62)";
	bctx.fillRect(0, 0, 64, 64);
	images[8] = bedrock;
	images[9] = makeSheet((ctx, x, y) => paintNoise(ctx, x, y, [
		214,
		186,
		118
	], 22));
	images[10] = makeSheet((ctx, x, y, face) => {
		if (face === 2) paintNoise(ctx, x, y, [
			236,
			242,
			248
		], 10);
		else if (face === 3) paintNoise(ctx, x, y, [
			168,
			176,
			186
		], 12);
		else paintNoise(ctx, x, y, [
			214,
			224,
			234
		], 12);
	});
	images[11] = makeSheet((ctx, x, y) => paintStripes(ctx, x, y, [
		166,
		122,
		62
	], [
		138,
		96,
		46
	]));
	images[12] = makeSheet((ctx, x, y, face) => {
		if (face === 2 || face === 3) paintNoise(ctx, x, y, [
			46,
			110,
			48
		], 16);
		else paintStripes(ctx, x, y, [
			38,
			102,
			42
		], [
			22,
			72,
			28
		]);
	});
	images[13] = makeSheet((ctx, x, y) => paintNoise(ctx, x, y, [
		168,
		152,
		132
	], 18));
	images[14] = makeSheet((ctx, x, y) => paintNoise(ctx, x, y, [
		148,
		82,
		186
	], 22));
	images[15] = makeSheet((ctx, x, y) => paintNoise(ctx, x, y, [
		128,
		122,
		118
	], 20));
	images[16] = makeSheet((ctx, x, y) => paintNoise(ctx, x, y, [
		18,
		10,
		28
	], 10));
	images[17] = makeSheet((ctx, x, y, face) => {
		if (face === 4) paintNoise(ctx, x, y, [
			48,
			48,
			52
		], 8);
		else paintNoise(ctx, x, y, [
			92,
			92,
			98
		], 12);
	});
	images[18] = makeSheet((ctx, x, y) => paintNoise(ctx, x, y, [
		232,
		232,
		236
	], 10));
	images[19] = makeSheet((ctx, x, y, face) => {
		if (face === 2) paintNoise(ctx, x, y, [
			180,
			54,
			54
		], 12);
		else paintStripes(ctx, x, y, [
			150,
			90,
			48
		], [
			120,
			70,
			36
		]);
	});
	images[20] = makeSheet((ctx, x, y) => paintNoise(ctx, x, y, [
		120,
		42,
		38
	], 22));
	images[21] = makeSheet((ctx, x, y) => paintStripes(ctx, x, y, [
		72,
		22,
		28
	], [
		48,
		14,
		18
	]));
	images[22] = bookshelfSheet(images[11]);
	images[23] = makeSheet((ctx, x, y, face) => {
		if (face === 2) paintNoise(ctx, x, y, [
			40,
			120,
			70
		], 12);
		else paintNoise(ctx, x, y, [
			28,
			36,
			32
		], 8);
	});
	images[24] = makeSheet((ctx, x, y, face) => {
		if (face === 2) paintFrameEye(ctx, x, y);
		else paintNoise(ctx, x, y, [
			28,
			36,
			32
		], 8);
	});
	images[25] = makeSheet((ctx, x, y) => paintNoise(ctx, x, y, [
		224,
		222,
		168
	], 14));
	const atlas = document.createElement("canvas");
	atlas.width = 512;
	atlas.height = 384;
	const actx = atlas.getContext("2d");
	actx.imageSmoothingEnabled = false;
	actx.fillStyle = "#3a2a18";
	actx.fillRect(0, 0, atlas.width, atlas.height);
	for (let group = 0; group <= 25; group++) {
		const src = images[group];
		if (!src) continue;
		const fallback = firstPainted(src);
		for (let face = 0; face < 6; face++) {
			let [sx, sy] = FACE_PX[face];
			if (tileOpaqueCount(src, sx, sy) < 40) {
				sx = fallback[0];
				sy = fallback[1];
			}
			const tile = extract16(src, sx, sy);
			const t = group * 6 + face;
			const col = t % 16;
			const row = Math.floor(t / 16);
			blitUpscale(actx, tile, col * 32, row * 32);
		}
	}
	const texture = new CanvasTexture(atlas);
	texture.magFilter = NearestFilter;
	texture.minFilter = NearestFilter;
	texture.colorSpace = SRGBColorSpace;
	texture.wrapS = ClampToEdgeWrapping;
	texture.wrapT = ClampToEdgeWrapping;
	texture.flipY = false;
	texture.generateMipmaps = false;
	texture.needsUpdate = true;
	const icons = {};
	for (const def of Object.values(BLOCKS)) {
		if (def.id === 0 || def.id === 12 || def.id === 18 || def.id === 47) continue;
		icons[def.id] = drawIsoIcon(images[def.atlas] ?? grass);
	}
	icons[20] = drawStickIcon();
	for (let id = 21; id <= 77; id++) if (isTool(id) || itemName(id)) icons[id] = drawToolIcon(id);
	icons[40] = drawMeatIcon(40);
	icons[41] = drawMeatIcon(41);
	icons[42] = drawMeatIcon(42);
	icons[43] = drawMeatIcon(43);
	icons[53] = drawMeatIcon(53);
	icons[54] = drawMeatIcon(54);
	icons[55] = drawMeatIcon(55);
	icons[56] = drawMeatIcon(56);
	icons[48] = drawItemIcon(48);
	icons[49] = drawItemIcon(49);
	icons[50] = drawItemIcon(50);
	icons[51] = drawItemIcon(51);
	icons[52] = drawItemIcon(52);
	icons[57] = drawItemIcon(57);
	icons[58] = drawItemIcon(58);
	icons[59] = drawItemIcon(59);
	icons[60] = drawItemIcon(60);
	icons[61] = drawItemIcon(61);
	icons[80] = drawItemIcon(80);
	icons[81] = drawItemIcon(81);
	icons[82] = drawItemIcon(82);
	icons[83] = drawItemIcon(83);
	icons[84] = drawItemIcon(84);
	return {
		texture,
		canvas: atlas,
		icons
	};
}
function paintFrameEye(ctx, x, y) {
	paintNoise(ctx, x, y, [
		34,
		48,
		40
	], 10);
	const img = ctx.getImageData(x, y, 16, 16);
	const d = img.data;
	const set = (px, py, r, g, b) => {
		const j = (py * 16 + px) * 4;
		d[j] = r;
		d[j + 1] = g;
		d[j + 2] = b;
		d[j + 3] = 255;
	};
	for (let py = 0; py < 16; py++) for (let px = 0; px < 16; px++) {
		const nx = (px + .5 - 8) / 5.4;
		const ny = (py + .5 - 8) / 3.4;
		const e = nx * nx + ny * ny;
		if (e > 1) continue;
		if (e > .78) set(px, py, 16, 20, 18);
		else if (e > .34) set(px, py, 232, 214, 92);
		else if (e > .1) set(px, py, 28, 148, 58);
		else set(px, py, 6, 10, 8);
	}
	set(6, 6, 245, 255, 220);
	ctx.putImageData(img, x, y);
}
function drawIsoIcon(src) {
	const size = 64;
	const c = document.createElement("canvas");
	c.width = size;
	c.height = size;
	const ctx = c.getContext("2d");
	ctx.imageSmoothingEnabled = false;
	const top = extract16(src, 0, 32);
	const left = extract16(src, 0, 16);
	const right = extract16(src, 16, 0);
	const ox = size / 2;
	texturedQuad(ctx, top, ox, size * .22, 56.32, 28.16, ox, 42.24, 7.68, 28.16);
	texturedQuad(ctx, left, 7.68, 28.16, ox, 42.24, ox, 69.12, 7.68, 55.04);
	texturedQuad(ctx, right, ox, 42.24, 56.32, 28.16, 56.32, 55.04, ox, 69.12);
	return c.toDataURL("image/png");
}
function texturedQuad(ctx, tex, x0, y0, x1, y1, x2, y2, x3, y3) {
	const w = tex.width;
	const h = tex.height;
	ctx.save();
	ctx.beginPath();
	ctx.moveTo(x0, y0);
	ctx.lineTo(x1, y1);
	ctx.lineTo(x2, y2);
	ctx.lineTo(x3, y3);
	ctx.closePath();
	ctx.clip();
	ctx.transform((x1 - x0) / w, (y1 - y0) / w, (x3 - x0) / h, (y3 - y0) / h, x0, y0);
	ctx.drawImage(tex, 0, 0);
	ctx.restore();
}
function atlasFaceUV(group, face, u, v) {
	const t = group * 6 + face;
	const col = t % 16;
	const row = Math.floor(t / 16);
	const pad = .5 / 32;
	const uu = u < .5 ? pad : .984375;
	const vv = v < .5 ? pad : .984375;
	return [(col + uu) / 16, (row + vv) / 12];
}
var GameAudio = class {
	ctx = null;
	master = null;
	volume = .7;
	unlock() {
		if (!this.ctx) {
			const AC = window.AudioContext || window.webkitAudioContext;
			this.ctx = new AC({ latencyHint: "interactive" });
			this.master = this.ctx.createGain();
			this.master.gain.value = this.volume;
			this.master.connect(this.ctx.destination);
		}
		if (this.ctx.state === "suspended") this.ctx.resume();
	}
	setVolume(v) {
		this.volume = v;
		if (this.master && this.ctx) this.master.gain.setTargetAtTime(v, this.ctx.currentTime, .02);
	}
	beep(freq, dur, type, gain = .12, slide) {
		if (!this.ctx || !this.master || this.volume <= .01) return;
		const t = this.ctx.currentTime;
		const osc = this.ctx.createOscillator();
		const g = this.ctx.createGain();
		osc.type = type;
		osc.frequency.setValueAtTime(freq, t);
		if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, slide), t + dur);
		g.gain.setValueAtTime(1e-4, t);
		g.gain.exponentialRampToValueAtTime(gain * this.volume, t + .01);
		g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
		osc.connect(g);
		g.connect(this.master);
		osc.start(t);
		osc.stop(t + dur + .02);
		osc.onended = () => {
			osc.disconnect();
			g.disconnect();
		};
	}
	noise(dur, gain = .18) {
		if (!this.ctx || !this.master || this.volume <= .01) return;
		const n = Math.max(1, Math.floor(this.ctx.sampleRate * dur));
		const buf = this.ctx.createBuffer(1, n, this.ctx.sampleRate);
		const data = buf.getChannelData(0);
		for (let i = 0; i < n; i++) data[i] = Math.random() * 2 - 1;
		const src = this.ctx.createBufferSource();
		src.buffer = buf;
		const g = this.ctx.createGain();
		const t = this.ctx.currentTime;
		g.gain.setValueAtTime(gain * this.volume, t);
		g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
		const f = this.ctx.createBiquadFilter();
		f.type = "lowpass";
		f.frequency.value = 1400;
		src.connect(f);
		f.connect(g);
		g.connect(this.master);
		src.start(t);
		src.stop(t + dur);
		src.onended = () => {
			src.disconnect();
			f.disconnect();
			g.disconnect();
		};
	}
	place() {
		this.beep(180, .07, "square", .1);
	}
	break() {
		this.noise(.12, .22);
	}
	jump() {
		this.beep(420, .14, "square", .08, 180);
	}
	hurt() {
		this.beep(160, .2, "sawtooth", .14, 70);
	}
	pickup() {
		this.beep(760, .08, "triangle", .08, 1140);
	}
	step() {
		this.noise(.04, .05);
	}
	click() {
		this.beep(520, .04, "square", .05);
	}
	swing() {
		this.beep(220, .1, "sawtooth", .06, 80);
	}
	eat() {
		this.beep(280, .09, "triangle", .07, 180);
		this.noise(.08, .04);
	}
	oink() {
		this.beep(240, .16, "square", .08, 140);
	}
	cluck() {
		this.beep(620, .08, "square", .06, 480);
	}
	moo() {
		this.beep(140, .22, "sawtooth", .07, 90);
	}
	snore() {
		this.beep(90, .35, "sine", .05, 70);
	}
	growl() {
		this.beep(90, .22, "sawtooth", .09, 50);
	}
	bones() {
		this.beep(520, .08, "square", .05, 280);
	}
	hiss() {
		this.noise(.28, .08);
	}
	skitter() {
		this.beep(180, .06, "square", .05, 90);
	}
	boom() {
		this.noise(.35, .28);
		this.beep(70, .3, "sawtooth", .12, 40);
	}
};
var GAME_CODES = /* @__PURE__ */ new Set([
	"KeyW",
	"KeyA",
	"KeyS",
	"KeyD",
	"Space",
	"ShiftLeft",
	"ShiftRight",
	"ControlLeft",
	"ControlRight",
	"KeyE",
	"Escape",
	"Tab",
	"KeyP",
	"Period",
	"NumpadDecimal",
	"Slash",
	"Digit1",
	"Digit2",
	"Digit3",
	"Digit4",
	"Digit5",
	"Digit6",
	"Digit7",
	"Digit8",
	"Digit9",
	"Digit0",
	"ArrowUp",
	"ArrowDown",
	"ArrowLeft",
	"ArrowRight"
]);
var Input = class {
	keys = /* @__PURE__ */ new Set();
	injected = null;
	prev = /* @__PURE__ */ new Set();
	lookDx = 0;
	lookDy = 0;
	wheel = 0;
	touchMoveX = 0;
	touchMoveY = 0;
	listeners = [];
	attach(target) {
		const onDown = (e) => {
			if (e.repeat) {
				if (GAME_CODES.has(e.code)) e.preventDefault();
				return;
			}
			this.keys.add(e.code);
			if (GAME_CODES.has(e.code)) e.preventDefault();
		};
		const onUp = (e) => {
			this.keys.delete(e.code);
		};
		const onBlur = () => {
			this.keys.clear();
		};
		const onMouseDown = (e) => {
			this.keys.add(`Mouse${e.button}`);
		};
		const onMouseUp = (e) => {
			this.keys.delete(`Mouse${e.button}`);
		};
		const onMove = (e) => {
			this.lookDx += e.movementX;
			this.lookDy += e.movementY;
		};
		const onWheel = (e) => {
			this.wheel += Math.sign(e.deltaY);
			e.preventDefault();
		};
		const onContext = (e) => e.preventDefault();
		const onVis = () => {
			if (document.hidden) this.keys.clear();
		};
		window.addEventListener("keydown", onDown);
		window.addEventListener("keyup", onUp);
		window.addEventListener("blur", onBlur);
		document.addEventListener("visibilitychange", onVis);
		target.addEventListener("mousedown", onMouseDown);
		window.addEventListener("mouseup", onMouseUp);
		window.addEventListener("mousemove", onMove);
		target.addEventListener("wheel", onWheel, { passive: false });
		target.addEventListener("contextmenu", onContext);
		this.listeners.push(() => {
			window.removeEventListener("keydown", onDown);
			window.removeEventListener("keyup", onUp);
			window.removeEventListener("blur", onBlur);
			document.removeEventListener("visibilitychange", onVis);
			target.removeEventListener("mousedown", onMouseDown);
			window.removeEventListener("mouseup", onMouseUp);
			window.removeEventListener("mousemove", onMove);
			target.removeEventListener("wheel", onWheel);
			target.removeEventListener("contextmenu", onContext);
		});
	}
	setKeys(codes) {
		this.injected = codes.slice();
	}
	clearInjected() {
		this.injected = null;
	}
	isDown(code) {
		if (this.injected) return this.injected.includes(code);
		return this.keys.has(code);
	}
	justPressed(code) {
		return this.isDown(code) && !this.prev.has(code);
	}
	consumeLook() {
		const d = {
			dx: this.lookDx,
			dy: this.lookDy
		};
		this.lookDx = 0;
		this.lookDy = 0;
		return d;
	}
	consumeWheel() {
		const w = this.wheel;
		this.wheel = 0;
		return w;
	}
	addLook(dx, dy) {
		this.lookDx += dx;
		this.lookDy += dy;
	}
	endFrame() {
		this.prev = new Set(this.injected ?? this.keys);
	}
	dispose() {
		for (const off of this.listeners) off();
		this.listeners = [];
		this.keys.clear();
	}
};
function emptyGrid(n) {
	return Array.from({ length: n }, () => null);
}
function addItem(dest, extra, id, count) {
	const bags = extra ? [dest, extra] : [dest];
	let left = count;
	if (!isTool(id)) {
		for (const bag of bags) for (const slot of bag) if (slot && slot.id === id && slot.count < 64) {
			const take = Math.min(64 - slot.count, left);
			slot.count += take;
			left -= take;
			if (left <= 0) return 0;
		}
	}
	for (const bag of bags) for (let i = 0; i < bag.length; i++) if (!bag[i]) {
		const take = isTool(id) ? 1 : Math.min(64, left);
		const dur = maxDurability(id);
		bag[i] = dur > 0 ? {
			id,
			count: take,
			dur
		} : {
			id,
			count: take
		};
		left -= take;
		if (left <= 0) return 0;
	}
	return left;
}
function takeOne(slots, index) {
	const s = slots[index];
	if (!s) return null;
	const id = s.id;
	s.count -= 1;
	if (s.count <= 0) slots[index] = null;
	return id;
}
function starterHotbar() {
	return emptyGrid(10);
}
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function hash2(x, z, seed) {
	let n = Math.imul(x | 0, 374761393) + Math.imul(z | 0, 668265263) + seed;
	n = Math.imul(n ^ n >>> 13, 1274126177);
	return ((n ^ n >>> 16) >>> 0) / 4294967296;
}
function strongholds(seed) {
	const rooms = [];
	for (let i = 0; i < 3; i++) {
		const ang = i / 3 * Math.PI * 2 + seed % 97 / 97 * .9;
		const r = 190 + (Math.abs(seed) + i * 131) % 240;
		rooms.push({
			x: Math.round(Math.cos(ang) * r),
			y: 12,
			z: Math.round(Math.sin(ang) * r)
		});
	}
	return rooms;
}
function frameSpots(room) {
	const y = room.y + 1;
	const spots = [];
	for (let i = 0; i < 4; i++) {
		spots.push([
			room.x + 4 + i,
			y,
			room.z + 3
		]);
		spots.push([
			room.x + 4 + i,
			y,
			room.z + 8
		]);
		spots.push([
			room.x + 3,
			y,
			room.z + 4 + i
		]);
		spots.push([
			room.x + 8,
			y,
			room.z + 4 + i
		]);
	}
	return spots;
}
function portalSpots(room) {
	const spots = [];
	for (let dz = 0; dz < 4; dz++) for (let dx = 0; dx < 4; dx++) spots.push([
		room.x + 4 + dx,
		room.y + 1,
		room.z + 4 + dz
	]);
	return spots;
}
function fortresses(seed) {
	const out = [];
	for (let gz = -2; gz <= 2; gz++) for (let gx = -2; gx <= 2; gx++) {
		if ((Math.abs(gx) + Math.abs(gz)) % 2 !== 0) continue;
		const jx = (hash2(gx, gz, seed) - .5) * 50;
		const jz = (hash2(gz, gx, seed + 5) - .5) * 50;
		out.push({
			x: Math.round(gx * 210 + jx),
			y: 32,
			z: Math.round(gz * 210 + jz)
		});
	}
	return out;
}
function nearFortress(seed, x, z, pad = 26) {
	let best = null;
	let d = pad * pad;
	for (const f of fortresses(seed)) {
		const dd = (f.x - x) ** 2 + (f.z - z) ** 2;
		if (dd < d) {
			d = dd;
			best = f;
		}
	}
	return best;
}
function chunkKey(cx, cz) {
	return `${cx},${cz}`;
}
function worldToChunk(x, z) {
	const cx = Math.floor(x / 16);
	const cz = Math.floor(z / 16);
	return [
		cx,
		cz,
		x - cx * 16,
		z - cz * 16
	];
}
var BIOME_NAME = [
	"Okyanus",
	"Ova",
	"Orman",
	"Çöl",
	"Kar"
];
var World = class {
	seed;
	kind;
	chunks = /* @__PURE__ */ new Map();
	dirty = /* @__PURE__ */ new Set();
	generating = /* @__PURE__ */ new Set();
	flow = /* @__PURE__ */ new Map();
	lavaFlow = /* @__PURE__ */ new Map();
	pendingWater = /* @__PURE__ */ new Set();
	pendingLava = /* @__PURE__ */ new Set();
	changes = /* @__PURE__ */ new Map();
	rooms = [];
	forts = [];
	loot = [];
	endTowers = [];
	isles = [];
	looted = /* @__PURE__ */ new Set();
	noise2;
	noise3;
	constructor(seed, kind = "overworld") {
		this.seed = seed;
		this.kind = kind;
		const rng = mulberry32(seed);
		this.noise2 = createNoise2D(rng);
		this.noise3 = createNoise3D(rng);
		this.rooms = kind === "overworld" ? strongholds(seed) : [];
		this.forts = kind === "nether" ? fortresses(seed) : [];
		if (kind === "overworld") this.buryStrongholds();
		if (kind === "end") this.planEnd();
	}
	biomeAt(wx, wz) {
		const continent = this.noise2(wx * .0034, wz * .0034);
		const temp = this.noise2(wx * .0052 + 90, wz * .0052);
		const rain = this.noise2(wx * .006 + 21, wz * .006);
		if (continent < -.16) return 0;
		if (temp > .3) return 3;
		if (temp < -.3) return 4;
		if (rain > .06) return 2;
		return 1;
	}
	heightAt(wx, wz) {
		const n = this.noise2(wx * .018, wz * .018) * 8 + this.noise2(wx * .05, wz * .05) * 3.2 + this.noise2(wx * .12, wz * .12) * 1.2;
		const b = this.biomeAt(wx, wz);
		let base = 20;
		let amp = 1;
		if (b === 0) {
			base = 11;
			amp = .45;
		} else if (b === 3) {
			base = 18;
			amp = .7;
		} else if (b === 4) {
			base = 24;
			amp = 1.25;
		} else if (b === 2) {
			base = 21;
			amp = 1;
		} else {
			base = 20;
			amp = .75;
		}
		return Math.max(6, Math.min(54, Math.floor(base + n * amp)));
	}
	findSpawn() {
		for (let r = 0; r <= 96; r += 3) {
			const steps = r === 0 ? 1 : 10;
			for (let i = 0; i < steps; i++) {
				const a = i / steps * Math.PI * 2 + r * .2;
				const wx = Math.round(Math.cos(a) * r);
				const wz = Math.round(Math.sin(a) * r);
				if (this.biomeAt(wx, wz) === 0) continue;
				const h = this.heightAt(wx, wz);
				if (h >= 17) return [
					wx + .5,
					h + 1.05,
					wz + .5
				];
			}
		}
		return [
			.5,
			this.heightAt(0, 0) + 1.05,
			.5
		];
	}
	ensureChunk(cx, cz) {
		const k = chunkKey(cx, cz);
		let data = this.chunks.get(k);
		if (data) return data;
		if (this.generating.has(k)) {
			data = /* @__PURE__ */ new Uint8Array(16384);
			this.chunks.set(k, data);
			return data;
		}
		this.generating.add(k);
		data = this.kind === "nether" ? this.generateNether(cx, cz) : this.kind === "end" ? this.generateEnd(cx, cz) : this.generate(cx, cz);
		this.replayChunk(cx, cz, data);
		this.generating.delete(k);
		this.chunks.set(k, data);
		this.dirty.add(k);
		return data;
	}
	remember(x, y, z, id) {
		const [cx, cz, lx, lz] = worldToChunk(Math.floor(x), Math.floor(z));
		const ck = chunkKey(cx, cz);
		let bucket = this.changes.get(ck);
		if (!bucket) {
			bucket = /* @__PURE__ */ new Map();
			this.changes.set(ck, bucket);
		}
		bucket.set(`${lx},${Math.floor(y)},${lz}`, id);
	}
	editBlock(x, y, z, id) {
		if (y < 0 || y >= 64) return false;
		x = Math.floor(x);
		y = Math.floor(y);
		z = Math.floor(z);
		this.remember(x, y, z, id);
		const [cx, cz] = worldToChunk(x, z);
		if (!this.chunks.has(chunkKey(cx, cz))) {
			this.ensureChunk(cx, cz);
			return this.getBlock(x, y, z) === id;
		}
		if (this.getBlock(x, y, z) === id) return true;
		return this.setBlock(x, y, z, id) || this.getBlock(x, y, z) === id;
	}
	loadEdits(edits) {
		for (const [x, y, z, id] of edits) this.remember(x, y, z, id);
	}
	exportEdits() {
		const out = [];
		for (const [ck, bucket] of this.changes) {
			const [cx, cz] = ck.split(",").map(Number);
			for (const [lk, id] of bucket) {
				const [lx, y, lz] = lk.split(",").map(Number);
				out.push([
					cx * 16 + lx,
					y,
					cz * 16 + lz,
					id
				]);
			}
		}
		return out;
	}
	replayChunk(cx, cz, data) {
		const bucket = this.changes.get(chunkKey(cx, cz));
		if (!bucket) return;
		for (const [lk, id] of bucket) {
			const [lx, y, lz] = lk.split(",").map(Number);
			if (y < 0 || y >= 64) continue;
			data[this.index(lx, y, lz)] = id;
		}
	}
	planEnd() {
		this.isles = [{
			x: 0,
			z: 0,
			r: 32,
			y: 34
		}];
		this.endTowers = [];
		for (let i = 0; i < 8; i++) {
			const a = i / 8 * Math.PI * 2 + .2;
			this.endTowers.push({
				x: Math.round(Math.cos(a) * 20),
				z: Math.round(Math.sin(a) * 20),
				top: 52
			});
		}
		for (let i = 0; i < 22; i++) {
			const a = hash2(i, 3, this.seed) * Math.PI * 2;
			const rad = 58 + hash2(i, 9, this.seed) * 170;
			const r = 7 + hash2(i, 4, this.seed) * 8;
			this.isles.push({
				x: Math.round(Math.cos(a) * rad),
				z: Math.round(Math.sin(a) * rad),
				r,
				y: 24 + Math.floor(hash2(i, 6, this.seed) * 12)
			});
		}
	}
	endSurface(wx, wz) {
		let best = null;
		for (const isle of this.isles) {
			const dx = wx - isle.x;
			const dz = wz - isle.z;
			const d = Math.hypot(dx, dz);
			if (d > isle.r) continue;
			const edge = 1 - d / isle.r;
			const n = this.noise2(wx * .07, wz * .07) * 1.6;
			const h = Math.floor(isle.y + edge * 5 + n);
			if (best == null || h > best) best = h;
		}
		return best;
	}
	generateEnd(cx, cz) {
		const data = /* @__PURE__ */ new Uint8Array(16384);
		const ox = cx * 16;
		const oz = cz * 16;
		for (let lz = 0; lz < 16; lz++) for (let lx = 0; lx < 16; lx++) {
			const wx = ox + lx;
			const wz = oz + lz;
			const h = this.endSurface(wx, wz);
			if (h == null) continue;
			const top = Math.max(1, Math.min(62, h));
			for (let y = Math.max(1, top - 5); y <= top; y++) this.setLocal(data, lx, y, lz, 85);
			for (const tower of this.endTowers) {
				if (tower.x !== wx || tower.z !== wz) continue;
				for (let y = top + 1; y <= tower.top; y++) this.setLocal(data, lx, y, lz, 19);
			}
		}
		return data;
	}
	generateNether(cx, cz) {
		const data = /* @__PURE__ */ new Uint8Array(16384);
		const ox = cx * 16;
		const oz = cz * 16;
		for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
			const wx = ox + x;
			const wz = oz + z;
			const n = this.noise2(wx * .035, wz * .035);
			const n2 = this.noise2(wx * .11 + 8, wz * .11);
			const h = 12 + Math.floor((n + 1) * 9 + n2 * 3);
			const ceil = 46 + Math.floor((n2 + 1) * 5);
			for (let y = 0; y < 64; y++) {
				let id = 0;
				if (y === 0 || y === 63) id = 9;
				else if (y >= ceil) id = 62;
				else if (y > h) id = y <= 11 ? 18 : 0;
				else if (this.noise3(wx * .08, y * .09, wz * .08) > .74 && y > 14 && y < h - 2) id = 0;
				else id = 62;
				data[this.index(x, y, z)] = id;
			}
		}
		for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) for (let y = 2; y < 20; y++) if (this.getLocal(data, x, y, z) === 18) this.scheduleLavaAround(ox + x, y, oz + z);
		this.stampFortress(data, cx, cz);
		return data;
	}
	generate(cx, cz) {
		const data = /* @__PURE__ */ new Uint8Array(16384);
		const ox = cx * 16;
		const oz = cz * 16;
		const trees = [];
		const cacti = [];
		for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
			const wx = ox + x;
			const wz = oz + z;
			const biome = this.biomeAt(wx, wz);
			const h = this.heightAt(wx, wz);
			for (let y = 0; y < 64; y++) {
				let id = 0;
				if (y === 0) id = 9;
				else if (y > h) {
					if (y <= 18 && (biome === 0 || h < 18)) id = 12;
					else id = 0;
				} else if (y === h) {
					if (biome === 0) id = 10;
					else if (biome === 3) id = 10;
					else if (biome === 4) id = 11;
					else id = 1;
				} else if (y >= h - 3) {
					if (biome === 0 || biome === 3) id = hash2(wx, y * 13 + wz, this.seed) < .42 ? 17 : 10;
					else id = 2;
				} else {
					id = 3;
					if (this.noise3(wx * .055, y * .07, wz * .055) > .8 && y > 5 && y < h - 6) {
						id = 0;
						const caveBelow = this.noise3(wx * .055, (y - 1) * .07, wz * .055);
						if (y <= 11 && (y <= 6 || caveBelow <= .8)) {
							if (this.noise3(wx * .09 + 7, y * .12, wz * .09) > .08) id = 18;
						}
					} else {
						const ore = this.noise3(wx * .13 + 40, y * .13, wz * .13);
						if (y < 8 && ore > .8) id = 19;
						else if (y < 10 && ore > .72) id = 8;
						else if (y < 14 && ore > .69) id = 16;
						else if (y < 16 && ore > .66) id = 7;
						else if (y < 22 && ore > .58) id = 15;
						else if (y < 28 && ore > .6) id = 6;
					}
				}
				data[x + z * 16 + y * 16 * 16] = id;
			}
			const top = this.getLocal(data, x, h, z);
			const roll = hash2(wx, wz, this.seed);
			if (biome === 2 && top === 1 && roll < .085) trees.push([
				x,
				h,
				z,
				biome
			]);
			else if (biome === 1 && top === 1 && roll < .016) trees.push([
				x,
				h,
				z,
				biome
			]);
			else if (biome === 4 && top === 11 && roll < .03) trees.push([
				x,
				h,
				z,
				biome
			]);
			else if (biome === 3 && top === 10 && h >= 18 && roll < .005) cacti.push([
				x,
				h,
				z
			]);
		}
		for (const t of trees) this.plantTree(data, cx, cz, t[0], t[1], t[2], t[3]);
		for (const c of cacti) this.plantCactus(data, c[0], c[1], c[2]);
		for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) for (let y = 2; y < 14; y++) if (this.getLocal(data, x, y, z) === 18) this.scheduleLavaAround(ox + x, y, oz + z);
		this.stampStronghold(data, cx, cz);
		return data;
	}
	putCell(data, ox, oz, x, y, z, id) {
		const lx = x - ox;
		const lz = z - oz;
		if (lx < 0 || lz < 0 || lx >= 16 || lz >= 16 || y < 1 || y >= 63) return;
		this.setLocal(data, lx, y, lz, id);
	}
	buryStrongholds() {
		for (const room of this.rooms) {
			let placed = false;
			for (let ring = 0; ring <= 160 && !placed; ring += 10) {
				const steps = ring === 0 ? 1 : 10;
				for (let i = 0; i < steps; i++) {
					const a = i / steps * Math.PI * 2 + room.x * .01;
					const tx = Math.round(room.x + Math.cos(a) * ring);
					const tz = Math.round(room.z + Math.sin(a) * ring);
					const spots = [
						[tx + 6, tz + 6],
						[tx + 16, tz + 6],
						[tx + 2, tz + 2],
						[tx + 20, tz + 10]
					];
					if (spots.some(([sx, sz]) => this.biomeAt(sx, sz) === 0)) continue;
					const minH = Math.min(...spots.map(([sx, sz]) => this.heightAt(sx, sz)));
					if (minH < 21) continue;
					room.x = tx;
					room.z = tz;
					room.y = Math.max(5, minH - 15);
					placed = true;
					break;
				}
			}
			if (!placed) {
				const h = this.heightAt(room.x + 6, room.z + 6);
				room.y = Math.max(4, Math.min(h, 16) - 12);
			}
		}
	}
	capRoof(data, ox, oz, x, z, roof) {
		for (let y = roof + 1; y <= roof + 4; y++) {
			const lx = x - ox;
			const lz = z - oz;
			if (lx < 0 || lz < 0 || lx >= 16 || lz >= 16 || y >= 63) continue;
			const cur = this.getLocal(data, lx, y, lz);
			if (cur === 12 || cur === 0) this.setLocal(data, lx, y, lz, 3);
		}
	}
	stampStronghold(data, cx, cz) {
		const ox = cx * 16;
		const oz = cz * 16;
		for (const room of this.rooms) {
			if (room.x + 28 < ox || room.x > ox + 16 + 2) continue;
			if (room.z + 14 < oz || room.z > oz + 16 + 2) continue;
			for (let dy = 0; dy <= 6; dy++) for (let dz = 0; dz <= 12; dz++) for (let dx = 0; dx <= 12; dx++) {
				const edge = dx === 0 || dx === 12 || dz === 0 || dz === 12 || dy === 0 || dy === 6;
				const door = dz === 0 && dx >= 5 && dx <= 7 && dy >= 1 && dy <= 3;
				const toLib = dx === 12 && dz >= 5 && dz <= 7 && dy >= 1 && dy <= 3;
				let id = 0;
				if (edge && !door && !toLib) id = 3;
				if (dy === 0 && dx >= 4 && dx <= 7 && dz >= 4 && dz <= 7) id = 18;
				this.putCell(data, ox, oz, room.x + dx, room.y + dy, room.z + dz, id);
			}
			for (const [x, y, z] of frameSpots(room)) this.putCell(data, ox, oz, x, y, z, 65);
			for (let x = room.x; x <= room.x + 12; x++) for (let z = room.z; z <= room.z + 12; z++) this.capRoof(data, ox, oz, x, z, room.y + 6);
			for (let dy = 0; dy <= 5; dy++) for (let dz = 0; dz <= 8; dz++) for (let dx = 0; dx <= 8; dx++) {
				const edge = dx === 0 || dx === 8 || dz === 0 || dz === 8 || dy === 0 || dy === 5;
				const door = dx === 0 && dz >= 3 && dz <= 5 && dy >= 1 && dy <= 3;
				let id = 0;
				if (edge && !door) id = dy >= 1 && dy <= 3 && dy !== 5 ? 64 : 3;
				if (dy === 0 || dy === 5) id = 3;
				if (door) id = 0;
				this.putCell(data, ox, oz, room.x + 12 + dx, room.y + dy, room.z + 2 + dz, id);
			}
			for (let x = room.x + 12; x <= room.x + 20; x++) for (let z = room.z + 2; z <= room.z + 10; z++) this.capRoof(data, ox, oz, x, z, room.y + 5);
			const key = `${room.x},${room.z}`;
			if (!this.looted.has(key)) {
				this.looted.add(key);
				this.loot.push({
					x: room.x + 18,
					y: room.y + 1,
					z: room.z + 6,
					id: 50,
					count: 4
				}, {
					x: room.x + 17,
					y: room.y + 1,
					z: room.z + 5,
					id: 51,
					count: 2
				}, {
					x: room.x + 19,
					y: room.y + 1,
					z: room.z + 7,
					id: 8,
					count: 1
				}, {
					x: room.x + 18,
					y: room.y + 1,
					z: room.z + 4,
					id: 82,
					count: 1
				});
			}
		}
	}
	stampFortress(data, cx, cz) {
		const ox = cx * 16;
		const oz = cz * 16;
		for (const fort of this.forts) {
			if (Math.abs(fort.x - (ox + 8)) > 40 || Math.abs(fort.z - (oz + 8)) > 40) continue;
			const carve = (x, z) => {
				if (Math.abs(x - fort.x) > 30 && Math.abs(z - fort.z) > 30) return;
				const onX = Math.abs(z - fort.z) <= 2 && Math.abs(x - fort.x) <= 28;
				const onZ = Math.abs(x - fort.x) <= 2 && Math.abs(z - fort.z) <= 28;
				const room = Math.abs(x - fort.x) <= 4 && Math.abs(z - fort.z) <= 4;
				if (!onX && !onZ && !room) return;
				for (let dy = 0; dy <= 5; dy++) {
					const edge = dy === 0 || dy === 5 || onX && Math.abs(z - fort.z) === 2 || onZ && Math.abs(x - fort.x) === 2 || room && (Math.abs(x - fort.x) === 4 || Math.abs(z - fort.z) === 4);
					const inside = room && Math.abs(x - fort.x) < 4 && Math.abs(z - fort.z) < 4;
					const id = edge && !(inside && dy > 0 && dy < 5) ? 63 : 0;
					this.putCell(data, ox, oz, x, fort.y + dy, z, dy === 0 ? 63 : id);
				}
			};
			for (let x = ox - 1; x < ox + 16 + 1; x++) for (let z = oz - 1; z < oz + 16 + 1; z++) carve(x, z);
		}
	}
	plantTree(data, cx, cz, lx, ground, lz, biome) {
		const ox = cx * 16;
		const oz = cz * 16;
		const topId = this.getLocal(data, lx, ground, lz);
		if (topId !== 1 && topId !== 11) return;
		const spruce = biome === 4;
		const h = spruce ? 6 + Math.floor(hash2(ox + lx, oz + lz, this.seed + 9) * 3) : 4 + Math.floor(hash2(ox + lx, oz + lz, this.seed + 9) * 2);
		for (let i = 1; i <= h; i++) this.setLocal(data, lx, ground + i, lz, 4);
		const top = ground + h;
		const rad = spruce ? 2 : 2;
		for (let dy = spruce ? -3 : -2; dy <= 2; dy++) for (let dx = -rad; dx <= rad; dx++) for (let dz = -rad; dz <= rad; dz++) {
			if (spruce) {
				const layer = Math.abs(dy);
				const r = layer <= 0 ? 0 : layer === 1 ? 1 : 2;
				if (Math.abs(dx) > r || Math.abs(dz) > r) continue;
				if (Math.abs(dx) === r && Math.abs(dz) === r && r > 0) continue;
			} else if (Math.abs(dx) === 2 && Math.abs(dz) === 2 && dy < 1) continue;
			const x = lx + dx;
			const y = top + dy;
			const z = lz + dz;
			if (x < 0 || z < 0 || x >= 16 || z >= 16 || y < 0 || y >= 64) continue;
			if (this.getLocal(data, x, y, z) === 0) this.setLocal(data, x, y, z, 5);
		}
	}
	plantCactus(data, lx, ground, lz) {
		if (ground < 18) return;
		if (this.getLocal(data, lx, ground, lz) !== 10) return;
		if (this.getLocal(data, lx, ground + 1, lz) !== 0) return;
		for (const [dx, dz] of [
			[1, 0],
			[-1, 0],
			[0, 1],
			[0, -1]
		]) {
			const n = this.getLocal(data, lx + dx, ground + 1, lz + dz);
			if (n === 12 || n === 14) return;
		}
		const h = 2 + Math.floor(hash2(lx, lz, this.seed + 3) * 2);
		for (let i = 1; i <= h; i++) {
			if (ground + i >= 64) break;
			if (this.getLocal(data, lx, ground + i, lz) !== 0) break;
			this.setLocal(data, lx, ground + i, lz, 14);
		}
	}
	index(x, y, z) {
		return x + z * 16 + y * 16 * 16;
	}
	getLocal(data, x, y, z) {
		if (y < 0 || y >= 64 || x < 0 || z < 0 || x >= 16 || z >= 16) return 0;
		return data[this.index(x, y, z)] ?? 0;
	}
	setLocal(data, x, y, z, id) {
		if (y < 0 || y >= 64 || x < 0 || z < 0 || x >= 16 || z >= 16) return;
		data[this.index(x, y, z)] = id;
	}
	getBlock(x, y, z) {
		if (y < 0) return this.kind === "end" ? 0 : 9;
		if (y >= 64) return 0;
		const [cx, cz, lx, lz] = worldToChunk(x, z);
		const data = this.chunks.get(chunkKey(cx, cz));
		if (!data) return 0;
		return data[this.index(lx, y, lz)] ?? 0;
	}
	setBlock(x, y, z, id) {
		if (y < 0 || y >= 64) return false;
		const [cx, cz, lx, lz] = worldToChunk(x, z);
		const data = this.ensureChunk(cx, cz);
		const i = this.index(lx, y, lz);
		const prev = data[i] ?? 0;
		if (prev === id) return false;
		if (prev === 12 && id === 18 || prev === 18 && id === 12) {
			data[i] = 0;
			this.flow.delete(this.cellKey(x, y, z));
			this.lavaFlow.delete(this.cellKey(x, y, z));
			this.markDirty(cx, cz, lx, lz);
			this.scheduleWaterAround(x, y, z);
			this.scheduleLavaAround(x, y, z);
			return true;
		}
		data[i] = id;
		if (prev === 12 || id !== 12) this.flow.delete(this.cellKey(x, y, z));
		if (prev === 18 || id !== 18) this.lavaFlow.delete(this.cellKey(x, y, z));
		this.markDirty(cx, cz, lx, lz);
		this.scheduleWaterAround(x, y, z);
		this.scheduleLavaAround(x, y, z);
		this.mixFluids(x, y, z);
		return true;
	}
	markDirty(cx, cz, lx, lz) {
		this.dirty.add(chunkKey(cx, cz));
		if (lx === 0) this.dirty.add(chunkKey(cx - 1, cz));
		if (lx === 15) this.dirty.add(chunkKey(cx + 1, cz));
		if (lz === 0) this.dirty.add(chunkKey(cx, cz - 1));
		if (lz === 15) this.dirty.add(chunkKey(cx, cz + 1));
	}
	mixFluids(x, y, z) {
		const id = this.getBlock(x, y, z);
		if (id !== 12 && id !== 18) return;
		const other = id === 12 ? 18 : 12;
		for (const [dx, dy, dz] of [
			[
				1,
				0,
				0
			],
			[
				-1,
				0,
				0
			],
			[
				0,
				1,
				0
			],
			[
				0,
				-1,
				0
			],
			[
				0,
				0,
				1
			],
			[
				0,
				0,
				-1
			]
		]) {
			const nx = x + dx;
			const ny = y + dy;
			const nz = z + dz;
			if (this.getBlock(nx, ny, nz) === other) {
				this.clearFluid(x, y, z);
				this.clearFluid(nx, ny, nz);
				return;
			}
		}
	}
	clearFluid(x, y, z) {
		if (y < 0 || y >= 64) return;
		const [cx, cz, lx, lz] = worldToChunk(x, z);
		const data = this.chunks.get(chunkKey(cx, cz));
		if (!data) return;
		const i = this.index(lx, y, lz);
		const prev = data[i] ?? 0;
		if (prev !== 12 && prev !== 18) return;
		data[i] = 0;
		this.flow.delete(this.cellKey(x, y, z));
		this.lavaFlow.delete(this.cellKey(x, y, z));
		this.markDirty(cx, cz, lx, lz);
		this.scheduleWaterAround(x, y, z);
		this.scheduleLavaAround(x, y, z);
	}
	cellKey(x, y, z) {
		return `${x},${y},${z}`;
	}
	setSource(x, y, z) {
		x = Math.floor(x);
		y = Math.floor(y);
		z = Math.floor(z);
		const id = this.getBlock(x, y, z);
		if (id === 12) {
			this.setFlow(x, y, z, 7);
			this.scheduleWaterAround(x, y, z);
		} else if (id === 18) {
			this.setLavaFlow(x, y, z, 7);
			this.scheduleLavaAround(x, y, z);
		}
	}
	isWaterSource(x, y, z) {
		if (this.getBlock(x, y, z) !== 12) return false;
		const raw = this.flow.get(this.cellKey(x, y, z));
		return raw === void 0 || raw === 7;
	}
	isLavaSource(x, y, z) {
		if (this.getBlock(x, y, z) !== 18) return false;
		const raw = this.lavaFlow.get(this.cellKey(x, y, z));
		return raw === void 0 || raw === 7;
	}
	waterLevel(x, y, z) {
		if (this.getBlock(x, y, z) !== 12) return -1;
		const raw = this.flow.get(this.cellKey(x, y, z));
		if (raw === void 0 || raw === 7) return 7;
		if (raw >= 8) return Math.min(6, raw - 8);
		return raw;
	}
	waterHeight(x, y, z) {
		if (this.getBlock(x, y, z) !== 12) return 0;
		const raw = this.flow.get(this.cellKey(x, y, z)) ?? 7;
		if (raw >= 8) return 1;
		if (raw === 7) return .9;
		return Math.max(.12, (raw + 1) / 8);
	}
	scheduleWater(x, y, z) {
		if (y < 1 || y >= 64) return;
		this.pendingWater.add(this.cellKey(x, y, z));
	}
	scheduleWaterAround(x, y, z) {
		this.scheduleWater(x, y, z);
		this.scheduleWater(x + 1, y, z);
		this.scheduleWater(x - 1, y, z);
		this.scheduleWater(x, y, z + 1);
		this.scheduleWater(x, y, z - 1);
		this.scheduleWater(x, y + 1, z);
		this.scheduleWater(x, y - 1, z);
	}
	setFlow(x, y, z, level) {
		this.flow.set(this.cellKey(x, y, z), level);
		const [cx, cz] = worldToChunk(x, z);
		this.dirty.add(chunkKey(cx, cz));
	}
	flowPower(raw) {
		if (raw === void 0) return 7;
		if (raw >= 8) return raw - 8;
		return raw;
	}
	flowRank(raw) {
		if (raw === void 0 || raw === 7) return 70;
		if (raw >= 8) return raw - 8;
		return raw;
	}
	placeFlow(x, y, z, level) {
		if (y < 1 || y >= 64) return;
		const id = this.getBlock(x, y, z);
		if (id === 18) {
			this.clearFluid(x, y, z);
			return;
		}
		if (id !== 0 && id !== 12) return;
		if (id === 12 && this.flowRank(this.flow.get(this.cellKey(x, y, z))) >= this.flowRank(level)) return;
		if (id !== 12) this.setBlock(x, y, z, 12);
		this.setFlow(x, y, z, level);
		this.scheduleWaterAround(x, y, z);
	}
	expectedWater(x, y, z) {
		if (this.getBlock(x, y + 1, z) === 12) return this.flowPower(this.flow.get(this.cellKey(x, y + 1, z))) + 8;
		let best = -1;
		for (const [dx, dz] of [
			[1, 0],
			[-1, 0],
			[0, 1],
			[0, -1]
		]) {
			const nx = x + dx;
			const nz = z + dz;
			if (this.getBlock(nx, y, nz) !== 12) continue;
			if (this.getBlock(nx, y - 1, nz) === 0) continue;
			const power = this.flowPower(this.flow.get(this.cellKey(nx, y, nz)));
			if (power <= 0) continue;
			best = Math.max(best, power - 1);
		}
		return best;
	}
	tryInfiniteWater(x, y, z) {
		if (!isSolid(this.getBlock(x, y - 1, z))) return;
		let sources = 0;
		for (const [dx, dz] of [
			[1, 0],
			[-1, 0],
			[0, 1],
			[0, -1]
		]) if (this.isWaterSource(x + dx, y, z + dz)) sources++;
		if (sources < 2) return;
		this.setBlock(x, y, z, 12);
		this.setFlow(x, y, z, 7);
		this.scheduleWaterAround(x, y, z);
	}
	tickWater(budget = 40) {
		if (!this.pendingWater.size) return;
		const queue = [...this.pendingWater];
		this.pendingWater.clear();
		let n = 0;
		for (const k of queue) {
			if (n++ >= budget) {
				this.pendingWater.add(k);
				continue;
			}
			const p = k.split(",").map(Number);
			this.updateWaterCell(p[0], p[1], p[2]);
		}
	}
	lavaLevel(x, y, z) {
		if (this.getBlock(x, y, z) !== 18) return -1;
		const raw = this.lavaFlow.get(this.cellKey(x, y, z));
		if (raw === void 0 || raw === 7) return 7;
		if (raw >= 8) return Math.min(6, raw - 8);
		return raw;
	}
	lavaHeight(x, y, z) {
		if (this.getBlock(x, y, z) !== 18) return 0;
		const raw = this.lavaFlow.get(this.cellKey(x, y, z)) ?? 7;
		if (raw >= 8) return 1;
		if (raw === 7) return .92;
		return Math.max(.18, (raw + 1) / 9);
	}
	scheduleLava(x, y, z) {
		if (y < 1 || y >= 64) return;
		this.pendingLava.add(this.cellKey(x, y, z));
	}
	scheduleLavaAround(x, y, z) {
		this.scheduleLava(x, y, z);
		this.scheduleLava(x + 1, y, z);
		this.scheduleLava(x - 1, y, z);
		this.scheduleLava(x, y, z + 1);
		this.scheduleLava(x, y, z - 1);
		this.scheduleLava(x, y + 1, z);
		this.scheduleLava(x, y - 1, z);
	}
	tickLava(budget = 24) {
		if (!this.pendingLava.size) return;
		const queue = [...this.pendingLava];
		this.pendingLava.clear();
		let n = 0;
		for (const k of queue) {
			if (n++ >= budget) {
				this.pendingLava.add(k);
				continue;
			}
			const p = k.split(",").map(Number);
			this.updateLavaCell(p[0], p[1], p[2]);
		}
	}
	setLavaFlow(x, y, z, level) {
		this.lavaFlow.set(this.cellKey(x, y, z), level);
		const [cx, cz] = worldToChunk(x, z);
		this.dirty.add(chunkKey(cx, cz));
	}
	placeLava(x, y, z, level) {
		if (y < 1 || y >= 64) return;
		const id = this.getBlock(x, y, z);
		if (id === 12) {
			this.clearFluid(x, y, z);
			return;
		}
		if (id !== 0 && id !== 18) return;
		if (id === 18 && this.flowRank(this.lavaFlow.get(this.cellKey(x, y, z))) >= this.flowRank(level)) return;
		if (id !== 18) this.setBlock(x, y, z, 18);
		this.setLavaFlow(x, y, z, level);
		this.scheduleLavaAround(x, y, z);
	}
	expectedLava(x, y, z) {
		if (this.getBlock(x, y + 1, z) === 18) return this.flowPower(this.lavaFlow.get(this.cellKey(x, y + 1, z))) + 8;
		let best = -1;
		for (const [dx, dz] of [
			[1, 0],
			[-1, 0],
			[0, 1],
			[0, -1]
		]) {
			const nx = x + dx;
			const nz = z + dz;
			if (this.getBlock(nx, y, nz) !== 18) continue;
			if (this.getBlock(nx, y - 1, nz) === 0) continue;
			const power = this.flowPower(this.lavaFlow.get(this.cellKey(nx, y, nz)));
			if (power <= 0) continue;
			best = Math.max(best, power - 1);
		}
		return best;
	}
	updateLavaCell(x, y, z) {
		if (this.getBlock(x, y, z) !== 18) return;
		this.mixFluids(x, y, z);
		if (this.getBlock(x, y, z) !== 18) return;
		const key = this.cellKey(x, y, z);
		const stored = this.lavaFlow.get(key);
		if (!(stored === void 0 || stored === 7)) {
			const expect = this.expectedLava(x, y, z);
			if (expect < 0) {
				this.setBlock(x, y, z, 0);
				return;
			}
			if (stored !== expect) this.setLavaFlow(x, y, z, expect);
		}
		const power = this.flowPower(this.lavaFlow.get(key));
		const below = this.getBlock(x, y - 1, z);
		if (below === 12) {
			this.clearFluid(x, y - 1, z);
			return;
		}
		if (below === 0) {
			this.placeLava(x, y - 1, z, power + 8);
			return;
		}
		if (power <= 0) return;
		const next = power - 1;
		this.placeLava(x + 1, y, z, next);
		this.placeLava(x - 1, y, z, next);
		this.placeLava(x, y, z + 1, next);
		this.placeLava(x, y, z - 1, next);
	}
	updateWaterCell(x, y, z) {
		const id = this.getBlock(x, y, z);
		if (id === 0) {
			this.tryInfiniteWater(x, y, z);
			return;
		}
		if (id !== 12) return;
		this.mixFluids(x, y, z);
		if (this.getBlock(x, y, z) !== 12) return;
		const key = this.cellKey(x, y, z);
		const stored = this.flow.get(key);
		if (!(stored === void 0 || stored === 7)) {
			const expect = this.expectedWater(x, y, z);
			if (expect < 0) {
				this.setBlock(x, y, z, 0);
				return;
			}
			if (stored !== expect) this.setFlow(x, y, z, expect);
		}
		const power = this.flowPower(this.flow.get(key));
		if (this.getBlock(x, y - 1, z) === 0) {
			this.placeFlow(x, y - 1, z, power + 8);
			return;
		}
		if (power <= 0) return;
		const next = power - 1;
		this.placeFlow(x + 1, y, z, next);
		this.placeFlow(x - 1, y, z, next);
		this.placeFlow(x, y, z + 1, next);
		this.placeFlow(x, y, z - 1, next);
	}
	solid(x, y, z) {
		return isSolid(this.getBlock(Math.floor(x), Math.floor(y), Math.floor(z)));
	}
	opaque(x, y, z) {
		return isOpaque(this.getBlock(x, y, z));
	}
	unloadFar(pcx, pcz, radius) {
		const removed = [];
		for (const k of this.chunks.keys()) {
			const [cx, cz] = k.split(",").map(Number);
			if (Math.max(Math.abs(cx - pcx), Math.abs(cz - pcz)) > radius + 1) {
				this.chunks.delete(k);
				this.dirty.delete(k);
				removed.push(k);
			}
		}
		return removed;
	}
	applyEdits(edits) {
		for (const [x, y, z, id] of edits) {
			this.ensureChunk(Math.floor(x / 16), Math.floor(z / 16));
			this.setBlock(x, y, z, id);
		}
	}
};
var SHADE = [
	.78,
	.78,
	1,
	.55,
	.86,
	.7
];
var FACES = [
	{
		dx: 1,
		dy: 0,
		dz: 0,
		corners: [
			[
				1,
				1,
				1
			],
			[
				1,
				1,
				0
			],
			[
				1,
				0,
				1
			],
			[
				1,
				0,
				0
			]
		],
		uv: [
			[0, 0],
			[1, 0],
			[0, 1],
			[1, 1]
		]
	},
	{
		dx: -1,
		dy: 0,
		dz: 0,
		corners: [
			[
				0,
				1,
				0
			],
			[
				0,
				1,
				1
			],
			[
				0,
				0,
				0
			],
			[
				0,
				0,
				1
			]
		],
		uv: [
			[0, 0],
			[1, 0],
			[0, 1],
			[1, 1]
		]
	},
	{
		dx: 0,
		dy: 1,
		dz: 0,
		corners: [
			[
				0,
				1,
				0
			],
			[
				1,
				1,
				0
			],
			[
				0,
				1,
				1
			],
			[
				1,
				1,
				1
			]
		],
		uv: [
			[1, 1],
			[0, 1],
			[1, 0],
			[0, 0]
		]
	},
	{
		dx: 0,
		dy: -1,
		dz: 0,
		corners: [
			[
				0,
				0,
				1
			],
			[
				1,
				0,
				1
			],
			[
				0,
				0,
				0
			],
			[
				1,
				0,
				0
			]
		],
		uv: [
			[1, 0],
			[0, 0],
			[1, 1],
			[0, 1]
		]
	},
	{
		dx: 0,
		dy: 0,
		dz: 1,
		corners: [
			[
				0,
				1,
				1
			],
			[
				1,
				1,
				1
			],
			[
				0,
				0,
				1
			],
			[
				1,
				0,
				1
			]
		],
		uv: [
			[0, 0],
			[1, 0],
			[0, 1],
			[1, 1]
		]
	},
	{
		dx: 0,
		dy: 0,
		dz: -1,
		corners: [
			[
				1,
				1,
				0
			],
			[
				0,
				1,
				0
			],
			[
				1,
				0,
				0
			],
			[
				0,
				0,
				0
			]
		],
		uv: [
			[0, 0],
			[1, 0],
			[0, 1],
			[1, 1]
		]
	}
];
function pushFace(positions, normals, uvs, colors, indices, x, y, z, fi, atlas, centered) {
	const face = FACES[fi];
	const shade = SHADE[fi];
	const base = positions.length / 3;
	for (let i = 0; i < 4; i++) {
		const c = face.corners[i];
		const ox = centered ? c[0] - .5 : x + c[0];
		const oy = centered ? c[1] - .5 : y + c[1];
		const oz = centered ? c[2] - .5 : z + c[2];
		positions.push(ox, oy, oz);
		normals.push(face.dx, face.dy, face.dz);
		const su = face.uv[i][0];
		const sv = face.uv[i][1];
		const [uu, vv] = atlasFaceUV(atlas, fi, su, sv);
		uvs.push(uu, vv);
		colors.push(shade, shade, shade);
	}
	indices.push(base, base + 2, base + 1, base + 2, base + 3, base + 1);
}
function meshChunk(world, cx, cz) {
	const data = world.chunks.get(chunkKey(cx, cz));
	if (!data) return null;
	const ox = cx * 16;
	const oz = cz * 16;
	const positions = [];
	const normals = [];
	const uvs = [];
	const colors = [];
	const indices = [];
	const neighbor = (x, y, z) => {
		if (y < 0 || y >= 64) return y < 0 ? 9 : 0;
		if (x >= 0 && z >= 0 && x < 16 && z < 16) return data[x + z * 16 + y * 16 * 16] ?? 0;
		return world.getBlock(ox + x, y, oz + z);
	};
	for (let y = 0; y < 64; y++) for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
		const id = data[x + z * 16 + y * 16 * 16] ?? 0;
		if (id === 0 || id === 12 || id === 18 || id === 47 || id === 67 || id === 65 || id === 66) continue;
		const def = BLOCKS[id];
		if (!def) continue;
		for (let fi = 0; fi < FACES.length; fi++) {
			const face = FACES[fi];
			const nid = neighbor(x + face.dx, y + face.dy, z + face.dz);
			if (isOpaque(nid)) continue;
			if (nid === id && !def.opaque) continue;
			pushFace(positions, normals, uvs, colors, indices, ox + x, y, oz + z, fi, def.atlas, false);
		}
	}
	if (indices.length === 0) return null;
	const geo = new BufferGeometry();
	geo.setAttribute("position", new Float32BufferAttribute(positions, 3));
	geo.setAttribute("normal", new Float32BufferAttribute(normals, 3));
	geo.setAttribute("uv", new Float32BufferAttribute(uvs, 2));
	geo.setAttribute("color", new Float32BufferAttribute(colors, 3));
	geo.setIndex(indices);
	geo.computeBoundingSphere();
	return geo;
}
function makeBlockGeometry(blockId) {
	const def = BLOCKS[blockId] ?? BLOCKS[1];
	const positions = [];
	const normals = [];
	const uvs = [];
	const colors = [];
	const indices = [];
	for (let fi = 0; fi < FACES.length; fi++) pushFace(positions, normals, uvs, colors, indices, 0, 0, 0, fi, def.atlas, true);
	const geo = new BufferGeometry();
	geo.setAttribute("position", new Float32BufferAttribute(positions, 3));
	geo.setAttribute("normal", new Float32BufferAttribute(normals, 3));
	geo.setAttribute("uv", new Float32BufferAttribute(uvs, 2));
	geo.setAttribute("color", new Float32BufferAttribute(colors, 3));
	geo.setIndex(indices);
	return geo;
}
function meshWater(world, cx, cz) {
	return meshFluid(world, cx, cz, 12, (x, y, z) => world.waterHeight(x, y, z), [
		1,
		1,
		1
	]);
}
function meshLava(world, cx, cz) {
	return meshFluid(world, cx, cz, 18, (x, y, z) => world.lavaHeight(x, y, z), [
		1.2,
		.55,
		.18
	]);
}
function meshFluid(world, cx, cz, fluid, heightAt, shadeMul) {
	const data = world.chunks.get(chunkKey(cx, cz));
	if (!data) return null;
	const ox = cx * 16;
	const oz = cz * 16;
	const positions = [];
	const normals = [];
	const colors = [];
	const indices = [];
	const neighbor = (x, y, z) => {
		if (y < 0 || y >= 64) return y < 0 ? 9 : 0;
		if (x >= 0 && z >= 0 && x < 16 && z < 16) return data[x + z * 16 + y * 16 * 16] ?? 0;
		return world.getBlock(ox + x, y, oz + z);
	};
	const shade = [
		.7,
		.7,
		1,
		.45,
		.82,
		.62
	];
	for (let y = 0; y < 64; y++) for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
		if ((data[x + z * 16 + y * 16 * 16] ?? 0) !== fluid) continue;
		const h = neighbor(x, y + 1, z) === fluid ? 1 : heightAt(ox + x, y, oz + z);
		for (let fi = 0; fi < FACES.length; fi++) {
			const face = FACES[fi];
			const nid = neighbor(x + face.dx, y + face.dy, z + face.dz);
			if (nid === fluid || isOpaque(nid)) continue;
			const base = positions.length / 3;
			const s = shade[fi];
			const dip = .12 * Math.min(1, 1 - h);
			for (let i = 0; i < 4; i++) {
				const c = face.corners[i];
				const py = y + c[1] * h;
				positions.push(ox + x + c[0], py, oz + z + c[2]);
				normals.push(face.dx, face.dy, face.dz);
				colors.push(s * shadeMul[0] * (1 - dip), s * shadeMul[1] * (1 - dip * .4), s * shadeMul[2]);
			}
			indices.push(base, base + 2, base + 1, base + 2, base + 3, base + 1);
		}
	}
	if (indices.length === 0) return null;
	const geo = new BufferGeometry();
	geo.setAttribute("position", new Float32BufferAttribute(positions, 3));
	geo.setAttribute("normal", new Float32BufferAttribute(normals, 3));
	geo.setAttribute("color", new Float32BufferAttribute(colors, 3));
	geo.setIndex(indices);
	geo.computeBoundingSphere();
	return geo;
}
function meshPortal(world, cx, cz) {
	const data = world.chunks.get(chunkKey(cx, cz));
	if (!data) return null;
	const ox = cx * 16;
	const oz = cz * 16;
	const positions = [];
	const normals = [];
	const uvs = [];
	const colors = [];
	const indices = [];
	const neighbor = (x, y, z) => {
		if (y < 0 || y >= 64) return 0;
		if (x >= 0 && z >= 0 && x < 16 && z < 16) return data[x + z * 16 + y * 16 * 16] ?? 0;
		return world.getBlock(ox + x, y, oz + z);
	};
	for (let y = 0; y < 64; y++) for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
		const id = data[x + z * 16 + y * 16 * 16] ?? 0;
		if (id !== 47 && id !== 67) continue;
		const end = id === 67;
		for (let fi = 0; fi < FACES.length; fi++) {
			const face = FACES[fi];
			const nid = neighbor(x + face.dx, y + face.dy, z + face.dz);
			if (nid === id || isOpaque(nid)) continue;
			const base = positions.length / 3;
			for (let i = 0; i < 4; i++) {
				const c = face.corners[i];
				positions.push(ox + x + c[0], y + c[1], oz + z + c[2]);
				normals.push(face.dx, face.dy, face.dz);
				uvs.push(c[0], c[1]);
				colors.push(end ? .15 : .85, end ? .02 : .35, end ? .22 : 1);
			}
			indices.push(base, base + 2, base + 1, base + 2, base + 3, base + 1);
		}
	}
	if (!indices.length) return null;
	const geo = new BufferGeometry();
	geo.setAttribute("position", new Float32BufferAttribute(positions, 3));
	geo.setAttribute("normal", new Float32BufferAttribute(normals, 3));
	geo.setAttribute("uv", new Float32BufferAttribute(uvs, 2));
	geo.setAttribute("color", new Float32BufferAttribute(colors, 3));
	geo.setIndex(indices);
	geo.computeBoundingSphere();
	return geo;
}
var ParticlePool = class {
	mesh;
	dummy = new Object3D();
	items = [];
	max;
	constructor(material, max = 80) {
		this.max = max;
		const geo = new BoxGeometry(.12, .12, .12);
		this.mesh = new InstancedMesh(geo, material, max);
		this.mesh.frustumCulled = false;
		this.mesh.count = 0;
		this.mesh.instanceMatrix.setUsage(DynamicDrawUsage);
		this.mesh.visible = true;
	}
	burst(x, y, z, n = 10) {
		for (let i = 0; i < n; i++) {
			if (this.items.length >= this.max) this.items.shift();
			this.items.push({
				x: x + Math.random() * .6 + .2,
				y: y + Math.random() * .6 + .2,
				z: z + Math.random() * .6 + .2,
				vx: (Math.random() - .5) * 4,
				vy: Math.random() * 3 + 1.5,
				vz: (Math.random() - .5) * 4,
				life: 0,
				max: .45 + Math.random() * .35,
				scale: .7 + Math.random() * .6
			});
		}
	}
	update(dt) {
		const live = [];
		for (const p of this.items) {
			p.life += dt;
			if (p.life >= p.max) continue;
			p.vy -= 18 * dt;
			p.x += p.vx * dt;
			p.y += p.vy * dt;
			p.z += p.vz * dt;
			live.push(p);
		}
		this.items = live;
		const n = this.items.length;
		this.mesh.count = n;
		for (let i = 0; i < n; i++) {
			const p = this.items[i];
			const t = 1 - p.life / p.max;
			this.dummy.position.set(p.x, p.y, p.z);
			this.dummy.scale.setScalar(p.scale * t);
			this.dummy.rotation.set(p.life * 6, p.life * 4, 0);
			this.dummy.updateMatrix();
			this.mesh.setMatrixAt(i, this.dummy.matrix);
		}
		this.mesh.instanceMatrix.needsUpdate = true;
	}
	dispose() {
		this.mesh.geometry.dispose();
		this.mesh.material.dispose();
		this.mesh.removeFromParent();
	}
};
var WALK = 4.4;
var SPRINT = 6.4;
var SNEAK = 1.55;
var SWIM = 2.1;
var LAVA_MOVE = 1.15;
var GRAVITY$1 = 28;
var JUMP = 8.6;
var WIDTH = .6;
var HEIGHT = 1.8;
var SNEAK_HEIGHT = 1.5;
var EYE = 1.62;
var SNEAK_EYE = 1.22;
var STEP_UP = .55;
var WATER_STEP = 1.25;
var Player = class {
	x = .5;
	y = 40;
	z = .5;
	vx = 0;
	vy = 0;
	vz = 0;
	yaw = 0;
	pitch = 0;
	onGround = false;
	sprinting = false;
	sneaking = false;
	inWater = false;
	inLava = false;
	swimBob = 0;
	coyote = 0;
	jumpBuf = 0;
	bob = 0;
	dist = 0;
	dive = 0;
	swimT = 0;
	get eyeY() {
		return this.y + (this.sneaking && !this.inWater ? SNEAK_EYE : EYE) + this.swimBob;
	}
	halfW() {
		return WIDTH * .5;
	}
	height() {
		return this.sneaking && !this.inWater ? SNEAK_HEIGHT : HEIGHT;
	}
	setSpawn(x, y, z) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.vx = this.vy = this.vz = 0;
	}
	look(dx, dy, sensitivity) {
		this.yaw -= dx * .0022 * sensitivity;
		this.pitch -= dy * .0022 * sensitivity;
		const lim = Math.PI / 2 - .04;
		if (this.pitch > lim) this.pitch = lim;
		if (this.pitch < -lim) this.pitch = -lim;
	}
	forward() {
		return {
			x: -Math.sin(this.yaw),
			z: -Math.cos(this.yaw)
		};
	}
	right() {
		return {
			x: Math.cos(this.yaw),
			z: -Math.sin(this.yaw)
		};
	}
	sampleWater(world) {
		const ix = Math.floor(this.x);
		const iz = Math.floor(this.z);
		const feet = world.getBlock(ix, Math.floor(this.y + .35), iz);
		const mid = world.getBlock(ix, Math.floor(this.y + 1.05), iz);
		const head = world.getBlock(ix, Math.floor(this.y + 1.5), iz);
		this.inWater = isWater(feet) || isWater(mid) || isWater(head);
		this.inLava = isLava(feet) || isLava(mid) || isLava(head);
		return this.inWater;
	}
	step(dt, world, moveX, moveZ, jump, sneak, sprint, canSprint = true) {
		this.sampleWater(world);
		if (this.inWater) this.sneaking = sneak;
		else {
			const want = sneak;
			if (!want && this.sneaking) {
				const old = this.sneaking;
				this.sneaking = false;
				if (this.aabbHits(world, this.x, this.y, this.z)) this.sneaking = old;
			} else this.sneaking = want;
		}
		const f = this.forward();
		const r = this.right();
		const mag = Math.hypot(moveX, moveZ);
		let ix = 0;
		let iz = 0;
		if (mag > 1e-4) {
			const nx = moveX / mag;
			const nz = moveZ / mag;
			if (this.inWater) {
				const h = Math.cos(this.pitch);
				ix = f.x * nz * h + r.x * nx;
				iz = f.z * nz * h + r.z * nx;
				this.dive = nz * Math.sin(this.pitch);
			} else {
				ix = f.x * nz + r.x * nx;
				iz = f.z * nz + r.z * nx;
				this.dive = 0;
			}
		} else this.dive = 0;
		this.sprinting = sprint && canSprint && !this.sneaking && !this.inWater && !this.inLava && mag > .1;
		const speed = this.inLava ? LAVA_MOVE : this.inWater ? SWIM : this.sneaking ? SNEAK : this.sprinting ? SPRINT : WALK;
		const accel = this.inLava || this.inWater ? 14 : this.onGround ? 40 : 12;
		const targetX = ix * speed;
		const targetZ = iz * speed;
		this.vx += (targetX - this.vx) * Math.min(1, accel * dt);
		this.vz += (targetZ - this.vz) * Math.min(1, accel * dt);
		if (mag < .05 && this.onGround && !this.inWater) {
			this.vx *= Math.max(0, 1 - 12 * dt);
			this.vz *= Math.max(0, 1 - 12 * dt);
		}
		this.coyote = this.onGround ? .1 : Math.max(0, this.coyote - dt);
		if (jump) this.jumpBuf = .12;
		else this.jumpBuf = Math.max(0, this.jumpBuf - dt);
		if (this.inLava) {
			this.vy -= 6 * dt;
			if (this.vy > 1.2) this.vy = 1.2;
			if (this.vy < -1.8) this.vy = -1.8;
			if (jump) this.vy += 8 * dt;
			this.swimBob = Math.sin(this.swimT * 2.2) * .03;
			this.swimT += dt;
		} else if (this.inWater) {
			this.swimT += dt;
			const moving = mag > .12;
			if (moving && Math.abs(this.dive) > .12) {
				const targetVy = this.dive * speed;
				this.vy += (targetVy - this.vy) * Math.min(1, 8 * dt);
			} else if (jump) this.vy += 12 * dt;
			else if (this.sneaking) this.vy -= 8 * dt;
			else if (moving) this.vy += (.22 - this.vy) * Math.min(1, 5 * dt);
			else this.vy += (.45 - this.vy) * Math.min(1, 3 * dt);
			if (this.vy > 4.4) this.vy = 4.4;
			if (this.vy < -4.2) this.vy = -4.2;
			this.swimBob = moving ? Math.sin(this.swimT * 2.2) * .018 : Math.sin(this.swimT * 1.2) * .008;
		} else {
			this.swimBob *= Math.max(0, 1 - 8 * dt);
			this.vy -= GRAVITY$1 * dt;
			if (this.vy < -42) this.vy = -42;
			if (this.jumpBuf > 0 && this.coyote > 0) {
				this.vy = JUMP;
				this.onGround = false;
				this.coyote = 0;
				this.jumpBuf = 0;
			}
		}
		const steps = Math.max(1, Math.ceil(Math.hypot(this.vx, this.vy, this.vz) * dt / .2));
		const sdt = dt / steps;
		let landedHard = 0;
		for (let i = 0; i < steps; i++) {
			const ox = this.x;
			const oz = this.z;
			this.x += this.vx * sdt;
			this.resolve(world, "x", ox);
			if (this.sneaking && !this.inWater && this.onGround && !this.hasGround(world)) {
				this.x = ox;
				this.vx = 0;
			}
			this.z += this.vz * sdt;
			this.resolve(world, "z", oz);
			if (this.sneaking && !this.inWater && this.onGround && !this.hasGround(world)) {
				this.z = oz;
				this.vz = 0;
			}
			const beforeY = this.y;
			this.y += this.vy * sdt;
			const wasUp = this.vy;
			this.resolve(world, "y", beforeY);
			if (this.onGround && wasUp < -13 && beforeY > this.y - .01) landedHard = Math.max(landedHard, -wasUp);
		}
		const spd = Math.hypot(this.vx, this.vz);
		if (this.onGround && spd > .6 && !this.inWater) {
			this.dist += spd * dt * (this.sprinting ? .62 : 1);
			const amp = this.sprinting ? .28 : .7;
			this.bob = Math.sin(this.dist * 7.2) * Math.min(1, spd / WALK) * amp;
		} else this.bob *= Math.max(0, 1 - 10 * dt);
		return landedHard;
	}
	hasGround(world) {
		const hw = this.halfW() - .02;
		const y = Math.floor(this.y - .08);
		for (let z = Math.floor(this.z - hw); z <= Math.floor(this.z + hw); z++) for (let x = Math.floor(this.x - hw); x <= Math.floor(this.x + hw); x++) if (isSolid(world.getBlock(x, y, z))) return true;
		return false;
	}
	resolve(world, axis, prev) {
		const hw = this.halfW();
		const h = this.height();
		if (axis === "y") this.onGround = false;
		const minX = this.x - hw;
		const maxX = this.x + hw;
		const minY = this.y;
		const maxY = this.y + h;
		const minZ = this.z - hw;
		const maxZ = this.z + hw;
		const x0 = Math.floor(minX);
		const x1 = Math.floor(maxX);
		const y0 = Math.floor(minY);
		const y1 = Math.floor(maxY);
		const z0 = Math.floor(minZ);
		const z1 = Math.floor(maxZ);
		let pushPos = 0;
		let pushNeg = 0;
		let stepBlock = null;
		let bestStep = 99;
		for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) {
			const id = world.getBlock(x, y, z);
			if (!isSolid(id)) continue;
			const top = y + solidTop(id);
			if (maxX <= x || minX >= x + 1 || maxY <= y || minY >= top || maxZ <= z || minZ >= z + 1) continue;
			if (axis === "x" || axis === "z") {
				const step = top - this.y;
				if (step > 0 && step < bestStep) {
					bestStep = step;
					stepBlock = [
						x,
						y,
						z
					];
				}
			}
			if (axis === "x") {
				if (x + .5 >= this.x) pushNeg = Math.max(pushNeg, maxX - x);
				else pushPos = Math.max(pushPos, x + 1 - minX);
			} else if (axis === "z") {
				if (z + .5 >= this.z) pushNeg = Math.max(pushNeg, maxZ - z);
				else pushPos = Math.max(pushPos, z + 1 - minZ);
			} else if (top - .5 >= this.y + h * .5) pushNeg = Math.max(pushNeg, maxY - y);
			else pushPos = Math.max(pushPos, top - minY);
		}
		const wedged = pushPos > 1e-6 && pushNeg > 1e-6;
		if (axis !== "y" && stepBlock && this.tryStep(world, stepBlock[0], stepBlock[1], stepBlock[2])) return;
		if (wedged) {
			if (axis === "x") {
				this.x = prev;
				this.vx = 0;
			} else if (axis === "z") {
				this.z = prev;
				this.vz = 0;
			} else {
				this.y = prev;
				this.vy = 0;
				this.onGround = true;
			}
			return;
		}
		const EPS = 1e-4;
		if (axis === "x") {
			if (pushPos > 0) this.x += pushPos + EPS;
			else if (pushNeg > 0) this.x -= pushNeg + EPS;
			if (pushPos > 0 || pushNeg > 0) this.vx = 0;
		} else if (axis === "z") {
			if (pushPos > 0) this.z += pushPos + EPS;
			else if (pushNeg > 0) this.z -= pushNeg + EPS;
			if (pushPos > 0 || pushNeg > 0) this.vz = 0;
		} else if (pushPos > 0) {
			this.y += pushPos + EPS;
			this.vy = 0;
			this.onGround = true;
		} else if (pushNeg > 0) {
			this.y -= pushNeg + EPS;
			this.vy = 0;
		}
	}
	tryStep(world, bx, by, bz) {
		if (this.sneaking && !this.inWater) return false;
		if (!this.onGround && !this.inWater) return false;
		const hw = this.halfW();
		const step = by + solidTop(world.getBlock(bx, by, bz)) - this.y;
		const maxStep = this.inWater ? WATER_STEP : STEP_UP;
		if (step <= 0 || step > maxStep) return false;
		const ny = this.y + step + .01;
		if (this.aabbHits(world, this.x, ny, this.z, hw)) return false;
		if (isSolid(world.getBlock(bx, by + 1, bz))) return false;
		this.y = ny;
		if (this.inWater) this.vy = Math.max(this.vy, 2.2);
		return true;
	}
	aabbHits(world, x, y, z, hw = this.halfW()) {
		const minX = x - hw;
		const maxX = x + hw;
		const minY = y;
		const maxY = y + this.height();
		const minZ = z - hw;
		const maxZ = z + hw;
		for (let iy = Math.floor(minY); iy <= Math.floor(maxY); iy++) for (let iz = Math.floor(minZ); iz <= Math.floor(maxZ); iz++) for (let ix = Math.floor(minX); ix <= Math.floor(maxX); ix++) {
			const id = world.getBlock(ix, iy, iz);
			if (!isSolid(id)) continue;
			const top = iy + solidTop(id);
			if (maxY <= iy || minY >= top || maxX <= ix || minX >= ix + 1 || maxZ <= iz || minZ >= iz + 1) continue;
			return true;
		}
		return false;
	}
};
function voxelRaycast(world, ox, oy, oz, dx, dy, dz, maxDist, hitTest = isSolid) {
	const len = Math.hypot(dx, dy, dz) || 1;
	dx /= len;
	dy /= len;
	dz /= len;
	let x = Math.floor(ox);
	let y = Math.floor(oy);
	let z = Math.floor(oz);
	const stepX = dx > 0 ? 1 : dx < 0 ? -1 : 0;
	const stepY = dy > 0 ? 1 : dy < 0 ? -1 : 0;
	const stepZ = dz > 0 ? 1 : dz < 0 ? -1 : 0;
	const tDeltaX = stepX !== 0 ? Math.abs(1 / dx) : Infinity;
	const tDeltaY = stepY !== 0 ? Math.abs(1 / dy) : Infinity;
	const tDeltaZ = stepZ !== 0 ? Math.abs(1 / dz) : Infinity;
	const frac = (v, step) => step > 0 ? 1 - (v - Math.floor(v)) : v - Math.floor(v);
	let tMaxX = stepX !== 0 ? tDeltaX * frac(ox, stepX) : Infinity;
	let tMaxY = stepY !== 0 ? tDeltaY * frac(oy, stepY) : Infinity;
	let tMaxZ = stepZ !== 0 ? tDeltaZ * frac(oz, stepZ) : Infinity;
	let nx = 0;
	let ny = 0;
	let nz = 0;
	let t = 0;
	for (let i = 0; i < 96 && t <= maxDist; i++) {
		if (hitTest(world.getBlock(x, y, z))) return {
			x,
			y,
			z,
			nx,
			ny,
			nz,
			dist: t
		};
		if (tMaxX < tMaxY && tMaxX < tMaxZ) {
			x += stepX;
			t = tMaxX;
			tMaxX += tDeltaX;
			nx = -stepX;
			ny = 0;
			nz = 0;
		} else if (tMaxY < tMaxZ) {
			y += stepY;
			t = tMaxY;
			tMaxY += tDeltaY;
			nx = 0;
			ny = -stepY;
			nz = 0;
		} else {
			z += stepZ;
			t = tMaxZ;
			tMaxZ += tDeltaZ;
			nx = 0;
			ny = 0;
			nz = -stepZ;
		}
	}
	return null;
}
var KEY = "blokcraft-save-v1";
function defaults(seed) {
	return {
		version: 7,
		seed,
		x: .5,
		y: 40,
		z: .5,
		yaw: 0,
		pitch: 0,
		health: 20,
		food: 20,
		saturation: 5,
		worldTime: 80,
		hotbar: starterHotbar(),
		inventory: emptyGrid(27),
		armor: emptyGrid(4),
		offhand: null,
		edits: [],
		netherEdits: [],
		endEdits: [],
		dim: "overworld",
		owX: .5,
		owY: 40,
		owZ: .5,
		ndX: null,
		ndY: null,
		ndZ: null,
		settings: {
			sensitivity: 1.4,
			renderDistance: 4,
			volume: .7
		},
		drops: [],
		furnaces: [],
		homeX: .5,
		homeY: 40,
		homeZ: .5,
		bedX: null,
		bedY: null,
		bedZ: null,
		dragonHp: 200,
		crystalMask: 255,
		dragonDead: false,
		broken: 0,
		kills: 0,
		sawNether: false,
		id: "",
		name: "Dünya",
		monsters: true,
		bonus: false
	};
}
var SKINS = [
	12880482,
	14724201,
	9262372,
	3875860,
	15979189
];
var SHIRTS = [
	3894949,
	3107642,
	9056304,
	12886874,
	5913971,
	3815994
];
var PANTS = [
	2962244,
	1980975,
	4863784,
	2371652,
	4008506
];
var LOOK_KEY = "blokcraft-look";
var INDEX_KEY = "blokcraft-worlds";
function worldKey(id) {
	return `blokcraft-world-${id}`;
}
function loadLook() {
	try {
		const raw = localStorage.getItem(LOOK_KEY);
		const parsed = raw ? JSON.parse(raw) : null;
		return {
			skin: clampIndex(parsed?.skin, SKINS.length, 0),
			shirt: clampIndex(parsed?.shirt, SHIRTS.length, 0),
			pants: clampIndex(parsed?.pants, PANTS.length, 0)
		};
	} catch {
		return {
			skin: 0,
			shirt: 0,
			pants: 0
		};
	}
}
function saveLook(look) {
	try {
		localStorage.setItem(LOOK_KEY, JSON.stringify(look));
	} catch {}
}
function clampIndex(n, len, fallback) {
	return typeof n === "number" && n >= 0 && n < len ? Math.floor(n) : fallback;
}
function parseSeed(text) {
	const t = text.trim();
	if (!t) return Math.floor(Math.random() * 1e9) + 1;
	if (/^\d+$/.test(t)) {
		const n = Number(t);
		return n > 0 ? Math.floor(n) % 2147483646 || 1 : 1;
	}
	let h = 2166136261;
	for (let i = 0; i < t.length; i++) h = Math.imul(h ^ t.charCodeAt(i), 16777619);
	return (h >>> 0) % 2147483646 + 1;
}
function readIndex() {
	try {
		const raw = localStorage.getItem(INDEX_KEY);
		const parsed = raw ? JSON.parse(raw) : [];
		return Array.isArray(parsed) ? parsed.filter((c) => c && typeof c.id === "string") : [];
	} catch {
		return [];
	}
}
function writeIndex(cards) {
	localStorage.setItem(INDEX_KEY, JSON.stringify(cards));
}
function cardOf(data, prev) {
	return {
		id: data.id,
		name: data.name || "Dünya",
		seed: data.seed,
		created: prev?.created ?? Date.now(),
		updated: Date.now(),
		worldTime: data.worldTime
	};
}
function listWorlds() {
	migrateLegacy();
	return readIndex().sort((a, b) => b.updated - a.updated);
}
function loadWorld(id) {
	migrateLegacy();
	try {
		const raw = localStorage.getItem(worldKey(id));
		if (!raw) return null;
		const data = normalize(JSON.parse(raw));
		data.id = id;
		return data;
	} catch {
		return null;
	}
}
function createWorld(opts) {
	const id = Math.random().toString(36).slice(2, 10);
	const data = defaults(opts.seed);
	data.id = id;
	data.name = opts.name.trim().slice(0, 32) || "Yeni dünya";
	data.worldTime = opts.start === "night" ? 315 : opts.start === "dawn" ? 12 : 80;
	data.monsters = opts.monsters;
	data.bonus = opts.bonus;
	if (opts.bonus) {
		data.hotbar[0] = {
			id: 22,
			count: 1,
			dur: 59
		};
		data.hotbar[1] = {
			id: 13,
			count: 32
		};
		data.hotbar[2] = {
			id: 53,
			count: 8
		};
	}
	const cards = readIndex().filter((c) => c.id !== id);
	cards.unshift(cardOf(data));
	localStorage.setItem(worldKey(id), JSON.stringify(data));
	writeIndex(cards);
	return id;
}
function deleteWorld(id) {
	writeIndex(readIndex().filter((c) => c.id !== id));
	localStorage.removeItem(worldKey(id));
	if (id === "legacy") localStorage.removeItem(KEY);
}
function migrateLegacy() {
	if (readIndex().length) return;
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return;
		const data = normalize(JSON.parse(raw));
		data.id = "legacy";
		data.name = data.name && data.name !== "Dünya" ? data.name : "İlk dünya";
		localStorage.setItem(worldKey(data.id), JSON.stringify(data));
		writeIndex([cardOf(data)]);
	} catch {}
}
function newSave(seed) {
	return defaults(seed ?? Math.floor(Math.random() * 1e9) + 1);
}
function normalize(parsed) {
	const merged = {
		...defaults(typeof parsed?.seed === "number" ? parsed.seed : 1),
		...parsed,
		version: 7
	};
	if (!Array.isArray(merged.hotbar) || merged.hotbar.length !== 10) merged.hotbar = starterHotbar();
	if (!Array.isArray(merged.inventory) || merged.inventory.length !== 27) merged.inventory = emptyGrid(27);
	if (!Array.isArray(merged.armor) || merged.armor.length !== 4) merged.armor = emptyGrid(4);
	if (!Array.isArray(merged.edits)) merged.edits = [];
	if (!Array.isArray(merged.netherEdits)) merged.netherEdits = [];
	if (!Array.isArray(merged.endEdits)) merged.endEdits = [];
	if (merged.dim !== "nether" && merged.dim !== "end") merged.dim = "overworld";
	if (typeof merged.owX !== "number") merged.owX = merged.x;
	if (typeof merged.owY !== "number") merged.owY = merged.y;
	if (typeof merged.owZ !== "number") merged.owZ = merged.z;
	if (!Array.isArray(merged.drops)) merged.drops = [];
	if (!Array.isArray(merged.furnaces)) merged.furnaces = [];
	if (typeof merged.homeX !== "number") merged.homeX = merged.x;
	if (typeof merged.homeY !== "number") merged.homeY = merged.y;
	if (typeof merged.homeZ !== "number") merged.homeZ = merged.z;
	if (typeof merged.bedX !== "number") merged.bedX = null;
	if (typeof merged.bedY !== "number") merged.bedY = null;
	if (typeof merged.bedZ !== "number") merged.bedZ = null;
	if (typeof merged.dragonHp !== "number") merged.dragonHp = 200;
	if (typeof merged.crystalMask !== "number") merged.crystalMask = 255;
	if (typeof merged.dragonDead !== "boolean") merged.dragonDead = false;
	if (typeof merged.broken !== "number") merged.broken = 0;
	if (typeof merged.kills !== "number") merged.kills = 0;
	if (typeof merged.sawNether !== "boolean") merged.sawNether = false;
	if (typeof merged.id !== "string") merged.id = "";
	if (typeof merged.name !== "string" || !merged.name.trim()) merged.name = "Dünya";
	if (typeof merged.monsters !== "boolean") merged.monsters = true;
	if (typeof merged.bonus !== "boolean") merged.bonus = false;
	if (typeof merged.saturation !== "number") merged.saturation = 5;
	if ((parsed?.version ?? 0) < 3) {
		merged.hotbar = starterHotbar();
		merged.inventory = emptyGrid(27);
		merged.offhand = null;
	}
	return merged;
}
function loadSave() {
	const first = listWorlds()[0];
	return first ? loadWorld(first.id) : null;
}
function writeSave(data) {
	try {
		const id = data.id || "legacy";
		data.id = id;
		localStorage.setItem(worldKey(id), JSON.stringify({
			...data,
			version: 7
		}));
		const cards = readIndex();
		const prev = cards.find((c) => c.id === id);
		const next = cards.filter((c) => c.id !== id);
		next.unshift(cardOf({
			...data,
			id
		}, prev));
		writeIndex(next);
		if (id === "legacy") localStorage.setItem(KEY, JSON.stringify({
			...data,
			version: 7
		}));
	} catch {}
}
var emptySlots = (n) => Array.from({ length: n }, () => null);
var defaultHud = () => ({
	health: 20,
	food: 20,
	air: 10,
	hotbar: emptySlots(10),
	selectedSlot: 0,
	inventory: emptySlots(27),
	armor: emptySlots(4),
	offhand: null,
	dayPhase: .28,
	isDay: true,
	fps: 0,
	x: 0,
	y: 0,
	z: 0,
	yaw: 0,
	targetName: null,
	breaking: 0,
	held: null,
	canResume: false,
	biome: "Ova",
	sneaking: false,
	inWater: false,
	blocking: false,
	sleeping: false,
	sleep: 0,
	toast: null
});
var useGameStore = create((set) => ({
	phase: "title",
	loading: 0,
	hud: defaultHud(),
	settings: {
		sensitivity: 1.4,
		renderDistance: 4,
		volume: .7
	},
	isMobile: false,
	pointerLocked: false,
	clickToPlay: false,
	loadError: null,
	setPhase: (phase) => set({ phase }),
	setLoading: (loading) => set({ loading }),
	patchHud: (p) => set((s) => ({ hud: {
		...s.hud,
		...p
	} })),
	setSettings: (s) => set((st) => ({ settings: {
		...st.settings,
		...s
	} })),
	setMobile: (isMobile) => set({ isMobile }),
	setPointerLocked: (pointerLocked) => set({ pointerLocked }),
	setClickToPlay: (clickToPlay) => set({ clickToPlay }),
	setLoadError: (loadError) => set({ loadError }),
	resetHud: () => set({
		hud: defaultHud(),
		loading: 0,
		clickToPlay: false,
		pointerLocked: false
	})
}));
var gameStore = useGameStore;
var BoatWorld = class {
	group = new Group();
	boats = [];
	next = 1;
	spawn(x, y, z) {
		const mesh = new Group();
		const hull = new Mesh(new BoxGeometry(.9, .28, 1.35), new MeshLambertMaterial({ color: 9067050 }));
		hull.position.y = .16;
		const rim = new Mesh(new BoxGeometry(1.02, .16, 1.48), new MeshLambertMaterial({ color: 7029024 }));
		rim.position.y = .32;
		mesh.add(hull, rim);
		mesh.position.set(x, y, z);
		this.group.add(mesh);
		const boat = {
			id: this.next++,
			x,
			y,
			z,
			vx: 0,
			vz: 0,
			vy: 0,
			yaw: 0,
			player: false,
			rider: null,
			mesh
		};
		this.boats.push(boat);
		return boat;
	}
	get playerBoat() {
		return this.boats.find((b) => b.player) ?? null;
	}
	drive(dt, mx, mz, yaw) {
		const b = this.playerBoat;
		if (!b) return;
		b.yaw = yaw;
		const f = mz * 7.4;
		const s = mx * 4.2;
		const tx = -Math.sin(yaw) * f + Math.cos(yaw) * s;
		const tz = -Math.cos(yaw) * f - Math.sin(yaw) * s;
		b.vx += (tx - b.vx) * Math.min(1, 6 * dt);
		b.vz += (tz - b.vz) * Math.min(1, 6 * dt);
	}
	dismountPlayer() {
		const b = this.playerBoat;
		if (!b) return;
		b.player = false;
		b.vx = 0;
		b.vz = 0;
	}
	mountPlayer(b) {
		for (const o of this.boats) o.player = false;
		if (b.rider) {
			b.rider.ride = 0;
			b.rider = null;
		}
		b.player = true;
	}
	ray(ox, oy, oz, dx, dy, dz, max = 4) {
		let best = null;
		for (const b of this.boats) {
			const vx = b.x - ox;
			const vy = b.y + .3 - oy;
			const vz = b.z - oz;
			const dist = Math.hypot(vx, vy, vz);
			if (dist > max || dist < .05) continue;
			if (vx / dist * dx + vy / dist * dy + vz / dist * dz < .72) continue;
			if (!best || dist < best.dist) best = {
				boat: b,
				dist
			};
		}
		return best;
	}
	update(dt, world, mobs) {
		for (const b of this.boats) {
			const sup = this.support(world, b);
			if (sup?.water) {
				b.vy = 0;
				b.y += (sup.y - b.y) * Math.min(1, 8 * dt);
			} else if (sup && b.y <= sup.y + .04) {
				b.y = sup.y;
				b.vy = 0;
			} else {
				b.vy -= 20 * dt;
				if (b.vy < -18) b.vy = -18;
				const next = b.y + b.vy * dt;
				if (sup && next < sup.y) {
					b.y = sup.y;
					b.vy = 0;
				} else b.y = next;
			}
			if (!b.player) {
				b.vx *= Math.max(0, 1 - 1.6 * dt);
				b.vz *= Math.max(0, 1 - 1.6 * dt);
			}
			const ox = b.x;
			b.x += b.vx * dt;
			if (this.blocked(world, b)) {
				b.x = ox;
				b.vx = 0;
			}
			const oz = b.z;
			b.z += b.vz * dt;
			if (this.blocked(world, b)) {
				b.z = oz;
				b.vz = 0;
			}
			b.mesh.position.set(b.x, b.y, b.z);
			b.mesh.rotation.y = b.yaw;
			if (b.rider) {
				if (b.rider.hp <= 0) {
					b.rider.ride = 0;
					b.rider = null;
				} else {
					b.rider.x = b.x;
					b.rider.y = b.y + .25;
					b.rider.z = b.z;
					b.rider.vx = 0;
					b.rider.vz = 0;
					b.rider.vy = 0;
				}
			}
		}
		for (const m of mobs) {
			if (m.ride) continue;
			for (const b of this.boats) {
				if (b.player || b.rider) continue;
				if (Math.hypot(m.x - b.x, m.z - b.z) < .9 && Math.abs(m.y - b.y) < 1.3) {
					b.rider = m;
					m.ride = b.id;
					break;
				}
			}
		}
	}
	support(world, b) {
		const ix = Math.floor(b.x);
		const iz = Math.floor(b.z);
		let y = Math.floor(b.y + .05);
		if (y < 1) y = 1;
		if (isSolid(world.getBlock(ix, y, iz))) return {
			y: y + 1,
			water: false
		};
		for (let i = 0; i < 8; i++) {
			const yy = y - i;
			if (yy < 1) break;
			const id = world.getBlock(ix, yy, iz);
			if (isWater(id)) {
				let s = yy;
				while (s < 62 && isWater(world.getBlock(ix, s + 1, iz))) s++;
				return {
					y: s + .16,
					water: true
				};
			}
			if (isSolid(id)) return {
				y: yy + 1,
				water: false
			};
		}
		return null;
	}
	blocked(world, b) {
		const y = Math.floor(b.y + .25);
		const r = .42;
		const spots = [
			[0, 0],
			[r, 0],
			[-.42, 0],
			[0, r],
			[0, -.42]
		];
		for (const [ox, oz] of spots) if (isSolid(world.getBlock(Math.floor(b.x + ox), y, Math.floor(b.z + oz)))) return true;
		return false;
	}
	clear() {
		for (const b of this.boats) {
			if (b.rider) b.rider.ride = 0;
			this.group.remove(b.mesh);
		}
		this.boats = [];
	}
};
var GRAVITY = 18;
var SURFACE = .08;
var PICK_DELAY = .85;
var PICK_RANGE = 1.15;
var LIFETIME = 300;
var DropWorld = class {
	group = new Group();
	items = [];
	blockMat;
	cache = /* @__PURE__ */ new Map();
	constructor(blockMat) {
		this.blockMat = blockMat;
	}
	spawn(x, y, z, id, count = 1, launch = true) {
		if (this.items.length > 80) {
			const old = this.items.shift();
			if (old) this.group.remove(old.mesh);
		}
		const mesh = this.makeMesh(id);
		mesh.position.set(x, y, z);
		this.group.add(mesh);
		this.items.push({
			x,
			y,
			z,
			vx: launch ? (Math.random() - .5) * .9 : 0,
			vy: launch ? 1.4 + Math.random() * .4 : 0,
			vz: launch ? (Math.random() - .5) * .9 : 0,
			id,
			count,
			age: 0,
			mesh,
			onGround: !launch
		});
	}
	load(list) {
		for (const d of list) this.spawn(d.x, d.y, d.z, d.id, d.count, false);
	}
	snapshot() {
		return this.items.map((e) => ({
			x: e.x,
			y: e.y,
			z: e.z,
			id: e.id,
			count: e.count
		}));
	}
	update(dt, world, px, py, pz, take) {
		if (dt > .08) dt = .08;
		const keep = [];
		const steps = Math.max(1, Math.ceil(dt / (1 / 90)));
		const h = dt / steps;
		for (const e of this.items) {
			e.age += dt;
			for (let s = 0; s < steps; s++) this.step(e, world, h);
			if (e.y < .08) {
				e.y = .08;
				e.vy = 0;
				e.vx = 0;
				e.vz = 0;
				e.onGround = true;
			}
			const spin = e.age * 1.6;
			const bob = e.onGround ? Math.sin(e.age * 2.4) * .04 : 0;
			e.mesh.position.set(e.x, e.y + .16 + bob, e.z);
			e.mesh.rotation.set(.22, spin, .12);
			const dx = e.x - px;
			const dy = e.y - (py + .7);
			const dz = e.z - pz;
			const dist = Math.hypot(dx, dy, dz);
			if (e.age > PICK_DELAY && dist < PICK_RANGE) {
				if (take(e.id, e.count)) {
					this.group.remove(e.mesh);
					continue;
				}
			}
			if (e.age > LIFETIME) {
				this.group.remove(e.mesh);
				continue;
			}
			keep.push(e);
		}
		this.items = keep;
	}
	step(e, world, dt) {
		this.unstick(e, world);
		e.vy -= GRAVITY * dt;
		if (e.vy < -12) e.vy = -12;
		if (e.onGround && Math.abs(e.vx) < .02 && Math.abs(e.vz) < .02 && e.vy <= 0) {
			e.vx = 0;
			e.vz = 0;
			const support = Math.floor(e.y - SURFACE - .05);
			if (this.blocked(world, e.x, support, e.z)) {
				e.vy = 0;
				e.y = support + 1 + SURFACE;
				return;
			}
			e.onGround = false;
		}
		this.moveX(e, world, e.vx * dt);
		this.moveZ(e, world, e.vz * dt);
		this.moveY(e, world, e.vy * dt);
		if (e.onGround) {
			e.vx *= .72;
			e.vz *= .72;
			if (Math.abs(e.vx) < .03) e.vx = 0;
			if (Math.abs(e.vz) < .03) e.vz = 0;
		}
	}
	moveX(e, world, dx) {
		if (!dx) return;
		const nx = e.x + dx;
		if (this.blocked(world, nx, e.y + SURFACE, e.z) || this.blocked(world, nx, e.y + .22, e.z)) {
			e.vx *= -.2;
			return;
		}
		e.x = nx;
	}
	moveZ(e, world, dz) {
		if (!dz) return;
		const nz = e.z + dz;
		if (this.blocked(world, e.x, e.y + SURFACE, nz) || this.blocked(world, e.x, e.y + .22, nz)) {
			e.vz *= -.2;
			return;
		}
		e.z = nz;
	}
	moveY(e, world, dy) {
		if (!dy) return;
		if (dy < 0) {
			const y0 = e.y;
			const y1 = e.y + dy;
			const from = Math.floor(y0);
			const to = Math.floor(y1);
			for (let by = from; by >= to; by--) {
				if (!this.blocked(world, e.x, by, e.z)) continue;
				const top = by + 1;
				if (y0 >= top - .001) {
					e.y = top + SURFACE;
					e.vy = 0;
					e.onGround = true;
					e.vx *= .55;
					e.vz *= .55;
					return;
				}
			}
			e.y = y1;
			e.onGround = false;
			return;
		}
		const ny = e.y + dy;
		if (this.blocked(world, e.x, ny + .28, e.z)) {
			e.vy = 0;
			return;
		}
		e.y = ny;
		e.onGround = false;
	}
	unstick(e, world) {
		let guard = 0;
		while (guard++ < 12 && this.blocked(world, e.x, e.y, e.z)) {
			e.y = Math.floor(e.y) + 1 + SURFACE;
			e.vy = 0;
			e.onGround = true;
		}
	}
	blocked(world, x, y, z) {
		if (y < 0) return true;
		const ix = Math.floor(x);
		const iy = Math.floor(y);
		const iz = Math.floor(z);
		const [cx, cz] = worldToChunk(ix, iz);
		if (!world.chunks.has(chunkKey(cx, cz))) return true;
		return isSolid(world.getBlock(ix, iy, iz));
	}
	makeMesh(id) {
		if (isPlaceable(id)) {
			let geo = this.cache.get(id);
			if (!geo) {
				geo = makeBlockGeometry(id);
				this.cache.set(id, geo);
			}
			const m = new Mesh(geo, this.blockMat);
			m.scale.setScalar(.28);
			return m;
		}
		const g = new Group();
		const col = itemColor(id);
		const box = new Mesh(new BoxGeometry(isTool(id) ? .12 : .18, isTool(id) ? .32 : .18, .08), new MeshLambertMaterial({ color: col }));
		g.add(box);
		return g;
	}
	clear() {
		for (const it of this.items) this.group.remove(it.mesh);
		this.items = [];
	}
	dispose() {
		this.group.removeFromParent();
		for (const g of this.cache.values()) g.dispose();
	}
};
var DEFS = {
	pig: {
		hp: 10,
		w: .9,
		h: .9,
		d: .95,
		speed: 1.05,
		drop: 40,
		dropMin: 1,
		dropMax: 2,
		name: "Domuz",
		dmg: 0,
		reach: 0
	},
	sheep: {
		hp: 8,
		w: .9,
		h: 1.3,
		d: 1.15,
		speed: 1,
		drop: 42,
		dropMin: 1,
		dropMax: 2,
		name: "Koyun",
		dmg: 0,
		reach: 0
	},
	cow: {
		hp: 10,
		w: .95,
		h: 1.4,
		d: 1.45,
		speed: .9,
		drop: 41,
		dropMin: 1,
		dropMax: 3,
		name: "İnek",
		dmg: 0,
		reach: 0
	},
	chicken: {
		hp: 4,
		w: .4,
		h: .7,
		d: .4,
		speed: 1.4,
		drop: 43,
		dropMin: 1,
		dropMax: 1,
		name: "Tavuk",
		dmg: 0,
		reach: 0
	},
	zombie: {
		hp: 12,
		w: .6,
		h: 1.85,
		d: .6,
		speed: 1.15,
		drop: 0,
		dropMin: 0,
		dropMax: 0,
		name: "Zombi",
		dmg: 3,
		reach: 1.35
	},
	creeper: {
		hp: 12,
		w: .6,
		h: 1.6,
		d: .6,
		speed: 1.05,
		drop: 0,
		dropMin: 0,
		dropMax: 0,
		name: "Creeper",
		dmg: 0,
		reach: 2.3
	},
	skeleton: {
		hp: 10,
		w: .6,
		h: 1.85,
		d: .6,
		speed: 1.2,
		drop: 0,
		dropMin: 0,
		dropMax: 0,
		name: "İskelet",
		dmg: 3,
		reach: 12
	},
	spider: {
		hp: 8,
		w: 1.3,
		h: .7,
		d: 1.3,
		speed: 1.55,
		drop: 0,
		dropMin: 0,
		dropMax: 0,
		name: "Örümcek",
		dmg: 2,
		reach: 1.25
	},
	enderman: {
		hp: 40,
		w: .6,
		h: 2.9,
		d: .6,
		speed: 1.35,
		drop: 82,
		dropMin: 1,
		dropMax: 1,
		name: "Enderman",
		dmg: 7,
		reach: 1.6
	},
	piglin: {
		hp: 20,
		w: .6,
		h: 1.9,
		d: .6,
		speed: 1.1,
		drop: 51,
		dropMin: 0,
		dropMax: 1,
		name: "Zombileşmiş Piglin",
		dmg: 5,
		reach: 1.4
	},
	blaze: {
		hp: 20,
		w: .7,
		h: 1.8,
		d: .7,
		speed: 1.25,
		drop: 80,
		dropMin: 1,
		dropMax: 5,
		name: "Blaze",
		dmg: 5,
		reach: 14
	}
};
var MAX_MOBS = 18;
var KEEP_DIST = 72;
var HOSTILE = /* @__PURE__ */ new Set([
	"zombie",
	"creeper",
	"skeleton",
	"spider"
]);
var mats = /* @__PURE__ */ new Map();
function mat(color, extra) {
	const key = color * 10 + (extra?.transparent ? 1 : 0);
	let m = mats.get(key);
	if (!m) {
		m = new MeshLambertMaterial({
			color,
			transparent: extra?.transparent ?? false,
			opacity: extra?.opacity ?? 1
		});
		mats.set(key, m);
	}
	return m;
}
function voxel(parent, x, y, z, sx, sy, sz, color) {
	const mesh = new Mesh(new BoxGeometry(sx, sy, sz), mat(color));
	mesh.position.set(x, y, z);
	mesh.castShadow = false;
	parent.add(mesh);
	return mesh;
}
function buildPig(crown) {
	const g = new Group();
	const pink = 15771824;
	const dark = 13662856;
	const snout = 16040132;
	const hoof = 3810332;
	voxel(g, 0, .58, .04, .78, .5, .92, pink);
	voxel(g, 0, .78, -.52, .52, .5, .48, pink);
	voxel(g, 0, .68, -.78, .32, .22, .18, snout);
	voxel(g, -.07, .66, -.88, .07, .07, .04, 5910584);
	voxel(g, .07, .66, -.88, .07, .07, .04, 5910584);
	voxel(g, -.3, 1.02, -.5, .16, .16, .08, dark);
	voxel(g, .3, 1.02, -.5, .16, .16, .08, dark);
	voxel(g, -.14, .84, -.76, .1, .1, .04, 16777215);
	voxel(g, .14, .84, -.76, .1, .1, .04, 16777215);
	voxel(g, -.14, .84, -.78, .055, .055, .03, 1708556);
	voxel(g, .14, .84, -.78, .055, .055, .03, 1708556);
	const fl = voxel(g, -.22, .18, -.28, .2, .36, .2, pink);
	const fr = voxel(g, .22, .18, -.28, .2, .36, .2, pink);
	const bl = voxel(g, -.22, .18, .32, .2, .36, .2, pink);
	const br = voxel(g, .22, .18, .32, .2, .36, .2, pink);
	voxel(fl, 0, -.16, 0, .2, .08, .2, hoof);
	voxel(fr, 0, -.16, 0, .2, .08, .2, hoof);
	voxel(bl, 0, -.16, 0, .2, .08, .2, hoof);
	voxel(br, 0, -.16, 0, .2, .08, .2, hoof);
	voxel(g, 0, .72, .52, .1, .1, .12, dark);
	if (crown) {
		voxel(g, 0, 1.12, -.52, .56, .1, .5, 15778890);
		voxel(g, 0, 1.28, -.52, .12, .22, .12, 16769162);
		voxel(g, -.2, 1.24, -.52, .1, .16, .1, 15778890);
		voxel(g, .2, 1.24, -.52, .1, .16, .1, 15778890);
		voxel(g, -.2, 1.12, -.52, .08, .08, .08, 12599376);
		voxel(g, .2, 1.12, -.52, .08, .08, .08, 3832020);
		voxel(g, 0, 1.12, -.52, .08, .08, .08, 12599376);
	}
	return {
		group: g,
		legs: [
			fl,
			fr,
			bl,
			br
		],
		wings: []
	};
}
function buildCow() {
	const g = new Group();
	const hide = 4863016;
	const white = 15722200;
	const pink = 15245456;
	const hoof = 2759700;
	voxel(g, 0, .85, .08, .92, .7, 1.28, hide);
	voxel(g, .18, .95, .1, .42, .42, .55, white);
	voxel(g, 0, 1.12, -.72, .52, .5, .42, hide);
	voxel(g, 0, .98, -.96, .36, .22, .16, pink);
	voxel(g, -.1, .96, -1.04, .06, .06, .04, 5910576);
	voxel(g, .1, .96, -1.04, .06, .06, .04, 5910576);
	voxel(g, -.16, 1.18, -.92, .1, .1, .04, 16777215);
	voxel(g, .16, 1.18, -.92, .1, .1, .04, 16777215);
	voxel(g, -.16, 1.18, -.94, .05, .05, .03, 1708556);
	voxel(g, .16, 1.18, -.94, .05, .05, .03, 1708556);
	voxel(g, -.28, 1.4, -.7, .1, .18, .08, 2892312);
	voxel(g, .28, 1.4, -.7, .1, .18, .08, 2892312);
	voxel(g, -.22, 1.38, -.68, .12, .1, .1, hide);
	voxel(g, .22, 1.38, -.68, .12, .1, .1, hide);
	voxel(g, 0, .55, .42, .28, .18, .22, pink);
	const fl = voxel(g, -.28, .32, -.38, .2, .64, .2, hide);
	const fr = voxel(g, .28, .32, -.38, .2, .64, .2, hide);
	const bl = voxel(g, -.28, .32, .48, .2, .64, .2, hide);
	const br = voxel(g, .28, .32, .48, .2, .64, .2, hide);
	voxel(fl, 0, -.3, 0, .2, .1, .2, hoof);
	voxel(fr, 0, -.3, 0, .2, .1, .2, hoof);
	voxel(bl, 0, -.3, 0, .2, .1, .2, hoof);
	voxel(br, 0, -.3, 0, .2, .1, .2, hoof);
	return {
		group: g,
		legs: [
			fl,
			fr,
			bl,
			br
		],
		wings: []
	};
}
function buildSheep() {
	const g = new Group();
	const wool = 16052714;
	const woolD = 14999508;
	const skin = 12891290;
	const face = 12099704;
	const hoof = 3811352;
	voxel(g, 0, .78, .06, .95, .72, 1.2, wool);
	voxel(g, 0, .92, .1, .7, .5, .9, woolD);
	voxel(g, 0, .92, -.68, .42, .42, .42, skin);
	voxel(g, 0, .82, -.9, .28, .22, .16, face);
	voxel(g, -.1, .98, -.88, .09, .09, .04, 16777215);
	voxel(g, .1, .98, -.88, .09, .09, .04, 16777215);
	voxel(g, -.1, .98, -.9, .05, .05, .03, 1708556);
	voxel(g, .1, .98, -.9, .05, .05, .03, 1708556);
	voxel(g, -.22, 1.16, -.62, .12, .12, .08, skin);
	voxel(g, .22, 1.16, -.62, .12, .12, .08, skin);
	const fl = voxel(g, -.24, .28, -.32, .18, .56, .18, skin);
	const fr = voxel(g, .24, .28, -.32, .18, .56, .18, skin);
	const bl = voxel(g, -.24, .28, .42, .18, .56, .18, skin);
	const br = voxel(g, .24, .28, .42, .18, .56, .18, skin);
	voxel(fl, 0, -.26, 0, .18, .08, .18, hoof);
	voxel(fr, 0, -.26, 0, .18, .08, .18, hoof);
	voxel(bl, 0, -.26, 0, .18, .08, .18, hoof);
	voxel(br, 0, -.26, 0, .18, .08, .18, hoof);
	return {
		group: g,
		legs: [
			fl,
			fr,
			bl,
			br
		],
		wings: []
	};
}
function buildChicken() {
	const g = new Group();
	const white = 16184298;
	const comb = 13643824;
	const beak = 15777840;
	const leg = 14721072;
	voxel(g, 0, .38, .02, .4, .32, .48, white);
	voxel(g, 0, .58, -.22, .28, .28, .28, white);
	voxel(g, 0, .54, -.4, .14, .1, .14, beak);
	voxel(g, 0, .44, -.36, .1, .1, .08, comb);
	voxel(g, 0, .74, -.22, .08, .12, .08, comb);
	voxel(g, 0, .78, -.22, .14, .08, .06, comb);
	voxel(g, -.08, .62, -.36, .07, .07, .03, 16777215);
	voxel(g, .08, .62, -.36, .07, .07, .03, 16777215);
	voxel(g, -.08, .62, -.38, .04, .04, .02, 1708556);
	voxel(g, .08, .62, -.38, .04, .04, .02, 1708556);
	const lw = voxel(g, -.26, .4, .02, .08, .22, .32, 15261904);
	const rw = voxel(g, .26, .4, .02, .08, .22, .32, 15261904);
	const fl = voxel(g, -.08, .12, 0, .06, .24, .06, leg);
	const fr = voxel(g, .08, .12, 0, .06, .24, .06, leg);
	voxel(fl, 0, -.12, -.04, .1, .03, .12, leg);
	voxel(fr, 0, -.12, -.04, .1, .03, .12, leg);
	voxel(g, 0, .38, .28, .08, .08, .12, 15253616);
	return {
		group: g,
		legs: [fl, fr],
		wings: [lw, rw]
	};
}
function buildZombie() {
	const g = new Group();
	const skin = 5016122;
	const shirt = 3820166;
	const pants = 2765640;
	voxel(g, 0, 1.05, 0, .56, .72, .32, shirt);
	voxel(g, 0, 1.62, .02, .48, .48, .48, skin);
	voxel(g, -.12, 1.68, -.24, .1, .08, .04, 273);
	voxel(g, .12, 1.68, -.24, .1, .08, .04, 273);
	voxel(g, 0, 1.5, -.24, .16, .06, .04, 1708556);
	const la = voxel(g, -.4, 1.05, -.08, .18, .62, .18, skin);
	const ra = voxel(g, .4, 1.05, -.08, .18, .62, .18, skin);
	return {
		group: g,
		legs: [
			voxel(g, -.14, .36, 0, .2, .72, .2, pants),
			voxel(g, .14, .36, 0, .2, .72, .2, pants),
			la,
			ra
		],
		wings: []
	};
}
function buildCreeper() {
	const g = new Group();
	const green = 3971634;
	const dark = 1718806;
	voxel(g, 0, .95, 0, .52, .78, .32, green);
	voxel(g, 0, 1.55, .02, .48, .48, .48, green);
	voxel(g, 0, 1.58, -.24, .08, .22, .04, dark);
	voxel(g, -.1, 1.64, -.24, .08, .1, .04, dark);
	voxel(g, .1, 1.64, -.24, .08, .1, .04, dark);
	voxel(g, -.08, 1.42, -.24, .08, .08, .04, dark);
	voxel(g, .08, 1.42, -.24, .08, .08, .04, dark);
	return {
		group: g,
		legs: [
			voxel(g, -.16, .28, -.08, .16, .56, .16, green),
			voxel(g, .16, .28, -.08, .16, .56, .16, green),
			voxel(g, -.16, .28, .12, .16, .56, .16, green),
			voxel(g, .16, .28, .12, .16, .56, .16, green)
		],
		wings: []
	};
}
function buildSkeleton() {
	const g = new Group();
	const bone = 15262420;
	const dark = 2761756;
	voxel(g, 0, 1.08, 0, .4, .62, .22, bone);
	voxel(g, 0, 1.58, 0, .42, .42, .42, bone);
	voxel(g, -.1, 1.64, -.22, .1, .08, .04, 273);
	voxel(g, .1, 1.64, -.22, .1, .08, .04, 273);
	voxel(g, 0, 1.48, -.22, .16, .05, .04, dark);
	const la = voxel(g, -.32, 1.05, 0, .1, .62, .1, bone);
	const ra = voxel(g, .32, 1.02, -.12, .1, .62, .1, bone);
	voxel(ra, 0, -.1, -.16, .08, .42, .08, dark);
	voxel(ra, .1, .16, -.16, .22, .06, .06, 9067058);
	return {
		group: g,
		legs: [
			voxel(g, -.1, .36, 0, .1, .7, .1, bone),
			voxel(g, .1, .36, 0, .1, .7, .1, bone),
			la,
			ra
		],
		wings: []
	};
}
function buildSpider() {
	const g = new Group();
	const body = 2761760;
	const eye = 12599344;
	voxel(g, 0, .38, .05, .7, .36, .9, body);
	voxel(g, 0, .42, -.48, .42, .28, .36, 1709588);
	voxel(g, -.1, .5, -.66, .08, .08, .04, eye);
	voxel(g, .1, .5, -.66, .08, .08, .04, eye);
	const legs = [];
	for (let i = 0; i < 4; i++) {
		const z = -.28 + i * .2;
		legs.push(voxel(g, -.48, .22, z, .42, .08, .08, body));
		legs.push(voxel(g, .48, .22, z, .42, .08, .08, body));
	}
	return {
		group: g,
		legs,
		wings: []
	};
}
function buildEnderman() {
	const g = new Group();
	const black = 1446940;
	voxel(g, 0, 1.55, 0, .42, 1.5, .28, black);
	voxel(g, 0, 2.55, 0, .48, .48, .48, black);
	voxel(g, -.12, 2.62, -.24, .1, .08, .04, 12607743);
	voxel(g, .12, 2.62, -.24, .1, .08, .04, 12607743);
	const al = voxel(g, -.34, 1.5, 0, .14, 1.3, .14, black);
	const ar = voxel(g, .34, 1.5, 0, .14, 1.3, .14, black);
	return {
		group: g,
		legs: [voxel(g, -.12, .55, 0, .14, 1.1, .14, black), voxel(g, .12, .55, 0, .14, 1.1, .14, black)],
		wings: [al, ar]
	};
}
function buildPiglin() {
	const g = new Group();
	const skin = 14256756;
	const cloth = 9058858;
	voxel(g, 0, 1.05, 0, .55, .75, .32, skin);
	voxel(g, 0, .85, 0, .58, .28, .34, cloth);
	voxel(g, 0, 1.62, 0, .48, .48, .48, skin);
	voxel(g, 0, 1.52, -.26, .22, .12, .12, 15773856);
	voxel(g, -.12, 1.68, -.24, .08, .08, .04, 2102288);
	voxel(g, .12, 1.68, -.24, .08, .08, .04, 2102288);
	voxel(g, .42, .95, -.1, .1, .55, .1, 14729296);
	const al = voxel(g, -.38, 1.05, 0, .16, .7, .16, skin);
	const ar = voxel(g, .38, 1.05, 0, .16, .7, .16, skin);
	return {
		group: g,
		legs: [
			voxel(g, -.14, .38, 0, .18, .75, .18, cloth),
			voxel(g, .14, .38, 0, .18, .75, .18, cloth),
			al,
			ar
		],
		wings: []
	};
}
function buildBlaze() {
	const g = new Group();
	voxel(g, 0, 1.05, 0, .5, .5, .5, 15777824);
	voxel(g, 0, 1.15, -.28, .12, .08, .04, 16773280);
	const rods = [];
	for (let i = 0; i < 6; i++) {
		const a = i / 6 * Math.PI * 2;
		rods.push(voxel(g, Math.cos(a) * .38, .7 + i % 3 * .28, Math.sin(a) * .38, .08, .42, .08, 16756768));
	}
	return {
		group: g,
		legs: rods,
		wings: []
	};
}
function buildModel(kind, crown) {
	if (kind === "pig") return buildPig(crown);
	if (kind === "cow") return buildCow();
	if (kind === "sheep") return buildSheep();
	if (kind === "zombie") return buildZombie();
	if (kind === "creeper") return buildCreeper();
	if (kind === "skeleton") return buildSkeleton();
	if (kind === "spider") return buildSpider();
	if (kind === "enderman") return buildEnderman();
	if (kind === "piglin") return buildPiglin();
	if (kind === "blaze") return buildBlaze();
	return buildChicken();
}
function mobName(kind, crown) {
	if (kind === "pig" && crown) return "Kral Domuz";
	return DEFS[kind].name;
}
var MobWorld = class {
	group = new Group();
	mobs = [];
	spawnT = .6;
	hostileT = 1.2;
	shots = [];
	spawn(kind, x, y, z, crown = false) {
		if (this.mobs.length >= MAX_MOBS) return null;
		const def = DEFS[kind];
		const built = buildModel(kind, crown);
		const flash = new Mesh(new BoxGeometry(def.w * 1.15, def.h * 1.1, def.d * 1.15), new MeshBasicMaterial({
			color: 16729122,
			transparent: true,
			opacity: .35,
			depthWrite: false
		}));
		flash.position.y = def.h * .5;
		flash.visible = false;
		built.group.add(flash);
		let burnMesh = null;
		if (HOSTILE.has(kind)) {
			burnMesh = new Mesh(new BoxGeometry(def.w * .85, def.h * .72, def.d * .85), mat(16738834, {
				transparent: true,
				opacity: .55
			}));
			burnMesh.position.y = def.h * .48;
			burnMesh.visible = false;
			built.group.add(burnMesh);
		}
		built.group.position.set(x, y, z);
		this.group.add(built.group);
		const m = {
			kind,
			x,
			y,
			z,
			yaw: Math.random() * Math.PI * 2,
			vx: 0,
			vy: 0,
			vz: 0,
			hp: def.hp,
			maxHp: def.hp,
			crown,
			mesh: built.group,
			legs: built.legs,
			wings: built.wings,
			hurtFlash: flash,
			walkT: Math.random() * 10,
			state: "idle",
			stateT: .6 + Math.random() * 1.4,
			wantYaw: Math.random() * Math.PI * 2,
			speed: def.speed,
			hurtT: 0,
			w: def.w,
			h: def.h,
			d: def.d,
			cool: .4,
			fuse: 0,
			aggro: 0,
			burnMesh,
			ride: 0,
			tp: 0
		};
		this.mobs.push(m);
		return m;
	}
	update(dt, world, px, py, pz, drops, hooks) {
		this.spawnT -= dt;
		if (this.spawnT <= 0) {
			this.spawnT = 2.4 + Math.random() * 1.6;
			if (!hooks.peaceful) {
				if (world.kind === "nether") this.trySpawnNether(world, px, pz);
				else if (world.kind !== "end") this.trySpawn(world, px, pz);
			} else if (world.kind === "overworld") this.trySpawn(world, px, pz);
		}
		this.hostileT -= dt;
		if (this.hostileT <= 0 && !hooks.peaceful) {
			this.hostileT = 2.8 + Math.random() * 2.2;
			if (world.kind === "nether") this.trySpawnNether(world, px, pz);
			else if (world.kind !== "end") this.trySpawnHostile(world, px, pz, hooks.isDay);
		}
		this.cull(px, pz);
		this.updateShots(dt, world, px, py, pz, hooks.hurt);
		for (let i = this.mobs.length - 1; i >= 0; i--) {
			const m = this.mobs[i];
			m.hurtT = Math.max(0, m.hurtT - dt);
			m.hurtFlash.visible = m.hurtT > 0;
			m.stateT -= dt;
			m.cool = Math.max(0, m.cool - dt);
			if (m.ride) {
				m.mesh.position.set(m.x, m.y, m.z);
				m.mesh.rotation.y = m.yaw;
				continue;
			}
			if (m.tp) {
				m.tp = 0;
				if (!m.ride) this.teleport(m, world);
			}
			if (HOSTILE.has(m.kind)) this.sunBurn(m, world, hooks.isDay, dt);
			this.separate(m, dt);
			this.ai(m, world, px, py, pz, dt, hooks);
			this.physics(m, world, dt);
			this.animate(m, dt);
			m.mesh.position.set(m.x, m.y, m.z);
			m.mesh.rotation.y = m.yaw;
			if (m.kind === "creeper" && m.fuse > 0) {
				const swell = 1 + Math.sin(m.fuse * 18) * .06 * m.fuse;
				m.mesh.scale.setScalar(swell);
				m.hurtFlash.visible = m.fuse > .45;
			} else m.mesh.scale.setScalar(1);
			if (m.hp <= 0) this.kill(i, drops);
		}
		hooks.sound;
	}
	hit(m, dmg, ax, az) {
		m.hp -= dmg;
		m.hurtT = .22;
		const dx = m.x - ax;
		const dz = m.z - az;
		const len = Math.hypot(dx, dz) || 1;
		m.vx = dx / len * 3.4;
		m.vz = dz / len * 3.4;
		m.vy = Math.min(2.1, m.vy + 1.6);
		m.wantYaw = Math.atan2(dx, dz);
		if (m.kind === "enderman" && !m.ride) m.tp = 1;
		if (m.kind === "piglin") {
			m.aggro = 16;
			for (const o of this.mobs) if (o !== m && o.kind === "piglin" && Math.hypot(o.x - m.x, o.z - m.z) < 18) o.aggro = 16;
		}
		if (HOSTILE.has(m.kind) || m.kind === "enderman" || m.kind === "blaze" || m.kind === "piglin") {
			m.aggro = 8;
			m.state = "walk";
			m.stateT = .4;
		} else {
			m.state = "panic";
			m.stateT = 1 + Math.random() * .5;
		}
	}
	raycast(ox, oy, oz, dx, dy, dz, max) {
		let best = null;
		for (const m of this.mobs) {
			const t = rayAabb(ox, oy, oz, dx, dy, dz, m.x - m.w * .5 - .2, m.y, m.z - m.d * .5 - .2, m.w + .4, m.h + .15, m.d + .4, max);
			if (t != null && (!best || t < best.dist)) best = {
				mob: m,
				dist: t
			};
		}
		return best;
	}
	nearestInLook(px, py, pz, dx, dy, dz, maxDist) {
		let best = null;
		for (const m of this.mobs) {
			const vx = m.x - px;
			const vy = m.y + m.h * .5 - py;
			const vz = m.z - pz;
			const dist = Math.hypot(vx, vy, vz);
			if (dist > maxDist || dist < .05) continue;
			if (vx / dist * dx + vy / dist * dy + vz / dist * dz < .62) continue;
			if (!best || dist < best.dist) best = {
				mob: m,
				dist
			};
		}
		return best;
	}
	kill(i, drops) {
		const m = this.mobs[i];
		const def = DEFS[m.kind];
		if (m.kind === "blaze") {
			const n = 1 + Math.floor(Math.random() * 5);
			drops?.spawn(m.x, m.y + .5, m.z, 80, n);
		} else {
			const n = def.dropMin + Math.floor(Math.random() * (def.dropMax - def.dropMin + 1));
			const extra = m.crown ? 1 : 0;
			if (def.drop && n + extra > 0) drops?.spawn(m.x, m.y + .4, m.z, def.drop, n + extra);
		}
		if (m.kind === "sheep") drops?.spawn(m.x + .2, m.y + .35, m.z, 45, 1 + Math.floor(Math.random() * 2));
		this.group.remove(m.mesh);
		this.disposeMesh(m.mesh);
		this.mobs.splice(i, 1);
	}
	ai(m, world, px, py, pz, dt, hooks) {
		if (m.kind === "enderman") {
			this.endermanAi(m, world, px, py, pz, dt, hooks);
			return;
		}
		if (m.kind === "blaze") {
			this.blazeAi(m, world, px, py, pz, dt, hooks);
			return;
		}
		if (m.kind === "piglin") {
			this.piglinAi(m, world, px, py, pz, dt, hooks);
			return;
		}
		if (HOSTILE.has(m.kind)) {
			this.hostileAi(m, world, px, py, pz, dt, hooks);
			return;
		}
		if (m.state === "panic") {
			const dx = m.x - px;
			const dz = m.z - pz;
			m.wantYaw = Math.atan2(dx, dz);
			if (m.stateT <= 0) {
				m.state = "walk";
				m.stateT = 1.2;
			}
		} else if (m.stateT <= 0) {
			if (m.state === "idle") {
				m.state = "walk";
				m.stateT = 1.8 + Math.random() * 2.8;
				m.wantYaw = Math.random() * Math.PI * 2;
			} else {
				m.state = "idle";
				m.stateT = 1.2 + Math.random() * 2.6;
			}
		}
		const turn = m.state === "panic" ? 8 : 3.2;
		let a = m.wantYaw - m.yaw;
		while (a > Math.PI) a -= Math.PI * 2;
		while (a < -Math.PI) a += Math.PI * 2;
		m.yaw += a * Math.min(1, turn * dt);
		const moving = m.state === "walk" || m.state === "panic";
		const spd = m.state === "panic" ? m.speed * 2.15 : m.state === "walk" ? m.speed : 0;
		if (moving && spd) {
			const fx = -Math.sin(m.yaw);
			const fz = -Math.cos(m.yaw);
			const nx = m.x + fx * .7;
			const nz = m.z + fz * .7;
			if (this.blockedAhead(world, nx, m.y, nz, m.h) === "wall") m.wantYaw += (Math.random() > .5 ? 1 : -1) * (.7 + Math.random());
			else {
				m.vx += (fx * spd - m.vx) * Math.min(1, 6 * dt);
				m.vz += (fz * spd - m.vz) * Math.min(1, 6 * dt);
			}
		} else {
			m.vx *= Math.max(0, 1 - 8 * dt);
			m.vz *= Math.max(0, 1 - 8 * dt);
		}
	}
	separate(m, dt) {
		for (const o of this.mobs) {
			if (o === m) continue;
			const dx = m.x - o.x;
			const dz = m.z - o.z;
			const d = Math.hypot(dx, dz);
			const min = (m.w + o.w) * .55;
			if (d < .05 || d > min) continue;
			const f = (min - d) / min * 2.2 * dt;
			m.vx += dx / d * f;
			m.vz += dz / d * f;
		}
	}
	physics(m, world, dt) {
		if (m.kind === "blaze") {
			m.vy += (.15 - m.vy) * Math.min(1, 3 * dt);
			if (m.vy > 1.4) m.vy = 1.4;
			if (m.vy < -1.4) m.vy = -1.4;
		} else if (this.inWater(world, m)) {
			m.vy -= 6 * dt;
			const surface = this.waterTop(world, m);
			if (surface != null && m.y + m.h * .45 < surface) m.vy += 14 * dt;
			else m.vy += (.15 - m.vy) * Math.min(1, 4 * dt);
			if (m.vy < -1.1) m.vy = -1.1;
			if (m.vy > 2.6) m.vy = 2.6;
		} else {
			m.vy -= 26 * dt;
			if (m.vy < -18) m.vy = -18;
		}
		this.stepMove(m, world, m.vx * dt, m.vz * dt);
		const before = m.y;
		m.y += m.vy * dt;
		if (this.aabbSolid(world, m)) {
			m.y = before;
			if (m.vy < 0) {
				let guard = 0;
				while (guard++ < 6 && !this.aabbSolid(world, m)) m.y -= .05;
				if (this.aabbSolid(world, m)) m.y += .05;
			}
			m.vy = 0;
		}
		if (m.y < .1) {
			m.y = .1;
			m.vy = 0;
		}
	}
	stepMove(m, world, dx, dz) {
		if (dx === 0 && dz === 0) return;
		const ox = m.x;
		const oz = m.z;
		const oy = m.y;
		m.x += dx;
		m.z += dz;
		if (!this.aabbSolid(world, m)) return;
		m.x = ox;
		m.z = oz;
		const foot = Math.floor(oy + .05);
		const ax = Math.floor(ox + Math.sign(dx || 0) * Math.max(.32, m.w * .48));
		const az = Math.floor(oz + Math.sign(dz || 0) * Math.max(.32, m.d * .48));
		const low = this.blocked(world, ax, foot, az);
		const high = this.blocked(world, ax, foot + 1, az);
		const one = low && !high;
		let room = !high;
		const need = Math.max(1, Math.ceil(m.h - .08));
		for (let i = 1; i <= need; i++) if (this.blocked(world, ax, foot + i, az)) room = false;
		if (one && room) {
			if (m.vy < 1.2) m.vy = 8;
			return;
		}
		m.vx = 0;
		m.vz = 0;
	}
	animate(m, dt) {
		const spd = Math.hypot(m.vx, m.vz);
		if (spd > .15) m.walkT += dt * spd * 7;
		const swing = Math.sin(m.walkT) * Math.min(.7, spd * .45);
		if (m.legs[0]) m.legs[0].rotation.x = swing;
		if (m.legs[1]) m.legs[1].rotation.x = -swing;
		if (m.legs[2]) m.legs[2].rotation.x = -swing;
		if (m.legs[3]) m.legs[3].rotation.x = swing;
		const flap = m.kind === "chicken" ? Math.sin(m.walkT * 2.2) * .45 : 0;
		if (m.wings[0]) m.wings[0].rotation.z = .25 + flap;
		if (m.wings[1]) m.wings[1].rotation.z = -.25 - flap;
	}
	aabbSolid(world, m) {
		const x0 = Math.floor(m.x - m.w * .45);
		const x1 = Math.floor(m.x + m.w * .45);
		const y0 = Math.floor(m.y + .05);
		const y1 = Math.floor(m.y + m.h - .05);
		const z0 = Math.floor(m.z - m.d * .45);
		const z1 = Math.floor(m.z + m.d * .45);
		for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) if (this.blocked(world, x, y, z)) return true;
		return false;
	}
	blockedAhead(world, x, y, z, h) {
		const ix = Math.floor(x);
		const iz = Math.floor(z);
		const iy = Math.floor(y + .1);
		if (isWater(world.getBlock(ix, iy, iz)) || isWater(world.getBlock(ix, iy - 1, iz))) return "clear";
		const low = this.blocked(world, ix, iy, iz);
		const high = this.blocked(world, ix, iy + 1, iz);
		if (low && high) return "wall";
		if (low) return "step";
		const below = world.getBlock(ix, iy - 1, iz);
		if (!isSolid(below) && !isWater(below)) return "wall";
		if (y - this.surfaceY(world, ix, iz) > 2.2) return "wall";
		return "clear";
	}
	inWater(world, m) {
		const x = Math.floor(m.x);
		const z = Math.floor(m.z);
		const y = Math.floor(m.y + .2);
		return isWater(world.getBlock(x, y, z)) || isWater(world.getBlock(x, y + 1, z));
	}
	waterTop(world, m) {
		const x = Math.floor(m.x);
		const z = Math.floor(m.z);
		let top = -1;
		const y0 = Math.max(0, Math.floor(m.y) - 1);
		for (let y = y0; y <= y0 + 5; y++) if (isWater(world.getBlock(x, y, z))) top = y;
		return top < 0 ? null : top + .9;
	}
	blocked(world, x, y, z) {
		if (y < 0) return true;
		const [cx, cz] = worldToChunk(x, z);
		if (!world.chunks.has(chunkKey(cx, cz))) return true;
		return isSolid(world.getBlock(x, y, z));
	}
	surfaceY(world, x, z) {
		for (let y = 60; y >= 1; y--) if (isSolid(world.getBlock(x, y, z)) && !isSolid(world.getBlock(x, y + 1, z))) return y + 1;
		return world.heightAt(x, z) + 1;
	}
	hostileAi(m, world, px, py, pz, dt, hooks) {
		const dx = px - m.x;
		const dy = py + .9 - (m.y + m.h * .6);
		const dz = pz - m.z;
		const dist = Math.hypot(dx, dz);
		const see = dist < 18 && Math.abs(dy) < 6 && this.sees(world, m.x, m.y + m.h * .75, m.z, px, py + 1.1, pz);
		if (see) m.aggro = 7;
		else m.aggro = Math.max(0, m.aggro - dt);
		const def = DEFS[m.kind];
		if (m.aggro > 0) {
			m.wantYaw = Math.atan2(-dx, -dz);
			m.state = "walk";
			if (m.kind === "creeper" && dist < def.reach && Math.abs(dy) < 2) {
				m.fuse += dt;
				m.vx *= Math.max(0, 1 - 10 * dt);
				m.vz *= Math.max(0, 1 - 10 * dt);
				if (m.fuse >= 1.35) {
					hooks.boom(m.x, m.y + .6, m.z);
					m.hp = 0;
				}
			} else {
				m.fuse = Math.max(0, m.fuse - dt * 1.5);
				if (dist > (m.kind === "skeleton" ? 7.5 : def.reach * .75)) {
					const fx = -Math.sin(m.wantYaw);
					const fz = -Math.cos(m.wantYaw);
					m.vx += (fx * m.speed * 1.35 - m.vx) * Math.min(1, 7 * dt);
					m.vz += (fz * m.speed * 1.35 - m.vz) * Math.min(1, 7 * dt);
				} else {
					m.vx *= Math.max(0, 1 - 8 * dt);
					m.vz *= Math.max(0, 1 - 8 * dt);
				}
				if (m.cool <= 0 && Math.abs(dy) < 2.2) {
					if (m.kind === "skeleton" && dist > 3.2 && dist < def.reach && see) {
						this.shoot(m, px, py + 1.05, pz);
						m.cool = 1.35;
					} else if (m.kind !== "skeleton" && m.kind !== "creeper" && dist < def.reach + .35) {
						hooks.hurt(def.dmg);
						m.cool = m.kind === "spider" ? .7 : .9;
					}
				}
			}
		} else {
			m.fuse = Math.max(0, m.fuse - dt);
			if (m.stateT <= 0) {
				m.state = m.state === "idle" ? "walk" : "idle";
				m.stateT = 1.2 + Math.random() * 2;
				m.wantYaw = Math.random() * Math.PI * 2;
			}
			const spd = m.state === "walk" ? m.speed * .65 : 0;
			const fx = -Math.sin(m.yaw);
			const fz = -Math.cos(m.yaw);
			if (spd && this.blockedAhead(world, m.x + fx * .6, m.y, m.z + fz * .6, m.h) !== "wall") {
				m.vx += (fx * spd - m.vx) * Math.min(1, 5 * dt);
				m.vz += (fz * spd - m.vz) * Math.min(1, 5 * dt);
			} else {
				m.vx *= Math.max(0, 1 - 8 * dt);
				m.vz *= Math.max(0, 1 - 8 * dt);
				if (spd) m.wantYaw += 1.1;
			}
		}
		let a = m.wantYaw - m.yaw;
		while (a > Math.PI) a -= Math.PI * 2;
		while (a < -Math.PI) a += Math.PI * 2;
		m.yaw += a * Math.min(1, 8 * dt);
	}
	sunBurn(m, world, isDay, dt) {
		const wet = isWater(world.getBlock(Math.floor(m.x), Math.floor(m.y), Math.floor(m.z)));
		const burn = isDay && !wet && this.seesSky(world, m);
		if (m.burnMesh) m.burnMesh.visible = burn;
		if (!burn) return;
		m.hurtT = .15;
		m.hp -= dt * 2.2;
	}
	seesSky(world, m) {
		const x = Math.floor(m.x);
		const z = Math.floor(m.z);
		const y0 = Math.floor(m.y + m.h);
		for (let y = y0; y < y0 + 14; y++) {
			if (y > 62) return true;
			const id = world.getBlock(x, y, z);
			if (isSolid(id) && id !== 5) return false;
		}
		return true;
	}
	sees(world, x0, y0, z0, x1, y1, z1) {
		const dx = x1 - x0;
		const dy = y1 - y0;
		const dz = z1 - z0;
		const steps = Math.max(1, Math.ceil(Math.hypot(dx, dy, dz) * 2));
		for (let i = 1; i < steps; i++) {
			const t = i / steps;
			const x = Math.floor(x0 + dx * t);
			const y = Math.floor(y0 + dy * t);
			const z = Math.floor(z0 + dz * t);
			const id = world.getBlock(x, y, z);
			if (isSolid(id) && id !== 5) return false;
		}
		return true;
	}
	shoot(m, px, py, pz, dmg = DEFS.skeleton.dmg) {
		const ox = m.x;
		const oy = m.y + m.h * .72;
		const oz = m.z;
		const dx = px - ox;
		const dy = py - oy;
		const dz = pz - oz;
		const len = Math.hypot(dx, dy, dz) || 1;
		const sp = 16;
		const mesh = new Mesh(new BoxGeometry(m.kind === "blaze" ? .16 : .08, m.kind === "blaze" ? .16 : .08, m.kind === "blaze" ? .16 : .42), mat(m.kind === "blaze" ? 16755234 : 15986660));
		mesh.position.set(ox, oy, oz);
		this.group.add(mesh);
		this.shots.push({
			x: ox,
			y: oy,
			z: oz,
			vx: dx / len * sp,
			vy: dy / len * sp,
			vz: dz / len * sp,
			life: 2.4,
			dmg,
			mesh
		});
	}
	updateShots(dt, world, px, py, pz, hurt) {
		for (let i = this.shots.length - 1; i >= 0; i--) {
			const s = this.shots[i];
			s.life -= dt;
			s.vy -= 4 * dt;
			s.x += s.vx * dt;
			s.y += s.vy * dt;
			s.z += s.vz * dt;
			s.mesh.position.set(s.x, s.y, s.z);
			const hitP = Math.abs(s.x - px) < .45 && Math.abs(s.z - pz) < .45 && s.y > py && s.y < py + 1.75;
			const solid = isSolid(world.getBlock(Math.floor(s.x), Math.floor(s.y), Math.floor(s.z)));
			if (hitP || solid || s.life <= 0 || s.y < 0) {
				if (hitP) hurt(s.dmg);
				this.group.remove(s.mesh);
				s.mesh.geometry.dispose();
				this.shots.splice(i, 1);
			}
		}
	}
	trySpawn(world, px, pz) {
		if (this.mobs.length >= MAX_MOBS) return;
		let animals = 0;
		for (const m of this.mobs) if (!HOSTILE.has(m.kind)) animals++;
		if (animals >= 7) return;
		for (let n = 0; n < 8; n++) {
			const ang = Math.random() * Math.PI * 2;
			const r = 16 + Math.random() * 28;
			const x = Math.floor(px + Math.cos(ang) * r) + .5;
			const z = Math.floor(pz + Math.sin(ang) * r) + .5;
			const biome = world.biomeAt(Math.floor(x), Math.floor(z));
			if (biome === 0) continue;
			const y = this.surfaceY(world, Math.floor(x), Math.floor(z));
			if (y < 18) continue;
			const ground = world.getBlock(Math.floor(x), y - 1, Math.floor(z));
			if (!isSolid(ground) || isWater(world.getBlock(Math.floor(x), y, Math.floor(z)))) continue;
			if (ground === 5 || ground === 4 || ground === 14) continue;
			if (biome === 3 && Math.random() > .15) continue;
			let near = false;
			for (const o of this.mobs) if (Math.hypot(o.x - x, o.z - z) < 8) {
				near = true;
				break;
			}
			if (near) continue;
			const roll = Math.random();
			const kind = roll < .3 ? "pig" : roll < .55 ? "sheep" : roll < .8 ? "cow" : "chicken";
			const crown = kind === "pig" && Math.random() < .05;
			this.spawn(kind, x, y + .02, z, crown);
			return;
		}
	}
	trySpawnHostile(world, px, pz, isDay) {
		let hostiles = 0;
		for (const m of this.mobs) if (HOSTILE.has(m.kind)) hostiles++;
		if (hostiles >= 7 || this.mobs.length >= MAX_MOBS) return;
		for (let n = 0; n < 10; n++) {
			const ang = Math.random() * Math.PI * 2;
			const r = 14 + Math.random() * 26;
			const x = Math.floor(px + Math.cos(ang) * r);
			const z = Math.floor(pz + Math.sin(ang) * r);
			const [cx, cz] = worldToChunk(x, z);
			if (!world.chunks.has(chunkKey(cx, cz))) continue;
			const top = this.surfaceY(world, x, z);
			let y = -1;
			if (!isDay && top >= 18) {
				const ground = world.getBlock(x, top - 1, z);
				if (isSolid(ground) && !isWater(world.getBlock(x, top, z)) && ground !== 5 && ground !== 14) y = top;
			}
			if (y < 0) for (let k = 0; k < 8; k++) {
				const cy = 4 + Math.floor(Math.random() * Math.max(2, top - 8));
				if (cy > top - 4) continue;
				if (!isSolid(world.getBlock(x, cy, z)) && !isSolid(world.getBlock(x, cy + 1, z)) && isSolid(world.getBlock(x, cy - 1, z))) {
					y = cy;
					break;
				}
			}
			if (y < 2) continue;
			let near = false;
			for (const o of this.mobs) if (Math.hypot(o.x - (x + .5), o.z - (z + .5)) < 7) {
				near = true;
				break;
			}
			if (near) continue;
			const roll = Math.random();
			const kind = roll < .34 ? "zombie" : roll < .58 ? "skeleton" : roll < .8 ? "spider" : "creeper";
			this.spawn(kind, x + .5, y + .02, z + .5, false);
			return;
		}
	}
	seedAround(world, px, pz, peaceful = false) {
		if (world.kind === "end") return;
		if (world.kind === "nether" && peaceful) return;
		const nether = world.kind === "nether";
		for (let i = 0; i < 18 && this.mobs.length < 6; i++) if (nether) this.trySpawnNether(world, px, pz);
		else this.trySpawn(world, px, pz);
	}
	trySpawnNether(world, px, pz) {
		if (this.mobs.length >= MAX_MOBS) return;
		for (let n = 0; n < 8; n++) {
			const ang = Math.random() * Math.PI * 2;
			const r = 12 + Math.random() * 24;
			const x = Math.floor(px + Math.cos(ang) * r);
			const z = Math.floor(pz + Math.sin(ang) * r);
			const [cx, cz] = worldToChunk(x, z);
			if (!world.chunks.has(chunkKey(cx, cz))) continue;
			const fort = nearFortress(world.seed, x, z, 30);
			let y = -1;
			if (fort && Math.random() < .65) {
				y = fort.y + 1;
				if (isSolid(world.getBlock(x, y, z)) || isSolid(world.getBlock(x, y + 1, z))) y = -1;
			}
			if (y < 0) {
				const top = this.surfaceY(world, x, z);
				if (top < 4) continue;
				if (!isSolid(world.getBlock(x, top - 1, z)) || isWater(world.getBlock(x, top, z))) continue;
				y = top;
			}
			let near = false;
			for (const o of this.mobs) if (Math.hypot(o.x - (x + .5), o.z - (z + .5)) < 7) {
				near = true;
				break;
			}
			if (near) continue;
			const kind = fort && y === fort.y + 1 ? "blaze" : Math.random() < .45 ? "enderman" : "piglin";
			this.spawn(kind, x + .5, y + .05, z + .5, false);
			return;
		}
	}
	teleport(m, world) {
		for (let i = 0; i < 14; i++) {
			const nx = m.x + (Math.random() - .5) * 22;
			const nz = m.z + (Math.random() - .5) * 22;
			const ix = Math.floor(nx);
			const iz = Math.floor(nz);
			const [cx, cz] = worldToChunk(ix, iz);
			if (!world.chunks.has(chunkKey(cx, cz))) continue;
			const y = this.surfaceY(world, ix, iz);
			if (y < 2) continue;
			if (isSolid(world.getBlock(ix, y, iz)) || isSolid(world.getBlock(ix, y + 1, iz))) continue;
			if (!isSolid(world.getBlock(ix, y - 1, iz))) continue;
			m.x = ix + .5;
			m.y = y + .05;
			m.z = iz + .5;
			m.vx = m.vz = 0;
			return;
		}
	}
	endermanAi(m, world, px, py, pz, dt, hooks) {
		const ex = m.x;
		const ey = m.y + m.h * .86;
		const ez = m.z;
		const vx = ex - px;
		const vy = ey - hooks.eyeY;
		const vz = ez - pz;
		const dist3 = Math.hypot(vx, vy, vz) || 1;
		if (vx / dist3 * hooks.look.x + vy / dist3 * hooks.look.y + vz / dist3 * hooks.look.z > .9 && dist3 < 26) m.aggro = 12;
		else m.aggro = Math.max(0, m.aggro - dt * .15);
		const dx = px - m.x;
		const dz = pz - m.z;
		const dist = Math.hypot(dx, dz);
		if (m.aggro > 0) {
			m.wantYaw = Math.atan2(-dx, -dz);
			if (dist > 2.2) {
				const fx = -Math.sin(m.wantYaw);
				const fz = -Math.cos(m.wantYaw);
				m.vx += (fx * m.speed * 1.4 - m.vx) * Math.min(1, 7 * dt);
				m.vz += (fz * m.speed * 1.4 - m.vz) * Math.min(1, 7 * dt);
			}
			if (m.cool <= 0 && dist < 2.1 && Math.abs(py - m.y) < 3) {
				hooks.hurt(DEFS.enderman.dmg);
				m.cool = .8;
			}
		} else {
			m.vx *= Math.max(0, 1 - 6 * dt);
			m.vz *= Math.max(0, 1 - 6 * dt);
			if (m.stateT <= 0) {
				m.stateT = 2 + Math.random() * 2;
				m.wantYaw = Math.random() * Math.PI * 2;
			}
		}
		let a = m.wantYaw - m.yaw;
		while (a > Math.PI) a -= Math.PI * 2;
		while (a < -Math.PI) a += Math.PI * 2;
		m.yaw += a * Math.min(1, 6 * dt);
	}
	blazeAi(m, world, px, py, pz, dt, hooks) {
		const dx = px - m.x;
		const dz = pz - m.z;
		const dist = Math.hypot(dx, dz);
		const see = dist < 20 && this.sees(world, m.x, m.y + 1, m.z, px, py + 1, pz);
		if (see) m.aggro = 8;
		else m.aggro = Math.max(0, m.aggro - dt);
		if (m.aggro > 0) {
			m.wantYaw = Math.atan2(-dx, -dz);
			const stop = dist < 5 ? -1 : dist > 10 ? 1 : 0;
			const fx = -Math.sin(m.wantYaw) * stop;
			const fz = -Math.cos(m.wantYaw) * stop;
			m.vx += (fx * m.speed - m.vx) * Math.min(1, 4 * dt);
			m.vz += (fz * m.speed - m.vz) * Math.min(1, 4 * dt);
			m.vy += (py + 1.2 - m.y - m.vy) * Math.min(1, 2 * dt);
			if (m.cool <= 0 && see && dist < 16) {
				this.shoot(m, px, py + 1, pz, 5);
				m.cool = 1.1;
			}
		} else {
			m.vx *= Math.max(0, 1 - 4 * dt);
			m.vz *= Math.max(0, 1 - 4 * dt);
		}
		let a = m.wantYaw - m.yaw;
		while (a > Math.PI) a -= Math.PI * 2;
		while (a < -Math.PI) a += Math.PI * 2;
		m.yaw += a * Math.min(1, 5 * dt);
	}
	piglinAi(m, world, px, py, pz, dt, hooks) {
		const dx = px - m.x;
		const dz = pz - m.z;
		const dist = Math.hypot(dx, dz);
		if (m.aggro > 0) {
			m.aggro = Math.max(0, m.aggro - dt * .04);
			m.wantYaw = Math.atan2(-dx, -dz);
			if (dist > 1.7) {
				const fx = -Math.sin(m.wantYaw);
				const fz = -Math.cos(m.wantYaw);
				m.vx += (fx * m.speed * 1.3 - m.vx) * Math.min(1, 6 * dt);
				m.vz += (fz * m.speed * 1.3 - m.vz) * Math.min(1, 6 * dt);
			}
			if (m.cool <= 0 && dist < 1.7 && Math.abs(py - m.y) < 2) {
				hooks.hurt(DEFS.piglin.dmg);
				m.cool = .9;
			}
		} else if (m.stateT <= 0) {
			m.state = m.state === "idle" ? "walk" : "idle";
			m.stateT = 1.4 + Math.random() * 2;
			m.wantYaw = Math.random() * Math.PI * 2;
		}
		if (m.aggro <= 0 && m.state === "walk") {
			const fx = -Math.sin(m.yaw);
			const fz = -Math.cos(m.yaw);
			if (this.blockedAhead(world, m.x + fx * .6, m.y, m.z + fz * .6, m.h) === "wall") m.wantYaw += 1.2;
			else {
				m.vx += (fx * m.speed * .7 - m.vx) * Math.min(1, 5 * dt);
				m.vz += (fz * m.speed * .7 - m.vz) * Math.min(1, 5 * dt);
			}
		} else if (m.aggro <= 0) {
			m.vx *= Math.max(0, 1 - 8 * dt);
			m.vz *= Math.max(0, 1 - 8 * dt);
		}
		let a = m.wantYaw - m.yaw;
		while (a > Math.PI) a -= Math.PI * 2;
		while (a < -Math.PI) a += Math.PI * 2;
		m.yaw += a * Math.min(1, 6 * dt);
	}
	cull(px, pz) {
		for (let i = this.mobs.length - 1; i >= 0; i--) {
			const m = this.mobs[i];
			if (Math.hypot(m.x - px, m.z - pz) > KEEP_DIST) {
				this.group.remove(m.mesh);
				this.disposeMesh(m.mesh);
				this.mobs.splice(i, 1);
			}
		}
	}
	disposeMesh(root) {
		root.traverse((o) => {
			const mesh = o;
			if (mesh.isMesh) mesh.geometry.dispose();
		});
	}
	clear() {
		for (const m of this.mobs) {
			this.group.remove(m.mesh);
			this.disposeMesh(m.mesh);
		}
		for (const s of this.shots) {
			this.group.remove(s.mesh);
			s.mesh.geometry.dispose();
		}
		this.shots = [];
		this.mobs = [];
	}
	dispose() {
		for (const m of this.mobs) this.disposeMesh(m.mesh);
		for (const s of this.shots) {
			this.group.remove(s.mesh);
			s.mesh.geometry.dispose();
		}
		this.shots = [];
		this.mobs = [];
		this.group.removeFromParent();
	}
};
function rayAabb(ox, oy, oz, dx, dy, dz, minx, miny, minz, w, h, d, max) {
	const invX = dx !== 0 ? 1 / dx : 0xe8d4a51000;
	const invY = dy !== 0 ? 1 / dy : 0xe8d4a51000;
	const invZ = dz !== 0 ? 1 / dz : 0xe8d4a51000;
	let tmin = 0;
	let tmax = max;
	const ax = ((dx >= 0 ? minx : minx + w) - ox) * invX;
	const bx = ((dx >= 0 ? minx + w : minx) - ox) * invX;
	tmin = Math.max(tmin, Math.min(ax, bx));
	tmax = Math.min(tmax, Math.max(ax, bx));
	const ay = ((dy >= 0 ? miny : miny + h) - oy) * invY;
	const by = ((dy >= 0 ? miny + h : miny) - oy) * invY;
	tmin = Math.max(tmin, Math.min(ay, by));
	tmax = Math.min(tmax, Math.max(ay, by));
	const az = ((dz >= 0 ? minz : minz + d) - oz) * invZ;
	const bz = ((dz >= 0 ? minz + d : minz) - oz) * invZ;
	tmin = Math.max(tmin, Math.min(az, bz));
	tmax = Math.min(tmax, Math.max(az, bz));
	if (tmax >= tmin && tmin <= max) return tmin < 0 ? tmax : tmin;
	return null;
}
var S = 20;
function tools(prefix, mat, axe, pick, shovel, sword) {
	return [
		{
			id: `pick-${mat}`,
			name: `${prefix} Kazma`,
			out: makeStack(pick),
			shaped: [
				mat,
				mat,
				mat,
				0,
				S,
				0,
				0,
				S,
				0
			]
		},
		{
			id: `axe-${mat}`,
			name: `${prefix} Balta`,
			out: makeStack(axe),
			shaped: [
				mat,
				mat,
				0,
				mat,
				S,
				0,
				0,
				S,
				0
			]
		},
		{
			id: `shovel-${mat}`,
			name: `${prefix} Kürek`,
			out: makeStack(shovel),
			shaped: [
				0,
				mat,
				0,
				0,
				S,
				0,
				0,
				S,
				0
			]
		},
		{
			id: `sword-${mat}`,
			name: `${prefix} Kılıç`,
			out: makeStack(sword),
			shaped: [
				0,
				mat,
				0,
				0,
				mat,
				0,
				0,
				S,
				0
			]
		}
	];
}
var RECIPES = [
	{
		id: "planks",
		name: "Tahta ×4",
		out: {
			id: 13,
			count: 4
		},
		shapeless: [{
			id: 4,
			count: 1
		}]
	},
	{
		id: "sticks",
		name: "Çubuk ×4",
		out: {
			id: 20,
			count: 4
		},
		shapeless: [{
			id: 13,
			count: 1
		}]
	},
	...tools("Tahta", 13, 21, 22, 23, 24),
	...tools("Taş", 3, 25, 26, 27, 28),
	...tools("Demir", 50, 70, 71, 72, 73),
	...tools("Altın", 51, 29, 30, 31, 32),
	...tools("Ametist", 52, 74, 75, 76, 77),
	...tools("Elmas", 8, 33, 34, 35, 36),
	{
		id: "shield",
		name: "Kalkan",
		out: makeStack(37),
		shaped: [
			13,
			13,
			13,
			13,
			0,
			13,
			0,
			13,
			0
		]
	},
	{
		id: "furnace",
		name: "Fırın",
		out: {
			id: 44,
			count: 1
		},
		shapeless: Array.from({ length: 9 }, () => ({
			id: 3,
			count: 1
		}))
	},
	{
		id: "bucket",
		name: "Kova",
		out: {
			id: 57,
			count: 1
		},
		shaped: [
			0,
			0,
			0,
			50,
			0,
			50,
			0,
			50,
			0
		]
	},
	{
		id: "bed",
		name: "Yatak",
		out: {
			id: 46,
			count: 1
		},
		shaped: [
			45,
			45,
			45,
			13,
			13,
			13,
			0,
			0,
			0
		]
	},
	{
		id: "flint-steel",
		name: "Çakmak",
		out: makeStack(61),
		shapeless: [{
			id: 50,
			count: 1
		}, {
			id: 60,
			count: 1
		}]
	},
	{
		id: "boat",
		name: "Tekne",
		out: {
			id: 84,
			count: 1
		},
		shaped: [
			13,
			0,
			13,
			13,
			13,
			13,
			0,
			0,
			0
		]
	},
	{
		id: "blaze-powder",
		name: "Blaze Tozu ×2",
		out: {
			id: 81,
			count: 2
		},
		shapeless: [{
			id: 80,
			count: 1
		}]
	},
	{
		id: "eye",
		name: "End Gözü",
		out: {
			id: 83,
			count: 1
		},
		shapeless: [{
			id: 82,
			count: 1
		}, {
			id: 81,
			count: 1
		}]
	}
];
function normalizeShape(cells) {
	const g = cells.map((v) => v || 0);
	const rowHas = [
		0,
		1,
		2
	].map((r) => g[r * 3] || g[r * 3 + 1] || g[r * 3 + 2]);
	const colHas = [
		0,
		1,
		2
	].map((c) => g[c] || g[3 + c] || g[6 + c]);
	const r0 = rowHas[0] ? 0 : rowHas[1] ? 1 : 2;
	const r1 = rowHas[2] ? 2 : rowHas[1] ? 1 : 0;
	const c0 = colHas[0] ? 0 : colHas[1] ? 1 : 2;
	const c1 = colHas[2] ? 2 : colHas[1] ? 1 : 0;
	const parts = [];
	for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) parts.push(g[r * 3 + c] || 0);
	return `${r1 - r0 + 1}x${c1 - c0 + 1}:${parts.join(",")}`;
}
function matchRecipe(grid) {
	const filled = grid.filter((s) => s && s.count > 0);
	if (!filled.length) return null;
	for (const rec of RECIPES) {
		if (rec.shapeless) {
			if (filled.length !== rec.shapeless.length) continue;
			const used = /* @__PURE__ */ new Set();
			let ok = true;
			for (const need of rec.shapeless) {
				const i = filled.findIndex((s, idx) => !used.has(idx) && s.id === need.id && s.count >= need.count);
				if (i < 0) {
					ok = false;
					break;
				}
				used.add(i);
			}
			if (ok) return rec;
		}
		if (rec.shaped) {
			if (normalizeShape(grid.map((s) => s && s.count > 0 ? s.id : 0)) === normalizeShape(rec.shaped)) return rec;
		}
	}
	return null;
}
function consumeGrid(grid, rec) {
	if (rec.shapeless) for (const need of rec.shapeless) {
		const slot = grid.find((s) => s && s.id === need.id && s.count >= need.count);
		if (!slot) continue;
		slot.count -= need.count;
	}
	else for (let i = 0; i < grid.length; i++) {
		const s = grid[i];
		if (!s) continue;
		s.count -= 1;
	}
	for (let i = 0; i < grid.length; i++) if (grid[i] && grid[i].count <= 0) grid[i] = null;
}
function countItem(bags, id) {
	let n = 0;
	for (const bag of bags) for (const s of bag) if (s?.id === id) n += s.count;
	return n;
}
function takeItems(bags, id, n) {
	if (countItem(bags, id) < n) return false;
	let left = n;
	for (const bag of bags) for (let i = 0; i < bag.length && left > 0; i++) {
		const s = bag[i];
		if (!s || s.id !== id) continue;
		const take = Math.min(s.count, left);
		s.count -= take;
		left -= take;
		if (s.count <= 0) bag[i] = null;
	}
	return left === 0;
}
function canCraft(rec, bags) {
	const need = /* @__PURE__ */ new Map();
	if (rec.shapeless) for (const s of rec.shapeless) need.set(s.id, (need.get(s.id) ?? 0) + s.count);
	else if (rec.shaped) {
		for (const id of rec.shaped) if (id) need.set(id, (need.get(id) ?? 0) + 1);
	}
	for (const [id, n] of need) if (countItem(bags, id) < n) return false;
	return true;
}
function craftInto(rec, bags, dest) {
	if (!canCraft(rec, bags)) return false;
	const need = /* @__PURE__ */ new Map();
	if (rec.shapeless) for (const s of rec.shapeless) need.set(s.id, (need.get(s.id) ?? 0) + s.count);
	else if (rec.shaped) {
		for (const id of rec.shaped) if (id) need.set(id, (need.get(id) ?? 0) + 1);
	}
	for (const [id, n] of need) takeItems(bags, id, n);
	let left = rec.out.count;
	const outId = rec.out.id;
	const dur = rec.out.dur;
	for (const bag of [dest, ...bags]) for (let i = 0; i < bag.length && left > 0; i++) {
		const s = bag[i];
		if (s && s.id === outId && !isTool(s.id) && s.count < 64) {
			const room = 64 - s.count;
			const take = Math.min(room, left);
			s.count += take;
			left -= take;
		} else if (!s) {
			const take = isTool(outId) ? 1 : Math.min(64, left);
			bag[i] = dur != null ? {
				id: outId,
				count: take,
				dur
			} : {
				id: outId,
				count: take
			};
			left -= take;
		}
	}
	return left === 0;
}
function box(g, x, y, z, w, h, d, color) {
	const m = new Mesh(new BoxGeometry(w, h, d), new MeshLambertMaterial({ color }));
	m.position.set(x, y, z);
	g.add(m);
	return m;
}
var EndBoss = class {
	group = new Group();
	crystals = [];
	dragon = new Group();
	wings = [];
	bits = [];
	beam;
	hp = 200;
	maxHp = 200;
	dead = false;
	mode = "fly";
	ang = 0;
	perchT = 0;
	nextPerch = 16;
	healT = 0;
	deathT = 0;
	exitSent = false;
	x = 0;
	y = 48;
	z = 0;
	time = 0;
	perchY = 40;
	constructor() {
		this.buildDragon();
		this.group.add(this.dragon);
		const beam = new Mesh(new CylinderGeometry(.35, 1.4, 18, 10, 1, true), new MeshBasicMaterial({
			color: 16054271,
			transparent: true,
			opacity: .85,
			side: 2,
			depthWrite: false
		}));
		beam.visible = false;
		beam.position.set(0, 42, 0);
		this.beam = beam;
		this.group.add(beam);
	}
	layout(towers, mask, hp, dead) {
		for (const c of this.crystals) {
			this.group.remove(c.mesh);
			c.mesh.geometry.dispose();
		}
		this.crystals = towers.map((t, i) => {
			const mesh = new Mesh(new OctahedronGeometry(.55, 0), new MeshLambertMaterial({
				color: 15192319,
				emissive: 12607743,
				emissiveIntensity: .85
			}));
			const y = t.top + 1.45;
			mesh.position.set(t.x + .5, y, t.z + .5);
			const alive = !dead && (mask & 1 << i) !== 0;
			mesh.visible = alive;
			this.group.add(mesh);
			return {
				x: t.x + .5,
				y,
				z: t.z + .5,
				alive,
				mesh,
				base: y
			};
		});
		this.hp = dead ? 0 : hp;
		this.dead = dead;
		this.mode = dead ? "gone" : "fly";
		this.dragon.visible = !dead;
		this.beam.visible = false;
	}
	crystalMask() {
		let m = 0;
		this.crystals.forEach((c, i) => {
			if (c.alive) m |= 1 << i;
		});
		return m;
	}
	crystalsLeft() {
		return this.crystals.filter((c) => c.alive).length;
	}
	buildDragon() {
		const body = 2364467;
		const wing = 5909896;
		box(this.dragon, 0, 0, 0, 1.5, 1.1, 3.2, body);
		box(this.dragon, 0, .35, -2.1, .9, .7, 1.3, 3283016);
		box(this.dragon, 0, .55, -2.7, .28, .18, .5, 1708064);
		box(this.dragon, -.28, .72, -2.55, .16, .16, .16, 13672703);
		box(this.dragon, .28, .72, -2.55, .16, .16, .16, 13672703);
		for (let i = 0; i < 4; i++) box(this.dragon, 0, .05, 1.8 + i * .7, .7 - i * .12, .45, .6, body);
		const left = box(this.dragon, -2.3, .35, -.2, 3.2, .08, 1.5, wing);
		const right = box(this.dragon, 2.3, .35, -.2, 3.2, .08, 1.5, wing);
		this.wings = [left, right];
	}
	rayCrystal(ox, oy, oz, dx, dy, dz, max) {
		let best = null;
		for (let i = 0; i < this.crystals.length; i++) {
			const c = this.crystals[i];
			if (!c.alive) continue;
			const vx = c.x - ox;
			const vy = c.y - oy;
			const vz = c.z - oz;
			const t = vx * dx + vy * dy + vz * dz;
			if (t < 0 || t > max) continue;
			const px = ox + dx * t;
			const py = oy + dy * t;
			const pz = oz + dz * t;
			if ((px - c.x) ** 2 + (py - c.y) ** 2 + (pz - c.z) ** 2 < .7 * .7 && (!best || t < best.dist)) best = {
				i,
				dist: t
			};
		}
		return best;
	}
	rayDragon(ox, oy, oz, dx, dy, dz, max) {
		if (this.dead || this.mode === "gone" || this.mode === "dying") return null;
		const vx = this.x - ox;
		const vy = this.y + .4 - oy;
		const vz = this.z - oz;
		const t = vx * dx + vy * dy + vz * dz;
		if (t < 0 || t > max) return null;
		const px = ox + dx * t;
		const py = oy + dy * t;
		const pz = oz + dz * t;
		if ((px - this.x) ** 2 + (py - (this.y + .4)) ** 2 + (pz - this.z) ** 2 > 2.6 * 2.6) return null;
		return t;
	}
	killCrystal(i) {
		const c = this.crystals[i];
		if (!c?.alive) return null;
		c.alive = false;
		c.mesh.visible = false;
		return c;
	}
	hit(dmg) {
		if (this.dead || this.mode === "dying" || this.mode === "gone") return false;
		this.hp -= dmg;
		if (this.crystalsLeft() > 0) {
			this.healT = 3.2;
			if (this.hp < 40) this.hp = 40;
		}
		if (this.hp <= 0 && this.crystalsLeft() === 0) {
			this.hp = 0;
			this.beginDeath();
			return true;
		}
		return false;
	}
	beginDeath() {
		this.mode = "dying";
		this.dead = true;
		this.deathT = 0;
		this.bits = [];
		this.dragon.traverse((o) => {
			if (o.isMesh) this.bits.push({
				mesh: o,
				v: new Vector3((Math.random() - .5) * 6, 2 + Math.random() * 4, (Math.random() - .5) * 6)
			});
		});
		this.beam.visible = true;
		this.beam.position.set(0, 40, 0);
	}
	update(dt) {
		this.time += dt;
		for (let i = 0; i < this.crystals.length; i++) {
			const c = this.crystals[i];
			if (!c.alive) continue;
			c.mesh.rotation.y += dt * .9;
			c.mesh.position.y = c.base + Math.sin(this.time * 1.7 + i) * .16;
			c.y = c.mesh.position.y;
		}
		if (this.mode === "gone") {
			this.dragon.visible = false;
			return null;
		}
		if (this.mode === "dying") {
			this.deathT += dt;
			for (const b of this.bits) {
				b.v.y -= 8 * dt;
				b.mesh.position.addScaledVector(b.v, dt);
				b.mesh.rotation.x += dt * 2;
			}
			this.beam.scale.set(1, 1 + this.deathT * 1.4, 1);
			this.beam.material.opacity = Math.max(0, .9 - this.deathT / 3.4);
			if (this.deathT > 3.1 && !this.exitSent) {
				this.exitSent = true;
				this.mode = "gone";
				this.dragon.visible = false;
				this.beam.visible = false;
				return "exit";
			}
			return null;
		}
		if (this.healT > 0 && this.crystalsLeft() > 0) {
			this.healT -= dt;
			this.hp = Math.min(this.maxHp, this.hp + dt * 14);
		}
		if (this.mode === "perch") {
			this.perchT -= dt;
			this.x += (0 - this.x) * Math.min(1, dt * 2);
			this.z += (0 - this.z) * Math.min(1, dt * 2);
			this.y += (this.perchY - this.y) * Math.min(1, dt * 2);
			if (this.perchT <= 0) {
				this.mode = "fly";
				this.nextPerch = 14 + Math.random() * 10;
			}
		} else {
			this.ang += dt * .35;
			this.nextPerch -= dt;
			this.x = Math.cos(this.ang) * 30;
			this.z = Math.sin(this.ang) * 30;
			this.y = 50 + Math.sin(this.time * .8) * 2.2;
			if (this.nextPerch <= 0) {
				this.mode = "perch";
				this.perchT = 6;
			}
		}
		this.dragon.position.set(this.x, this.y, this.z);
		this.dragon.rotation.y = Math.atan2(-Math.cos(this.ang), Math.sin(this.ang));
		const flap = Math.sin(this.time * (this.mode === "perch" ? 2 : 5));
		this.wings[0].rotation.z = .25 + flap * .45;
		this.wings[1].rotation.z = -.25 - flap * .45;
		return null;
	}
};
var SMELT = {
	[48]: 50,
	[49]: 51,
	[15]: 50,
	[7]: 51,
	[40]: 53,
	[41]: 54,
	[42]: 55,
	[43]: 56
};
function smeltResult(id) {
	return SMELT[id] ?? 0;
}
function fuelSeconds(id) {
	if (id === 6) return 80;
	if (id === 4) return 15;
	if (id === 13) return 15;
	if (id === 20) return 5;
	return 0;
}
function emptyFurnace(x, y, z) {
	return {
		x,
		y,
		z,
		input: null,
		fuel: null,
		out: null,
		cook: 0,
		burn: 0,
		burnMax: 0
	};
}
function tickFurnace(f, dt) {
	const src = f.input;
	const product = src ? smeltResult(src.id) : 0;
	const canOut = product > 0 && (!f.out || f.out.id === product && f.out.count < 64);
	if (f.burn > 0) f.burn = Math.max(0, f.burn - dt);
	if (f.burn <= 0 && canOut) {
		const fuel = f.fuel;
		const t = fuel ? fuelSeconds(fuel.id) : 0;
		if (t > 0 && fuel) {
			fuel.count -= 1;
			if (fuel.count <= 0) f.fuel = null;
			f.burnMax = t;
			f.burn = t;
		}
	}
	if (!canOut || f.burn <= 0) {
		f.cook = canOut ? Math.max(0, f.cook - dt * 2) : 0;
		return;
	}
	f.cook += dt;
	if (f.cook >= 10 && src) {
		f.cook -= 10;
		src.count -= 1;
		if (src.count <= 0) f.input = null;
		if (!f.out) f.out = {
			id: product,
			count: 1
		};
		else f.out.count += 1;
	}
}
var W = 4;
var H = 6;
function frameOk(world, x, y, z, axis) {
	for (let dy = 0; dy < H; dy++) for (let d = 0; d < W; d++) {
		const wx = axis === "x" ? x + d : x;
		const wz = axis === "z" ? z + d : z;
		const edge = dy === 0 || dy === 5 || d === 0 || d === 3;
		const id = world.getBlock(wx, y + dy, wz);
		if (edge) {
			if (id !== 19) return false;
		} else if (id !== 0 && id !== 47) return false;
	}
	return true;
}
function fill(world, x, y, z, axis, id) {
	for (let dy = 1; dy < 5; dy++) for (let d = 1; d < 3; d++) {
		const wx = axis === "x" ? x + d : x;
		const wz = axis === "z" ? z + d : z;
		world.editBlock(wx, y + dy, wz, id);
	}
}
function tryLightPortal(world, hx, hy, hz) {
	for (const axis of ["x", "z"]) for (let oy = -5; oy <= 0; oy++) for (let od = -3; od <= 0; od++) {
		const x = axis === "x" ? hx + od : hx;
		const z = axis === "z" ? hz + od : hz;
		const y = hy + oy;
		if (frameOk(world, x, y, z, axis)) {
			fill(world, x, y, z, axis, 47);
			return true;
		}
	}
	return false;
}
function breakPortalNear(world, x, y, z) {
	const seen = /* @__PURE__ */ new Set();
	const q = [[
		x,
		y,
		z
	]];
	while (q.length) {
		const [cx, cy, cz] = q.pop();
		const k = `${cx},${cy},${cz}`;
		if (seen.has(k)) continue;
		seen.add(k);
		if (world.getBlock(cx, cy, cz) !== 47) continue;
		world.editBlock(cx, cy, cz, 0);
		q.push([
			cx + 1,
			cy,
			cz
		], [
			cx - 1,
			cy,
			cz
		], [
			cx,
			cy + 1,
			cz
		], [
			cx,
			cy - 1,
			cz
		], [
			cx,
			cy,
			cz + 1
		], [
			cx,
			cy,
			cz - 1
		]);
	}
}
var DAY_LEN = 420;
var FIXED = 1 / 60;
var GameEngine = class {
	canvas;
	renderer;
	scene;
	camera;
	world;
	player = new Player();
	input = new Input();
	audio = new GameAudio();
	yawObj = new Object3D();
	material = null;
	waterMat = null;
	lavaMat = null;
	portalMat = null;
	chunkMeshes = /* @__PURE__ */ new Map();
	frameGroups = /* @__PURE__ */ new Map();
	frameTpl = null;
	frameEye = null;
	waterMeshes = /* @__PURE__ */ new Map();
	lavaMeshes = /* @__PURE__ */ new Map();
	portalMeshes = /* @__PURE__ */ new Map();
	sun;
	hemi;
	ambient;
	sunMesh;
	moonMesh;
	stars;
	highlight;
	crackMesh;
	hand = new Group();
	vmScene = new Scene();
	vmCam = new PerspectiveCamera(52, 1, .05, 3);
	blockView;
	toolViews = /* @__PURE__ */ new Map();
	shieldView = null;
	activeTool = null;
	drops = null;
	boats = new BoatWorld();
	tosses = [];
	mobs = new MobWorld();
	particles = null;
	crackMats = [];
	worldTime = 80;
	health = 20;
	food = 20;
	air = 10;
	saturation = 5;
	exhaust = 0;
	eatT = 0;
	attackCd = 0;
	regenT = 0;
	starveT = 0;
	drownT = 0;
	meatView = null;
	hotbar = [];
	inventory = [];
	armor = [];
	offhand = null;
	craftGrid = emptyGrid(9);
	selected = 0;
	furnaces = /* @__PURE__ */ new Map();
	furnaceAt = null;
	lavaHurt = 0;
	edits = [];
	dim = "overworld";
	overworld = null;
	nether = null;
	end = null;
	endBoss = new EndBoss();
	avatar = null;
	avatarLegs = [];
	thirdPerson = false;
	shots = [];
	shotT = 20;
	broken = 0;
	kills = 0;
	sawNether = false;
	voidT = 0;
	saveId = "";
	worldName = "Dünya";
	monsters = true;
	bonus = false;
	ow = {
		x: .5,
		y: 40,
		z: .5
	};
	nd = null;
	portalT = 0;
	portalLock = 0;
	switching = false;
	seed = 1;
	saveTimer = 0;
	stepTimer = 0;
	acc = 0;
	last = 0;
	running = false;
	disposed = false;
	target = null;
	breakT = 0;
	breakKey = "";
	placeCd = 0;
	hudT = 0;
	fpsAccum = 0;
	fpsFrames = 0;
	fps = 0;
	hurtFlash = 0;
	hurtDir = 1;
	icons = {};
	meshQueue = [];
	viewGeoCache = /* @__PURE__ */ new Map();
	lastCx = 99999;
	lastCz = 99999;
	swingT = 0;
	onResize;
	onLockChange;
	onLockError;
	spawnX = .5;
	spawnY = 40;
	spawnZ = .5;
	homeX = .5;
	homeY = 40;
	homeZ = .5;
	bedBlock = null;
	sleeping = false;
	sleepT = 0;
	toast = "";
	toastT = 0;
	snoreT = 0;
	constructor(canvas) {
		this.canvas = canvas;
		this.renderer = new WebGLRenderer({
			canvas,
			antialias: false,
			powerPreference: "high-performance",
			alpha: false
		});
		this.renderer.setClearColor(8308963, 1);
		this.renderer.outputColorSpace = SRGBColorSpace;
		this.renderer.shadowMap.enabled = false;
		this.scene = new Scene();
		this.scene.fog = new Fog(8308963, 40, 110);
		this.camera = new PerspectiveCamera(72, 1, .08, 220);
		this.yawObj.add(this.camera);
		this.scene.add(this.yawObj);
		this.hemi = new HemisphereLight(12114175, 4016682, .7);
		this.scene.add(this.hemi);
		this.ambient = new AmbientLight(16777215, .38);
		this.scene.add(this.ambient);
		this.sun = new DirectionalLight(16774354, 1.15);
		this.sun.position.set(40, 80, 20);
		this.scene.add(this.sun);
		this.sunMesh = new Mesh(new SphereGeometry(8, 12, 12), new MeshBasicMaterial({
			color: 16770976,
			fog: false,
			depthWrite: false
		}));
		this.moonMesh = new Mesh(new SphereGeometry(5, 10, 10), new MeshBasicMaterial({
			color: 14542591,
			fog: false,
			depthWrite: false
		}));
		this.scene.add(this.sunMesh, this.moonMesh);
		const starGeo = new BufferGeometry();
		const starPos = /* @__PURE__ */ new Float32Array(900);
		for (let i = 0; i < 300; i++) {
			const th = Math.random() * Math.PI * 2;
			const ph = Math.acos(2 * Math.random() - 1);
			const r = 160;
			starPos[i * 3] = r * Math.sin(ph) * Math.cos(th);
			starPos[i * 3 + 1] = r * Math.cos(ph);
			starPos[i * 3 + 2] = r * Math.sin(ph) * Math.sin(th);
		}
		starGeo.setAttribute("position", new BufferAttribute(starPos, 3));
		this.stars = new Points(starGeo, new PointsMaterial({
			color: 16777215,
			size: 1.4,
			fog: false,
			transparent: true,
			opacity: 0
		}));
		this.scene.add(this.stars);
		const box = new BoxGeometry(1.002, 1.002, 1.002);
		this.highlight = new LineSegments(new EdgesGeometry(box), new LineBasicMaterial({
			color: 1118481,
			transparent: true,
			opacity: .85
		}));
		this.highlight.visible = false;
		this.scene.add(this.highlight);
		this.crackMesh = new Mesh(box, new MeshBasicMaterial({
			transparent: true,
			opacity: 0,
			depthWrite: false
		}));
		this.crackMesh.visible = false;
		this.scene.add(this.crackMesh);
		this.endBoss.group.visible = false;
		this.scene.add(this.endBoss.group);
		this.avatar = this.buildAvatar();
		this.avatar.visible = false;
		this.scene.add(this.avatar);
		this.blockView = new Mesh(new BoxGeometry(.01, .01, .01), new MeshLambertMaterial());
		this.blockView.frustumCulled = false;
		this.blockView.visible = false;
		this.hand.add(this.blockView);
		this.hand.frustumCulled = false;
		this.hand.visible = false;
		this.vmScene.add(this.hand);
		const vmKey = new DirectionalLight(16774100, 1.15);
		vmKey.position.set(.35, .9, .55);
		this.vmScene.add(vmKey);
		this.vmScene.add(new HemisphereLight(15266559, 4016682, .55));
		this.vmScene.add(new AmbientLight(16777215, .4));
		this.world = new World(1);
		this.input.attach(canvas);
		this.onResize = () => this.resize();
		this.onLockChange = () => {
			const locked = document.pointerLockElement === this.canvas;
			gameStore.getState().setPointerLocked(locked);
			if (!locked && gameStore.getState().phase === "playing" && !gameStore.getState().isMobile && !this.sleeping) gameStore.getState().setClickToPlay(true);
		};
		this.onLockError = () => {
			window.setTimeout(() => {
				const st = gameStore.getState();
				if (st.phase === "playing" && !st.isMobile && document.pointerLockElement !== this.canvas) st.setClickToPlay(true);
			}, 80);
		};
		window.addEventListener("resize", this.onResize);
		document.addEventListener("pointerlockchange", this.onLockChange);
		document.addEventListener("pointerlockerror", this.onLockError);
		this.resize();
	}
	async init(opts = {}) {
		const atlas = await buildAtlas();
		if (this.disposed) {
			atlas.texture.dispose();
			return;
		}
		this.icons = atlas.icons;
		this.material = new MeshLambertMaterial({
			map: atlas.texture,
			vertexColors: true,
			side: 0
		});
		this.blockView.material.dispose();
		this.blockView.material = this.material.clone();
		this.blockView.material.vertexColors = true;
		this.waterMat = new MeshLambertMaterial({
			color: 2780840,
			transparent: true,
			opacity: .48,
			vertexColors: true,
			side: 0,
			depthWrite: true
		});
		this.lavaMat = new MeshLambertMaterial({
			color: 14708768,
			transparent: true,
			opacity: .88,
			vertexColors: true,
			emissive: 12599312,
			emissiveIntensity: .45,
			side: 0,
			depthWrite: true
		});
		this.portalMat = new MeshLambertMaterial({
			color: 11619583,
			transparent: true,
			opacity: .52,
			vertexColors: true,
			emissive: 8003784,
			emissiveIntensity: .7,
			side: 2,
			depthWrite: false
		});
		this.drops = new DropWorld(this.material);
		this.scene.add(this.drops.group);
		this.scene.add(this.boats.group);
		this.scene.add(this.mobs.group);
		this.particles = new ParticlePool(new MeshLambertMaterial({
			color: 7031336,
			vertexColors: false
		}));
		this.scene.add(this.particles.mesh);
		this.crackMats = [
			.25,
			.45,
			.65,
			.85
		].map((p) => {
			const tex = new CanvasTexture(makeCrack(p));
			tex.magFilter = NearestFilter;
			tex.minFilter = NearestFilter;
			tex.flipY = false;
			return new MeshBasicMaterial({
				map: tex,
				transparent: true,
				opacity: .85,
				depthWrite: false,
				polygonOffset: true,
				polygonOffsetFactor: -2
			});
		});
		const data = opts.id ? loadWorld(opts.id) : opts.resume ? loadSave() : newSave();
		if (!data) throw new Error("Kayıt bulunamadı");
		this.saveId = data.id || "legacy";
		this.worldName = data.name || "Dünya";
		this.monsters = data.monsters !== false;
		this.bonus = !!data.bonus;
		const brandNew = data.edits.length === 0 && data.x === .5 && data.y === 40 && data.z === .5;
		this.applySave(data);
		this.overworld = new World(this.seed, "overworld");
		this.nether = new World(this.seed + 7919, "nether");
		this.end = new World(this.seed + 4400, "end");
		this.overworld.loadEdits(data.edits);
		this.nether.loadEdits(data.netherEdits ?? []);
		this.end.loadEdits(data.endEdits ?? []);
		this.dim = data.dim === "nether" ? "nether" : data.dim === "end" ? "end" : "overworld";
		this.world = this.dim === "nether" ? this.nether : this.dim === "end" ? this.end : this.overworld;
		this.endBoss.layout(this.end.endTowers, data.crystalMask ?? 255, data.dragonHp ?? 200, data.dragonDead ?? false);
		this.endBoss.perchY = (this.end.endSurface(0, 0) ?? 36) + 2.2;
		this.endBoss.group.visible = this.dim === "end";
		this.broken = data.broken ?? 0;
		this.kills = data.kills ?? 0;
		this.sawNether = data.sawNether ?? false;
		this.ow = {
			x: data.owX ?? data.x,
			y: data.owY ?? data.y,
			z: data.owZ ?? data.z
		};
		this.nd = data.ndX != null && data.ndY != null && data.ndZ != null ? {
			x: data.ndX,
			y: data.ndY,
			z: data.ndZ
		} : null;
		if (brandNew && this.dim === "overworld") {
			const [sx, sy, sz] = this.world.findSpawn();
			this.player.setSpawn(sx, sy, sz);
			this.spawnX = sx;
			this.spawnY = sy;
			this.spawnZ = sz;
			this.homeX = sx;
			this.homeY = sy;
			this.homeZ = sz;
		}
		await this.loadEndFrame();
		await this.generateAround(true);
		this.refreshBedSpawn();
		await this.meshAllDirty();
		this.drops?.load(data.drops ?? []);
		this.mobs.seedAround(this.world, this.player.x, this.player.z, !this.monsters);
		this.syncCamera();
		this.pushHud(true);
		this.exposeControls();
	}
	applySave(data) {
		this.seed = data.seed;
		this.player.x = data.x;
		this.player.y = data.y;
		this.player.z = data.z;
		this.player.yaw = data.yaw;
		this.player.pitch = data.pitch;
		this.health = data.health;
		this.food = data.food ?? 20;
		this.saturation = data.saturation ?? 5;
		this.worldTime = data.worldTime;
		this.hotbar = data.hotbar.map((s) => s ? { ...s } : null);
		this.inventory = data.inventory.map((s) => s ? { ...s } : null);
		this.armor = data.armor.map((s) => s ? { ...s } : null);
		this.offhand = data.offhand ? { ...data.offhand } : null;
		this.edits = data.edits.slice();
		this.dim = data.dim === "nether" ? "nether" : data.dim === "end" ? "end" : "overworld";
		this.craftGrid = emptyGrid(9);
		this.homeX = data.homeX ?? data.x;
		this.homeY = data.homeY ?? data.y;
		this.homeZ = data.homeZ ?? data.z;
		this.spawnX = this.homeX;
		this.spawnY = this.homeY;
		this.spawnZ = this.homeZ;
		if (data.bedX != null && data.bedY != null && data.bedZ != null) this.bedBlock = {
			x: data.bedX,
			y: data.bedY,
			z: data.bedZ
		};
		else this.bedBlock = null;
		this.furnaces.clear();
		for (const f of data.furnaces ?? []) this.furnaces.set(`${f.x},${f.y},${f.z}`, {
			...f,
			input: f.input ? { ...f.input } : null,
			fuel: f.fuel ? { ...f.fuel } : null,
			out: f.out ? { ...f.out } : null
		});
		gameStore.getState().setSettings(data.settings);
		gameStore.getState().patchHud({ canResume: true });
	}
	snapshot() {
		const settings = gameStore.getState().settings;
		return {
			version: 7,
			seed: this.seed,
			x: this.player.x,
			y: this.player.y,
			z: this.player.z,
			yaw: this.player.yaw,
			pitch: this.player.pitch,
			health: this.health,
			food: this.food,
			saturation: this.saturation,
			worldTime: this.worldTime,
			hotbar: this.hotbar.map((s) => s ? { ...s } : null),
			inventory: this.inventory.map((s) => s ? { ...s } : null),
			armor: this.armor.map((s) => s ? { ...s } : null),
			offhand: this.offhand ? { ...this.offhand } : null,
			edits: this.overworld?.exportEdits() ?? this.edits,
			netherEdits: this.nether?.exportEdits() ?? [],
			endEdits: this.end?.exportEdits() ?? [],
			dim: this.dim,
			owX: this.dim === "overworld" ? this.player.x : this.ow.x,
			owY: this.dim === "overworld" ? this.player.y : this.ow.y,
			owZ: this.dim === "overworld" ? this.player.z : this.ow.z,
			ndX: this.dim === "nether" ? this.player.x : this.nd?.x ?? null,
			ndY: this.dim === "nether" ? this.player.y : this.nd?.y ?? null,
			ndZ: this.dim === "nether" ? this.player.z : this.nd?.z ?? null,
			dragonHp: this.endBoss.hp,
			crystalMask: this.endBoss.crystalMask(),
			dragonDead: this.endBoss.dead,
			broken: this.broken,
			kills: this.kills,
			sawNether: this.sawNether,
			id: this.saveId,
			name: this.worldName,
			monsters: this.monsters,
			bonus: this.bonus,
			settings,
			drops: this.drops?.snapshot() ?? [],
			furnaces: [...this.furnaces.values()].map((f) => ({
				...f,
				input: f.input ? { ...f.input } : null,
				fuel: f.fuel ? { ...f.fuel } : null,
				out: f.out ? { ...f.out } : null
			})),
			homeX: this.homeX,
			homeY: this.homeY,
			homeZ: this.homeZ,
			bedX: this.bedBlock?.x ?? null,
			bedY: this.bedBlock?.y ?? null,
			bedZ: this.bedBlock?.z ?? null
		};
	}
	save() {
		writeSave(this.snapshot());
		gameStore.getState().patchHud({ canResume: true });
	}
	start() {
		if (this.running) return;
		this.running = true;
		this.last = performance.now();
		this.renderer.setAnimationLoop((t) => this.frame(t));
	}
	stop() {
		this.running = false;
		this.renderer.setAnimationLoop(null);
	}
	requestLock() {
		this.audio.unlock();
		const p = this.canvas.requestPointerLock?.({ unadjustedMovement: true });
		if (p && typeof p.catch === "function") p.catch(() => {
			this.canvas.requestPointerLock?.();
		});
		gameStore.getState().setClickToPlay(false);
	}
	resize() {
		const w = Math.max(1, this.canvas.clientWidth);
		const h = Math.max(1, this.canvas.clientHeight);
		const mobile = gameStore.getState().isMobile;
		this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, mobile ? 1.15 : 1.5));
		this.renderer.setSize(w, h, false);
		this.camera.aspect = w / h;
		this.camera.updateProjectionMatrix();
		this.vmCam.aspect = w / h;
		this.vmCam.updateProjectionMatrix();
	}
	frame(now) {
		if (this.disposed) return;
		const dt = Math.min((now - this.last) / 1e3, .1);
		this.last = now;
		this.fpsAccum += dt;
		this.fpsFrames++;
		if (this.fpsAccum >= .4) {
			this.fps = this.fpsFrames / this.fpsAccum;
			this.fpsAccum = 0;
			this.fpsFrames = 0;
		}
		const phase = gameStore.getState().phase;
		const playing = phase === "playing";
		if (playing && !this.sleeping) this.worldTime += dt;
		if (this.toastT > 0) this.toastT = Math.max(0, this.toastT - dt);
		if (playing) {
			this.acc += dt;
			let steps = 0;
			while (this.acc >= FIXED && steps < 5) {
				this.fixed(FIXED);
				this.acc -= FIXED;
				steps++;
			}
			if (this.acc > FIXED * 5) this.acc = 0;
			this.updateLook();
			if (!this.sleeping) {
				this.updateTarget();
				this.updateBreakPlace(dt);
			}
			this.drops?.update(dt, this.world, this.player.x, this.player.y, this.player.z, (id, n) => {
				const left = addItem(this.hotbar, this.inventory, id, n);
				if (left < n) this.audio.pickup();
				return left === 0;
			});
			this.particles?.update(dt);
			if (this.dim === "end") {
				if (this.endBoss.update(dt) === "exit") this.openExit();
			}
			this.saveTimer += dt;
			if (this.saveTimer > 18) {
				this.saveTimer = 0;
				this.save();
			}
		} else {
			this.acc = 0;
			this.input.consumeLook();
			this.world.tickWater(24);
		}
		this.flushMeshes(this.switching ? 8 : playing ? 2 : 6);
		if (phase !== "paused" && phase !== "title" && phase !== "loading") this.tickFurnaces(dt);
		this.updateDay();
		this.syncCamera(dt);
		this.updateViewmodel(dt, playing);
		this.hurtFlash = Math.max(0, this.hurtFlash - dt);
		this.renderer.render(this.scene, this.camera);
		if (playing && !this.switching) {
			this.shotT -= dt;
			if (this.shotT <= 0 && this.shots.length < 6) {
				this.shotT = 30;
				const was = this.thirdPerson;
				this.thirdPerson = true;
				this.syncCamera(dt);
				this.renderer.render(this.scene, this.camera);
				try {
					this.shots.push(this.canvas.toDataURL("image/jpeg", .62));
				} catch {}
				this.thirdPerson = was;
				this.syncCamera(dt);
				this.renderer.render(this.scene, this.camera);
			}
		}
		if (this.hand.visible) {
			this.renderer.autoClear = false;
			this.renderer.clearDepth();
			this.renderer.render(this.vmScene, this.vmCam);
			this.renderer.autoClear = true;
		}
		this.hudT += dt;
		if (this.hudT > .08) {
			this.hudT = 0;
			this.pushHud(false);
		}
		this.handleCraftKey();
		this.input.endFrame();
	}
	handleCraftKey() {}
	updateLook() {
		const st = gameStore.getState();
		if (st.phase !== "playing" || this.sleeping) return;
		const look = this.input.consumeLook();
		const locked = st.pointerLocked;
		const mobile = st.isMobile;
		if (locked || mobile || this.input.isDown("Mouse0") || this.input.isDown("Mouse2")) this.player.look(look.dx, look.dy, st.settings.sensitivity);
		else {
			this.input.lookDx = 0;
			this.input.lookDy = 0;
		}
	}
	fixed(dt) {
		let mx = 0;
		let mz = 0;
		if (this.input.isDown("KeyA") || this.input.isDown("ArrowLeft")) mx -= 1;
		if (this.input.isDown("KeyD") || this.input.isDown("ArrowRight")) mx += 1;
		if (this.input.isDown("KeyW") || this.input.isDown("ArrowUp")) mz += 1;
		if (this.input.isDown("KeyS") || this.input.isDown("ArrowDown")) mz -= 1;
		mx += this.input.touchMoveX;
		mz += this.input.touchMoveY;
		if (mx > 1) mx = 1;
		if (mx < -1) mx = -1;
		if (mz > 1) mz = 1;
		if (mz < -1) mz = -1;
		if (this.input.justPressed("KeyC")) this.thirdPerson = !this.thirdPerson;
		if (this.sleeping) {
			this.sleepT += dt;
			this.player.vx = this.player.vy = this.player.vz = 0;
			this.snoreT -= dt;
			if (this.snoreT <= 0) {
				this.snoreT = 1.15;
				this.audio.snore();
			}
			if (this.sleepT >= 4.2) this.finishSleep();
			return;
		}
		const jump = this.input.justPressed("Space") || this.player.inWater && this.input.isDown("Space");
		const sneak = this.input.isDown("ShiftLeft") || this.input.isDown("ShiftRight");
		const sprint = this.input.isDown("ControlLeft") || this.input.isDown("ControlRight");
		if (this.boats.playerBoat && sneak) {
			this.boats.dismountPlayer();
			this.player.y += .6;
		} else if (this.boats.playerBoat) this.boats.drive(dt, mx, mz, this.player.yaw);
		this.boats.update(dt, this.world, this.mobs.mobs);
		if (this.boats.playerBoat) {
			const b = this.boats.playerBoat;
			this.player.x = b.x;
			this.player.y = b.y + .15;
			this.player.z = b.z;
			this.player.vx = this.player.vy = this.player.vz = 0;
			this.player.onGround = true;
			this.player.inWater = false;
		}
		const riding = !!this.boats.playerBoat;
		this.player.onGround;
		const distBefore = this.player.dist;
		const landed = riding ? 0 : this.player.step(dt, this.world, mx, mz, jump, sneak, sprint, this.food > 6);
		if (jump && this.player.vy > 0 && !this.player.inWater) {
			this.audio.jump();
			this.addExhaust(this.player.sprinting ? .2 : .05);
		}
		this.addExhaust((this.player.dist - distBefore) * (this.player.sprinting ? .1 : .01));
		let fall = landed;
		if (this.offhand?.id === 37 && sneak) fall *= .28;
		if (fall > 13) this.damage(Math.min(10, Math.floor((fall - 13) * .55)));
		this.stepTimer += dt;
		if (this.player.onGround && Math.hypot(this.player.vx, this.player.vz) > 1.4 && this.stepTimer > (this.player.sprinting ? .32 : .44)) {
			this.stepTimer = 0;
			this.audio.step();
		}
		if (this.dim === "end" && this.player.y < 6) {
			this.voidT += dt;
			if (this.voidT > .7) {
				this.voidT = 0;
				this.damage(1);
			}
		} else if (this.player.y < -8) {
			this.voidT = 0;
			this.health = 20;
			this.food = 20;
			this.air = 10;
			this.drownT = 0;
			this.saturation = 5;
			this.player.setSpawn(this.spawnX, this.spawnY, this.spawnZ);
			this.audio.hurt();
		} else this.voidT = 0;
		const wheel = this.input.consumeWheel();
		if (wheel) this.selected = (this.selected + wheel + 10) % 10;
		for (let i = 0; i < 9; i++) if (this.input.justPressed(`Digit${i + 1}`)) this.selected = i;
		if (this.input.justPressed("Digit0")) this.selected = 9;
		const pcx = Math.floor(this.player.x / 16);
		const pcz = Math.floor(this.player.z / 16);
		if (pcx !== this.lastCx || pcz !== this.lastCz) this.streamChunks(pcx, pcz);
		this.world.tickWater(48);
		this.world.tickLava(28);
		if (this.player.inLava) {
			this.lavaHurt += dt;
			if (this.lavaHurt >= .5) {
				this.lavaHurt = 0;
				this.damage(4);
			}
		} else this.lavaHurt = 0;
		this.tickBreath(dt);
		this.attackCd = Math.max(0, this.attackCd - dt);
		this.tickHunger(dt);
		const phase = (this.worldTime / DAY_LEN % 1 + 1) % 1;
		const isDay = this.dim === "overworld" && Math.sin(phase * Math.PI * 2) > .05;
		this.tickPortal(dt);
		const look = this.lookDir();
		this.mobs.update(dt, this.world, this.player.x, this.player.y, this.player.z, this.drops, {
			isDay,
			look,
			eyeY: this.player.eyeY,
			peaceful: !this.monsters,
			sound: (kind) => {
				if (kind === "chicken") this.audio.cluck();
				else if (kind === "cow") this.audio.moo();
				else if (kind === "zombie") this.audio.growl();
				else if (kind === "skeleton") this.audio.bones();
				else if (kind === "creeper") this.audio.hiss();
				else if (kind === "spider") this.audio.skitter();
				else this.audio.oink();
			},
			hurt: (n) => {
				if (this.player.sneaking && this.offhand?.id === 37) n = Math.max(1, Math.round(n * .35));
				this.damage(n);
			},
			boom: (x, y, z) => this.mobBoom(x, y, z)
		});
		this.tickToss(dt);
		while (this.world.loot.length) {
			const it = this.world.loot.pop();
			this.drops?.spawn(it.x + .5, it.y + .45, it.z + .5, it.id, it.count, false);
		}
	}
	updateTarget() {
		const f = this.lookDir();
		const held = this.hotbar[this.selected]?.id ?? 0;
		const fluids = held === 57 || held === 58 || held === 59;
		this.target = voxelRaycast(this.world, this.player.x, this.player.eyeY, this.player.z, f.x, f.y, f.z, 6.2, fluids ? (id) => isSolid(id) || isFluid(id) : isSolid);
		if (this.target) {
			this.highlight.visible = true;
			this.highlight.position.set(this.target.x + .5, this.target.y + .5, this.target.z + .5);
			const mh = this.mobs.raycast(this.player.x, this.player.eyeY, this.player.z, f.x, f.y, f.z, 4.6);
			if (mh) {
				const bd = Math.hypot(this.target.x + .5 - this.player.x, this.target.y + .5 - this.player.eyeY, this.target.z + .5 - this.player.z);
				if (mh.dist < bd) this.highlight.visible = false;
			}
		} else this.highlight.visible = false;
	}
	lookDir() {
		const cy = Math.cos(this.player.pitch);
		return {
			x: -Math.sin(this.player.yaw) * cy,
			y: Math.sin(this.player.pitch),
			z: -Math.cos(this.player.yaw) * cy
		};
	}
	updateBreakPlace(dt) {
		this.placeCd = Math.max(0, this.placeCd - dt);
		const breaking = this.input.isDown("Mouse0");
		const justHit = this.input.justPressed("Mouse0");
		const placing = this.input.justPressed("Mouse2") || this.input.isDown("Mouse2") && this.placeCd <= 0;
		const held = this.hotbar[this.selected]?.id ?? 0;
		const look = this.lookDir();
		if (justHit && (held === 82 || held === 83)) {
			if (held === 83 && this.target && (this.world.getBlock(this.target.x, this.target.y, this.target.z) === 65 || this.world.getBlock(this.target.x, this.target.y, this.target.z) === 66)) {
				this.insertEye(this.target.x, this.target.y, this.target.z);
				return;
			}
			this.throwEye(held === 83 ? "eye" : "pearl");
			return;
		}
		if (justHit && held === 84) {
			this.placeBoat();
			return;
		}
		let mobHit = this.mobs.raycast(this.player.x, this.player.eyeY, this.player.z, look.x, look.y, look.z, 4.6);
		if (!mobHit) mobHit = this.mobs.nearestInLook(this.player.x, this.player.eyeY, this.player.z, look.x, look.y, look.z, 3.1);
		const blockDist = this.target ? Math.hypot(this.target.x + .5 - this.player.x, this.target.y + .5 - this.player.eyeY, this.target.z + .5 - this.player.z) : 99;
		const boatHit = this.boats.ray(this.player.x, this.player.eyeY, this.player.z, look.x, look.y, look.z, 4.2);
		if (this.dim === "end" && justHit) {
			const crystal = this.endBoss.rayCrystal(this.player.x, this.player.eyeY, this.player.z, look.x, look.y, look.z, 6);
			const dragonDist = this.endBoss.rayDragon(this.player.x, this.player.eyeY, this.player.z, look.x, look.y, look.z, 6.5);
			if (crystal && crystal.dist < blockDist && (dragonDist == null || crystal.dist < dragonDist)) {
				this.blastCrystal(crystal.i);
				this.swingT = .22;
				this.audio.swing();
				return;
			}
			if (dragonDist != null && dragonDist < blockDist + .4 && this.attackCd <= 0) {
				this.attackCd = .5;
				this.swingT = .22;
				this.audio.swing();
				const healed = this.endBoss.crystalsLeft() > 0;
				const died = this.endBoss.hit(attackDamage(held) || 1);
				this.particles?.burst(this.endBoss.x, this.endBoss.y + .6, this.endBoss.z, 8);
				this.showToast(died ? "Ejderha düşüyor" : healed ? "Ejderha canını yeniledi" : `Ejderha ${Math.ceil(this.endBoss.hp)}`);
				this.wearHeld();
				return;
			}
		}
		if (justHit && boatHit && boatHit.dist + .2 < blockDist) {
			this.boats.mountPlayer(boatHit.boat);
			this.showToast("Tekneye bindin");
			return;
		}
		const mobFirst = mobHit != null && mobHit.dist < 4.2 && (mobHit.dist < blockDist + .45 || mobHit.dist < 2.4);
		if ((justHit || breaking) && mobFirst && mobHit && this.attackCd <= 0) {
			this.attackCd = .55;
			this.swingT = .22;
			this.audio.swing();
			this.addExhaust(.1);
			this.mobs.hit(mobHit.mob, attackDamage(held), this.player.x, this.player.z);
			if (mobHit.mob.hp <= 0) this.kills++;
			if (mobHit.mob.kind === "chicken") this.audio.cluck();
			else if (mobHit.mob.kind === "cow") this.audio.moo();
			else if (mobHit.mob.kind === "zombie") this.audio.growl();
			else if (mobHit.mob.kind === "skeleton") this.audio.bones();
			else if (mobHit.mob.kind === "creeper") this.audio.hiss();
			else if (mobHit.mob.kind === "spider") this.audio.skitter();
			else this.audio.oink();
			this.particles?.burst(mobHit.mob.x, mobHit.mob.y + .4, mobHit.mob.z, 8);
			this.wearHeld();
			this.breakT = 0;
			this.crackMesh.visible = false;
			return;
		}
		if (justHit && held === 61 && this.target) {
			const t = this.target;
			const lit = tryLightPortal(this.world, t.x, t.y, t.z) || tryLightPortal(this.world, t.x + t.nx, t.y + t.ny, t.z + t.nz);
			this.wearHeld();
			if (lit) {
				this.audio.place();
				this.showToast("Portal açıldı");
			} else this.showToast("Obsidyen çerçeve 4 eninde 6 boyunda olmalı");
			this.breakT = 0;
			this.crackMesh.visible = false;
			return;
		}
		if (isFood(held) && this.food < 20 && this.input.isDown("Mouse2")) {
			this.eatT += dt;
			if (this.eatT >= 1.32) {
				this.eatT = 0;
				const stats = foodStats(held);
				if (stats) {
					takeOne(this.hotbar, this.selected);
					this.food = Math.min(20, this.food + stats.hunger);
					this.saturation = Math.min(this.food, this.saturation + stats.saturation);
					this.audio.eat();
				}
			}
			this.breakT = 0;
			this.crackMesh.visible = false;
			return;
		}
		this.eatT = 0;
		if (breaking && this.target && !(mobHit && mobHit.dist < blockDist)) {
			const key = `${this.target.x},${this.target.y},${this.target.z}`;
			if (key !== this.breakKey) {
				this.breakKey = key;
				this.breakT = 0;
			}
			const id = this.world.getBlock(this.target.x, this.target.y, this.target.z);
			const def = BLOCKS[id];
			if (def && def.breakable) {
				if (this.breakT <= 0 && isTool(held)) this.audio.swing();
				this.breakT += dt;
				const dur = this.mineTime(id, def.hardness, held);
				const p = Math.min(1, this.breakT / dur);
				this.crackMesh.visible = p > .02;
				this.crackMesh.position.set(this.target.x + .5, this.target.y + .5, this.target.z + .5);
				const mi = Math.min(this.crackMats.length - 1, Math.floor(p * this.crackMats.length));
				this.crackMesh.material = this.crackMats[mi];
				if (!canFinishMine(id, held)) {
					if (this.breakT > dur * .9) this.breakT = dur * .9;
				} else if (p >= 1) {
					const drop = canHarvest(id, held) ? def.drops : 0;
					const finalDrop = id === 17 && drop === 17 && Math.random() < .25 ? 60 : drop;
					this.breakBlock(this.target.x, this.target.y, this.target.z, finalDrop);
					this.wearHeld();
					this.addExhaust(.005);
					this.breakT = 0;
				}
			} else {
				this.breakT = 0;
				this.crackMesh.visible = false;
			}
		} else {
			this.breakT = 0;
			this.breakKey = "";
			this.crackMesh.visible = false;
		}
		if (placing && this.target && !isFood(held)) {
			this.useOnTarget();
			this.placeCd = .22;
		}
	}
	addExhaust(n) {
		if (n <= 0) return;
		this.exhaust += n;
		while (this.exhaust >= 4) {
			this.exhaust -= 4;
			if (this.saturation > 0) this.saturation = Math.max(0, this.saturation - 1);
			else this.food = Math.max(0, this.food - 1);
		}
	}
	tickHunger(dt) {
		if (this.food >= 18 && this.health < 20) {
			this.regenT += dt;
			if (this.regenT >= 4) {
				this.regenT = 0;
				this.health = Math.min(20, this.health + 1);
				this.addExhaust(6);
			}
		} else this.regenT = 0;
		if (this.food <= 0) {
			this.starveT += dt;
			if (this.starveT >= 4) {
				this.starveT = 0;
				this.damage(1);
			}
		} else this.starveT = 0;
	}
	wearHeld(n = 1) {
		const s = this.hotbar[this.selected];
		if (wearStack(s, n)) {
			this.hotbar[this.selected] = null;
			this.audio.break();
		}
	}
	tickFurnaces(dt) {
		for (const f of this.furnaces.values()) tickFurnace(f, dt);
	}
	activeFurnace() {
		if (!this.furnaceAt) return null;
		return this.furnaces.get(this.furnaceAt) ?? null;
	}
	setFurnaceSlot(which, s) {
		const f = this.activeFurnace();
		if (!f) return;
		if (which === "input") f.input = s;
		else if (which === "fuel") f.fuel = s;
		else f.out = s;
	}
	openFurnace(x, y, z) {
		const k = `${x},${y},${z}`;
		if (!this.furnaces.has(k)) this.furnaces.set(k, emptyFurnace(x, y, z));
		this.furnaceAt = k;
		document.exitPointerLock?.();
		gameStore.getState().setPhase("furnace");
		gameStore.getState().setClickToPlay(false);
	}
	trySleep() {
		const t = this.target;
		if (!t) return;
		this.setBedSpawn(t.x, t.y, t.z);
		const phase = (this.worldTime / DAY_LEN % 1 + 1) % 1;
		if (Math.sin(phase * Math.PI * 2) > .05) return;
		this.sleeping = true;
		this.sleepT = 0;
		this.snoreT = .4;
		this.player.setSpawn(t.x + .5, t.y + .12, t.z + .5);
		this.player.pitch = .2;
		document.exitPointerLock?.();
		gameStore.getState().setClickToPlay(false);
		this.pushHud(true);
	}
	wake() {
		if (!this.sleeping) return;
		this.sleeping = false;
		this.sleepT = 0;
		this.standBesideBed();
		this.pushHud(true);
	}
	finishSleep() {
		this.sleeping = false;
		this.sleepT = 4.2;
		this.worldTime = 80;
		this.health = Math.min(20, this.health + 2);
		this.standBesideBed();
		this.showToast("Günaydın");
		this.pushHud(true);
	}
	standBesideBed() {
		const b = this.bedBlock;
		if (!b) return;
		this.player.setSpawn(b.x + .5, b.y + 1.05, b.z + 1.4);
		this.player.pitch = 0;
	}
	setBedSpawn(x, y, z) {
		this.bedBlock = {
			x,
			y,
			z
		};
		this.spawnX = x + .5;
		this.spawnY = y + 1.05;
		this.spawnZ = z + .5;
		this.showToast("Yeniden doğma noktası ayarlandı");
	}
	refreshBedSpawn() {
		const b = this.bedBlock;
		if (!b || this.world.getBlock(b.x, b.y, b.z) !== 46) {
			this.bedBlock = null;
			this.spawnX = this.homeX;
			this.spawnY = this.homeY;
			this.spawnZ = this.homeZ;
			return;
		}
		this.spawnX = b.x + .5;
		this.spawnY = b.y + 1.05;
		this.spawnZ = b.z + .5;
	}
	showToast(msg) {
		this.toast = msg;
		this.toastT = 3.2;
		this.pushHud(true);
	}
	useOnTarget() {
		const t = this.target;
		if (!t) return;
		const bid = this.world.getBlock(t.x, t.y, t.z);
		const hid = this.hotbar[this.selected]?.id ?? 0;
		if (bid === 44) {
			this.openFurnace(t.x, t.y, t.z);
			return;
		}
		if (bid === 46) {
			this.trySleep();
			return;
		}
		if (hid === 83 && (bid === 65 || bid === 66)) {
			this.insertEye(t.x, t.y, t.z);
			return;
		}
		if (hid === 61) {
			if (tryLightPortal(this.world, t.x, t.y, t.z) || tryLightPortal(this.world, t.x + t.nx, t.y + t.ny, t.z + t.nz)) {
				this.wearHeld();
				this.audio.place();
				return;
			}
		}
		if (hid === 57 && (bid === 12 || bid === 18)) {
			if (!(bid === 12 ? this.world.isWaterSource(t.x, t.y, t.z) : this.world.isLavaSource(t.x, t.y, t.z))) return;
			this.world.editBlock(t.x, t.y, t.z, 0);
			this.giveBucket(bid === 12 ? 58 : 59);
			this.audio.place();
			return;
		}
		if (hid === 58 || hid === 59) {
			const px = t.x + t.nx;
			const py = t.y + t.ny;
			const pz = t.z + t.nz;
			const place = hid === 58 ? 12 : 18;
			const cur = this.world.getBlock(px, py, pz);
			if (cur !== 0 && cur !== place) return;
			this.world.editBlock(px, py, pz, place);
			this.world.setSource(px, py, pz);
			this.giveBucket(57);
			this.audio.place();
			return;
		}
		this.tryPlace();
	}
	breakBlock(x, y, z, drop) {
		const prev = this.world.getBlock(x, y, z);
		if (!this.world.editBlock(x, y, z, 0)) return;
		this.broken++;
		this.audio.break();
		this.particles?.burst(x, y, z, 12);
		if (prev === 44) this.furnaces.delete(`${x},${y},${z}`);
		if (prev === 46 && this.bedBlock && this.bedBlock.x === x && this.bedBlock.y === y && this.bedBlock.z === z) {
			this.bedBlock = null;
			this.spawnX = this.homeX;
			this.spawnY = this.homeY;
			this.spawnZ = this.homeZ;
			this.showToast("Yatak kırıldı");
		}
		if (prev === 47 || prev === 19) {
			breakPortalNear(this.world, x + 1, y, z);
			breakPortalNear(this.world, x - 1, y, z);
			breakPortalNear(this.world, x, y + 1, z);
			breakPortalNear(this.world, x, y - 1, z);
			breakPortalNear(this.world, x, y, z + 1);
			breakPortalNear(this.world, x, y, z - 1);
		}
		if (drop && drop !== 0) this.drops?.spawn(x + .5, y + .42, z + .5, drop, 1);
	}
	giveBucket(id) {
		const held = this.hotbar[this.selected];
		if (held && held.count > 1) {
			held.count -= 1;
			addItem(this.hotbar, this.inventory, id, 1);
		} else this.hotbar[this.selected] = {
			id,
			count: 1
		};
	}
	tryPlace() {
		const t = this.target;
		if (!t) return;
		const stack = this.hotbar[this.selected];
		if (!stack || !isPlaceable(stack.id)) return;
		const px = t.x + t.nx;
		const py = t.y + t.ny;
		const pz = t.z + t.nz;
		if (isSolid(this.world.getBlock(px, py, pz))) return;
		const cur = this.world.getBlock(px, py, pz);
		if (cur !== 0 && cur !== 12 && cur !== 18) return;
		const hw = this.player.halfW();
		if (boxesOverlap(this.player.x - hw, this.player.y, this.player.z - hw, hw * 2, this.player.height(), hw * 2, px, py, pz, 1, 1, 1)) return;
		if (!this.world.editBlock(px, py, pz, stack.id)) return;
		if (stack.id === 44) this.furnaces.set(`${px},${py},${pz}`, emptyFurnace(px, py, pz));
		if (stack.id === 46) this.setBedSpawn(px, py, pz);
		takeOne(this.hotbar, this.selected);
		this.audio.place();
		this.addExhaust(.005);
	}
	mobBoom(x, y, z) {
		const R = 2.3;
		for (let dy = -2; dy <= 2; dy++) for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
			if (dx * dx + dy * dy + dz * dz > R * R) continue;
			const bx = Math.floor(x) + dx;
			const by = Math.floor(y) + dy;
			const bz = Math.floor(z) + dz;
			const id = this.world.getBlock(bx, by, bz);
			if (id === 0 || id === 9 || id === 19) continue;
			const def = BLOCKS[id];
			if (!def?.breakable || def.hardness > 5) continue;
			this.world.editBlock(bx, by, bz, 0);
		}
		const d = Math.hypot(this.player.x - x, this.player.y + .9 - y, this.player.z - z);
		if (d < 5.2) this.damage(Math.max(2, Math.round((5.2 - d) * 2.4)));
		this.particles?.burst(x, y, z, 26);
		this.audio.boom();
	}
	mineTime(id, hardness, held) {
		const base = mineDuration(id, hardness, held);
		return this.player.inWater ? base * 1.85 : base;
	}
	tickBreath(dt) {
		const ix = Math.floor(this.player.x);
		const iz = Math.floor(this.player.z);
		if (isWater(this.world.getBlock(ix, Math.floor(this.player.y + 1.5), iz)) && !this.boats.playerBoat) {
			this.air = Math.max(0, this.air - dt * (10 / 15));
			if (this.air <= 0) {
				this.drownT += dt;
				if (this.drownT >= 1) {
					this.drownT = 0;
					this.damage(2);
				}
			}
		} else {
			this.drownT = 0;
			this.air = Math.min(10, this.air + dt * 4);
		}
	}
	damage(n) {
		if (n <= 0) return;
		this.health = Math.max(0, this.health - n);
		this.hurtFlash = .32;
		this.hurtDir = Math.random() < .5 ? -1 : 1;
		this.audio.hurt();
		if (this.health <= 0) {
			if (this.dim === "end") {
				this.respawnFromEnd();
				return;
			}
			this.health = 20;
			this.food = 20;
			this.air = 10;
			this.drownT = 0;
			this.saturation = 5;
			this.exhaust = 0;
			this.player.setSpawn(this.spawnX, this.spawnY, this.spawnZ);
		}
	}
	async generateAround(blocking) {
		const dist = gameStore.getState().settings.renderDistance;
		const pcx = Math.floor(this.player.x / 16);
		const pcz = Math.floor(this.player.z / 16);
		const jobs = [];
		for (let dz = -dist - 1; dz <= dist + 1; dz++) for (let dx = -dist - 1; dx <= dist + 1; dx++) jobs.push([
			pcx + dx,
			pcz + dz,
			Math.abs(dx) + Math.abs(dz)
		]);
		jobs.sort((a, b) => a[2] - b[2]);
		let i = 0;
		for (const [cx, cz] of jobs) {
			this.world.ensureChunk(cx, cz);
			this.world.dirty.add(`${cx},${cz}`);
			i++;
			if (blocking && i % 8 === 0) {
				gameStore.getState().setLoading(i / jobs.length * .55);
				await yieldFrame();
				if (this.disposed) return;
			}
		}
	}
	async meshAllDirty() {
		const keys = [...this.world.dirty];
		keys.sort((a, b) => {
			const [ax, az] = a.split(",").map(Number);
			const [bx, bz] = b.split(",").map(Number);
			const pcx = Math.floor(this.player.x / 16);
			const pcz = Math.floor(this.player.z / 16);
			return Math.abs(ax - pcx) + Math.abs(az - pcz) - (Math.abs(bx - pcx) + Math.abs(bz - pcz));
		});
		const total = Math.max(1, keys.length);
		let i = 0;
		for (const k of keys) {
			this.world.dirty.delete(k);
			const [cx, cz] = k.split(",").map(Number);
			this.rebuildChunk(cx, cz);
			i++;
			if (i % 6 === 0) {
				gameStore.getState().setLoading(.55 + i / total * .45);
				await yieldFrame();
				if (this.disposed) return;
			}
		}
		this.meshQueue = [];
		gameStore.getState().setLoading(1);
	}
	streamChunks(pcx, pcz) {
		this.lastCx = pcx;
		this.lastCz = pcz;
		const dist = gameStore.getState().settings.renderDistance;
		for (let dz = -dist; dz <= dist; dz++) for (let dx = -dist; dx <= dist; dx++) {
			const cx = pcx + dx;
			const cz = pcz + dz;
			this.world.ensureChunk(cx, cz);
		}
		const removed = this.world.unloadFar(pcx, pcz, dist);
		for (const k of removed) this.disposeChunkMesh(k);
	}
	flushMeshes(budget) {
		if (this.world.dirty.size) {
			const keys = [...this.world.dirty];
			keys.sort((a, b) => {
				const [ax, az] = a.split(",").map(Number);
				const [bx, bz] = b.split(",").map(Number);
				const pcx = Math.floor(this.player.x / 16);
				const pcz = Math.floor(this.player.z / 16);
				return Math.abs(ax - pcx) + Math.abs(az - pcz) - (Math.abs(bx - pcx) + Math.abs(bz - pcz));
			});
			this.meshQueue = keys;
		}
		let n = 0;
		while (n < budget && this.meshQueue.length) {
			const k = this.meshQueue.shift();
			if (!this.world.dirty.has(k)) continue;
			this.world.dirty.delete(k);
			const [cx, cz] = k.split(",").map(Number);
			this.rebuildChunk(cx, cz);
			n++;
		}
	}
	rebuildChunk(cx, cz) {
		const k = chunkKey(cx, cz);
		this.disposeChunkMesh(k);
		if (!this.material) return;
		const geo = meshChunk(this.world, cx, cz);
		if (geo) {
			const mesh = new Mesh(geo, this.material);
			mesh.matrixAutoUpdate = false;
			mesh.updateMatrix();
			this.scene.add(mesh);
			this.chunkMeshes.set(k, mesh);
		}
		if (this.waterMat) {
			const wgeo = meshWater(this.world, cx, cz);
			if (wgeo) {
				const wm = new Mesh(wgeo, this.waterMat);
				wm.matrixAutoUpdate = false;
				wm.updateMatrix();
				this.scene.add(wm);
				this.waterMeshes.set(k, wm);
			}
		}
		if (this.lavaMat) {
			const lgeo = meshLava(this.world, cx, cz);
			if (lgeo) {
				const lm = new Mesh(lgeo, this.lavaMat);
				lm.matrixAutoUpdate = false;
				lm.updateMatrix();
				this.scene.add(lm);
				this.lavaMeshes.set(k, lm);
			}
		}
		if (this.portalMat) {
			const pgeo = meshPortal(this.world, cx, cz);
			if (pgeo) {
				const pm = new Mesh(pgeo, this.portalMat);
				pm.matrixAutoUpdate = false;
				pm.updateMatrix();
				this.scene.add(pm);
				this.portalMeshes.set(k, pm);
			}
		}
		this.syncFrames(cx, cz);
	}
	async loadEndFrame() {
		try {
			const gltf = await new GLTFLoader().loadAsync("/models/end-frame.gltf");
			gltf.scene.updateMatrixWorld(true);
			const buckets = /* @__PURE__ */ new Map();
			gltf.scene.traverse((obj) => {
				const mesh = obj;
				if (!mesh.isMesh) return;
				const geo = mesh.geometry.clone();
				geo.applyMatrix4(mesh.matrixWorld);
				const mat = Array.isArray(mesh.material) ? mesh.material[0] : mesh.material;
				const list = buckets.get(mat) ?? [];
				list.push(geo);
				buckets.set(mat, list);
			});
			const group = new Group();
			for (const [src, geos] of buckets) {
				const merged = mergeGeometries(geos, false);
				if (!merged) continue;
				const std = src;
				if (std.map) {
					std.map.magFilter = NearestFilter;
					std.map.minFilter = NearestFilter;
					std.map.colorSpace = SRGBColorSpace;
					std.map.needsUpdate = true;
				}
				const mat = new MeshLambertMaterial({
					map: std.map ?? null,
					color: std.color ?? 16777215,
					alphaTest: .05,
					side: 2
				});
				const mesh = new Mesh(merged, mat);
				mesh.castShadow = false;
				mesh.receiveShadow = false;
				group.add(mesh);
				for (const g of geos) g.dispose();
			}
			this.frameTpl = group;
			const eye = new Group();
			const shell = new Mesh(new SphereGeometry(.12, 8, 6), new MeshLambertMaterial({
				color: 4841616,
				emissive: 1334322,
				emissiveIntensity: .35
			}));
			shell.scale.set(1, .55, 1);
			const pupil = new Mesh(new SphereGeometry(.045, 6, 5), new MeshLambertMaterial({ color: 1056792 }));
			pupil.position.set(0, .05, 0);
			eye.add(shell, pupil);
			eye.position.set(0, .7, 0);
			this.frameEye = eye;
		} catch (err) {
			console.warn("end frame model", err);
		}
	}
	syncFrames(cx, cz) {
		const k = chunkKey(cx, cz);
		this.clearFrames(k);
		if (!this.frameTpl) return;
		const data = this.world.chunks.get(k);
		if (!data) return;
		const ox = cx * 16;
		const oz = cz * 16;
		const root = new Group();
		let n = 0;
		for (let y = 0; y < 64; y++) for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
			const id = data[x + z * 16 + y * 16 * 16] ?? 0;
			if (id !== 65 && id !== 66) continue;
			const wx = ox + x;
			const wz = oz + z;
			const inst = this.frameTpl.clone(true);
			inst.position.set(wx + .5, y + .002, wz + .5);
			inst.rotation.y = this.frameYaw(wx, y, wz);
			if (id === 66 && this.frameEye) inst.add(this.frameEye.clone(true));
			root.add(inst);
			n++;
		}
		if (!n) return;
		this.scene.add(root);
		this.frameGroups.set(k, root);
	}
	frameYaw(x, y, z) {
		const isFrame = (bx, bz) => {
			const id = this.world.getBlock(bx, y, bz);
			return id === 65 || id === 66;
		};
		let sx = 0;
		let sz = 0;
		let n = 0;
		for (let dz = -6; dz <= 6; dz++) for (let dx = -6; dx <= 6; dx++) {
			if (!isFrame(x + dx, z + dz)) continue;
			sx += dx;
			sz += dz;
			n++;
		}
		if (!n) return 0;
		const dx = sx / n;
		const dz = sz / n;
		if (Math.abs(dx) > Math.abs(dz)) return dx > 0 ? Math.PI / 2 : -Math.PI / 2;
		return dz > 0 ? 0 : Math.PI;
	}
	clearFrames(k) {
		const g = this.frameGroups.get(k);
		if (!g) return;
		this.scene.remove(g);
		this.frameGroups.delete(k);
	}
	disposeChunkMesh(k) {
		this.clearFrames(k);
		const m = this.chunkMeshes.get(k);
		if (m) {
			this.scene.remove(m);
			m.geometry.dispose();
			this.chunkMeshes.delete(k);
		}
		const w = this.waterMeshes.get(k);
		if (w) {
			this.scene.remove(w);
			w.geometry.dispose();
			this.waterMeshes.delete(k);
		}
		const lv = this.lavaMeshes.get(k);
		if (lv) {
			this.scene.remove(lv);
			lv.geometry.dispose();
			this.lavaMeshes.delete(k);
		}
		const p = this.portalMeshes.get(k);
		if (p) {
			this.scene.remove(p);
			p.geometry.dispose();
			this.portalMeshes.delete(k);
		}
	}
	placeBoat() {
		const dir = this.lookDir();
		const t = this.target;
		const x = t ? t.x + t.nx + .5 : this.player.x + dir.x * 2;
		const y = t ? t.y + t.ny : this.player.y;
		const z = t ? t.z + t.nz + .5 : this.player.z + dir.z * 2;
		const boat = this.boats.spawn(x, y + .1, z);
		boat.yaw = this.player.yaw;
		takeOne(this.hotbar, this.selected);
		this.boats.mountPlayer(boat);
		this.audio.place();
		this.showToast("Tekne");
	}
	throwEye(kind) {
		const dir = this.lookDir();
		let vx = dir.x * 14;
		let vy = dir.y * 14 + 1.4;
		let vz = dir.z * 14;
		let tx = 0;
		let tz = 0;
		if (kind === "eye") {
			const rooms = this.world.rooms.length ? this.world.rooms : strongholds(this.seed);
			let s = rooms[0];
			let best = Infinity;
			for (const room of rooms) {
				const dd = (room.x - this.player.x) ** 2 + (room.z - this.player.z) ** 2;
				if (dd < best) {
					best = dd;
					s = room;
				}
			}
			tx = s.x + 6.5;
			tz = s.z + 6.5;
			const dx = tx - this.player.x;
			const dz = tz - this.player.z;
			const len = Math.hypot(dx, dz) || 1;
			vx = dx / len * 12;
			vz = dz / len * 12;
			vy = 6.5;
		}
		const mesh = new Mesh(new SphereGeometry(.14, 8, 6), new MeshLambertMaterial({
			color: kind === "eye" ? 4050548 : 1336918,
			emissive: kind === "eye" ? 1334322 : 403488
		}));
		mesh.position.set(this.player.x, this.player.eyeY, this.player.z);
		this.scene.add(mesh);
		this.tosses.push({
			kind,
			x: this.player.x,
			y: this.player.eyeY,
			z: this.player.z,
			vx,
			vy,
			vz,
			tx,
			tz,
			mesh
		});
		takeOne(this.hotbar, this.selected);
		this.audio.swing();
	}
	tickToss(dt) {
		for (let i = this.tosses.length - 1; i >= 0; i--) {
			const t = this.tosses[i];
			if (t.kind === "eye") {
				const dx = t.tx - t.x;
				const dz = t.tz - t.z;
				const d = Math.hypot(dx, dz);
				if (d < 16) t.vy = -10;
				else {
					t.vx += (dx / d * 12 - t.vx) * Math.min(1, 3 * dt);
					t.vz += (dz / d * 12 - t.vz) * Math.min(1, 3 * dt);
					t.vy -= 7 * dt;
				}
			} else t.vy -= 16 * dt;
			const px = t.x;
			const py = t.y;
			const pz = t.z;
			t.x += t.vx * dt;
			t.y += t.vy * dt;
			t.z += t.vz * dt;
			t.mesh.position.set(t.x, t.y, t.z);
			if (!(t.y < 1 || isSolid(this.world.getBlock(Math.floor(t.x), Math.floor(t.y), Math.floor(t.z))))) continue;
			if (t.kind === "pearl") {
				const tx = px;
				const ty = Math.max(1, py);
				const tz = pz;
				if (!isSolid(this.world.getBlock(Math.floor(tx), Math.floor(ty), Math.floor(tz)))) {
					this.player.setSpawn(tx, ty, tz);
					this.showToast("Işınlandın");
				}
			} else if (Math.hypot(t.tx - t.x, t.tz - t.z) < 18) this.showToast("End gözü tapınağa gömüldü");
			else this.drops?.spawn(px, py + .2, pz, 83, 1, false);
			this.scene.remove(t.mesh);
			t.mesh.geometry.dispose();
			t.mesh.material.dispose();
			this.tosses.splice(i, 1);
		}
	}
	insertEye(x, y, z) {
		if (this.world.getBlock(x, y, z) !== 65) {
			this.showToast("Bu çerçevede göz var");
			return;
		}
		this.world.editBlock(x, y, z, 66);
		takeOne(this.hotbar, this.selected);
		this.audio.place();
		for (const room of this.world.rooms) {
			const frames = frameSpots(room);
			if (!frames.some(([fx, fy, fz]) => fx === x && fy === y && fz === z)) continue;
			if (frames.every(([fx, fy, fz]) => this.world.getBlock(fx, fy, fz) === 66)) {
				for (const [px, py, pz] of portalSpots(room)) this.world.editBlock(px, py, pz, 67);
				this.showToast("End portalı açıldı");
			} else this.showToast("End gözü yerleştirildi");
			return;
		}
		this.showToast("End gözü yerleştirildi");
	}
	tickPortal(dt) {
		if (this.switching) return;
		if (this.portalLock > 0) {
			this.portalLock -= dt;
			this.portalT = 0;
			return;
		}
		const x = Math.floor(this.player.x);
		const y = Math.floor(this.player.y);
		const z = Math.floor(this.player.z);
		const here = this.world.getBlock(x, y, z);
		const above = this.world.getBlock(x, y + 1, z);
		const nether = here === 47 || above === 47;
		const endGate = here === 67 || above === 67;
		if (!nether && !endGate) {
			this.portalT = 0;
			return;
		}
		this.portalT += dt;
		if (this.portalT < .85) return;
		this.portalT = 0;
		this.portalLock = 3.2;
		if (endGate && this.dim === "overworld") this.enterEnd();
		else if (endGate && this.dim === "end") this.startCredits();
		else if (nether && this.dim !== "end") this.switchDimension();
	}
	async switchDimension() {
		if (this.switching || !this.overworld || !this.nether || !this.end) return;
		if (this.dim === "overworld") {
			this.ow = {
				x: this.player.x,
				y: this.player.y,
				z: this.player.z
			};
			this.sawNether = true;
			if (!this.nd) {
				const nx = Math.floor(this.ow.x / 8);
				const nz = Math.floor(this.ow.z / 8);
				this.carveNetherPortal(nx, 26, nz);
				this.nd = {
					x: nx + 1.5,
					y: 26.05,
					z: nz + .5
				};
			}
			await this.arrive("nether", this.nd.x, this.nd.y, this.nd.z, "Nether");
		} else if (this.dim === "nether") {
			this.nd = {
				x: this.player.x,
				y: this.player.y,
				z: this.player.z
			};
			await this.arrive("overworld", this.ow.x, this.ow.y + .05, this.ow.z, "Üst dünya");
		}
	}
	enterEnd() {
		if (this.dim !== "overworld" || this.switching || !this.end) return;
		this.ow = {
			x: this.player.x,
			y: this.player.y,
			z: this.player.z
		};
		const y = (this.end.endSurface(6, 6) ?? 36) + 1.15;
		this.arrive("end", 6.5, y, 6.5, "End");
	}
	respawnFromEnd() {
		if (this.switching) return;
		this.health = 20;
		this.food = 20;
		this.air = 10;
		this.drownT = 0;
		this.saturation = 5;
		this.exhaust = 0;
		let x = this.homeX;
		let y = this.homeY;
		let z = this.homeZ;
		let msg = "Dünyada doğdun";
		const bed = this.bedBlock;
		if (bed && this.overworld?.getBlock(bed.x, bed.y, bed.z) === 46) {
			x = bed.x + .5;
			y = bed.y + .2;
			z = bed.z + .5;
			msg = "Yatağında doğdun";
		}
		this.arrive("overworld", x, y, z, msg);
	}
	startCredits() {
		document.exitPointerLock?.();
		gameStore.getState().setClickToPlay(false);
		gameStore.getState().setPhase("credits");
	}
	creditsView() {
		return {
			lines: this.storyLines(),
			shots: this.shots.slice()
		};
	}
	returnFromCredits() {
		gameStore.getState().setPhase("playing");
		this.portalLock = 3.5;
		this.arrive("overworld", this.ow.x, this.ow.y + .2, this.ow.z, "Üst dünya");
		this.requestLock();
	}
	storyLines() {
		const lines = ["Bir zamanlar üst dünyada bir gezgin uyanmıştı."];
		if (this.broken > 4) lines.push(`${this.broken} bloğu elleriyle kırmış, taşı ve toprağı yol etmişti.`);
		if (this.kills > 0) lines.push(`Yoluna çıkan ${this.kills} canlıyı geri püskürtmüştü.`);
		if (this.sawNether) lines.push("Obsidyen bir kapıdan geçmiş, Nether'ın sıcaklığına inmişti.");
		lines.push("On altı end gözünü çerçevelere koyunca ortada bir portal açıldı.");
		lines.push("End'in boşluğuna adım attı. Altında ada yoktu; sadece karanlık.");
		lines.push("Büyük adanın çevresinde sekiz kule duruyordu. Üstlerinde kristaller dönüyordu.");
		if (this.endBoss.crystalsLeft() === 0) lines.push("Kristalleri bir bir patlattı. Ejderha artık iyileşemiyordu.");
		lines.push("Ejderha parçalandı. Ortasından bir ışık yükseldi.");
		lines.push("Adanın ortasında ana kayadan bir kapı kaldı. Gezgin içeri girdi.");
		return lines;
	}
	blastCrystal(i) {
		const c = this.endBoss.killCrystal(i);
		if (!c) return;
		this.audio.boom();
		this.particles?.burst(c.x, c.y, c.z, 18);
		const px = this.player.x;
		const py = this.player.y + .9;
		const pz = this.player.z;
		if (Math.hypot(px - c.x, py - c.y, pz - c.z) < 8.5) {
			const blocked = this.occluded(c.x, c.y, c.z, px, py, pz);
			this.damage(blocked ? 3 : 8);
			const dx = px - c.x;
			const dz = pz - c.z;
			const len = Math.hypot(dx, dz) || 1;
			const kick = blocked ? 3 : 8;
			this.player.vx += dx / len * kick;
			this.player.vz += dz / len * kick;
			this.player.vy = Math.max(this.player.vy, blocked ? 2.2 : 5.4);
		}
		for (const m of this.mobs.mobs) {
			if (Math.hypot(m.x - c.x, m.y - c.y, m.z - c.z) > 7) continue;
			m.hp -= 8;
			const dx = m.x - c.x;
			const dz = m.z - c.z;
			const len = Math.hypot(dx, dz) || 1;
			m.vx += dx / len * 7;
			m.vz += dz / len * 7;
			m.vy = 4;
		}
	}
	occluded(x, y, z, px, py, pz) {
		const steps = 8;
		for (let i = 1; i < steps; i++) {
			const t = i / steps;
			const bx = Math.floor(x + (px - x) * t);
			const by = Math.floor(y + (py - y) * t);
			const bz = Math.floor(z + (pz - z) * t);
			if (isSolid(this.world.getBlock(bx, by, bz))) return true;
		}
		return false;
	}
	openExit() {
		const w = this.end;
		if (!w) return;
		const y = w.endSurface(0, 0) ?? 34;
		for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) w.editBlock(dx, y, dz, 9);
		w.editBlock(0, y + 1, 0, 67);
		this.portalLock = 2.4;
		this.showToast("Çıkış portalı açıldı");
	}
	async arrive(next, x, y, z, toast) {
		if (this.switching || !this.overworld || !this.nether || !this.end) return;
		this.switching = true;
		this.dim = next;
		this.world = next === "nether" ? this.nether : next === "end" ? this.end : this.overworld;
		this.player.setSpawn(x, y, z);
		this.player.vx = this.player.vy = this.player.vz = 0;
		this.endBoss.group.visible = next === "end";
		this.showToast(toast);
		this.dropMeshes();
		this.mobs.clear();
		this.boats.clear();
		for (const t of this.tosses) {
			this.scene.remove(t.mesh);
			t.mesh.geometry.dispose();
		}
		this.tosses = [];
		this.drops?.clear();
		this.meshQueue = [];
		this.lastCx = 99999;
		this.lastCz = 99999;
		await this.generateAround(false);
		this.stepOutOfPortal();
		const dist = gameStore.getState().settings.renderDistance;
		const pcx = Math.floor(this.player.x / 16);
		const pcz = Math.floor(this.player.z / 16);
		for (let dz = -dist - 1; dz <= dist + 1; dz++) for (let dx = -dist - 1; dx <= dist + 1; dx++) {
			this.world.ensureChunk(pcx + dx, pcz + dz);
			this.world.dirty.add(`${pcx + dx},${pcz + dz}`);
		}
		await this.meshAllDirty();
		this.mobs.seedAround(this.world, this.player.x, this.player.z, !this.monsters);
		this.syncCamera();
		this.save();
		this.switching = false;
	}
	carveNetherPortal(x, y, z) {
		const w = this.nether;
		if (!w) return;
		for (let dy = 0; dy < 7; dy++) for (let dx = -1; dx <= 4; dx++) for (let dz = -2; dz <= 2; dz++) w.editBlock(x + dx, y + dy, z + dz, 0);
		for (let dx = -1; dx <= 4; dx++) for (let dz = -2; dz <= 2; dz++) w.editBlock(x + dx, y - 1, z + dz, 62);
		for (let dy = 0; dy < 6; dy++) for (let dx = 0; dx < 4; dx++) {
			const edge = dy === 0 || dy === 5 || dx === 0 || dx === 3;
			w.editBlock(x + dx, y + dy, z, edge ? 19 : 47);
		}
	}
	stepOutOfPortal() {
		const x = Math.floor(this.player.x);
		const y = Math.floor(this.player.y);
		const z = Math.floor(this.player.z);
		const gate = (bx, by, bz) => {
			const id = this.world.getBlock(bx, by, bz);
			return id === 47 || id === 67;
		};
		if (!(gate(x, y, z) || gate(x, y + 1, z))) return;
		for (const [dx, dz] of [
			[0, 2],
			[0, -2],
			[3, 0],
			[-3, 0],
			[0, 3],
			[0, -3]
		]) {
			const nx = x + dx;
			const nz = z + dz;
			if (gate(nx, y, nz) || gate(nx, y + 1, nz)) continue;
			if (isSolid(this.world.getBlock(nx, y, nz)) || isSolid(this.world.getBlock(nx, y + 1, nz))) continue;
			const below = this.world.getBlock(nx, y - 1, nz);
			if (below === 18 || below === 12 || !isSolid(below)) continue;
			this.player.x = nx + .5;
			this.player.z = nz + .5;
			return;
		}
	}
	buildAvatar() {
		const g = new Group();
		const look = loadLook();
		const skin = SKINS[look.skin] ?? SKINS[0];
		const shirt = SHIRTS[look.shirt] ?? SHIRTS[0];
		const pants = PANTS[look.pants] ?? PANTS[0];
		const part = (x, y, z, w, h, d, color) => {
			const m = new Mesh(new BoxGeometry(w, h, d), new MeshLambertMaterial({ color }));
			m.position.set(x, y, z);
			g.add(m);
			return m;
		};
		part(0, 1.62, 0, .5, .5, .5, skin);
		part(0, 1.05, 0, .5, .72, .28, shirt);
		const armL = part(-.38, 1.05, 0, .22, .72, .22, skin);
		const armR = part(.38, 1.05, 0, .22, .72, .22, skin);
		const legL = part(-.14, .36, 0, .22, .72, .22, pants);
		const legR = part(.14, .36, 0, .22, .72, .22, pants);
		this.avatarLegs = [
			legL,
			legR,
			armL,
			armR
		];
		return g;
	}
	syncAvatar() {
		const a = this.avatar;
		if (!a) return;
		a.position.set(this.player.x, this.player.y, this.player.z);
		a.rotation.y = this.player.yaw;
		const swing = Math.sin(this.player.bob * 1.4) * .6;
		const [legL, legR, armL, armR] = this.avatarLegs;
		if (legL && legR && armL && armR) {
			legL.rotation.x = swing;
			legR.rotation.x = -swing;
			armL.rotation.x = -swing;
			armR.rotation.x = swing;
		}
	}
	dropMeshes() {
		const keys = /* @__PURE__ */ new Set([
			...this.chunkMeshes.keys(),
			...this.waterMeshes.keys(),
			...this.lavaMeshes.keys(),
			...this.portalMeshes.keys()
		]);
		for (const k of keys) this.disposeChunkMesh(k);
	}
	updateDay() {
		if (this.dim === "end") {
			const sky = new Color(459023);
			this.scene.background = sky;
			this.scene.fog.color.copy(sky);
			this.scene.fog.near = 18;
			this.scene.fog.far = 90;
			this.hemi.color.set(6965896);
			this.hemi.groundColor.set(1181720);
			this.hemi.intensity = .45;
			this.ambient.color.set(13350880);
			this.ambient.intensity = .32;
			this.sun.intensity = .18;
			this.sun.color.set(14205183);
			this.stars.visible = true;
			this.stars.material.opacity = .7;
			this.sunMesh.visible = false;
			this.moonMesh.visible = false;
			gameStore.getState().patchHud({
				dayPhase: .82,
				isDay: false
			});
			return;
		}
		if (this.dim === "nether") {
			const sky = new Color(1312262);
			this.scene.background = sky;
			this.scene.fog.color.copy(sky);
			this.scene.fog.near = 8;
			this.scene.fog.far = 48;
			this.hemi.color.set(16733488);
			this.hemi.groundColor.set(2754566);
			this.hemi.intensity = .55;
			this.ambient.color.set(16737860);
			this.ambient.intensity = .38;
			this.sun.intensity = .22;
			this.sun.color.set(16733491);
			this.stars.visible = false;
			this.sunMesh.visible = false;
			this.moonMesh.visible = false;
			gameStore.getState().patchHud({
				dayPhase: .75,
				isDay: false
			});
			if (this.portalMat) {
				const t = this.worldTime * 6;
				this.portalMat.emissiveIntensity = .7 + Math.sin(t) * .25;
				this.portalMat.opacity = .55;
			}
			return;
		}
		this.hemi.color.set(12114175);
		this.hemi.groundColor.set(4016682);
		this.ambient.color.set(16777215);
		this.stars.visible = true;
		const phase = (this.worldTime / DAY_LEN % 1 + 1) % 1;
		const ang = phase * Math.PI * 2;
		const sunY = Math.sin(ang);
		const sunX = Math.cos(ang);
		const day = Math.max(0, sunY);
		const dusk = Math.max(0, 1 - Math.abs(sunY) * 3);
		const skyDay = new Color(7980256);
		const skyDusk = new Color(14711368);
		const sky = new Color(329490).clone().lerp(skyDay, day);
		sky.lerp(skyDusk, dusk * .7);
		this.scene.background = sky;
		this.scene.fog.color.copy(sky);
		const dist = gameStore.getState().settings.renderDistance;
		this.scene.fog.near = dist * 8;
		this.scene.fog.far = dist * 16 + 24;
		this.sun.position.set(sunX * 80, sunY * 80, 30);
		this.sun.intensity = .12 + day * 1.05;
		this.sun.color.set(dusk > .2 ? 16760969 : 16774096);
		this.hemi.intensity = .22 + day * .55;
		this.ambient.intensity = .16 + day * .28;
		this.stars.material.opacity = Math.max(0, .85 - day * 1.6);
		const px = this.player.x;
		const py = this.player.y;
		const pz = this.player.z;
		this.sunMesh.position.set(px + sunX * 140, py + sunY * 140, pz + 40);
		this.moonMesh.position.set(px - sunX * 140, py - sunY * 140, pz - 30);
		this.sunMesh.visible = sunY > -.15;
		this.moonMesh.visible = sunY < .15;
		this.stars.position.set(px, py, pz);
		gameStore.getState().patchHud({
			dayPhase: phase,
			isDay: sunY > .05
		});
		if (this.portalMat) {
			const t = this.worldTime * 6;
			this.portalMat.emissiveIntensity = .55 + Math.sin(t) * .28;
			this.portalMat.opacity = .42 + Math.sin(t * 1.3) * .12;
		}
	}
	syncCamera(dt = .016) {
		if (this.sleeping && this.bedBlock) {
			const b = this.bedBlock;
			const lie = Math.min(1, this.sleepT / 1.1);
			this.yawObj.position.set(b.x + .5, b.y + 1.35 - lie * .35, b.z + 1.15);
			this.yawObj.rotation.set(0, Math.PI, 0);
			this.camera.position.set(0, 0, 0);
			this.camera.rotation.set(-.15 + lie * .85, 0, Math.sin(this.sleepT * 1.4) * .04);
			return;
		}
		this.syncAvatar();
		const tilt = (this.hurtFlash / .32) ** 2 * .05 * this.hurtDir;
		if (this.thirdPerson && !this.sleeping) {
			const dir = this.lookDir();
			let dist = 4.4;
			for (let t = .45; t < dist; t += .28) {
				const bx = Math.floor(this.player.x - dir.x * t);
				const by = Math.floor(this.player.eyeY - dir.y * t);
				const bz = Math.floor(this.player.z - dir.z * t);
				if (isSolid(this.world.getBlock(bx, by, bz))) {
					dist = Math.max(.7, t - .2);
					break;
				}
			}
			this.yawObj.position.set(this.player.x - dir.x * dist, this.player.eyeY - dir.y * dist, this.player.z - dir.z * dist);
			this.yawObj.rotation.set(0, this.player.yaw, 0);
			this.camera.position.set(0, 0, 0);
			this.camera.rotation.set(this.player.pitch, 0, tilt);
			if (this.avatar) this.avatar.visible = true;
		} else {
			this.yawObj.position.set(this.player.x, this.player.eyeY, this.player.z);
			this.yawObj.rotation.set(0, this.player.yaw, 0);
			const bob = this.player.bob * .02;
			this.camera.position.set(0, bob, 0);
			this.camera.rotation.set(this.player.pitch, 0, tilt);
			if (this.avatar) this.avatar.visible = false;
		}
		this.vmCam.rotation.z = tilt;
		const wantFov = this.player.sprinting ? 74 : 72;
		this.camera.fov += (wantFov - this.camera.fov) * Math.min(1, dt * 4);
		if (Math.abs(this.camera.fov - wantFov) > .02) this.camera.updateProjectionMatrix();
	}
	updateViewmodel(dt, playing) {
		const id = this.hotbar[this.selected]?.id ?? 0;
		const tool = isTool(id);
		const kind = toolKind(id);
		const blocking = playing && this.player.sneaking && this.offhand?.id === 37;
		const show = playing && !this.sleeping && !this.thirdPerson && (id > 0 || blocking);
		this.hand.visible = show;
		if (this.activeTool) this.activeTool.visible = false;
		this.blockView.visible = false;
		if (this.shieldView) this.shieldView.visible = false;
		if (this.meatView) this.meatView.visible = false;
		if (show && tool && kind && kind !== "shield") {
			let g = this.toolViews.get(id);
			if (!g) {
				g = modelForItem(id) ?? void 0;
				if (g) {
					this.toolViews.set(id, g);
					this.hand.add(g);
				}
			}
			if (g) {
				g.visible = true;
				this.activeTool = g;
			}
		} else if (show && id > 0 && isPlaceable(id)) {
			this.blockView.visible = true;
			let geo = this.viewGeoCache.get(id);
			if (!geo) {
				geo = makeBlockGeometry(id);
				this.viewGeoCache.set(id, geo);
			}
			if (this.blockView.geometry !== geo) this.blockView.geometry = geo;
		} else if (show && id > 0 && !tool && !isPlaceable(id)) {
			if (!this.meatView) {
				this.meatView = new Mesh(new BoxGeometry(.22, .14, .28), new MeshLambertMaterial({ color: itemColor(id) }));
				this.hand.add(this.meatView);
			}
			this.meatView.material.color.setHex(itemColor(id));
			this.meatView.visible = true;
		}
		if (blocking) {
			if (!this.shieldView) {
				this.shieldView = modelForItem(37);
				if (this.shieldView) this.vmScene.add(this.shieldView);
			}
			if (this.shieldView) {
				this.shieldView.visible = true;
				this.shieldView.scale.setScalar(.42);
				this.shieldView.position.set(-.18, -.12, -.42);
				this.shieldView.rotation.set(-.15, .35, .08);
			}
		}
		const attacking = playing && this.input.isDown("Mouse0");
		if (attacking) this.swingT += dt * (tool ? 16 : 12);
		else this.swingT *= Math.max(0, 1 - dt * 8);
		const swing = Math.sin(this.swingT) * (attacking ? 1 : .2);
		const bob = playing ? this.player.bob * .04 : 0;
		if (kind === "sword") {
			this.hand.scale.setScalar(.26);
			this.hand.position.set(.3, -.2 + bob, -.54);
			this.hand.rotation.set(-.32 + swing * 1.15, .16, .26 + swing * .5);
		} else if (kind === "axe" || kind === "pick" || kind === "shovel") {
			this.hand.scale.setScalar(.28);
			this.hand.position.set(.32, -.24 + bob, -.52);
			this.hand.rotation.set(-.65 + swing * .9, .38, .4 + swing * .7);
		} else if (kind === "shield") {
			this.hand.scale.setScalar(.4);
			this.hand.position.set(.22, -.18 + bob, -.48);
			this.hand.rotation.set(-.2, .4, .1);
		} else if (this.blockView.visible) {
			this.hand.scale.setScalar(.13);
			this.hand.position.set(.38, -.28 + bob, -.66);
			this.hand.rotation.set(.18 + swing * .22, .62, .12 + swing * .22);
		} else if (this.meatView?.visible) {
			this.hand.scale.setScalar(.9);
			this.hand.position.set(.32, -.22 + bob, -.55);
			this.hand.rotation.set(.2 + swing * .2, .4, .1);
		}
	}
	pushHud(force) {
		const t = this.target ? this.world.getBlock(this.target.x, this.target.y, this.target.z) : 0;
		const look = this.lookDir();
		const mh = this.mobs.raycast(this.player.x, this.player.eyeY, this.player.z, look.x, look.y, look.z, 4.6);
		const blockDist = this.target ? Math.hypot(this.target.x + .5 - this.player.x, this.target.y + .5 - this.player.eyeY, this.target.z + .5 - this.player.z) : 99;
		let name = t && t !== 0 ? blockName(t) : null;
		if (mh && mh.dist < blockDist) name = mobName(mh.mob.kind, mh.mob.crown);
		gameStore.getState().patchHud({
			health: this.health,
			food: this.food,
			air: this.air,
			hotbar: this.hotbar.map((s) => s ? { ...s } : null),
			selectedSlot: this.selected,
			inventory: this.inventory.map((s) => s ? { ...s } : null),
			armor: this.armor.map((s) => s ? { ...s } : null),
			offhand: this.offhand ? { ...this.offhand } : null,
			fps: Math.round(this.fps),
			x: this.player.x,
			y: this.player.y,
			z: this.player.z,
			yaw: this.player.yaw,
			targetName: name,
			breaking: this.target && this.breakT > 0 ? Math.min(1, this.breakT / this.mineTime(t, BLOCKS[t]?.hardness || 1, this.hotbar[this.selected]?.id ?? 0)) : 0,
			held: this.hotbar[this.selected] ? { ...this.hotbar[this.selected] } : null,
			canResume: true,
			biome: BIOME_NAME[this.world.biomeAt(Math.floor(this.player.x), Math.floor(this.player.z))] ?? "Ova",
			sneaking: this.player.sneaking,
			inWater: this.player.inWater,
			blocking: this.player.sneaking && this.offhand?.id === 37,
			sleeping: this.sleeping,
			sleep: Math.min(1, this.sleepT / 4.2),
			toast: this.toastT > 0 ? this.toast : null
		});
	}
	refreshHud() {
		this.pushHud(true);
	}
	iconsMap() {
		return this.icons;
	}
	setRenderDistance(n) {
		gameStore.getState().setSettings({ renderDistance: n });
		this.lastCx = 99999;
		this.lastCz = 99999;
	}
	interactInventory(from, fi, to, ti) {
		const bag = (which, i) => {
			if (which === "hotbar") return {
				arr: this.hotbar,
				index: i
			};
			if (which === "inv") return {
				arr: this.inventory,
				index: i
			};
			if (which === "armor") return {
				arr: this.armor,
				index: i
			};
			return {
				arr: [this.offhand],
				index: 0
			};
		};
		const a = bag(from, fi);
		const b = bag(to, ti);
		const sa = a.arr[a.index];
		const sb = b.arr[b.index];
		if (sa && sb && sa.id === sb.id && !isTool(sa.id)) {
			const room = 64 - sb.count;
			const take = Math.min(room, sa.count);
			sb.count += take;
			sa.count -= take;
			if (sa.count <= 0) a.arr[a.index] = null;
		} else {
			a.arr[a.index] = sb;
			b.arr[b.index] = sa;
		}
		if (from === "offhand") this.offhand = a.arr[0] ?? null;
		if (to === "offhand") this.offhand = b.arr[0] ?? null;
		this.audio.click();
		this.pushHud(true);
	}
	dumpCraftBack() {
		for (let i = 0; i < this.craftGrid.length; i++) {
			const s = this.craftGrid[i];
			if (!s) continue;
			addItem(this.hotbar, this.inventory, s.id, s.count);
			this.craftGrid[i] = null;
		}
		this.pushHud(true);
	}
	craftRecipe(id) {
		const rec = RECIPES.find((r) => r.id === id);
		if (!rec) return false;
		const ok = craftInto(rec, [this.hotbar, this.inventory], this.hotbar);
		if (ok) this.audio.pickup();
		this.pushHud(true);
		return ok;
	}
	takeCraftResult() {
		const rec = matchRecipe(this.craftGrid);
		if (!rec) return;
		consumeGrid(this.craftGrid, rec);
		addItem(this.hotbar, this.inventory, rec.out.id, rec.out.count);
		this.audio.pickup();
		this.pushHud(true);
	}
	matchedCraft() {
		return matchRecipe(this.craftGrid);
	}
	canMake(id) {
		const rec = RECIPES.find((r) => r.id === id);
		if (!rec) return false;
		return canCraft(rec, [this.hotbar, this.inventory]);
	}
	exposeControls() {
		window.__controlsTest = {
			getYaw: () => this.player.yaw,
			getSpeed: () => Math.hypot(this.player.vx, this.player.vz),
			getPosition: () => ({
				x: this.player.x,
				y: this.player.y,
				z: this.player.z
			}),
			setKeys: (codes) => {
				if (!codes.length) this.input.clearInjected();
				else this.input.setKeys(codes);
			},
			setSteer: (v) => {
				if (v > .1) this.input.setKeys(["KeyW", "KeyA"]);
				else if (v < -.1) this.input.setKeys(["KeyW", "KeyD"]);
				else this.input.setKeys(["KeyW"]);
			}
		};
	}
	dispose() {
		this.disposed = true;
		this.stop();
		this.save();
		window.removeEventListener("resize", this.onResize);
		document.removeEventListener("pointerlockchange", this.onLockChange);
		document.removeEventListener("pointerlockerror", this.onLockError);
		this.input.dispose();
		for (const k of [...this.chunkMeshes.keys()]) this.disposeChunkMesh(k);
		this.drops?.dispose();
		this.mobs.dispose();
		this.waterMat?.dispose();
		this.lavaMat?.dispose();
		this.portalMat?.dispose();
		for (const k of [...this.waterMeshes.keys()]) this.disposeChunkMesh(k);
		this.particles?.dispose();
		this.material?.map?.dispose();
		this.material?.dispose();
		for (const m of this.crackMats) {
			m.map?.dispose();
			m.dispose();
		}
		for (const g of this.viewGeoCache.values()) g.dispose();
		this.blockView.geometry.dispose();
		this.blockView.material.dispose();
		for (const g of this.toolViews.values()) g.traverse((o) => {
			const m = o;
			if (m.isMesh) m.geometry.dispose();
		});
		this.shieldView?.traverse((o) => {
			const m = o;
			if (m.isMesh) m.geometry.dispose();
		});
		this.highlight.geometry.dispose();
		this.highlight.material.dispose();
		this.sunMesh.geometry.dispose();
		this.sunMesh.material.dispose();
		this.moonMesh.geometry.dispose();
		this.moonMesh.material.dispose();
		this.stars.geometry.dispose();
		this.stars.material.dispose();
		this.renderer.dispose();
		if (window.__controlsTest) delete window.__controlsTest;
	}
};
function boxesOverlap(ax, ay, az, aw, ah, ad, bx, by, bz, bw, bh, bd) {
	return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by && az < bz + bd && az + ad > bz;
}
function makeCrack(p) {
	const c = document.createElement("canvas");
	c.width = 32;
	c.height = 32;
	const ctx = c.getContext("2d");
	ctx.clearRect(0, 0, 32, 32);
	ctx.strokeStyle = "rgba(20,16,12,0.92)";
	ctx.lineWidth = 2;
	ctx.beginPath();
	const n = 3 + Math.floor(p * 6);
	for (let i = 0; i < n; i++) {
		ctx.moveTo(16, 16);
		const a = i / n * Math.PI * 2 + p;
		ctx.lineTo(16 + Math.cos(a) * (8 + p * 12), 16 + Math.sin(a) * (8 + p * 12));
	}
	ctx.stroke();
	return c;
}
function yieldFrame() {
	return new Promise((r) => requestAnimationFrame(() => r()));
}
function Credits({ lines, shots, onBack }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "credits-root",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "credits-track",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "credits-kicker",
					children: "Blokcraft"
				}),
				lines.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "credits-block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: line }), shots[i] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: shots[i],
						alt: ""
					}) : null]
				}, i)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "credits-back",
					onClick: onBack,
					children: "Oyuna geri dön"
				})
			]
		})
	});
}
var MAX = 64;
function copyStack(s) {
	return s.dur != null ? {
		id: s.id,
		count: s.count,
		dur: s.dur
	} : {
		id: s.id,
		count: s.count
	};
}
function clickStack(cursor, origin, slot, here, read, write) {
	if (!cursor) {
		if (!slot) return {
			cursor: null,
			origin: null
		};
		write(here, null);
		return {
			cursor: copyStack(slot),
			origin: here
		};
	}
	if (!slot) {
		write(here, copyStack(cursor));
		return {
			cursor: null,
			origin: null
		};
	}
	if (slot.id === cursor.id && !isTool(slot.id) && slot.count < MAX) {
		const take = Math.min(MAX - slot.count, cursor.count);
		slot.count += take;
		write(here, slot);
		const left = cursor.count - take;
		return {
			cursor: left > 0 ? {
				...cursor,
				count: left
			} : null,
			origin: left > 0 ? origin : null
		};
	}
	write(here, copyStack(cursor));
	if (origin && !sameRef(origin, here)) {
		if (!read(origin)) {
			write(origin, copyStack(slot));
			return {
				cursor: null,
				origin: null
			};
		}
	}
	return {
		cursor: copyStack(slot),
		origin: here
	};
}
function gatherMatches(cursor, slots, read, write) {
	if (isTool(cursor.id) || cursor.count >= MAX) return cursor;
	const next = copyStack(cursor);
	for (const ref of slots) {
		if (next.count >= MAX) break;
		const slot = read(ref);
		if (!slot || slot.id !== next.id || isTool(slot.id)) continue;
		const take = Math.min(MAX - next.count, slot.count);
		next.count += take;
		slot.count -= take;
		write(ref, slot.count > 0 ? slot : null);
	}
	return next;
}
function stashCursor(engine, held, origin, read, write) {
	if (origin) {
		const home = read(origin);
		if (!home) {
			write(origin, copyStack(held));
			return;
		}
		if (home.id === held.id && !isTool(held.id) && home.count < MAX) {
			const take = Math.min(MAX - home.count, held.count);
			home.count += take;
			write(origin, home);
			held = {
				...held,
				count: held.count - take
			};
			if (held.count <= 0) return;
		}
	}
	addItem(engine.hotbar, engine.inventory, held.id, held.count);
}
function sameRef(a, b) {
	return a.bag === b.bag && a.i === b.i;
}
function Crafting({ engine, icons }) {
	const hud = useGameStore((s) => s.hud);
	const [cursor, setCursor] = (0, import_react.useState)(null);
	const [origin, setOrigin] = (0, import_react.useState)(null);
	const [mouse, setMouse] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const [, bump] = (0, import_react.useState)(0);
	const cursorRef = (0, import_react.useRef)(cursor);
	const originRef = (0, import_react.useRef)(origin);
	cursorRef.current = cursor;
	originRef.current = origin;
	const refresh = () => {
		engine?.refreshHud();
		bump((n) => n + 1);
	};
	(0, import_react.useEffect)(() => {
		return () => {
			const held = cursorRef.current;
			if (!held || !engine) return;
			stashCursor(engine, held, originRef.current, (r) => getSlot$1(engine, r.bag, r.i), (r, v) => setSlot$1(engine, r.bag, r.i, v));
			engine.refreshHud();
		};
	}, [engine]);
	const onSlot = (bag, i, detail = 1) => {
		if (!engine) return;
		const read = (r) => getSlot$1(engine, r.bag, r.i);
		const write = (r, v) => setSlot$1(engine, r.bag, r.i, v);
		if (detail >= 2 && cursor && !isTool(cursor.id)) {
			const slots = [
				...engine.hotbar.map((_, n) => ({
					bag: "hotbar",
					i: n
				})),
				...engine.inventory.map((_, n) => ({
					bag: "inv",
					i: n
				})),
				...engine.craftGrid.map((_, n) => ({
					bag: "craft",
					i: n
				}))
			];
			setCursor(gatherMatches({ ...cursor }, slots, read, write));
			refresh();
			return;
		}
		const next = clickStack(cursor, origin, getSlot$1(engine, bag, i), {
			bag,
			i
		}, read, write);
		setCursor(next.cursor);
		setOrigin(next.origin);
		refresh();
	};
	const result = engine?.matchedCraft() ?? null;
	const craftSlots = engine?.craftGrid ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overlay-root inventory-overlay",
		onMouseMove: (e) => setMouse({
			x: e.clientX,
			y: e.clientY
		}),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "inv-panel craft-panel",
			role: "dialog",
			"aria-label": "Yapım masası",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "inv-head",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hammer, { size: 18 }), " Yapım masası"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "1 odun = 4 tahta · 1 tahta = 4 çubuk. Nokta veya Esc kapatır." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "craft-layout",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "craft-bench",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "craft-grid",
								children: Array.from({ length: 9 }, (_, i) => {
									const s = craftSlots[i];
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvSlot$1, {
										icon: s ? icons[s.id] : void 0,
										count: s?.count ?? 0,
										label: s ? blockName(s.id) : "",
										onClick: (e) => onSlot("craft", i, e.detail)
									}, i);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "craft-arrow",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "slot inv-slot craft-result",
								title: result ? blockName(result.out.id) : "Sonuç",
								onClick: () => {
									if (!engine || !result) return;
									engine.takeCraftResult();
									refresh();
								},
								children: [result && icons[result.out.id] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: icons[result.out.id],
									alt: "",
									draggable: false
								}) : null, result && result.out.count > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "slot-count",
									children: result.out.count
								}) : null]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "craft-book",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "craft-book-label",
							children: "Tarifler"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "craft-recipes",
							children: RECIPES.map((r) => {
								const ok = engine?.canMake(r.id) ?? false;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "craft-recipe",
									disabled: !ok,
									onClick: () => {
										if (!engine) return;
										engine.craftRecipe(r.id);
										refresh();
									},
									children: [
										icons[r.out.id] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: icons[r.out.id],
											alt: ""
										}) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: r.name }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("em", { children: ["×", r.out.count] })
									]
								}, r.id);
							})
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "inv-grid craft-inv",
					children: hud.inventory.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvSlot$1, {
						icon: s ? icons[s.id] : void 0,
						count: s?.count ?? 0,
						label: s ? blockName(s.id) : "",
						onClick: (e) => onSlot("inv", i, e.detail)
					}, i))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "inv-hotbar",
					children: hud.hotbar.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvSlot$1, {
						icon: s ? icons[s.id] : void 0,
						count: s?.count ?? 0,
						selected: i === hud.selectedSlot,
						label: s ? blockName(s.id) : "",
						onClick: (e) => onSlot("hotbar", i, e.detail)
					}, i))
				})
			]
		}), cursor ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "cursor-item",
			style: {
				left: mouse.x + 12,
				top: mouse.y + 12
			},
			children: [icons[cursor.id] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: icons[cursor.id],
				alt: ""
			}) : null, cursor.count > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: cursor.count }) : null]
		}) : null]
	});
}
function InvSlot$1({ icon, count, selected, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: `slot inv-slot ${selected ? "is-selected" : ""}`,
		title: label,
		onClick,
		children: [icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: icon,
			alt: "",
			draggable: false
		}) : null, count > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "slot-count",
			children: count
		}) : null]
	});
}
function getSlot$1(engine, bag, i) {
	if (bag === "hotbar") return engine.hotbar[i] ?? null;
	if (bag === "inv") return engine.inventory[i] ?? null;
	return engine.craftGrid[i] ?? null;
}
function setSlot$1(engine, bag, i, v) {
	if (bag === "hotbar") engine.hotbar[i] = v;
	else if (bag === "inv") engine.inventory[i] = v;
	else engine.craftGrid[i] = v;
}
function Furnace({ engine, icons }) {
	const hud = useGameStore((s) => s.hud);
	const [cursor, setCursor] = (0, import_react.useState)(null);
	const [origin, setOrigin] = (0, import_react.useState)(null);
	const [mouse, setMouse] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const [, bump] = (0, import_react.useState)(0);
	const cursorRef = (0, import_react.useRef)(cursor);
	const originRef = (0, import_react.useRef)(origin);
	cursorRef.current = cursor;
	originRef.current = origin;
	const refresh = () => {
		engine?.refreshHud();
		bump((n) => n + 1);
	};
	const f = engine?.activeFurnace() ?? null;
	const read = (r) => {
		if (!engine) return null;
		if (r.bag === "hotbar") return engine.hotbar[r.i] ?? null;
		if (r.bag === "inv") return engine.inventory[r.i] ?? null;
		const furn = engine.activeFurnace();
		if (!furn) return null;
		if (r.bag === "input") return furn.input;
		if (r.bag === "fuel") return furn.fuel;
		return furn.out;
	};
	const write = (r, v) => {
		if (!engine) return;
		if (r.bag === "hotbar") engine.hotbar[r.i] = v;
		else if (r.bag === "inv") engine.inventory[r.i] = v;
		else if (r.bag === "input" || r.bag === "fuel" || r.bag === "out") engine.setFurnaceSlot(r.bag, v);
	};
	(0, import_react.useEffect)(() => {
		return () => {
			const held = cursorRef.current;
			if (!held || !engine) return;
			stashCursor(engine, held, originRef.current, read, write);
			engine.refreshHud();
		};
	}, [engine]);
	const clickSlot = (which, i = 0, detail = 1) => {
		if (!engine) return;
		const here = {
			bag: which,
			i
		};
		if (detail >= 2 && cursor && !isTool(cursor.id)) {
			const slots = [
				...engine.hotbar.map((_, n) => ({
					bag: "hotbar",
					i: n
				})),
				...engine.inventory.map((_, n) => ({
					bag: "inv",
					i: n
				})),
				{
					bag: "input",
					i: 0
				},
				{
					bag: "fuel",
					i: 0
				},
				{
					bag: "out",
					i: 0
				}
			];
			setCursor(gatherMatches({ ...cursor }, slots, read, write));
			refresh();
			return;
		}
		if (which === "out") {
			const slot = read(here);
			if (!slot || cursor) return;
			write(here, null);
			setCursor(copyStack(slot));
			setOrigin(here);
			refresh();
			return;
		}
		const next = clickStack(cursor, origin, read(here), here, read, write);
		setCursor(next.cursor);
		setOrigin(next.origin);
		refresh();
	};
	const cookPct = f ? Math.min(1, f.cook / 10) : 0;
	const burnPct = f && f.burnMax > 0 ? Math.min(1, f.burn / f.burnMax) : 0;
	const burning = (f?.burn ?? 0) > 0;
	const inputBad = !!f?.input && smeltResult(f.input.id) === 0;
	const fuelBad = !!f?.fuel && fuelSeconds(f.fuel.id) === 0 && !burning;
	const status = inputBad ? "Bu eşya pişmez. Ham demir, ham altın veya çiğ et koy." : fuelBad ? "Bu yakıt yanmaz. Kömür, odun, tahta veya çubuk koy." : burning ? "Ateş yanıyor. Ok dolunca bir adet pişer." : "Yakıt bitince alev söner. Pişirme okla ilerler.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overlay-root inventory-overlay",
		onMouseMove: (e) => setMouse({
			x: e.clientX,
			y: e.clientY
		}),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "inv-panel craft-panel",
			role: "dialog",
			"aria-label": "Fırın",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "inv-head",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { size: 18 }), " Fırın"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Üst yuva pişer, alt yuva yakar. Esc kapatır, pişirme sürer." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "furnace-machine",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "furnace-io",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Pişecek" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "slot furnace-slot",
									onClick: (e) => clickSlot("input", 0, e.detail),
									title: "Pişecek",
									children: [f?.input ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: icons[f.input.id],
										alt: blockName(f.input.id)
									}) : null, (f?.input?.count ?? 0) > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "slot-count",
										children: f.input.count
									}) : null]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "furnace-fire-col",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flame-gauge",
										"aria-label": burning ? "Yakıt yanıyor" : "Ateş yok",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "flame-ghost-shape" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
											className: "flame-lit-shape",
											style: { height: `${Math.round(burnPct * 100)}%` }
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "slot furnace-slot",
									onClick: (e) => clickSlot("fuel", 0, e.detail),
									title: "Yakıt",
									children: [f?.fuel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: icons[f.fuel.id],
										alt: blockName(f.fuel.id)
									}) : null, (f?.fuel?.count ?? 0) > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "slot-count",
										children: f.fuel.count
									}) : null]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Yakıt" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "smelt-arrow",
							"aria-hidden": true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "smelt-arrow-track",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "smelt-shaft" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "smelt-head" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "smelt-arrow-fill",
								style: { width: `${Math.round(cookPct * 100)}%` },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "smelt-shaft" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "smelt-head" })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "furnace-out",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Çıktı" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "slot furnace-slot",
								onClick: (e) => clickSlot("out", 0, e.detail),
								title: "Çıktı",
								children: [f?.out ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: icons[f.out.id],
									alt: blockName(f.out.id)
								}) : null, (f?.out?.count ?? 0) > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "slot-count",
									children: f.out.count
								}) : null]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "furnace-status",
					children: status
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "inv-grid",
					children: hud.inventory.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "slot",
						onClick: (e) => clickSlot("inv", i, e.detail),
						children: [s ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: icons[s.id],
							alt: ""
						}) : null, (s?.count ?? 0) > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "slot-count",
							children: s.count
						}) : null]
					}, i))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "inv-hotbar",
					children: hud.hotbar.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "slot",
						onClick: (e) => clickSlot("hotbar", i, e.detail),
						children: [s ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: icons[s.id],
							alt: ""
						}) : null, (s?.count ?? 0) > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "slot-count",
							children: s.count
						}) : null]
					}, i))
				})
			]
		}), cursor ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			className: "inv-cursor",
			src: icons[cursor.id],
			alt: "",
			style: {
				left: mouse.x + 8,
				top: mouse.y + 8
			}
		}) : null]
	});
}
function HUD({ icons, onCraft, onWake }) {
	const hud = useGameStore((s) => s.hud);
	const phase = useGameStore((s) => s.phase);
	const isMobile = useGameStore((s) => s.isMobile);
	const low = hud.health > 0 && hud.health <= 4;
	const prevHp = (0, import_react.useRef)(hud.health);
	const [hurt, setHurt] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (hud.health < prevHp.current) setHurt((n) => n + 1);
		prevHp.current = hud.health;
	}, [hud.health]);
	if (phase === "title" || phase === "loading" || phase === "credits") return null;
	const hearts = [];
	for (let i = 0; i < 10; i++) {
		const hp = hud.health - i * 2;
		hearts.push(hp >= 2 ? "full" : hp === 1 ? "half" : "empty");
	}
	const bubbles = [];
	const air = hud.air ?? 10;
	if (air < 9.96) for (let i = 0; i < 10; i++) {
		const left = air - i;
		bubbles.push(left >= 1 ? "full" : left >= .45 ? "pop" : "empty");
	}
	const foods = [];
	for (let i = 0; i < 10; i++) {
		const fp = (hud.food ?? 20) - i * 2;
		foods.push(fp >= 2 ? "full" : fp === 1 ? "half" : "empty");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "hud-root",
		"aria-hidden": phase !== "playing",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hud-top",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hud-chip",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hud-muted",
							children: "xyz"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "hud-num",
							children: [
								hud.x.toFixed(1),
								" ",
								hud.y.toFixed(1),
								" ",
								hud.z.toFixed(1)
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hud-chip",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "day-dot",
							"data-day": hud.isDay ? "1" : "0"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: hud.isDay ? "Gündüz" : "Gece" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hud-chip",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: hud.biome })
					}),
					hud.inWater ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hud-chip",
						children: "Yüzme"
					}) : null,
					hud.sneaking && !hud.inWater ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hud-chip",
						children: hud.blocking ? "Kalkan" : "Eğilme"
					}) : null,
					!isMobile ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hud-chip",
						children: [hud.fps, " fps"]
					}) : null
				]
			}),
			phase === "playing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "craft-fab",
				onClick: onCraft,
				"aria-label": "Yapım masası",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hammer, { size: 18 }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Yapım" }),
					!isMobile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "." }) : null
				]
			}) : null,
			phase === "playing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "crosshair" }) : null,
			hud.targetName ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "target-label",
				children: hud.targetName
			}) : null,
			hud.toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "game-toast",
				children: hud.toast
			}) : null,
			hud.sleeping ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sleep-screen",
				style: { ["--p"]: String(hud.sleep) },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "sleep-veil" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sleep-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Uyuyorsun" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "sleep-bar",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { width: `${Math.round(hud.sleep * 100)}%` } })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onWake,
							children: "Yataktan kalk"
						})
					]
				})]
			}) : null,
			low ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hurt-cloud" }) : null,
			hurt > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `hurt-flash ${low ? "is-deep" : ""}` }, hurt) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hud-bottom",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bars-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "vitals",
						children: [bubbles.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bubbles",
							"aria-label": "Nefes",
							children: bubbles.map((k, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bubble, { kind: k }, i))
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hearts",
							"aria-label": `${hud.health} can`,
							children: [hearts.map((k, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { kind: k }, i)), hurt > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "heart-glint" }, hurt) : null]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "foods",
						"aria-label": `${hud.food} açlık`,
						children: foods.map((k, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drum, { kind: k }, i))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hotbar-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot, {
						icon: hud.offhand ? icons[hud.offhand.id] : void 0,
						count: hud.offhand?.count ?? 0,
						offhand: true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hotbar",
						children: hud.hotbar.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot, {
							icon: s ? icons[s.id] : void 0,
							count: s?.count ?? 0,
							selected: i === hud.selectedSlot,
							label: s ? blockName(s.id) : "",
							dur: s?.dur,
							durMax: s ? durMaxOf(s.id, s.dur) : 0
						}, i))
					})]
				})]
			})
		]
	});
}
function durMaxOf(id, dur) {
	return maxDurability(id) || (dur ?? 0);
}
function Slot({ icon, count, selected, offhand, label, dur, durMax }) {
	const showDur = dur != null && durMax && durMax > 0 && dur < durMax;
	const pct = showDur ? Math.max(0, Math.min(1, dur / durMax)) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `slot ${selected ? "is-selected" : ""} ${offhand ? "is-offhand" : ""}`,
		title: label,
		children: [
			icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: icon,
				alt: "",
				draggable: false
			}) : null,
			count > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "slot-count",
				children: count
			}) : null,
			showDur ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
				className: "slot-dur",
				style: {
					width: `${Math.round(pct * 100)}%`,
					background: pct > .3 ? "#5ec45a" : "#c4453c"
				}
			}) : null
		]
	});
}
function Bubble({ kind }) {
	const full = kind === "full";
	const pop = kind === "pop";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 16 16",
		className: `bubble bubble-${kind}`,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "8",
				cy: "8",
				r: "5.2",
				fill: full ? "#7fd4f0" : pop ? "#9adff2" : "none",
				stroke: "#143046",
				strokeWidth: "1.3"
			}),
			full || pop ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "6.1",
				cy: "6.2",
				r: "1.3",
				fill: "#f4fbff"
			}) : null,
			pop ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M3 8 H6 M10 8 H13 M8 3 V6 M8 10 V13",
				stroke: "#d8f4ff",
				strokeWidth: "1.2"
			}) : null,
			kind === "empty" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "8",
				cy: "8",
				r: "5.2",
				fill: "#102028",
				stroke: "#1c3344",
				strokeWidth: "1.3"
			}) : null
		]
	});
}
function Heart({ kind }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 16 16",
		className: `heart heart-${kind}`,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 14 L2.2 8.4 A3.6 3.6 0 0 1 8 3.8 A3.6 3.6 0 0 1 13.8 8.4 Z",
				fill: kind === "empty" ? "none" : "#c4453c",
				stroke: "#2a120f",
				strokeWidth: "1.3"
			}),
			kind === "half" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 14 L2.2 8.4 A3.6 3.6 0 0 1 8 3.8 Z",
				fill: "#c4453c"
			}) : null,
			kind === "empty" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 14 L2.2 8.4 A3.6 3.6 0 0 1 8 3.8 A3.6 3.6 0 0 1 13.8 8.4 Z",
				fill: "#1a1c16",
				stroke: "#2a120f",
				strokeWidth: "1.3"
			}) : null
		]
	});
}
function Drum({ kind }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 16 16",
		className: `drum drum-${kind}`,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M5 3.2 C5 2.2 6.2 1.4 7.6 1.6 C9.2 1.8 10 3 10 4.2 L9.6 8.2 C11.4 8.6 13.2 10.2 13.2 12.1 C13.2 14.2 11.2 15.4 8.8 15.4 C6.2 15.4 4.4 14 4.4 12.1 C4.4 10.6 5.4 9.4 7 8.6 L6.2 4.4 C6 3.6 5.6 3.4 5 3.2 Z",
				fill: kind === "empty" ? "#1a1c16" : "#c47a32",
				stroke: "#2a1a0f",
				strokeWidth: "1.1"
			}),
			kind === "full" || kind === "half" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8.2 8.6 C10.4 9 12 10.4 12 12 C12 13.6 10.4 14.6 8.8 14.6 C7.4 14.6 6 13.8 6 12.4 C6 10.8 7 9.4 8.2 8.6 Z",
				fill: "#e8c070"
			}) : null,
			kind === "half" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "8.8",
				y: "1",
				width: "7",
				height: "14",
				fill: "#0e100c",
				opacity: "0.72"
			}) : null
		]
	});
}
function StevePreview({ mouseX, mouseY }) {
	const wrapRef = (0, import_react.useRef)(null);
	const mouse = (0, import_react.useRef)({
		x: 0,
		y: 0
	});
	mouse.current = {
		x: mouseX,
		y: mouseY
	};
	(0, import_react.useEffect)(() => {
		const wrap = wrapRef.current;
		if (!wrap) return;
		const canvas = document.createElement("canvas");
		canvas.className = "steve-canvas";
		wrap.appendChild(canvas);
		const renderer = new WebGLRenderer({
			canvas,
			alpha: true,
			antialias: false
		});
		renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
		renderer.setClearColor(0, 0);
		renderer.outputColorSpace = SRGBColorSpace;
		const scene = new Scene();
		const camera = new PerspectiveCamera(32, 1, .1, 20);
		camera.position.set(0, 1.15, 4.4);
		camera.lookAt(0, 1, 0);
		scene.add(new AmbientLight(16777215, .85));
		const key = new DirectionalLight(16774360, 1.1);
		key.position.set(2.2, 4, 3);
		scene.add(key);
		const fill = new DirectionalLight(12112127, .35);
		fill.position.set(-3, 1, -2);
		scene.add(fill);
		const root = new Group();
		scene.add(root);
		let head = null;
		let raf = 0;
		let dead = false;
		new GLTFLoader().load("/models/steve.gltf", (gltf) => {
			if (dead) return;
			const model = gltf.scene;
			model.traverse((o) => {
				const m = o;
				if (m.isMesh) {
					m.frustumCulled = false;
					const mat = m.material;
					if (mat.map) {
						mat.map.magFilter = NearestFilter;
						mat.map.minFilter = NearestFilter;
						mat.map.flipY = false;
					}
				}
			});
			const box = new Box3().setFromObject(model);
			const size = new Vector3();
			box.getSize(size);
			const center = new Vector3();
			box.getCenter(center);
			model.position.sub(center);
			model.position.y += size.y * .5;
			root.add(model);
			head = model.getObjectByName("Head") ?? null;
		}, void 0, () => {});
		const loop = () => {
			raf = requestAnimationFrame(loop);
			const w = wrap.clientWidth;
			const h = wrap.clientHeight;
			if (w > 0 && h > 0) {
				renderer.setSize(w, h, false);
				camera.aspect = w / h;
				camera.updateProjectionMatrix();
			}
			const rect = wrap.getBoundingClientRect();
			const cx = rect.left + rect.width / 2;
			const cy = rect.top + rect.height * .4;
			const dx = mouse.current.x - cx;
			const dy = mouse.current.y - cy;
			const yaw = Math.atan2(dx, 160) * .9;
			const pitch = MathUtils.clamp(-dy / 280, -.55, .45);
			root.rotation.y = MathUtils.lerp(root.rotation.y, yaw, .18);
			if (head) head.rotation.x = MathUtils.lerp(head.rotation.x, pitch, .2);
			else root.rotation.x = MathUtils.lerp(root.rotation.x, pitch * .25, .15);
			renderer.render(scene, camera);
		};
		raf = requestAnimationFrame(loop);
		return () => {
			dead = true;
			cancelAnimationFrame(raf);
			renderer.dispose();
			canvas.remove();
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: wrapRef,
		className: "steve-wrap"
	});
}
var ARMOR_LABELS = [
	"Kask",
	"Göğüs",
	"Pantolon",
	"Bot"
];
function Inventory({ engine, icons }) {
	const hud = useGameStore((s) => s.hud);
	const [cursor, setCursor] = (0, import_react.useState)(null);
	const [origin, setOrigin] = (0, import_react.useState)(null);
	const [mouse, setMouse] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const cursorRef = (0, import_react.useRef)(cursor);
	const originRef = (0, import_react.useRef)(origin);
	cursorRef.current = cursor;
	originRef.current = origin;
	(0, import_react.useEffect)(() => {
		return () => {
			const held = cursorRef.current;
			if (!held || !engine) return;
			stashCursor(engine, held, originRef.current, (r) => getSlot(engine, r.bag, r.i), (r, v) => setSlot(engine, r.bag, r.i, v));
			engine.refreshHud();
		};
	}, [engine]);
	const onSlot = (bag, i, detail = 1) => {
		if (!engine) return;
		const read = (r) => getSlot(engine, r.bag, r.i);
		const write = (r, v) => setSlot(engine, r.bag, r.i, v);
		if (detail >= 2 && cursor && !isTool(cursor.id)) {
			const slots = [...engine.hotbar.map((_, n) => ({
				bag: "hotbar",
				i: n
			})), ...engine.inventory.map((_, n) => ({
				bag: "inv",
				i: n
			}))];
			setCursor(gatherMatches({ ...cursor }, slots, read, write));
			engine.refreshHud();
			return;
		}
		const next = clickStack(cursor, origin, getSlot(engine, bag, i), {
			bag,
			i
		}, read, write);
		setCursor(next.cursor);
		setOrigin(next.origin);
		engine.refreshHud();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overlay-root inventory-overlay",
		onMouseMove: (e) => setMouse({
			x: e.clientX,
			y: e.clientY
		}),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "inv-panel",
			role: "dialog",
			"aria-label": "Envanter",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "inv-head",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Envanter" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Fareyi hareket ettir — karakter bakar. E veya Esc kapatır." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "inv-body",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "inv-equip",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "armor-col",
							children: [hud.armor.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvSlot, {
								icon: s ? icons[s.id] : void 0,
								count: s?.count ?? 0,
								label: ARMOR_LABELS[i],
								onClick: (e) => onSlot("armor", i, e.detail)
							}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvSlot, {
								icon: hud.offhand ? icons[hud.offhand.id] : void 0,
								count: hud.offhand?.count ?? 0,
								label: "Sol el",
								onClick: (e) => onSlot("offhand", 0, e.detail)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StevePreview, {
							mouseX: mouse.x,
							mouseY: mouse.y
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "inv-grid",
						children: hud.inventory.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvSlot, {
							icon: s ? icons[s.id] : void 0,
							count: s?.count ?? 0,
							label: s ? blockName(s.id) : "",
							onClick: (e) => onSlot("inv", i, e.detail)
						}, i))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "inv-hotbar",
					children: hud.hotbar.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvSlot, {
						icon: s ? icons[s.id] : void 0,
						count: s?.count ?? 0,
						selected: i === hud.selectedSlot,
						label: s ? blockName(s.id) : "",
						onClick: (e) => onSlot("hotbar", i, e.detail)
					}, i))
				})
			]
		}), cursor ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "cursor-item",
			style: {
				left: mouse.x + 12,
				top: mouse.y + 12
			},
			children: [icons[cursor.id] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: icons[cursor.id],
				alt: ""
			}) : null, cursor.count > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: cursor.count }) : null]
		}) : null]
	});
}
function InvSlot({ icon, count, selected, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: `slot inv-slot ${selected ? "is-selected" : ""}`,
		title: label,
		onClick,
		children: [icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: icon,
			alt: "",
			draggable: false
		}) : null, count > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "slot-count",
			children: count
		}) : null]
	});
}
function getSlot(engine, bag, i) {
	if (bag === "hotbar") return engine.hotbar[i] ?? null;
	if (bag === "inv") return engine.inventory[i] ?? null;
	if (bag === "armor") return engine.armor[i] ?? null;
	return engine.offhand;
}
function setSlot(engine, bag, i, v) {
	if (bag === "hotbar") engine.hotbar[i] = v;
	else if (bag === "inv") engine.inventory[i] = v;
	else if (bag === "armor") engine.armor[i] = v;
	else engine.offhand = v;
}
function MobileControls({ engine, onPause, onInventory, onCraft }) {
	const phase = useGameStore((s) => s.phase);
	const joy = (0, import_react.useRef)(null);
	const look = (0, import_react.useRef)(null);
	const stick = (0, import_react.useRef)(null);
	const nub = (0, import_react.useRef)(null);
	if (phase !== "playing") return null;
	const setMove = (x, y) => {
		if (!engine) return;
		engine.input.touchMoveX = x;
		engine.input.touchMoveY = y;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "touch-layer",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "joy-pad",
				ref: stick,
				onPointerDown: (e) => {
					e.currentTarget.setPointerCapture(e.pointerId);
					joy.current = {
						id: e.pointerId,
						x: e.clientX,
						y: e.clientY
					};
				},
				onPointerMove: (e) => {
					if (!joy.current || joy.current.id !== e.pointerId) return;
					const dx = e.clientX - joy.current.x;
					const dy = e.clientY - joy.current.y;
					const r = 48;
					const m = Math.hypot(dx, dy);
					const nx = m > r ? dx / m * r : dx;
					const ny = m > r ? dy / m * r : dy;
					if (nub.current) nub.current.style.transform = `translate(${nx}px, ${ny}px)`;
					setMove(nx / r, -ny / r);
				},
				onPointerUp: (e) => {
					if (joy.current?.id !== e.pointerId) return;
					joy.current = null;
					if (nub.current) nub.current.style.transform = "translate(0,0)";
					setMove(0, 0);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "joy-base",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "joy-nub",
						ref: nub
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "look-pad",
				onPointerDown: (e) => {
					e.currentTarget.setPointerCapture(e.pointerId);
					look.current = {
						id: e.pointerId,
						x: e.clientX,
						y: e.clientY
					};
				},
				onPointerMove: (e) => {
					if (!look.current || look.current.id !== e.pointerId) return;
					const dx = e.clientX - look.current.x;
					const dy = e.clientY - look.current.y;
					look.current.x = e.clientX;
					look.current.y = e.clientY;
					engine?.input.addLook(dx * 1.6, dy * 1.6);
				},
				onPointerUp: (e) => {
					if (look.current?.id === e.pointerId) look.current = null;
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "touch-actions",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "touch-btn",
						onClick: onPause,
						"aria-label": "Duraklat",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { size: 18 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "touch-btn",
						onClick: onInventory,
						"aria-label": "Envanter",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Backpack, { size: 18 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "touch-btn",
						onClick: onCraft,
						"aria-label": "Yapım",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hammer, { size: 18 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "touch-btn",
						onPointerDown: () => engine?.input.keys.add("Space"),
						onPointerUp: () => engine?.input.keys.delete("Space"),
						"aria-label": "Zıpla",
						children: "Z"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "touch-btn",
						onPointerDown: () => engine?.input.keys.add("ShiftLeft"),
						onPointerUp: () => engine?.input.keys.delete("ShiftLeft"),
						"aria-label": "Eğil",
						children: "Eğil"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "touch-btn touch-break",
						onPointerDown: () => engine?.input.keys.add("Mouse0"),
						onPointerUp: () => engine?.input.keys.delete("Mouse0"),
						"aria-label": "Kır",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pickaxe, { size: 18 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "touch-btn touch-place",
						onPointerDown: () => engine?.input.keys.add("Mouse2"),
						onPointerUp: () => engine?.input.keys.delete("Mouse2"),
						"aria-label": "Koy",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { size: 18 })
					})
				]
			})
		]
	});
}
function PauseMenu({ engine, onResume, onQuit }) {
	const settings = useGameStore((s) => s.settings);
	const setSettings = useGameStore((s) => s.setSettings);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overlay-root pause-overlay",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pause-panel",
			role: "dialog",
			"aria-label": "Duraklatıldı",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "title-kicker",
					children: "Menü"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Duraklatıldı" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pause-actions",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn-primary",
							onClick: onResume,
							children: "Devam et"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn-ghost",
							onClick: () => {
								engine?.save();
							},
							children: "Kaydet"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn-ghost",
							onClick: onQuit,
							children: "Ana menü"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "settings",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Fare hassasiyeti" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: .4,
								max: 3,
								step: .1,
								value: settings.sensitivity,
								onChange: (e) => setSettings({ sensitivity: Number(e.target.value) })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: settings.sensitivity.toFixed(1) })
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Görüş mesafesi" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 2,
								max: 6,
								step: 1,
								value: settings.renderDistance,
								onChange: (e) => {
									const renderDistance = Number(e.target.value);
									setSettings({ renderDistance });
									engine?.setRenderDistance(renderDistance);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: settings.renderDistance })
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Ses" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 0,
								max: 1,
								step: .05,
								value: settings.volume,
								onChange: (e) => {
									const volume = Number(e.target.value);
									setSettings({ volume });
									engine?.audio.setVolume(volume);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: Math.round(settings.volume * 100) })
						] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pause-hint",
					children: "Shift eğil / kalkan · Ctrl koş · . yapım masası · E envanter"
				})
			]
		})
	});
}
function hex(n) {
	return `#${n.toString(16).padStart(6, "0")}`;
}
function ago(t) {
	const m = Math.floor(Math.max(0, Date.now() - t) / 6e4);
	if (m < 1) return "az önce";
	if (m < 60) return `${m} dk önce`;
	const h = Math.floor(m / 60);
	if (h < 48) return `${h} sa önce`;
	return `${Math.floor(h / 24)} gün önce`;
}
function TitleScreen({ onPlay }) {
	const [view, setView] = (0, import_react.useState)("home");
	const [worlds, setWorlds] = (0, import_react.useState)(() => listWorlds());
	const [confirmId, setConfirmId] = (0, import_react.useState)(null);
	const [look, setLook] = (0, import_react.useState)(() => loadLook());
	const [name, setName] = (0, import_react.useState)("Yeni dünya");
	const [seedText, setSeedText] = (0, import_react.useState)("");
	const [start, setStart] = (0, import_react.useState)("day");
	const [bonus, setBonus] = (0, import_react.useState)(false);
	const [monsters, setMonsters] = (0, import_react.useState)(true);
	const seedPreview = (0, import_react.useMemo)(() => seedText.trim() ? parseSeed(seedText) : null, [seedText]);
	const refresh = () => setWorlds(listWorlds());
	const patchLook = (next) => {
		setLook(next);
		saveLook(next);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overlay-root title-screen",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: view === "home" ? "title-panel" : "title-panel menu-wide",
			children: [
				view === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "title-kicker",
						children: "Hayatta kalma"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "title-mark",
						children: "Blokcraft"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "title-lead",
						children: "Boş ellerle başla. Odun kır, tahta ve çubuk yap, alet üret. Ova, orman, çöl, kar ve okyanus seni bekliyor."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "title-actions",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn-primary",
							onClick: () => {
								refresh();
								setView("worlds");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { size: 18 }), "Tek oyunculu"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn-ghost",
							onClick: () => setView("look"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { size: 18 }), "Karakter"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "title-keys",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "W A S D" }), " hareket"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "Space" }), " zıpla / yüz"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "Shift" }), " eğil / kalkan"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "Ctrl" }), " koş"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "Sol tık" }), " kır"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "Sağ tık" }), " koy"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "." }), " yapım masası"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "E" }), " envanter"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "C" }), " üçüncü şahıs"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "Esc" }), " duraklat"] })
						]
					})
				] }) : null,
				view === "worlds" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "menu-back",
						onClick: () => setView("home"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { size: 16 }), " Geri"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "title-kicker",
						children: "Kayıtlar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Dünyalar" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "world-list",
						children: [worlds.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "title-lead",
							children: "Henüz dünya yok."
						}) : null, worlds.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "world-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "world-main",
								onClick: () => onPlay(w.id),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: w.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Tohum ",
									w.seed,
									" · Gün ",
									Math.floor(w.worldTime / 420),
									" · ",
									ago(w.updated)
								] })]
							}), confirmId === w.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "world-del",
								onClick: () => {
									deleteWorld(w.id);
									setConfirmId(null);
									refresh();
								},
								children: "Sil"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "icon-btn",
								"aria-label": "Dünyayı sil",
								onClick: () => setConfirmId(w.id),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 16 })
							})]
						}, w.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn-primary",
						onClick: () => setView("create"),
						children: "Yeni dünya"
					})
				] }) : null,
				view === "create" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "menu-back",
						onClick: () => setView("worlds"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { size: 16 }), " Dünyalar"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "title-kicker",
						children: "Yeni dünya"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Özellikler" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: ["Ad", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: name,
							maxLength: 32,
							onChange: (e) => setName(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [
							"Tohum",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "seed-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: seedText,
									placeholder: "Boş bırak, rastgele olsun",
									onChange: (e) => setSeedText(e.target.value)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "icon-btn",
									"aria-label": "Rastgele tohum",
									onClick: () => setSeedText(String(Math.floor(Math.random() * 1e9) + 1)),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dices, { size: 16 })
								})]
							}),
							seedPreview != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: ["Sayı: ", seedPreview] }) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "field-label",
						children: "Başlangıç"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "seg",
						children: [
							"dawn",
							"day",
							"night"
						].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: start === id ? "on" : "",
							onClick: () => setStart(id),
							children: id === "dawn" ? "Şafak" : id === "day" ? "Gündüz" : "Gece"
						}, id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "check",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: bonus,
							onChange: (e) => setBonus(e.target.checked)
						}), "Bonus sandık: tahta kazma, tahta ve pişmiş et"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "check",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: monsters,
							onChange: (e) => setMonsters(e.target.checked)
						}), "Canavarlar çıksın"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn-primary",
						onClick: () => {
							onPlay(createWorld({
								name,
								seed: parseSeed(seedText),
								start,
								bonus,
								monsters
							}));
						},
						children: "Dünyayı oluştur"
					})
				] }) : null,
				view === "look" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "menu-back",
						onClick: () => setView("home"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { size: 16 }), " Geri"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "title-kicker",
						children: "Karakter"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Görünüş" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "look-layout",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "look-stage",
							"aria-hidden": true,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
									className: "look-head",
									style: { background: hex(SKINS[look.skin] ?? SKINS[0]) }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
									className: "look-body",
									style: { background: hex(SHIRTS[look.shirt] ?? SHIRTS[0]) }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { background: hex(SKINS[look.skin] ?? SKINS[0]) } }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { background: hex(SKINS[look.skin] ?? SKINS[0]) } })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { background: hex(PANTS[look.pants] ?? PANTS[0]) } }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { background: hex(PANTS[look.pants] ?? PANTS[0]) } })] })
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "field-label",
								children: "Ten"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "swatches",
								children: SKINS.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: look.skin === i ? "on" : "",
									style: { background: hex(c) },
									"aria-label": `Ten ${i + 1}`,
									onClick: () => patchLook({
										...look,
										skin: i
									})
								}, c))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "field-label",
								children: "Gömlek"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "swatches",
								children: SHIRTS.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: look.shirt === i ? "on" : "",
									style: { background: hex(c) },
									"aria-label": `Gömlek ${i + 1}`,
									onClick: () => patchLook({
										...look,
										shirt: i
									})
								}, c))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "field-label",
								children: "Pantolon"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "swatches",
								children: PANTS.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: look.pants === i ? "on" : "",
									style: { background: hex(c) },
									"aria-label": `Pantolon ${i + 1}`,
									onClick: () => patchLook({
										...look,
										pants: i
									})
								}, c))
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "title-lead",
						children: "Bu görünüş bütün dünyalarda, üçüncü şahısta kullanılır."
					})
				] }) : null
			]
		})
	});
}
function GameApp() {
	const canvasRef = (0, import_react.useRef)(null);
	const engineRef = (0, import_react.useRef)(null);
	const [icons, setIcons] = (0, import_react.useState)({});
	const [engineTick, setEngineTick] = (0, import_react.useState)(0);
	const phase = useGameStore((s) => s.phase);
	const loading = useGameStore((s) => s.loading);
	const clickToPlay = useGameStore((s) => s.clickToPlay);
	const isMobile = useGameStore((s) => s.isMobile);
	const loadError = useGameStore((s) => s.loadError);
	const setPhase = useGameStore((s) => s.setPhase);
	const setMobile = useGameStore((s) => s.setMobile);
	const setClickToPlay = useGameStore((s) => s.setClickToPlay);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(pointer: coarse), (max-width: 700px)");
		const sync = () => setMobile(mq.matches);
		sync();
		mq.addEventListener("change", sync);
		return () => mq.removeEventListener("change", sync);
	}, [setMobile]);
	const boot = (0, import_react.useCallback)(async (id) => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		engineRef.current?.dispose();
		engineRef.current = null;
		useGameStore.getState().resetHud();
		useGameStore.getState().setLoadError(null);
		setPhase("loading");
		setClickToPlay(false);
		const engine = new GameEngine(canvas);
		engineRef.current = engine;
		window.__blokEngine = engine;
		try {
			await engine.init({ id });
			engine.audio.setVolume(useGameStore.getState().settings.volume);
			setIcons(engine.iconsMap());
			engine.start();
			setEngineTick((n) => n + 1);
			setPhase("playing");
			setClickToPlay(true);
		} catch (err) {
			const msg = err instanceof Error ? err.message : "Dünya yüklenemedi";
			useGameStore.getState().setLoadError(msg);
			setPhase("title");
		}
	}, [setPhase, setClickToPlay]);
	(0, import_react.useEffect)(() => {
		return () => {
			engineRef.current?.dispose();
			engineRef.current = null;
		};
	}, []);
	const closeOverlay = (0, import_react.useCallback)(() => {
		if (useGameStore.getState().phase === "crafting") engineRef.current?.dumpCraftBack();
		setPhase("playing");
		if (useGameStore.getState().isMobile) setClickToPlay(false);
		else engineRef.current?.requestLock();
	}, [setPhase, setClickToPlay]);
	const openCraft = (0, import_react.useCallback)(() => {
		document.exitPointerLock?.();
		setPhase("crafting");
	}, [setPhase]);
	(0, import_react.useEffect)(() => {
		const craftKey = (code) => code === "Period" || code === "NumpadDecimal" || code === "Slash";
		let relockOnUp = false;
		const onKey = (e) => {
			const st = useGameStore.getState();
			if (st.phase === "title" || st.phase === "loading" || st.phase === "credits") return;
			if (craftKey(e.code)) {
				if (e.repeat) return;
				e.preventDefault();
				if (st.phase === "crafting") {
					relockOnUp = true;
					closeOverlay();
				} else if (st.phase === "playing" || st.phase === "inventory" || st.phase === "furnace") {
					document.exitPointerLock?.();
					setClickToPlay(false);
					setPhase("crafting");
				}
				return;
			}
			if (e.code === "Escape") {
				e.preventDefault();
				if (useGameStore.getState().hud.sleeping) {
					engineRef.current?.wake();
					relockOnUp = true;
					engineRef.current?.requestLock();
					return;
				}
				if (st.phase === "inventory" || st.phase === "crafting" || st.phase === "furnace") {
					relockOnUp = true;
					closeOverlay();
					return;
				}
				if (st.phase === "paused") {
					setPhase("playing");
					relockOnUp = true;
					engineRef.current?.requestLock();
					return;
				}
				document.exitPointerLock?.();
				setPhase("paused");
				engineRef.current?.save();
				return;
			}
			if (e.code === "KeyE") {
				e.preventDefault();
				if (st.phase === "inventory" || st.phase === "crafting" || st.phase === "furnace") {
					relockOnUp = true;
					closeOverlay();
				} else if (st.phase === "playing") {
					document.exitPointerLock?.();
					setClickToPlay(false);
					setPhase("inventory");
				}
			}
		};
		const onUp = (e) => {
			if (!relockOnUp) return;
			if (e.code !== "Escape" && e.code !== "KeyE" && !craftKey(e.code)) return;
			relockOnUp = false;
			const st = useGameStore.getState();
			if (st.phase === "playing" && !st.isMobile) engineRef.current?.requestLock();
		};
		window.addEventListener("keydown", onKey, true);
		window.addEventListener("keyup", onUp, true);
		return () => {
			window.removeEventListener("keydown", onKey, true);
			window.removeEventListener("keyup", onUp, true);
		};
	}, [
		setPhase,
		setClickToPlay,
		closeOverlay
	]);
	const onCanvasClick = () => {
		if (phase !== "playing") return;
		engineRef.current?.requestLock();
	};
	const quit = () => {
		engineRef.current?.save();
		engineRef.current?.dispose();
		engineRef.current = null;
		useGameStore.getState().resetHud();
		setPhase("title");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "game-shell",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "game-canvas",
				onClick: onCanvasClick,
				onContextMenu: (e) => e.preventDefault()
			}),
			phase === "credits" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Credits, {
				lines: engineRef.current?.creditsView().lines ?? ["Gezgin, End'in kapısından geçti."],
				shots: engineRef.current?.creditsView().shots ?? [],
				onBack: () => engineRef.current?.returnFromCredits()
			}) : null,
			phase === "title" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TitleScreen, { onPlay: (id) => void boot(id) }) : null,
			phase === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overlay-root load-overlay",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "title-panel",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "title-kicker",
							children: "Dünya"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Chunklar üretiliyor" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "load-bar",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { width: `${Math.round(loading * 100)}%` } })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "title-lead",
							children: [Math.round(loading * 100), "%"]
						})
					]
				})
			}) : null,
			loadError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overlay-root",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "title-panel",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Yükleme hatası" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "title-lead",
						children: loadError
					})]
				})
			}) : null,
			phase === "playing" && clickToPlay ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "click-play",
				onClick: onCanvasClick,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isMobile ? "Dokun ve oyna" : "Tıkla ve oyna" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "WASD yürü · Space zıpla · Shift eğil · . yapım" })]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HUD, {
				icons,
				onCraft: openCraft,
				onWake: () => {
					engineRef.current?.wake();
					engineRef.current?.requestLock();
				}
			}),
			phase === "paused" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PauseMenu, {
				engine: engineRef.current,
				onResume: () => {
					setPhase("playing");
					engineRef.current?.requestLock();
				},
				onQuit: quit
			}) : null,
			phase === "inventory" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inventory, {
				engine: engineRef.current,
				icons
			}) : null,
			phase === "crafting" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crafting, {
				engine: engineRef.current,
				icons
			}) : null,
			phase === "furnace" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Furnace, {
				engine: engineRef.current,
				icons
			}) : null,
			isMobile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileControls, {
				engine: engineRef.current,
				onPause: () => {
					document.exitPointerLock?.();
					setPhase("paused");
				},
				onInventory: () => {
					if (phase === "inventory") {
						setPhase("playing");
						setClickToPlay(false);
					} else {
						setPhase("inventory");
						setClickToPlay(false);
					}
				},
				onCraft: () => {
					if (phase === "crafting") closeOverlay();
					else openCraft();
				}
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: engineTick
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {});
}
//#endregion
export { Home as component };
