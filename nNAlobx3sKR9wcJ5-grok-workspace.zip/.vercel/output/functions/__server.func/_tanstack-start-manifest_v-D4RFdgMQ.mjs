//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D4RFdgMQ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CR96DaA4.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CR96DaA4.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BUVto1C4.js"]
	}
} });
//#endregion
export { tsrStartManifest };
