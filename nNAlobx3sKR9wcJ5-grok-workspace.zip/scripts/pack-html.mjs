import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";

const root = "/workspace";
const staticDir = join(root, ".vercel/output/static");
const assets = join(staticDir, "assets");
const indexName = "index-CR96DaA4.js";
const routesName = "routes-BUVto1C4.js";
const cssName = "styles-BFoaEMqI.css";

let index = readFileSync(join(assets, indexName), "utf8");
let routes = readFileSync(join(assets, routesName), "utf8");
const css = readFileSync(join(assets, cssName), "utf8");

function dataUrl(file, mime) {
  const b64 = readFileSync(file).toString("base64");
  return `data:${mime};base64,${b64}`;
}

const files = {
  "/textures/grass.png": dataUrl(join(staticDir, "textures/grass.png"), "image/png"),
  "/textures/stone.png": dataUrl(join(staticDir, "textures/stone.png"), "image/png"),
  "/textures/wood.png": dataUrl(join(staticDir, "textures/wood.png"), "image/png"),
  "/textures/leaves.png": dataUrl(join(staticDir, "textures/leaves.png"), "image/png"),
  "/textures/coal.png": dataUrl(join(staticDir, "textures/coal.png"), "image/png"),
  "/textures/gold.png": dataUrl(join(staticDir, "textures/gold.png"), "image/png"),
  "/textures/diamond.png": dataUrl(join(staticDir, "textures/diamond.png"), "image/png"),
  "/models/end-frame.gltf": dataUrl(join(staticDir, "models/end-frame.gltf"), "model/gltf+json"),
  "/models/steve.gltf": dataUrl(join(staticDir, "models/steve.gltf"), "model/gltf+json"),
};

for (const src of [index, routes]) {
  for (const path of Object.keys(files)) {
    if (!src.includes(path)) console.warn("missing", path);
  }
}

function swap(code) {
  let out = code;
  for (const [path, url] of Object.entries(files)) out = out.split(path).join(url);
  return out;
}

index = swap(index);
routes = swap(routes);

const importLine = `import{i as e,n as t,r as n,t as r}from"./${indexName}";`;
if (!routes.includes(importLine)) throw new Error("routes import not found");
routes = routes.replace(importLine, "const{i:e,n:t,r:n,t:r}=window.__blok;");

const dyn = `import(\`./${routesName}\`)`;
if (!index.includes(dyn)) throw new Error("dynamic import not found");
index = index.replace(dyn, `import(__ROUTES_URL__)`);
const marker = `hydrateRoot)(document`;
if (!index.includes(marker)) throw new Error("hydrate marker not found");
index = index.replace(marker, `hydrateRoot)(document`);
index = index.replace(
  `(0,tv.hydrateRoot)(document`,
  `window.__blok={i:c,n:Ys,r:u,t:B};(0,tv.hydrateRoot)(document`,
);

const html = `<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
<title>Blokcraft</title>
<meta name="theme-color" content="#0e100c"/>
<style>${css}</style>
</head>
<body>
<script data-tsr-stream-part="">(self.$R=self.$R||{})["tsr"]=[];self.$_TSR={h(){this.hydrated=!0,this.c()},e(){this.streamEnded=!0,this.c()},c(){this.hydrated&&this.streamEnded&&(delete self.$_TSR,delete self.$R.tsr)},p(e){this.initialized?e():this.buffer.push(e)},buffer:[]};$_TSR.router=($R=>$R[0]={manifest:$R[1]={routes:$R[2]={__root__:$R[3]={preloads:$R[4]=[],scripts:$R[5]=[]},"/":$R[8]={preloads:$R[9]=[]}}},matches:$R[10]=[$R[11]={i:"__root__",u:1,s:"success",ssr:!0},$R[12]={i:"",u:1,s:"pending",ssr:!1}]})($R["tsr"]);$_TSR.e();</script>
<script type="module">
const routesUrl = URL.createObjectURL(new Blob([${JSON.stringify(routes)}], { type: "text/javascript" }));
const indexCode = ${JSON.stringify(index)}.replaceAll("__ROUTES_URL__", JSON.stringify(routesUrl));
await import(URL.createObjectURL(new Blob([indexCode], { type: "text/javascript" })));
</script>
</body>
</html>
`;

mkdirSync(join(root, "artifacts"), { recursive: true });
const out = join(root, "artifacts/Blokcraft.html");
writeFileSync(out, html);
console.log("wrote", out, html.length);
